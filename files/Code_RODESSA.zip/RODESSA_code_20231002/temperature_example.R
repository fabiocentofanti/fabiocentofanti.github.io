
## This script reproduces the example about temperature analysis 
## in passenger railway vehicles, in Section 5 of the paper.

rm(list = ls())
setwd(dirname(rstudioapi::getSourceEditorContext()$path))

library(forecast)
library(vars)
library(Rssa)
source("functions_RODESSA.R")

## Loading real data
load("Temperature.RData")
dim(temperature)
head(temperature)

## Setting parameters
p <- dim(temperature)[2]
N <- dim(temperature)[1]
( L <- round((N*p)/(p+1)) ) # 151
q <- 7

## RODESSA
# computing the tuning constants for RODESSA: 
tuning_const <- get_tuning_const(delta_c = 0.9, delta_r = 0.9, 
                                 N = N, L = L, p = p)
tuning_const$c_vec 
# 5.139479 4.000000

mod_rodessa <- RODESSA(temperature, q = q, L = L,
                       c_1 = tuning_const$c_vec[1], 
                       c_2 = tuning_const$c_vec[2])
# (takes a minute)
# [1] "Iteration 47  Obj =  2789.8032"
# [1] "Iteration 48  Obj =  2789.803"
# [1] "Iteration 49  Obj =  2789.8028"

mod_for <- forecast(mod_rodessa, 10) # compute forecasts
forecasts <- mod_for$forecasts
alpha <- 0.0027
q_c <- quantile(tuning_const$w_c_opt, alpha) 
# quantile to identify cellwise outliers
q_c # 0.2756692
q_r <- quantile(tuning_const$w_r_opt, alpha) 
# quantile to identify casewise outliers
q_r # 0.7684598

## Defining the x-axis labels
orario <- seq(ISOdatetime(2001,2,3,10,0,0), 
              ISOdatetime(2001,2,3,22,0,0),
              by=(60*60*2))
orario <- format(as.POSIXct(orario), format = "%H:%M")

## Enhanced time series plot 
pdf(file = "temperature_enhanced_ts_plot.pdf", 
    width = 13, height = 10)
par(mar = c(5,5,5,2)+0.1)
par(mgp = c(3, 1, 0))
enhanced_ts_plot(mod_rodessa = mod_rodessa, q_c = q_c, 
                 q_r = q_r, xaxis_lab=orario, lwd=4,
                 cex.axis=1.5, cex.lab=1.8, cex.main=2)
dev.off()

##############################################################


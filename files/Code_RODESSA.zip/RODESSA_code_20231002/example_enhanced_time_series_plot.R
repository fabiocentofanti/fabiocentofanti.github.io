
## This script illustrates the enhanced time series plot.

rm(list = ls())
setwd(dirname(rstudioapi::getSourceEditorContext()$path))

library(forecast)
library(vars)
library(Rssa)
source("functions_RODESSA.R")

## Setting the parameters
p <- 4  # dimension of the multivariate time series
N <- 70 # number of timepoints
L <- round((N*p)/(p+1)) # window length
q <- 2  # the rank of the approximation

## Generating the data
scenario <- "S3"
type_out <- "casewise"
sigma <- 20
per_out <- 0.1
set.seed(12)
ser <- simulate_mdata(N, sigma = sigma, scenario=scenario) 
# generates clean data
ser_con <- contaminte_ser(ser, type_out, 3*sigma, per_out) 
# contaminates the data 

## RODESSA
# computing the tuning constants for RODESSA: 
tuning_const <- get_tuning_const(delta_c = 0.9, delta_r = 0.9, 
                                 N = N, L = L, p = p)
tuning_const$c_vec
# 5.134669 4.000000 
mod_rodessa <- RODESSA(ser_con, q = q, L = L,
                       c_1 = tuning_const$c_vec[1], 
                       c_2 = tuning_const$c_vec[2])
# [1] "Iteration 0  Obj =  418595.2852"
# [1] "Iteration 1  Obj =  406625.7367"
# [1] "Iteration 2  Obj =  405450.6475"
# [1] "Iteration 3  Obj =  405324.4963"
# [1] "Iteration 4  Obj =  405310.0263"
# [1] "Iteration 5  Obj =  405308.3364"
# [1] "Iteration 6  Obj =  405308.1373"
# [1] "Iteration 7  Obj =  405308.1137"
# [1] "Iteration 8  Obj =  405308.1109"
# [1] "Iteration 9  Obj =  405308.1105"
# [1] "Iteration 10 Obj =  405308.1105"

mod_for <- forecast(mod_rodessa, 10) # compute forecasts
forecasts <- mod_for$forecasts
alpha <- 0.0027
q_c <- quantile(tuning_const$w_c_opt, alpha) 
# quantile to identify cellwise outliers
q_c # 0.2773745
q_r <- quantile(tuning_const$w_r_opt, alpha) 
# quantile to identify casewise outliers
q_r # 0.7401757

## Enhanced time series plot 
pdf(file="Enhanced_ts_plot.pdf",width=8,height=8)
enhanced_ts_plot(mod_rodessa = mod_rodessa, 
                 q_c = q_c, q_r = q_r)
dev.off()

## Enhanced time series plot with forecasts
pdf(file="Enhanced_ts_plot_with_forecast.pdf",width=8,height=8)
enhanced_ts_plot(mod_rodessa = mod_rodessa, 
                 forecasts = forecasts, 
                 q_c = q_c, q_r = q_r)
dev.off()

### Test code for q=1:

q <- 1
mod_rodessa <- RODESSA(ser_con, q = q, L = L,
                       c_1 = tuning_const$c_vec[1], 
                       c_2 = tuning_const$c_vec[2])
# [1] "Iteration 107  Obj =  678413.4436"
# [1] "Iteration 108  Obj =  678413.4436"
# [1] "Iteration 109  Obj =  678413.4436"

mod_for <- forecast(mod_rodessa, 10) # compute forecasts
forecasts <- mod_for$forecasts
alpha <- 0.0027

## Enhanced time series plot 
pdf(file="Enhanced_ts_plot_rank_1.pdf",width=8,height=8)
enhanced_ts_plot(mod_rodessa = mod_rodessa, 
                 q_c = q_c, q_r = q_r)
dev.off()

## Enhanced time series plot with forecasts
pdf(file="Enhanced_ts_plot_rank_1_with_forecast.pdf",
width=8,height=8)
enhanced_ts_plot(mod_rodessa = mod_rodessa, 
                 forecasts = forecasts, 
                 q_c = q_c, q_r = q_r)
dev.off()

##############################################################

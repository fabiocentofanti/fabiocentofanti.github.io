
######################################################################
##                                                                   #
## Functions to compute RODESSA for multivariate SSA.                #
##                                                                   #
## This code contains all the functions required by Simulation_run.R #
## and Example_enhanced_ts_plot.R                                    #
##                                                                   #
######################################################################

### Generic functions

sHankel <- function(X, p, L) {
  # construct stacked Hankel matrix from a multivariate time series
  X_list <- lapply(1:p, function(ii) hankel(X[, ii], L=L))
  X_sHankel <- do.call(cbind, X_list)
  return(X_sHankel)
}

sHankel2ts <- function(X, p) {
  # construct multivariate time series from a stacked Hankel matrix
  Ku <- dim(X)[2]/p
  tser <- sapply(1:p, function(ii) hankel(X[, (1+Ku*(ii-1)):(Ku*ii)]))
  return(tser)
}

rho_bisq <- function(x, c) {
  # bisquare rho function
  return(sapply(x, function(t) {
      if (abs(t)<c)((c^2)/6)*(1-(1-(t/c)^2)^3) else ((c^2)/6)}))
}

weight_bisq <- function(x, c) {
  # bisquare weight function
  if (is.matrix(x))
      return(matrix(sapply(x, function(t){
        if (abs(t)<c) (1-(t/c)^2)^2 else 0}), 
                    dim(x)[1],dim(x)[2]))
  else
      return(sapply(x, function(t){
        if (abs((t))<c) (1-((t)/c)^2)^2 else 0}))
}


### Functions for the simulation study

simulate_mdata <- function(N, sigma = 0.5, scenario = "S1") {
  # Function for generating clean data from the simulation study
  p <- 4
  set.seed(1234)
  if (scenario == "S1") {
     f1 <- function(t) {
       20 * cos(2*pi * (t) / 10)
     }
     f2 <- function(t) {
       30 * cos(2*pi * (t) / 10)
     }
     f3 <- function(t) {
       40 * cos(2*pi * (t) / 10)
     }
     f4 <- function(t) {
       50 * cos(2*pi * (t) / 10)
     }
     s <- cbind(f1(1:N), f2(1:N), f3(1:N), f4(1:N))
  }
  if (scenario == "S2") {
     f1 <- function(t){
       35 * cos(2*pi * (t) / 10)
     }
     f2 <- function(t) {
       35 * cos(2*pi * (t) / 10 + pi / 5)
     }
     f3 <- function(t) {
       35 * cos(2*pi * (t) / 10)
     }
     f4 <- function(t) {
       35 * cos(2*pi * (t) / 10 + pi / 5)
     }
     s <- cbind(f1(1:N), f2(1:N), f3(1:N), f4(1:N))
  }
  if (scenario == "S3") {
     f1 <- function(t) {
       20 * cos(2*pi * (t) / 10)
     }
     f2 <- function(t) {
       30 * cos(2*pi * (t) / 10 + pi / 5)
     }
     f3 <- function(t) {
       40 * cos(2*pi * (t) / 10)
     }
     f4 <- function(t) {
       50 * cos(2*pi * (t) / 10 + pi / 5)
     }
     s <- cbind(f1(1:N), f2(1:N), f3(1:N), f4(1:N))
  }
  ts <- s + rnorm(N*p, sd = sigma)
  return(ts)
}

contaminte_ser <- function(ser, type = "cellwise", size, per_out = 0.1) {
  # Function for adding outliers to a clean time series.
  p <- dim(ser)[2]
  ser_con <- ser
  if (type == "cellwise") {
    ind <- sample(1:length(ser), per_out*length(ser))
    if (size != 0) {
       ser_con[ind] <- ser[ind] + rep(size, length(ind))
    }
  }
  if (type == "casewise") {
    ind <- sample(1:(length(ser)/p), per_out*(length(ser)/p))
    if (size != 0) {
       ser_con[ind, ] <- ser[ind, ] + rep(size, length(ind))
    }
  }
  return(ser_con)
}

get_scale <- function(X, Xfit, p, scale = "equal") {
  # Compute the scale_1 estimate for competing methods
  # and for initialisation of RODESSA.
  L <- dim(X)[1]
  Ku <- dim(X)[2]/p
  n_diag <- L+Ku-1
  Ri <- X-Xfit
  Ri_list <- lapply(1:p, function(ii) Ri[, (1+Ku*(ii-1)):(Ku*ii)])
  indxx <- row(Ri_list[[1]]) + col(Ri_list[[1]]) - 1
  ll_diag <- sapply(1:n_diag, function(ii) length(which(indxx == ii)))
  X_split_l <- lapply(1:p, function(ii) split(Ri_list[[ii]]^2, indxx))
  dres <- matrix(0, n_diag, p)
  for (gg in 1:p) {
    dres[, gg] <- sapply(1:n_diag, function(ii) 
      ((sum(X_split_l[[gg]][[ii]])))/(ll_diag[ii]))
    # computes the squared norms of the diagonal residuals
  } 
  if (scale == "equal") # calculate the biweight M-scale
    scale <- RobStatTM::scaleM(dres)
  else
    scale <- mean(apply(dres, 2, RobStatTM::scaleM))
  return(scale)
}
 
cal_a <- function(Ut) {
  # Compute coefficient vector a for forecasting
  Ps <- Ut[-dim(Ut)[1], , drop=F]
  pi_vec <- Ut[dim(Ut)[1], ]
  v2 <- sum(pi_vec^2)
  a <- apply(matrix(pi_vec, dim(Ps)[1], dim(Ps)[2], byrow = T)
             *Ps, 1, sum)/(1-v2)
  return(a)
}

rec_mfor <- function(Xfit, lag = 1, q, p) {
  # Compute recurrent forecasting
  L <- dim(Xfit)[1]    # nrow
  Ku <- dim(Xfit)[2]/p # ncol for 1 component
  modsvd <- svd(Xfit)
  UD <- (modsvd$u) %*% sqrt(diag(modsvd$d))[, 1:q]
  m <- qr.Q(qr(UD))
  sign_m <- sign(crossprod(m, UD)) * diag(1, ncol(m))
  a <- cal_a(m %*% sign_m)
  x_fit <- sapply(1:p, function(ii) 
    hankel(Xfit[, (1+Ku*(ii-1)):(Ku*ii)]))
  x_pred <- x_fit
  N <- dim(x_fit)[1]
  for (ii in 1:length(lag)) {
    x_ii <- x_pred[(N-L+1+lag[ii]-1+1):(N+lag[ii]-1), ]
    x_ii <- t(x_ii) %*% a
    x_pred <- rbind(x_pred, t(x_ii))
  }
  return(x_pred)
}

forecast <- function(mod, lag = 20) {
  # Compute fitted values and forecasts
  U <- mod$U
  V <- mod$V
  if(is.vector(mod$U)) U = matrix(U, ncol=1)
  if(is.vector(mod$V)) V = matrix(V, ncol=1)
  q <- dim(U)[2]
  p <- dim(mod$tser)[2]
  N <- dim(mod$tser)[1]
  Xfit <- U %*% t(V)
  fit <- sHankel2ts(Xfit,p)
  forecasts <- rec_mfor(Xfit = Xfit, lag = 1:lag, q = q, p = p)
  forecasts <- forecasts[(N+1):(N+lag), ]
  out <- list(fit = fit, forecasts = forecasts)
  return(out)
}

get_RE <- function(mod, scenario, N) {
  # Compute reconstruction error (RE)
  ser0 <- simulate_mdata(N, 0, scenario = scenario)
  return(mean(abs(mod$fit-ser0)^2))
}

get_FE <- function(mod, scenario, N, lag) {
  # Compute forecasting error (FE)
  ser0 <- simulate_mdata(N+lag, 0, scenario = scenario)
  return(mean((abs(mod$forecasts-ser0[(N+1):(N+lag), ])^2)))
}

### Functions to compute RODESSA

get_tuning_const <- function(delta_c = 0.9, delta_r = 0.9, 
                             N, L, p, rep = 10, scale = "equal", 
                             c_grid = seq(4, 6, length=500)){
  # Compute the tuning constants for RODESSA.
  # Arguments:
  # delta_c: target value \delta_c for the average of the weights w_c
  # delta_r: target value \delta_r for the average of the weights w_r
  # N: length of the time series
  # L: window length for SSA
  # p: number of components of the multivariate time series
  # rep: number of replications
  # scale: if "equal", the \sigma^2_{1,j} are assumed equal
  # c_grid: grid of tuning constants to try.
  c_mat <- matrix(0, rep, 2)
  w_c_opt <- w_r_opt <- numeric()
  set.seed(1) # to make this function reproducible
  for (iii in 1:rep) {
    ser_norm <- matrix(rnorm(N*p), N, p) # generate i.i.d. residuals 
    # following the standard normal distribution
    X_norm <- sHankel(ser_norm, p, L) # turn into stacked Hankel matrix
    Ku <- dim(X_norm)[2]/p
    K <- dim(X_norm)[2]
    n_diag <- L+Ku-1
    Ri <- X_norm
    Ri_list <- lapply(1:p, function(ii) Ri[, (1+Ku*(ii-1)):(Ku*ii)])
    indxx <- row(Ri_list[[1]]) + col(Ri_list[[1]]) - 1
    ll_diag <- sapply(1:n_diag, function(ii) length(which(indxx == ii)))
    X_split_l <- lapply(1:p, function(ii) split(Ri_list[[ii]]^2, indxx))
    dres <- matrix(0, n_diag, p)
    for (jj in 1:p) {
      dres[, jj] <- sapply(1:n_diag, function(ii) 
        ((sum(X_split_l[[jj]][[ii]])))/(ll_diag[ii]))
      # compute the squared norms of the diagonal residuals
      } 
    if (scale == "equal") # compute sigma_{1,j}^2
      scale_1 <- rep(RobStatTM::scaleM(dres), p)
    else
      scale_1 <- apply(dres, 2, RobStatTM::scaleM)
    # standardized squared norms of the diagonal residuals
    dres <- dres/matrix(scale_1, n_diag, p, byrow = T) 
    meanw_c <- numeric()
    w_c <- list()
    for (ii in 1:length(c_grid)) {
      w_c[[ii]] <- weight_bisq(sqrt(abs(dres)), c = c_grid[ii]) 
      # the cellwise weights w_c
      meanw_c[ii] <- mean(w_c[[ii]])
    }
    ind_min <- which.min(abs(meanw_c-delta_c))
    c_1_opt <- c_grid[ind_min]
    w_c_opt <- c(w_c_opt, w_c[[ind_min]])
    Ri2 <- rho_bisq(as.numeric(sqrt(dres)), c = c_1_opt)
    Ri3 <- matrix(Ri2, n_diag, p)*matrix(scale_1, n_diag, p, byrow = T)
    ores <- apply(Ri3, 1, sum) 
    # unstandardized overall squared norm of residuals
    scale_2 <- RobStatTM::scaleM(ores) # compute sigma_2^2
    ores <- ores/(scale_2) # standardized
    meanw_r <- numeric()
    w_r <- list()
    for (ii in 1:length(c_grid)) {
      w_r[[ii]] <- weight_bisq(sqrt(abs(ores)), c = c_grid[ii]) 
      # the casewise weights w_r
      meanw_r[ii] <- mean(w_r[[ii]])
    }
    ind_min <- which.min(abs(meanw_r-delta_r))
    c_2_opt <- c_grid[ind_min]
    w_r_opt <- c(w_r_opt, w_r[[ind_min]])
    c_mat[iii,] <- c(c_1_opt, c_2_opt)
  }
  c_vec <- apply(c_mat, 2, mean)
  out <- list(c_vec = c_vec,
              w_c_opt = w_c_opt,
              w_r_opt = w_r_opt)
  return(out)
}  

initialization <- function(tser, q, L){
  # Select the initial estimates of U and V to be used in RODESSA among: 
  # RLM (Rodrigues et al. 2018),
  # CHENG (Cheng et al. 2015), 
  # and CMSSA classical multivariate SSA.
  
  p <- dim(tser)[2]
  X <- sHankel(tser, p, L)
  Ku <- dim(X)[2]/p
  
  ## RLM (Rodrigues et al. 2018)
  mod_init_rlm <- get_initi_rlm(X, q)
  U0_rlm <- mod_init_rlm$U
  V0_rlm <- mod_init_rlm$V
  mod_rlm <- list(U = U0_rlm, V = V0_rlm, tser = tser)
  
  ## CHENG (Cheng et al. 2015)
  dd <- rpca::rpca(X) # Candes
  mod_init_cheng <- svd(dd$L)
  U0_cheng <- mod_init_cheng$u %*% sqrt(diag(mod_init_cheng$d))[, 1:q]
  V0_cheng <- mod_init_cheng$v %*% sqrt(diag(mod_init_cheng$d))[, 1:q]
  mod_cheng <- list(U = U0_cheng, V = V0_cheng, tser = tser)
  
  ## CMSSA classical multivariate SSA
  svd_mod <- svd(X)
  U0_CMSSA <- svd_mod$u %*% sqrt(diag(svd_mod$d))[, 1:q]
  V0_CMSSA <- svd_mod$v %*% sqrt(diag(svd_mod$d))[, 1:q]
  mod_CMSSA <- list(U = U0_CMSSA, V = V0_CMSSA, tser = tser)
  
  # Fitted stacked Hankel matrices
  Xfit_rlm <- U0_rlm %*% t(V0_rlm)
  Xfit_cheng <- U0_cheng %*% t(V0_cheng)
  Xfit_CMSSA <- U0_CMSSA %*% t(V0_CMSSA)
  
  ## scales corresponding to the fit
  scale_rlm <- get_scale(X, Xfit_rlm, p)
  scale_cheng <- get_scale(X, Xfit_cheng, p)
  scale_CMSSA <- get_scale(X, Xfit_CMSSA, p)
  
  # select the estimator with lowest scale
  ind_min_s <- which.min(c(scale_rlm, scale_cheng, scale_CMSSA)) 
  
  if (ind_min_s == 1) {
    U0 <- U0_rlm
    V0 <- V0_rlm
  }
  if (ind_min_s == 2) {
    U0 <- U0_cheng
    V0 <- V0_cheng
  }
  if (ind_min_s == 3) {
    U0 <- U0_CMSSA
    V0 <- V0_CMSSA
  }
  if(is.vector(U0)) U0 = matrix(U0, ncol=1)
  if(is.vector(V0)) V0 = matrix(V0, ncol=1)
  out <- list(U0 = U0,
              V0 = V0,
              estimator_list = list(mod_rlm = mod_rlm,
                                    mod_cheng = mod_cheng,
                                    mod_CMSSA = mod_CMSSA))
  return(out)
}

RODESSA <- function(tser, q, L, c_1 = 4, c_2 = 4, 
                    max_iter = 1000, nu = 1e-05, trace = T, 
                    scale = "equal", U0 = NULL, V0 = NULL) {
  # Compute the RODESSA estimator.
  # Arguments:
  # tser: the multivariate time series as an N by p matrix
  # q: the rank for SSA
  # L: window length for SSA
  # c_1: the tuning constant for \rho_1
  # c_2: the tuning constant for \rho_2
  # U0, V0: initial estimators, if null they are selected among
  #         three potential initial estimators
  # max_iter: maximum iterations of the IRLS algorithm
  # nu: tolerance of the IRLS algorithm (for stopping rule)
  # trace: if TRUE the value of the objective function at each 
  #        iteration is printed
  # scale: if "equal", the \sigma^2_{1,j} are assumed equal

  f_u <- function(U, V, Weightsmat, X, K, L) { # for rank > 1
    U_t <- t(U)
    V <- t(sapply(1:K, function(ii) 
      chol2inv(chol((U_t %*% (Weightsmat[, ii]*U)))) %*% U_t %*% 
        (Weightsmat[, ii]*X[, ii])))
    V_t <- t(V)
    U<-t(sapply(1:L, function(ii) 
      chol2inv(chol((V_t %*% (Weightsmat[ii, ]*V)))) %*% V_t %*% 
        (Weightsmat[ii, ]*X[ii, ])))
    out <- list(U, V)
    return(out)
  } 
  
  f_u1 <- function(U, V, Weightsmat, X, K, L){ # for rank 1
    V <- (sapply(1:K, function(ii) 
      solve(t(U) %*% diag(Weightsmat[, ii]) %*% U) %*% t(U) %*% 
        diag(Weightsmat[, ii]) %*% X[, ii]))
    U <- (sapply(1:L, function(ii)
      solve(t(V) %*% diag(Weightsmat[ii, ]) %*% V) %*% t(V) %*% 
        diag(Weightsmat[ii, ]) %*% X[ii, ]))
    if(is.vector(U)) U = matrix(U, ncol=1)
    if(is.vector(V)) V = matrix(V, ncol=1)    
    out <- list(U, V)
    return(out)
  } 
  
  normalV = function(U1,V1,q){ # normalizes V
    svdout <- svd(U1 %*% t(V1))
    U2 <- svdout$u %*% (diag(svdout$d))[, 1:q, drop=F]
    V2 <- svdout$v[, 1:q, drop=F]
    return(list(U2 = U2, V2 = V2))
  }

  # Here the main function starts
  if (is.null(U0)) {
    init_est <- initialization(tser, q, L)
    U <- init_est$U0
    V <- init_est$V0
  }
  else {
    U <- U0
    V <- V0
    init_est <- NULL
  }
  p <- dim(tser)[2]
  X <- sHankel(tser, p, L) 
  # turns the multivariate time series into a stacked Hankel matrix.
  Ku <- dim(X)[2]/p
  K <- dim(X)[2]
  n_diag <- L+Ku-1
  Xfit_old <- U %*% t(V)
  Ri <- X - Xfit_old
  X_list <- lapply(1:p, function(ii) X[, (1+Ku*(ii-1)):(Ku*ii)])
  Ri_list <- lapply(1:p, function(ii) Ri[,(1+Ku*(ii-1)):(Ku*ii)])
  indxx <- row(X_list[[1]]) + col(X_list[[1]]) - 1
  ll_diag <- sapply(1:n_diag, function(ii) length(which(indxx == ii)))
  X_split_l <- lapply(1:p, function(ii) split(Ri_list[[ii]]^2, indxx))
  dres <- matrix(0, n_diag, p)
  for (jj in 1:p) {
    dres[, jj] <- sapply(1:n_diag, function(ii) 
      ((sum(X_split_l[[jj]][[ii]])))/(ll_diag[ii]))
    # computes the squared norms of the diagonal residuals
  } 
  if (scale == "equal") # compute sigma_1^2
    scale_1 <- rep(RobStatTM::scaleM(dres), p)
  else
    scale_1 <- apply(dres, 2, RobStatTM::scaleM)
  # standardized squared norms of the diagonal residuals
  dres <- dres/matrix(scale_1, n_diag, p, byrow = T)
  weights_c <- sapply(1:p, function(ii) 
    weight_bisq(sqrt(abs(dres[, ii])), c = c_1))
  # = cellwise weights w_c
  Ri2 <- rho_bisq(as.numeric(sqrt(dres)), c = c_1)
  Ri3 <- matrix(Ri2, n_diag, p)*matrix(scale_1, n_diag, p, byrow = T)
  ores <- apply(Ri3, 1, sum)/p
  scale_2 <- RobStatTM::scaleM(ores) # compute sigma_2^2
  ores <- ores/scale_2
  weights_r <- weight_bisq(sqrt(abs(ores)), c = c_2) 
  # = casewise weights w_r
  Weightsmat <- lapply(1:p, function(ii) 
    hankel(weights_r*weights_c[, ii], L = L))
  Weightsmat <- do.call(cbind, Weightsmat) # matrix of weights
  
  if (q == 1) f_U <- f_u1 else f_U <- f_u
  obj_vec <- numeric()
  if (trace) {
    obj_vec[1] <- object_func(X = X, Xfit = Xfit_old, q = q, 
                              scale_1 = scale_1, scale_2 = scale_2,
                              p = p, c_1 = c_1, c_2 = c_2)
    print(paste("Iteration", 0," Obj = ", round(obj_vec[1], 4)))
  }
  
  ### IRLS loop
  diff <- Inf
  iter <- 1
  while (diff > nu & iter < max_iter) {
    normout = normalV(U, V, q)
    U = normout$U2 # scores
    V = normout$V2 # orthonormal loadings
    UV <- f_U(U, V, Weightsmat, X, K, L)
    U <- UV[[1]] # update U
    V <- UV[[2]] # update V
    Xfit <- U %*% t(V)
    Ri <- X - Xfit # compute new residuals
    Ri_list <- lapply(1:p, function(ii) Ri[, (1+Ku*(ii-1)):(Ku*ii)])
    X_split_l <- lapply(1:p, function(ii) split(Ri_list[[ii]]^2, indxx))
    for (jj in 1:p) {
      dres[, jj] <- sapply(1:n_diag, function(ii) 
        ((sum(X_split_l[[jj]][[ii]])))/(ll_diag[ii]*scale_1[jj])) 
      # = the diagonal residuals
    }
    weights_c <- sapply(1:p, function(ii) 
      weight_bisq(sqrt(abs(dres[, ii])), c = c_1)) 
    # = cellwise weights w_c
    Ri2 <- rho_bisq(sqrt(dres), c = c_1)
    Ri3 <- Ri2*matrix(scale_1, n_diag, p, byrow = T)
    ores <- apply(Ri3, 1, sum)/(p*scale_2)
    weights_r <- weight_bisq(sqrt(abs(ores)), c = c_2) 
    # = casewise weights w_r
    Weightsmat <- lapply(1:p, function(ii) 
      hankel(weights_r*weights_c[, ii], L = L))
    Weightsmat <- do.call(cbind, Weightsmat) # matrix of weights
    diff <- sqrt(sum((Xfit-Xfit_old)^2))/sqrt(sum((Xfit_old)^2))
    Xfit_old <- Xfit
    iter <- iter + 1
    if (trace) {
      obj_vec[iter] <- object_func(X = X, Xfit = Xfit, q = q, 
                                   scale_1 = scale_1, scale_2 = scale_2, 
                                   p = p, c_1 = c_1, c_2 = c_2)
      print(paste("Iteration", iter-1," Obj = ", round(obj_vec[iter], 4)))
    }
  }
  obj <- object_func(X = X, Xfit = Xfit, q = q, scale_1 = scale_1, 
                     scale_2 = scale_2, p = p, c_1 = c_1, c_2 = c_2) 
  # objective function at the optimum
  if(is.vector(U)) U = matrix(U, ncol=1)
  if(is.vector(V)) V = matrix(V, ncol=1)
  out <- list(U = U,
              V = V,
              scale_1 = scale_1,
              scale_2 = scale_2,
              weights_r = weights_r,
              weights_c = weights_c,
              Weightsmat = Weightsmat,
              dres = dres,
              ores = ores,
              obj = obj,
              init_est = init_est,
              tser = tser)
  return(out)
}

object_func <- function(X, Xfit, q, scale_1 = 1, scale_2 = 1, p, c_1, c_2){
  # The loss function of RODESSA.
  L <- dim(X)[1]
  Ku <- dim(X)[2]/p
  K <- dim(X)[2]
  n_diag <- L+Ku-1
  Ri <- X - Xfit # the actual residual R_{ij}
  X_list <- lapply(1:p, function(ii) X[, (1+Ku*(ii-1)):(Ku*ii)])
  Ri_list <- lapply(1:p, function(ii) Ri[, (1+Ku*(ii-1)):(Ku*ii)])
  indxx <- row(X_list[[1]]) + col(X_list[[1]]) - 1
  ll_diag <- sapply(1:n_diag, function(ii) length(which(indxx==ii)))
  X_split_l <- lapply(1:p, function(ii) split(Ri_list[[ii]]^2, indxx))
  dres <- matrix(0, n_diag, p)
  for (jj in 1:p) {
    dres[, jj] <- sapply(1:n_diag, function(ii)
      ((sum(X_split_l[[jj]][[ii]])))/(ll_diag[ii]*scale_1[jj]))
  }
  # dres (squared norm of _d_iagonal _res_iduals) is 
  # the argument of \rho_1 in the RODESSA objective.
  Ri2 <- rho_bisq(as.numeric(sqrt(dres)), c=c_1)
  # = the result of \rho_1(...)
  Ri3 <- matrix(Ri2, n_diag, p)*matrix(scale_1, n_diag, p, byrow = T)
  ores <- apply(Ri3, 1, sum) # adds it over the dimensions
  ores <- ores/(p*scale_2)
  d03 <- rho_bisq((as.numeric(sqrt(abs(ores)))), c = c_2)
  # = the result of \rho_2(...)
  out <- sum(d03*ll_diag*scale_2*p)
  return(out)
}

### RLM functions (Rodrigues et al. 2018)

alternate_regression <- function(R, u_0, max_iter = 30, nu = 10^-8) {
  # Compute alternating L1 regression given the initialization u_0
  # of the left singular vector.
  u <- u_0
  n <- dim(R)[1]
  p <- dim(R)[2]
  u_old <- u
  iter <- 0
  diff <- 1000
  while (diff > nu & iter < max_iter) {
    v <- sapply(1:p, function(ii) 
      matrixStats::weightedMedian(R[, ii]/u, w = abs(u), na.rm = T))
    u <- sapply(1:n, function(ii) 
      matrixStats::weightedMedian(R[ii, ]/v, w = abs(v), na.rm = T))
    diff <- sum(((u-u_old)/u_old)^2)
    u_old <- u
    iter <- iter+1
  }
  out <- list(u = u,
              v = v)
  return(out)
}

get_initi_rlm <- function(X, q, max_iter = 30) {
  # Compute the Rodrigues et al. (2018) estimator.
  # Arguments:
  # X: the stacked Hankel matrix
  # q: the rank
  # max_iter: the maximum number of iterations in the alternating 
  #           L1 regression.
  #
  # The left singular vector in the alternating L1 regression is 
  # initialized by considering the columns of X for the rank-one 
  # approximation and the columns of the residual matrix for the
  # others. 
  # Then, among all possible solutions (one for each different 
  # initialization), the one that provides the lowest residual 
  # robust scale is selected.
  n <- dim(X)[1]
  p <- dim(X)[2]
  U <- matrix(0, n, q)
  V <- matrix(0, p, q)
  R_new <- X
  ind <- 1:p
  for (ll in 1:q) {
    R <- R_new
    sigma_jj <- numeric()
    Upar <- matrix(0, n, max(ind))
    Vpar <- matrix(0, p, max(ind))
    for (jj in ind) {
      u_0 <- R[, jj] # select inital left singular vector
      mod <- alternate_regression(R, u_0 = u_0, max_iter = max_iter) 
      # Inner loop for the alternating L1 regression
      u <- Upar[, jj] <- mod$u
      v <- Vpar[, jj] <- mod$v
      sigma_jj[jj] <- RobStatTM::scaleM(R - u %*% t(v)) 
      # computes the robust residual scale for each initial estimator.  
    }
    ind_min <- which.min(sigma_jj) # select the solution corresponding 
                                   # to the lowest residual scale.
    U[, ll] <- Upar[, ind_min]
    V[, ll] <- Vpar[, ind_min]
    R_new <- R - U[, ll] %*% t(V[, ll])
  }
  out <- list(U = U,
              V = V)
  return(out)
}

### CS functions (Chen and Sacchi 2015)

CS <- function(tser, q, L, c = 4, max_iter = 1000, 
               nu = 10^-5, trace = T, U0 = NULL, V0 = NULL) {
  # Computes the Chen and Sacchi (2015) estimator.
  # Arguments:
  # tser: the multivariate time series as a matrix Nxp
  # q: the rank for SSA
  # L: window length for SSA
  # c: the tuning constant for \rho
  # max_iter: maximum iteration of the IRLS algorithm  
  # nu: tolerance of the IRLS algorithm
  # trace: if TRUE the value of the objective function at each 
  #        iteration is printed
  # U0, V0: initial estimators, if null they are selected among
  #         three potential initial estimators
  if (is.null(U0)) {
    init_est <- initialization(tser, q, L)
    U <- init_est$U0
    V <- init_est$V0
  }
  else {
    U <- U0
    V <- V0
    init_est <- NULL
  }
  X <- sHankel(tser, p, L) # turns the multivariate time series 
                           # into a stacked Hankel matrix.
  K <- dim(X)[2]
  Ri <- X - U %*% t(V) # compute residuals
  scale <- RobStatTM::scaleM(Ri)
  Weightsmat <- weight_bisq(Ri/scale, c=c) # computes weights
  Xfit_old <- U %*% t(V)
  obj_old <- 10000
  diff <- 100
  iter <- 1
  obj_vec <- numeric()
  if (trace) {
    obj_vec[1] <- object_func_CS(x = c(U,V), X = X, q = q, 
                                 scale = scale, c = c)
    print(paste("Iteration", 0," Obj = ", round(obj_vec[1], 4)))
  }
  while (diff > nu & iter < max_iter) {
    V <- t(sapply(1:K, function(ii)
      solve(t(U) %*% diag(Weightsmat[, ii]) %*% U) %*% t(U) %*% 
        diag(Weightsmat[, ii]) %*% X[, ii])) # update V
    U <- t(sapply(1:L, function(ii) 
      solve(t(V) %*% diag(Weightsmat[ii, ]) %*% V) %*% t(V) %*% 
        diag(Weightsmat[ii, ]) %*% X[ii,])) # update U
    Ri <- X - U %*% t(V) # compute residuals
    Weightsmat <- weight_bisq(Ri/scale, c = c) # computes weights
    Xfit <- U %*% t(V)
    diff <- sum(((Xfit-Xfit_old)/Xfit_old)^2)
    Xfit_old <- Xfit
    iter <- iter + 1
    if (trace) {
      obj_vec[iter] <- object_func_CS(x = c(U,V), X = X, q = q,
                                      scale = scale, c = c)
      print(paste("Iteration", iter-1," Obj = ", round(obj_vec[iter], 4)))
    }
    if (iter == max_iter) print("maximal number of iterations reached")
  }
  obj <- object_func_CS(x = c(U,V), X = X, q = q, scale = scale, c = c)
  out<-list(U = U,
            V = V,
            scale = scale,
            weights = Weightsmat,
            obj = obj,
            tser = tser)
  return(out)
}

object_func_CS <- function(x, X, q, scale = 1, c){
  # Computes loss function for CS.
  n <- dim(X)[1]
  p <- dim(X)[2]
  U <- matrix(x[1:(n*q)], n, q)
  V <- matrix(x[(n*q+1):(n*q+p*q)], p, q)
  Ri2 <- (X - U %*% t(V))/scale
  sum(rho_bisq(Ri2, c = c))
}

### Enhanced time series plot functions

enhanced_ts_plot <- function(mod_rodessa, forecasts = NULL, 
                             plot.type = c("multiple", "single"), 
                             xy.labels, xy.lines, panel = lines, nc, 
                             yax.flip = FALSE, q_c, q_r,
                             mar.multi = c(0, 5.1, 0, if 
                                           (yax.flip) 5.1 else 2.1), 
                             oma.multi = c(6,0, 5, 0), axes = TRUE, 
                             xaxis_lab=NULL,  ...) {
  main <- "Enhanced time series plot"
  col <- "gold2"
  fit <- forecast(mod_rodessa, 1)$fit
  x <- ts(mod_rodessa$tser)
  w_r <- mod_rodessa$weights_r
  w_c <- mod_rodessa$weights_c
  ind_out_c <- which((w_c) < q_c, arr.ind = T)
  ind_out_r <- which((w_r) < q_r, arr.ind = T)
  ind_pos <- lapply(1:dim(x)[2], function(ii) which(x[, ii] > fit[, ii]))
  ind_neg <- lapply(1:dim(x)[2], function(ii) which(x[, ii] < fit[, ii]))
  y <- NULL
  
  plotts <- function(x, y = NULL, fit = NULL, forec = NULL, 
                     forec_true = NULL, type_w ="ro",
                     plot.type = c("multiple", "single"), xy.labels, 
                     xy.lines, panel = lines, nc, xlabel, ylabel, 
                     type = "l", xlim = NULL, ylim = NULL, xlab = "Time", 
                     ylab, log = "", col = par("col"), bg = NA, 
                     pch = par("pch"), cex = par("cex"), lty = par("lty"), 
                     lwd = par("lwd"), axes = TRUE, frame.plot = axes, 
                     ann = par("ann"), cex.lab = par("cex.lab"), 
                     col.lab = par("col.lab"), font.lab = par("font.lab"), 
                     cex.axis = par("cex.axis"), col.axis = par("col.axis"), 
                     font.axis = par("font.axis"), main = NULL,
                     xaxis_lab=NULL,...) {
    plot.type <- match.arg(plot.type)
    nser <- NCOL(x)
    if (plot.type == "multiple" && nser > 1) {
      addmain <- function(main, cex.main = par("cex.main"), 
                          font.main = par("font.main"), 
                          col.main = par("col.main"), ...){
        mtext(main, side = 3, line = 3, cex = cex.main, 
              font = font.main, col = col.main, ...)}
      panel <- match.fun(panel)
      nser <- NCOL(x)
      if (!is.null(forec)) {
        rec_ind <- 1:dim(x)[1]
        pre_ind <- (dim(x)[1]+1):(dim(x)[1]+dim(forec)[1])
        fit <- rbind(fit, forec)
      }
      else {
        rec_ind <- 1:dim(x)[1]
        pre_ind <- dim(x)[1]
      }
      if (!is.null(forec_true)) {
        x_rec <- x;
        x_pred <- forec_true;
      }
      if (nser > 10) 
        stop("cannot plot more than 10 series as \"multiple\"")
      if (is.null(main)) 
        main <- xlabel
      nm <- paste("Series", 1L:nser)
      if (missing(nc)) 
        nc <- if (nser > 4) 
          2
      else 1
      nr <- nser
      oldpar <- par(mar = mar.multi, oma = oma.multi, mfcol = c(nr,1))
      on.exit(par(oldpar))
      if (is.null(xlim)) xlim <- c(0, max(pre_ind))
      if (is.null(ylim)) ylim <- range(c(x, forec_true))
      for (i in 1L:nser) {
        plot.default(x[, i], axes = FALSE, xlab = "", 
                     ylab = "", log = log, col = col, bg = bg, pch = pch, 
                     ann = ann, type = "n", ylim=ylim,xlim=xlim, ...)
        panel(x[, i], col = col, bg = bg, pch = pch, 
              cex = cex, lwd = lwd, lty = lty, type = type, 
              ...)
        if (!is.null(forec_true))
          lines(pre_ind, forec_true[, i], col = col, lwd = lwd)
        
        if (type_w == "tot") {
          col2pos <- sapply(1:length(c(w_tot[, i])), function(ll)
            adjustcolor("red", alpha.f = (0.82-c((w_tot[, i]))[ll])))
          col2neg <- sapply(1:length(c(w_tot[,i])), function(ll)
            adjustcolor("blue", alpha.f = (0.82-c((w_tot[, i]))[ll])))
        }
        else {
          col2pos <- sapply(1:length(c(w_c[, i])), function(ll)
            adjustcolor("red", alpha.f = (1.2-c((w_c[,i]))[ll])))
          col2neg <- sapply(1:length(c(w_c[, i])), function(ll)
            adjustcolor("blue", alpha.f = (1.2-c((w_c[,i]))[ll])))
          
          col2 <- col2pos
          col2[ind_neg[[i]]] <- col2neg[ind_neg[[i]]]
        }
        
        if (!is.null(fit)) col2 <- c(col2, rep(
          adjustcolor("black", alpha.f = 0.01), length(pre_ind)))
        points(x[, i], cex = 1.5, pch = 19, col = "white")
        points(x[, i], pch = 19, cex = 1.5, col = col2)
        points(x[, i], cex = 1.5)
        if (!is.null(forec_true))
          points(pre_ind, forec_true[, i], cex = 1.5, pch = 4)
        if (!is.null(fit)) {
          if (!is.null(forec)) {
            lines(rec_ind, fit[rec_ind, i], col = adjustcolor(
              "black", alpha.f = 1), lwd=1.5);
            lines(pre_ind, fit[pre_ind, i], col = adjustcolor(
              "darkolivegreen3", alpha.f = 1), lwd=2, lty=1)
            points(pre_ind, fit[pre_ind,i], col=adjustcolor(
              "darkolivegreen3", alpha.f = 1), cex=1.5, pch=2)
          }
          else
            lines(rec_ind, fit[rec_ind,i], col = "black", lwd = 1.5);
        }
        
        ur <- par("usr")[c(3, 4)]
        if (type_w == "ro") {
          if (length(which(ind_out_c[, 2]==i)) > 0) {
            ind_out_pos <- ind_pos[[i]][which(
              ind_pos[[i]]%in%ind_out_c[which(ind_out_c[, 2]==i), 1])]
            if (length(ind_out_pos) > 0)
              points(ind_out_pos, x[ind_out_pos, i],
                     pch = 15, col = 2, cex = 2)
            ind_out_neg <-ind_neg[[i]][which(
              ind_neg[[i]]%in%ind_out_c[which(ind_out_c[, 2]==i), 1])]
            if (length(ind_out_neg) > 0)
              points(ind_out_neg, x[ind_out_neg, i],
                     pch = 15, col = "Blue", cex = 2)
          }
          if (i %in% c((1:nc*nr)-nr+1)) {
            col3 <- sapply(1:length(c(w_r)), function(ll) adjustcolor(
              "black", alpha.f = (1-c((w_r))[ll])))
            
            par(xpd = NA)
            points(1:length(x[rec_ind, i]), rep(ur[2]+0.05*(ur[2]-ur[1]), 
                                                length(x[rec_ind, i])), 
                   pch = 19, cex = 1.5, col = col3)
            points(1:length(x[rec_ind, i]), rep(ur[2]+0.05*(ur[2]-ur[1]), 
                                                length(x[rec_ind, i])), 
                   cex = 1.5)
            if (length(ind_out_r) > 0)
              points(ind_out_r, rep(ur[2]+0.05*(ur[2]-ur[1]), 
                                    length(ind_out_r)), pch = 19, 
                     cex = 1.5, col = 1)
          }
          par(xpd = T)
          abline(v = ind_out_r, lty = 2, col = "grey")
        }
        if (frame.plot) 
          box(...)
        y.side <- if (i %% 2 || !yax.flip) 
          2
        else 4
        do.xax <- i %% nr == 0 || i == nser
        if (axes) {
          axis(y.side, xpd = NA, cex.axis = cex.axis, 
               col.axis = col.axis, font.axis = font.axis, 
               ...)
          if (do.xax)
            if(is.null(xaxis_lab)){
              axis(1, xpd = NA, cex.axis = cex.axis, col.axis = col.axis,
                   font.axis = font.axis, ...)}
          else{
            axis(1, at=seq(1,length(x[, i]),length.out=length(xaxis_lab)),
                 labels=xaxis_lab,xpd = NA, cex.axis = cex.axis,
                 col.axis = col.axis, font.axis = font.axis, ...)
          }
        }
        if (ann) {
          mtext(nm[i], y.side, line = 3, cex = cex.lab, 
                col = col.lab, font = font.lab, ...)
          if (do.xax) 
            mtext(xlab, side = 1, line = 3, cex = cex.lab, 
                  col = col.lab, font = font.lab, ...)
        }
      }
      
      if (ann && !is.null(main)) {
        par(mfcol = c(1, 1))
        addmain(main, ...)
      }
      return(invisible())
    }
    x <- as.ts(x)
    if (!is.null(y)) {
      y <- hasTsp(y)
      if (NCOL(x) > 1 || NCOL(y) > 1) 
        stop("scatter plots only for univariate time series")
      if (is.ts(x) && is.ts(y)) {
        xy <- ts.intersect(x, y)
        xy <- xy.coords(xy[, 1], xy[, 2], xlabel, ylabel, 
                        log)
      }
      else xy <- xy.coords(x, y, xlabel, ylabel, log)
      if (missing(xlab)) 
        xlab <- xy$xlab
      if (missing(ylab)) 
        ylab <- xy$ylab
      if (is.null(xlim)) 
        xlim <- range(xy$x[is.finite(xy$x)])
      if (is.null(ylim)) 
        ylim <- range(xy$y[is.finite(xy$y)])
      n <- length(xy$x)
      if (missing(xy.labels)) 
        xy.labels <- (n <= 150)
      do.lab <- if (is.logical(xy.labels)) 
        xy.labels
      else {
        if (!is.character(xy.labels)) 
          stop("'xy.labels' must be logical or character")
        TRUE
      }
      ptype <- if (do.lab) 
        "n"
      else if (missing(type)) 
        "p"
      else type
      dev.hold()
      on.exit(dev.flush())
      plot.default(xy, type = ptype, xlab = xlab, ylab = ylab, 
                   xlim = xlim, ylim = ylim, log = log, col = col, 
                   bg = bg, pch = pch, cex = cex, lty = lty, lwd = lwd, 
                   axes = axes, frame.plot = frame.plot, ann = ann, 
                   main = main, ...)
      if (missing(xy.lines)) 
        xy.lines <- do.lab
      if (do.lab) 
        text(xy, labels = if (is.character(xy.labels)) 
          xy.labels
          else if (all(tsp(x) == tsp(y))) 
            formatC(unclass(time(x)), width = 1)
          else seq_along(xy$x), col = col, cex = cex)
      if (xy.lines) 
        lines(xy, col = col, lty = lty, lwd = lwd, type = 
                if (do.lab) "c" else "l")
      return(invisible())
    }
    if (missing(ylab)) {
      ylab <- colnames(x)
      if (length(ylab) != 1L) 
        ylab <- xlabel
    }
    if (is.matrix(x)) {
      k <- ncol(x)
      tx <- time(x)
      xy <- xy.coords(x = matrix(rep.int(tx, k), ncol = k), 
                      y = x, log = log, setLab = FALSE)
      xy$x <- tx
    }
    else xy <- xy.coords(x, NULL, log = log, setLab = FALSE)
    if (is.null(xlim)) 
      xlim <- range(xy$x)
    if (is.null(ylim)) 
      ylim <- range(xy$y[is.finite(xy$y)])
    plot.new()
    plot.window(xlim, ylim, log, ...)
    if (is.matrix(x)) {
      for (i in seq_len(k)){
        lines.default(xy$x, x[, i], 
                      col = col[(i - 1L)%%length(col) + 1L], 
                      lty = lty[(i - 1L)%%length(lty) + 1L], 
                      lwd = lwd[(i - 1L)%%length(lwd) + 1L], 
                      bg  = bg[(i - 1L)%%length(bg) + 1L], 
                      pch = pch[(i - 1L)%%length(pch) + 1L], 
                      cex = cex[(i - 1L)%%length(cex) + 1L], 
                      type = type) }                                 
    }
    else {
      lines.default(xy$x, x, col = col[1L], bg = bg, lty = lty[1L], 
                    lwd = lwd[1L], pch = pch[1L], cex = cex[1L], 
                    type = type)
    }
    if (ann) 
      title(main = main, xlab = xlab, ylab = ylab, ...)
    if (axes) {
      axis(1, ...)
      axis(2, ...)
    }
    if (frame.plot) 
      box(...)
  }
  xlabel <- if (!missing(x)) 
    deparse1(substitute(x))
  ylabel <- if (!missing(y)) 
    deparse1(substitute(y))
  plotts(x = x, y = y, fit = fit, forec = forecasts, forec_true = NULL, 
         plot.type = plot.type, xy.labels = xy.labels, 
         xy.lines = xy.lines, panel = panel, nc = nc, xlabel = xlabel, 
         ylabel = ylabel, axes = axes, main=main, col=col, 
         xaxis_lab=xaxis_lab,...)
}


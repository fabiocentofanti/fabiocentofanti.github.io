
# This script provides reconstruction and forecasting errors for 
# the simulation in Scenario 3, for the casewise contamination 
# model and with contamination probability equal to 0.1. 

rm(list = ls())
setwd(dirname(rstudioapi::getSourceEditorContext()$path))

library(forecast)
library(vars)
library(Rssa)
source("functions_RODESSA.R")

## Setting the simulation parameters
N <- 70 # length of the time series
p <- 4  # number of time series components
( L <- round((N*p)/(p+1)) ) # 56, window length for SSA
q <- 2  # rank of SSA
N_run = 2 # = number of replications, set to 2 just for testing.
scenario <- "S3"
type_out <- "casewise"
sigma <- 20
epsilon <- 0.1 # contamination probability

tuning_const <- get_tuning_const(delta_c = 0.9, delta_r = 0.9, 
                                 N = N, L = L, p = p) 
# Computes the tuning constants for RODESSA. 
tuning_const$c_vec 
# 5.134669 4.000000 

# gamma_vec <- seq(0, 8, length.out = 9)
gamma_vec = c(0,5) # just for testing
method_names <-c("CMSSA", "CHENG", "RLM", "CS", "RODESSA")
RE_mat <- FE_mat <- matrix(0, length(gamma_vec), 5, 
                           dimnames = list(paste("gamma=", gamma_vec), 
                                           method_names))
set.seed(1) # needed to reproduce result
for (iiii in 1:length(gamma_vec)) {
  print(paste0("gamma=", gamma_vec[iiii]))
  func_par <- function(ll){
    # generate clean data:
    ser <- simulate_mdata(N, sigma = sigma, scenario = scenario) 
    # contaminate the data:
    ser_con <- contaminte_ser(ser, type_out, gamma_vec[iiii]*sigma, 
                              epsilon) 
  
    ## Calculate competing approaches and initial estimates:
    init_est <- initialization(ser_con, q, L)
  
    ## CMSSA classical multivariate SSA
    mod_CMSSA <- init_est$estimator_list$mod_CMSSA
      
    ## CHENG (Cheng et al. 2015)
    mod_cheng <- init_est$estimator_list$mod_cheng
    
    ## RLM (Rodrigues et al. 2018)
    mod_rlm <- init_est$estimator_list$mod_rlm

    ## CS (Chen and Sacchi 2015)
    mod_cs <- CS(ser_con, q = q, L = L, U0 = init_est$U0, 
                 V0 = init_est$V0, c = 4.3, trace = F)
    
    ## RODESSA
    mod_rodessa <- RODESSA(ser_con, q = q, L = L, 
                           U0 = init_est$U0, 
                           V0 = init_est$V0,
                           c_1=tuning_const$c_vec[1], 
                           c_2=tuning_const$c_vec[2],
                           trace = F)
    
    ## Calculate fitted values and forecasts
    lag <- 20
    mod_for_rlm     <- forecast(mod_rlm, lag = lag)
    mod_for_cheng   <- forecast(mod_cheng, lag = lag)
    mod_for_CMSSA   <- forecast(mod_CMSSA, lag = lag)
    mod_for_cs      <- forecast(mod_cs, lag = lag)
    mod_for_rodessa <- forecast(mod_rodessa, lag = lag)
    
    ## Calculate reconstruction errors (RE)
    RE_rlm     <- get_RE(mod_for_rlm, scenario, N)
    RE_cheng   <- get_RE(mod_for_cheng, scenario, N)
    RE_CMSSA   <- get_RE(mod_for_CMSSA, scenario, N)
    RE_cs      <- get_RE(mod_for_cs, scenario, N)
    RE_rodessa <- get_RE(mod_for_rodessa, scenario, N)
    RE         <- c(RE_CMSSA, RE_cheng, RE_rlm, RE_cs, RE_rodessa)
    
    ## Calculate forecasting errors (FE)
    FE_rlm     <- get_FE(mod_for_rlm, scenario, N, lag = lag)
    FE_cheng   <- get_FE(mod_for_cheng, scenario, N, lag = lag)
    FE_CMSSA   <- get_FE(mod_for_CMSSA, scenario, N, lag = lag)
    FE_cs      <- get_FE(mod_for_cs, scenario, N, lag = lag)
    FE_rodessa <- get_FE(mod_for_rodessa, scenario, N, lag = lag)
    FE         <- c(FE_CMSSA, FE_cheng, FE_rlm, FE_cs, FE_rodessa)
    
    out <- list(RE, FE)
    return(out)
  }
  
  mod_out <- parallel::mclapply(1:N_run, func_par, mc.cores = 1)
  ## If you have a UNIX system you may be able to use 
  ## parallelization, set mc.cores=parallel::detectCores()
  RE_iiii <- t(sapply(mod_out, "[[", 1))
  FE_iiii <- t(sapply(mod_out, "[[", 2))
  RE_mat[iiii, ] <- apply(RE_iiii, 2, median)
  FE_mat[iiii, ] <- apply(FE_iiii, 2, median)
}

## Print results

print(RE_mat)
#              CMSSA    CHENG      RLM       CS  RODESSA
# gamma= 0  30.84992 38.14926 26.82080 24.73194 23.23604
# gamma= 5 101.19364 66.08096 33.19453 32.13155 27.27621

print(FE_mat)
#              CMSSA     CHENG      RLM       CS  RODESSA
# gamma= 0  39.50927  52.94874 52.97331 31.02442 32.14612
# gamma= 5 208.03679 106.62316 35.88355 37.28729 36.35666

#########################################################

The folder contains the following R files:

The code functions_RODESSA.R contains all the functions 
required by the scripts below.

The script example_enhanced_time_series_plot.R produces 
an enhanced time series plot for a small artificial
dataset.

The file temperature.RData contains the 176 by 6 data 
matrix used in the real data example in Section 5, about 
temperature analysis in passenger railway vehicles.

The script temperature_example.R reproduces that
example and draws its enhanced time series plot.

The script simulation_run.R provides reconstruction and 
forecasting errors for the simulation in Scenario 3, 
for the casewise contamination model with contamination 
probability 0.1 (with a tiny number of replications for
illustration purposes).

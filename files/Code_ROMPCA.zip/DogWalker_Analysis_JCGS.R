# Analysis of Dog Walker

rm(list = ls()); 
setwd(dirname(rstudioapi::getSourceEditorContext()$path))

source("ROMPCA_Code_JCGS.R")
set.seed(1998)

# Preprocessing the data --------------------------------------------------
data(data_dogWalker)
X <- data_dogWalker

# down sampling the data
walker_images <- lapply(1:dim(X)[1], function(i) X[i, , , ])
target_dim <- c(72, 90)
walker_images_ds <- lapply(walker_images, downsample_image_decimation, target_dim = target_dim)
X <- abind::abind(walker_images_ds, along = 4)
dims <- dim(X) #; dims
X.cont <- X

# add some gittering for the scale
X.unf <- n_unfold(X, 4)
X.git <- add.git(X.unf)

tnsr <- as.tensor(X.cont); num_modes <- tnsr@num_modes; dimension <- tnsr@modes
L <- (num_modes - 1); N <- tail(dimension, 1)

# Dog Walker analysis -----------------------------------------------------
dime <- c(dimension[-num_modes], 1000)
b <- 1.5
# get_tuning_const_tanh(dime, b, 1)
par.r <- c(0.6919393, 0.6981706, 8.7418434, 4.3859319)

# Choose ranks
ROMPCA(X = X.cont, X.git = X.git, cent = T)

# ROMPCA
ranks <- c(1, 1, 1)
ROMPCA.out.dog <- ROMPCA(
  X = X.cont,
  ranks = ranks,
  X.git = X.git,
  tpar = par.r,
  cut_out = FALSE
)

# Apply classical MPCA ----------------------------------------------------
MPCA.out.dog <- MPCA(X.cont, ranks = c(9, 9, 1), tol = 1e-05)

# Tensor unfolding ------------------------------------------------------------
Dog_data <- X.cont
DDC.out <- ROMPCA.out.dog$DDC.MPCA.init$ddc.out
DDC_unf <- cellWise::DDC(rTensor::unfold(
  as.tensor(X.git),
  row_idx = 4,
  col_idx = c(3, 1, 2)
)@data)

R.full.std <- ROMPCA.out.dog$R.std
ROMPCA.std.unf <- rTensor::unfold(as.tensor(R.full.std),
                                  row_idx = 4,
                                  col_idx = c(3, 1, 2))

# Reconstructed frames ----------------------------------------------------
frame.choice <- c(10, 11, 19, 25)
Orig.frame <- lapply(frame.choice, function(i) {
  grid::rasterGrob(Dog_data[, , , i])
})

ROMCPA.frame <- lapply(frame.choice, function(i) {
  img.fit <-  ROMPCA.out.dog$Xhat.decenter[, , , i]@data
  img.fit <- img.fit / max(img.fit)
  grid::rasterGrob(img.fit)
})

# figure 10
all_frames_rompca <- c(Orig.frame, ROMCPA.frame)
gridExtra::grid.arrange(
  grobs = all_frames_rompca,
  ncol = length(frame.choice),
  nrow = 2,
  clip = TRUE
)

pdf("DogWalker_ReconsFrames_Comp.pdf", width = 4.5, height = 1.8)
gridExtra::grid.arrange(
  grobs = all_frames_rompca,
  ncol = length(frame.choice),
  nrow = 2,
  clip = TRUE
)
dev.off()

# figure S.8
MCPA.frame <- lapply(frame.choice, function(i) {
  img.fit <-  MPCA.out.dog$Xhat.decenter[, , , i]@data
  img.fit <- img.fit / max(img.fit)
  grid::rasterGrob(img.fit)
})

all_frames_mpca <- c(Orig.frame, MCPA.frame)
gridExtra::grid.arrange(
  grobs = all_frames_mpca,
  ncol = length(frame.choice),
  nrow = 2,
  clip = TRUE
)

pdf("DogWalker_ReconsFrames_Comp_MPCA.pdf", width = 4.5, height = 1.8)
gridExtra::grid.arrange(
  grobs = all_frames_mpca,
  ncol = length(frame.choice),
  nrow = 2,
  clip = TRUE
)
dev.off()

# Unfolded residuals ------------------------------------------------------
# figure S.9
cellMap_new(
  R = DDC_unf$stdResid,
  rowlabels =  rep("", N),
  columnblocklabels = rep("", floor(19440 / 100)),
  columnangle = 0,
  # adjustcolumnlabels = 1,
  darkestColor = 5,
  mTitle = " Residual cellmap",
  sizemain = 1.2,
  sizerowlabels = 0.8,
  sizetitles = 1.2,
  sizecolumnlabels = 0,
  rowtitle = "Cases",
  columntitle = "",
  ncolumnsinblock = 100,
  autolabel = FALSE,
  drawCircles = FALSE
) +
  theme(
    axis.title.x = element_blank(),
    panel.border = element_blank(),
    axis.text.x = element_blank(),
    plot.margin = unit(c(0, 0, 0, 0), "cm")
  )

ggsave(
  filename = "DogWalker_UnfResidualMap_DDC.pdf",
  device = "pdf",
  width = 7,
  height = 2,
  dpi = 400
)

# figure S.9
cellMap_new(
  R = ROMPCA.std.unf@data,
  rowlabels =  rep("", N),
  columnblocklabels = rep("", floor(19440 / 100)),
  columnangle = 0,
  adjustcolumnlabels = 0.5,
  darkestColor = 5,
  mTitle = " Residual cellmap",
  sizemain = 1.2,
  sizerowlabels = 0.8,
  sizetitles = 1.2,
  sizecolumnlabels = 0,
  rowtitle = "Cases",
  columntitle = NULL,
  ncolumnsinblock = 100,
  autolabel = FALSE,
  drawCircles = FALSE
) +
  theme(
    axis.title.x = element_blank(),
    panel.border = element_blank(),
    axis.text.x = element_blank(),
    plot.margin = unit(c(0, 0, 0, 0), "cm")
  )

ggsave(
  filename = "DogWalker_UnfResidualMap_ROMPCA.pdf",
  device = "pdf",
  width = 7,
  height = 2,
  dpi = 400
)

# Residuals per observation -----------------------------------------------
# figure 12
col <- 3
frame.choice <- c(1, 9, 19, 25)
ROMPCA.resmap <- lapply(frame.choice, function(i) {
  # img.fit <- cellWise::cellMap(
  img.fit <- cellMap_new(
    R = R.full.std[, , col, i],
    rowlabels =  rep("", 72),
    columnlabels = rep("", 90),
    columnangle = 0,
    adjustcolumnlabels = 0.5,
    darkestColor = 5,
    mTitle = paste("Residuals -", i),
    sizemain = 1,
    sizerowlabels = 0.8,
    sizetitles = 1,
    sizecolumnlabels = 0.8,
    rowtitle = NULL,
    columntitle = NULL,
    autolabel = FALSE,
    drawCircles = FALSE
  ) +
    theme(
      axis.title.x = element_blank(),
      panel.border = element_blank(),
      axis.text.x = element_blank(),
      plot.margin = unit(c(0, 0, 0, 0), "cm")
    )
  
  img.grob <- ggplotGrob(img.fit + theme(plot.margin = margin(0, 0, 0, 0, "cm")))
  img.grob
})

gridExtra::grid.arrange(
  grobs = ROMPCA.resmap,
  ncol = length(frame.choice),
  nrow = 1,
  clip = TRUE
)

pdf("DogWalker_ResidualMaps_ROMPCA.pdf", width = 8, height = 1.8)
gridExtra::grid.arrange(
  grobs = ROMPCA.resmap,
  ncol = length(frame.choice),
  nrow = 1,
  clip = TRUE
)
dev.off()

# Plot the scores from ROMPCA ---------------------------------------------
# figure 13
pdf("DogWalker_ScoresPlot_ROMPCA.pdf", width = 8, height = 4)
par(
  mar = c(2, 2.5, 2, 1) + 0.1,
  mgp = c(1, 0.1, 0),
  tck = -0.01,
  cex.axis = 0.9
) 
plot(ROMPCA.out.dog$U.tilde, pch = 19, xlab = "Frames", ylab = "Core tensor")
dev.off()

################################################################################
##                                                                             #
## Functions to perform ROMPCA.                                                #
##                                                                             #
################################################################################

# List of required CRAN packages -------------------------------------------

required_packages <- c("argparse", "rTensor", "Rcpp", "cellWise", 
                       "ggplot2", "RcppArmadillo", "devtools", "OmicsPLS",
                       "combinat", "fastmatrix","Matrix", "abind", "rrcov",
                       "robustbase", "scales", "reshape2", "RSpectra")

# Function to check and install missing CRAN packages
install_if_missing <- function(packages) {
  missing_packages <- packages[!(packages %in% installed.packages()[,"Package"])]
  if(length(missing_packages) > 0) {
    cat("\n Installing missing packages:", paste(missing_packages, collapse = ", "), "\n")
    install.packages(missing_packages, dependencies = TRUE)
  } else {
    cat("\n All required CRAN packages are already installed.\n")
  }
}

# Install required CRAN packages
install_if_missing(required_packages)

# Main functions ----------------------------------------------------------

DDC_MPCA <- function(X.cont, X.ddc = NULL, ranks, alpha = 0.75, tol = 1e-05, silent = FALSE, seed = 1998) {
  # Initialisation starting with DDC.
  #
  # Arguments:
  # X.cont: an P_1 x ... x P_L x N tensor.
  #         Current version takes up to L = 3.
  # X.ddc: an P_1 x ... x P_L x N  tensor used for DDC.
  # ranks: the number of ranks for every mode.
  # alpha: parameter for the proportion of observations retained after DDC.
  #        Depending on the value, there is a tradeoff between robustness
  #        and efficiency. Typically set to 0.75.
  # tol: tolerance of the IRLS algorithm (for stopping rule)
  # init: a list containing initial estimators for V, U and C.
  #       Typically NULL and computed internally.
  # seed: value that defines the random seed.
  # silent: whether the progress bar is outputted.
  
  set.seed(seed)
  dimension <- dim(X.cont)
  N <- tail(dimension, 1)
  num_modes <- length(dimension); L <- (num_modes - 1)
  
  #### Apply DDC ####
  if (is.null(X.ddc)){
    X.unf <- n_unfold(X.cont, num_modes)
    ddc.out <- cellWise::DDC(X.unf, DDCpars = list(silent = silent))
  } else {
    # this for real data application to avoid constant scale
    X.unf <- n_unfold(X.ddc, num_modes)
    ddc.out <- cellWise::DDC(X.unf, DDCpars = list(silent = silent))
  }
  
  #### construct weight tensor ####
  ind.case.ddc <- ddc.out$indrows
  indcell.out <- array(0, dim(X.unf))
  indcell.out[ddc.out$indcells] <- NA
  indcell.out <- n_fold(indcell.out, X.cont, N, n = num_modes)
  indcell.out <- which(is.na(indcell.out)) # for cellwise weight
  W.fixed <- array(1, dim(X.cont))
  
  if (L == 3) {
    W.fixed[indcell.out] <- 0
    if (length(which(is.na(X.cont))) != 0)  W.fixed[which(is.na(X.cont))] <- 0 # for NA
    if (length(ind.case.ddc) != 0) W.fixed[,,,ind.case.ddc] <- 0 # for casewise weight 
  } else {
    W.fixed[indcell.out] <- 0
    if (length(which(is.na(X.cont))) != 0)  W.fixed[which(is.na(X.cont))] <- 0
    if (length(ind.case.ddc) != 0) W.fixed[,, ind.case.ddc] <- 0
  }
  
  #### MPCA on the h=alpha*n observations with smallest number of cellwise outliers ####
  outl.obs <- array(rep(1, prod(dimension)), dimension)
  outl.obs <- n_unfold(outl.obs, num_modes)
  outl.obs[ddc.out$indcells] <- 0
  
  sorted_indices <- order(rowSums(outl.obs), decreasing = FALSE)
  sorted_indices <- setdiff(sorted_indices, ind.case.ddc) # to remove the observations considered as casewise by DDC
  
  reduced_indices <- sorted_indices[1:ceiling(alpha * N)]
  if ((length(ind.case.ddc)/N) > 0.5) {
    stop("Too many outlying cases are flagged by DDC")
  } else if((length(ind.case.ddc)/N) > 0.25) {
     reduced_indices <- sorted_indices
  }
  
  if (L == 3) {
    X_sorted_ddc <- n_fold(ddc.out$Ximp, X.cont, N, n = num_modes)
    X_sorted_ddc <- X_sorted_ddc[,,, reduced_indices] 
  } else {
    X_sorted_ddc <- n_fold(ddc.out$Ximp, X.cont, N, n = num_modes)
    X_sorted_ddc <- X_sorted_ddc[,, reduced_indices] 
  }
  
  MPCA.reduced <- MPCA(X_sorted_ddc, ranks, tol = tol, silent = silent)
  V_reduced <- MPCA.reduced$V
  Center_reduced <- MPCA.reduced$Center
  X.cont.cent <- tnsr_cent(as.tensor(X.cont), mean_tens = (Center_reduced))@data
  
  #### Reweighting step ####
  W.fixed.onlycell <- array(1, dim(X.cont))
  W.fixed.onlycell[indcell.out] <- 0
  if (length(which(is.na(X.cont))) != 0) {W.fixed.onlycell[which(is.na(X.cont))] <- 0} # for NA
  
  if (any(is.na(X.cont))) {
     U_ddc_list <- lapply(1:N, function(i)
       U_samp_NA(
         tens_s(as.tensor(X.cont.cent), i)@data,
         V_reduced,
         tens_s(as.tensor(W.fixed.onlycell), i)@data,
         ranks
       ))
  } else {
     U_ddc_list <- lapply(1:N, function(i)
       U_samp(
         tens_s(as.tensor(X.cont.cent), i)@data,
         V_reduced,
         tens_s(as.tensor(W.fixed.onlycell), i)@data,
         ranks
       ))
  }
  
  U_ddc <- abind::abind(U_ddc_list, along = num_modes)
  Xhat.ddc <- ttl(as.tensor(U_ddc), V_reduced, ms = 1:L)
  Xhat.decenter.ddc <- tnsr_cent(Xhat.ddc, mean_tens = (-Center_reduced))
  
  #### Results ####
  res <- list(
    U.tilde = U_ddc,
    V = V_reduced,
    Center = Center_reduced,
    Xhat = Xhat.ddc@data,
    Xhat.decenter = Xhat.decenter.ddc,
    ddc.out = ddc.out
  )
  return(res)
}

MPCA <- function(X, ranks, max_itr = 100, tol = 1e-05, init = NULL, silent = FALSE){
  # classical MPCA using the IRLS algorithm.
  #
  # Arguments:
  # X: an P_1 x ... x P_L x N  tensor.
  #    Current version takes up to L = 3.
  # ranks: the number of ranks for every mode.
  # max_itr: maximum number of iterations.
  # tol: tolerance of the IRLS algorithm (for stopping rule)
  # init: a list containing initial estimators for V, U and C.
  #       Typically NULL and computed internally.
  # silent: whether the progress bar is outputted.
  
  tnsr <- as.tensor(X)
  num_modes <- tnsr@num_modes
  L <- (num_modes - 1)
  modes <- tnsr@modes
  X <- tnsr@data
  P <- dim(X)
  
  #### Initialisation with classical MPCA ####
  # Get the mean tensor
  C <- array(0, P[-num_modes])
  
  for (i in 1:P[num_modes]) {
    C <- C + tens_s(as.tensor(X), i)@data
  }
  
  C <- C / P[num_modes]
  Xt <- tnsr_cent(as.tensor(X), mean_tens = (C))@data
  
  if (is.null(init)) {
    # MPCA
    V_list <- vector("list", L)
    
    for (i in 1:L) {
      Xn <- n_unfold(Xt, n = i)
      Xn.decomp <- RSpectra::eigs_sym(tcrossprod(Xn, Xn), k = ranks[i])
      V_list[[i]] <- as.matrix(Xn.decomp$vectors)
    }
  } else {
    Cent <- init$Center
    Xt <- tnsr_cent(as.tensor(X), mean_tens = (Cent))@data
    V_list <- init$V
  }
  
  itr <- 0
  U <- ttl(as.tensor(Xt), lapply(V_list, t), ms = 1:(num_modes - 1))
  Xhat <- ttl(U, V_list, ms = 1:(num_modes - 1))
  
  # Initialize the weights
  W <- array(1, dim(Xt))
  fnorm.U <- sapply(1:tail(dim(Xt), 1), function(i) {
    frobnorm(tens_s(U@data, i))
  })
  E <- sum(fnorm.U^2)
  
  EE <- matrix(c(0, E), nrow = 1)
  U <- U@data
  
  #### Main part ####
  converged <- FALSE
  if (silent == FALSE) {
    pb <- txtProgressBar(min = 0, max = max_itr, style = 3)
  }
  
  while ((itr < max_itr)) {
    
    if (silent == FALSE) {
      setTxtProgressBar(pb, itr)
    }
    itr <- itr + 1
    ## U update
    V_list <- Get_V(Xt, V_list, U, W)
    
    ## Core tensor update
    U <- ttl(as.tensor(Xt), lapply(V_list, t), ms = 1:(num_modes - 1))@data
    Xhat <- ttl(as.tensor(U), V_list, ms = 1:(num_modes - 1))
    
    ## Center update
    Nu <- array(0, P[-num_modes])
    De <- array(0, P[-num_modes])
    
    for (i in 1:P[num_modes]) {
      Nu <- Nu + ((tens_s(as.tensor(X), i)@data - tens_s(Xhat, i)@data) * tens_s(as.tensor(W), i)@data)
      De <- De + tens_s(as.tensor(W), i)@data
    }
    
    C <- Nu / De
    Xt <- tnsr_cent(as.tensor(X), mean_tens = (C))@data
    
    ## Convergence
    fnorm.U <- sapply(1:tail(dim(Xt), 1), function(i) {
      frobnorm(tens_s(U, i))
    })
    
    ssDe <- sum(fnorm.U^2)
    EE <- rbind(EE, c(itr, ssDe))
    if (abs(ssDe - E)/E < tol) {
      converged <- TRUE
      if (silent == FALSE) {
        setTxtProgressBar(pb, max_itr)
      }
      break
    }
    
    if (itr == max_itr && silent == FALSE) {
      setTxtProgressBar(pb, max_itr)
    }
    
    E <- ssDe
  }
  
  if (silent == FALSE) {
    close(pb)
  }
  
  #### Result ####
  res <- list()
  res$X <- X
  res$X.tilde <- Xt
  res$U.tilde <- U
  res$V <- V_list
  res$Xhat.decenter <- tnsr_cent(Xhat, mean_tens = (-C))
  res$Xhat <- Xhat@data
  res$Center <- C
  res$W <- W
  res$loss <- EE
  res$itr <- itr
  res$converged <- converged
  
  return(res)
}

L1_MPCA <- function(X, ranks, init = NULL, max_itr = 100, scale, tol = 1e-05, delta = 1e-05, silent = FALSE) {
  # second initialization of ROMPCA.
  #
  # Arguments:
  # X: an P_1 x ... x P_L x N tensor.
  #    Current version takes up to L = 3.
  # ranks: the number of ranks for every mode.
  # tol: tolerance of the IRLS algorithm (for stopping rule).
  # max_itr: maximum number of iterations.
  # init: a list containing initial estimators for V, U and C.
  # scale: scale computed on the initialisation.
  # delta: parameters for the weights.
  # silent: whether the progress bar is outputted.
  
  tnsr <- as.tensor(X)
  num_modes <- tnsr@num_modes
  L <- (num_modes - 1)
  modes <- tnsr@modes
  X <- tnsr@data
  P <- dim(X)
  
  #### Extract initial estimates ####
  # You need to specify an initialization
  if (is.null(init)) {
    stop("Error: An initialization (init) must be specified.", call. = FALSE)
  }
  
  V_list <- init$V
  U <- as.tensor(init$U.tilde)
  Cent <- init$Center
  Xt <- tnsr_cent(as.tensor(X), mean_tens = (Cent))@data
  
  itr <- 0
  Xhat <- ttl(U, V_list, ms = 1:(num_modes - 1))
  
  #### Initialize weights and loss ####
  W <- L1_weights(Xt, Xhat@data, scale = scale, delta = delta)
  if (any(is.na(X))) {
    W[which(is.na(X))] <- 0
  }
  E <- sum(abs((Xt - Xhat@data)), na.rm = T)
  EE <- matrix(c(0, E), nrow = 1)
  U <- U@data
  
  #### Main part ####
  converged <- FALSE
  if (silent == FALSE) {
    pb <- txtProgressBar(min = 0, max = max_itr, style = 3)
  }
  while ((itr < max_itr)) {
    setTxtProgressBar(pb, itr)
    itr <- itr + 1
    
    ## U update
    if (any(is.na(X))) {
      V_list <- Get_V_NA(Xt, V_list, U, W) 
    } else {
      V_list <- Get_V(Xt, V_list, U, W)
    }
    
    ## Core tensor update
    if (any(is.na(X))) {
      U.list <-
        lapply(1:P[num_modes], function(i)
          U_samp_NA(
            tens_s(as.tensor(Xt), i)@data,
            V_list,
            tens_s(as.tensor(W), i)@data,
            ranks
          ))
    } else {
      U.list <-
        lapply(1:P[num_modes], function(i)
          U_samp(
            tens_s(as.tensor(Xt), i)@data,
            V_list,
            tens_s(as.tensor(W), i)@data,
            ranks
          ))
    }
    
    U <- abind::abind(U.list, along = num_modes)
    Xhat <- ttl(as.tensor(U), V_list, ms = 1:L)
    
    ## Center update
    Nu <- array(0, P[-num_modes])
    De <- array(0, P[-num_modes])
    
    if (any(is.na(X))) {
      for (i in 1:P[num_modes]) {
        D.miss <- (tens_s(as.tensor(X), i)@data - tens_s(Xhat, i)@data)
        D.miss[which(is.na(D.miss))] <- 0
        Nu <- Nu + (D.miss * tens_s(as.tensor(W), i)@data)
        De <- De + tens_s(as.tensor(W), i)@data
      }
      
    } else {
      for (i in 1:P[num_modes]) {
        Nu <-
          Nu + ((tens_s(as.tensor(X), i)@data - tens_s(Xhat, i)@data) * tens_s(as.tensor(W), i)@data)
        De <- De + tens_s(as.tensor(W), i)@data
      }
      
    }
    
    C <- Nu / De
    Xt <- tnsr_cent(as.tensor(X), mean_tens = (C))@data
    
    ## Weight update
    W <- L1_weights(Xt, Xhat@data, scale = scale, delta = delta)
    if (any(is.na(X))) {
      W[which(is.na(X))] <- 0
    }
    
    ## Convergence
    ssDe <- sum(abs((Xt - Xhat@data)), na.rm = T)
    EE <- rbind(EE, c(itr, ssDe))
    
    if (abs(ssDe - E)/E < tol) {
      converged <- TRUE
      if (silent == FALSE) {
        setTxtProgressBar(pb, max_itr)
      }
      break
    }
    
    if (itr == max_itr && silent == FALSE) {
      setTxtProgressBar(pb, max_itr)
    }
    
    E <- ssDe
  }
  
  if (silent == FALSE) {
    close(pb)
  }
  
  #### Result ####
  res <- list()
  res$X <- X
  res$X.tilde <- Xt
  res$U.tilde <- U
  res$V <- V_list
  res$Xhat.decenter <- tnsr_cent(Xhat, mean_tens = (-C))
  res$Xhat <- Xhat@data
  res$Center <- C
  res$W <- W
  res$loss <- EE
  res$itr <- itr
  res$converged <- converged
  return(res)
}

ROMPCA <- function(X, ranks = NULL, b = 1.5, max_itr = 100, X.git = NULL, tol = 1e-05, delta = 1e-05,
                   scale.case = NULL, scale.cell = NULL, init = NULL, cent = FALSE,
                   tpar = NULL, n.clean = 100, cut_out = FALSE, silent = FALSE){
  # Cellwise and casewise robust MPCA.
  #
  # Arguments:
  # X: an P_1 x ... x P_L x N tensor.
  #    Current version takes up to L = 3.
  # ranks: the number of ranks for every mode.
  #        If NULL then the algorithm stops by showing the eigenvalue
  #        cumulative plot. The user needs to choose the rank from this.
  # cent:  whether to compute the eigenvalue cumulative plot on the centered
  #        data.
  # X.git: an P_1 x ... x P_L x N tensor with gittering for DDC.
  # b_1: the tuning constant for rho_1.
  # tol: tolerance of the IRLS algorithm (for stopping rule).
  # max_itr: maximum number of iterations.
  # tpar: tuning parameter vector including b, c, q1, and q2 to tune rho_2.
  #       Can be NULL and computed internally.
  # init: a list containing initial estimators for V, U and C.
  #       Typically NULL and computed internally.
  # scale.case: casewise residual scales.
  #             Typically NULL and computed internally.
  # scale.cell: cellwise residual scales.
  #             Typically NULL and computed internally.
  # cut_out: whether the cutoff is outputted.
  #          Typically FALSE.
  # delta: parameter for L1 weights.
  # silent: whether the progress bar is outputted.
  
  #### Get tensor and dimensions ####
  tnsr <- as.tensor(X)
  num_modes <- tnsr@num_modes
  L <- (num_modes - 1)
  modes <- tnsr@modes
  X <- tnsr@data
  P <- dim(X)
  cinit <- FALSE
  
  #### Ranks ####
  if (is.null(ranks)) {
    
    # comments for the user
    cat("\n================================================\n")
    cat("🔍 Compute cumulative eigenvalues \n")
    cat("   to choose ranks accordingly based on the plot\n")
    cat("==================================================\n\n")
    
    # DDC on the unfolded
    if (is.null(X.git)) {
      DDC.out <- cellWise::DDC(n_unfold(X, num_modes), DDCpars = list(silent = TRUE)) 
    } else {
      # this for real data application to avoid constant scale
      DDC.out <- cellWise::DDC(n_unfold(X.git, num_modes), DDCpars = list(silent = TRUE))
    }
    
    # DDC imputed 
    DDC.imp <- n_fold(DDC.out$Ximp, X, N, n = num_modes)
    
    X.na.imp <- X
    if(any(is.na(X))){
      X.na.imp[which(is.na(X))] <- DDC.imp[which(is.na(X))]
    }
    
    # get the cellwise outliers
    ind.case.ddc <- DDC.out$indrows
    indcell.out <- array(0, dim(DDC.out$Ximp))
    indcell.out[DDC.out$indcells] <- NA
    indcell.out <- n_fold(indcell.out, X, N, n = num_modes)
    indcell.out <- which(is.na(indcell.out))
    
    # impute also the cells with DDC and remove casewise outliers
    X.ccase.imp <- X.na.imp
    X.ccase.imp[indcell.out] <- DDC.imp[indcell.out]
    if(length(DDC.out$indrows) != 0) {
      X.ccase.imp <- X.ccase.imp[, , , -DDC.out$indrows]
    }
    
    X.imp.cent <- X.ccase.imp
    if (cent == T) {
      dimes <- dim(X.ccase.imp)
      center.data.imp <- array(0, dimes[-num_modes])
      for (i in 1:dimes[num_modes]) {
        center.data.imp <- center.data.imp + tens_s(as.tensor(X.ccase.imp), i)@data
      }
      DDC.imp.cent <- center.data.imp / dimes[num_modes]
      
      X.imp.cent <- (tnsr_cent(as.tensor(X.ccase.imp), mean_tens = (DDC.imp.cent))@data)
      
      X.imp.sum <- array(0, dimes[-num_modes])
      for (i in 1:dimes[num_modes]) {
        X.imp.sum <- X.imp.sum + tens_s(as.tensor(X.imp.cent), i)@data
      }
      X.imp.cent <- X.imp.sum
    }
    
    mode1 <- n_unfold(X.imp.cent, n = 1)
    mode2 <- n_unfold(X.imp.cent, n = 2)
    eig1 <- eigen(mode1 %*% t(mode1))$values
    eig2 <- eigen(mode2 %*% t(mode2))$values
    cumulative_eig1 <- c(0, (cumsum(eig1) / sum(eig1)))
    cumulative_eig2 <- c(0, (cumsum(eig2) / sum(eig2)))
    
    if (L == 3){
      mode3 <- n_unfold(X.imp.cent, n = 3)
      eig3 <- eigen(mode3 %*% t(mode3))$values
      cumulative_eig3 <- c(0, (cumsum(eig3) / sum(eig3)))
    }
    
    # Plot cumulative eigenvalues 
    col.modes <- c("black", "red")
    legend.modes <- c("Mode 1", "Mode 2")
    
    plot(0:length(eig1), cumulative_eig1, type = "b", pch = 22, lty = 1, lwd = 3,
         xlab = "Ranks", ylab = "",
         ylim = c(0, 1), xlim = c(0, 25), col = "black")
    grid()
    points(0:length(eig2), cumulative_eig2, type = "b", pch = 23, lty = 2, col = "red", lwd = 3)
    if(L == 3){
      points(0:length(eig3), cumulative_eig3, type = "b", pch = 24, lty = 3, col = "blue", lwd = 3)
      col.modes <- c("black", "red", "blue")
      legend.modes <- c("Mode 1", "Mode 2", "Mode 3")
    }
    legend("bottomright", inset = c(0.015, 0.015), legend = legend.modes,
           pch = c(21 + 1:L), lty = (1:L), col = col.modes, cex = 0.6,
           box.lwd = 2, bg = "white", box.col = "black")
    
    cat("\n===============================================\n")
    cat("💡 Use the cumulative eigenvalues plot\n")
    cat("   to decide on the ranks.\n")
    cat("=================================================\n\n")
    # Stop execution and indicate next steps
    stop("Rerun ROMPCA with the chosen ranks")
  }
  
  #### Extract initial estimates ####
  if (is.null(init)) {
    # MPCA on reduced set and reweighting step
    cinit <- TRUE
    if (is.null(X.git)) {
      if (silent == FALSE) {
        # cat("\n===============================================\n")
        # cat("             DDC initialization                  \n")
        # cat("===============================================\n\n")
        
        cat("\nDDC initialization:\n\n")
      }
      
      DDC.MPCA.init <- DDC_MPCA(
        X.cont = X,
        ranks = ranks,
        tol = tol,
        silent = silent
      )
    } else {
      if (silent == FALSE) {
        # cat("\n===============================================\n")
        # cat("             DDC initialization                  \n")
        # cat("===============================================\n\n")
        
        cat("\nDDC initialization:\n\n")
      }
      
      DDC.MPCA.init <- DDC_MPCA(
        X.cont = X,
        X.ddc = X.git,
        ranks = ranks,
        tol = tol,
        silent = silent
      )
    }
    
    # Compute scale for L1
    scale.L1 <- apply((X - DDC.MPCA.init$Xhat.decenter@data), 1:L, scale_tanh)
    
    # L1-MPCA
    if (silent == FALSE) {
      # cat("\n===============================================\n")
      # cat("               L1 initialization                 \n")
      # cat("===============================================\n\n")
      cat("\nL1 initialization:\n\n")
    }
    
    L1.out <- L1_MPCA(
      X,
      ranks,
      max_itr = max_itr,
      init = DDC.MPCA.init,
      tol = tol,
      scale = scale.L1,
      delta = delta,
      silent = silent
    )
    L1.init <- list(
      X.tilde = L1.out$X.tilde,
      U.tilde = L1.out$U.tilde,
      V = L1.out$V,
      Xhat = L1.out$Xhat,
      Center = L1.out$Center
    )
    
    # choose initialization according to casewise scale
    init.comp.ddc <- init.scale.comp(X, b = b, init = DDC.MPCA.init, m.name = "DDC-Init")
    init.comp.L1 <- init.scale.comp(X, b = b, init = L1.init, m.name = "L1-Init")
    
    init.comp <- cbind(init.comp.ddc, init.comp.L1)
    init.name <- colnames(init.comp[, which.min(init.comp), drop = FALSE])
    
    # choose the initialisation with lowest casewise scale
    list.init <- list("DDC-Init" = DDC.MPCA.init, "L1-Init" = L1.init)
    init <- list.init[[init.name]]
  }
  
  V_list <- init$V
  U <- init$U.tilde
  Cent <- init$Center
  Xt <- tnsr_cent(as.tensor(X), mean_tens = (Cent))@data
  Xhat <- init$Xhat
  
  #### Scale from initialization ####
  scale.out <- get_scale_tanh(Xt, Xhat, b)
  
  if (is.null(scale.case)) {
    scale.case <- scale.out$scale.case
  }
  
  if (is.null(scale.cell)) {
    scale.cell <- scale.out$scale.cell
  }
  
  # Get tuning constants
  if (is.null(tpar)) {
    dime <- c(P[-num_modes], 1000)
    par <- get_tuning_const_tanh(dime, b, 1) 
  } else {
    par <- tpar
  }
  
  #### Initialize weights and loss ####
  Weight.est <- weight_tanh_tanh(Xt, Xhat, b_1 = b,
                                 scale.cell = scale.cell, 
                                 scale.case = scale.case, 
                                 bb = par[1], cc = par[2], 
                                 q1 = par[3], q2 = par[4])
  W <- Weight.est$W
  Wc <- Weight.est$w1
  
  if (any(is.na(X))) {
    miss.idx <- which(is.na(X))
    W[miss.idx] <- 0
    Wc[miss.idx] <- 0
  }
  
  E <- get_loss_tanh(Xt, Xhat, b_1 = b,
                     scale.cell = scale.cell, 
                     scale.case = scale.case,
                     bb = par[1], cc = par[2], 
                     q1 = par[3], q2 = par[4])
  EE <- matrix(c(0, E), nrow = 1)
  
  #### Main part ####
  converged <- FALSE
  itr <- 0
  if(silent == FALSE) {
    # cat("\n===============================================\n")
    # cat("                    ROMPCA                       \n")
    # cat("===============================================\n\n")
    cat("\nIRLS part of ROMPCA:\n\n")
    
    pb <- txtProgressBar(min = 0, max = max_itr, style = 3)
  }
  
  while ((itr < max_itr)) {
    
    if (silent == FALSE) {
      setTxtProgressBar(pb, itr)
    }
    itr <- itr + 1
    
    ## V update
    if (any(is.na(X))) {
      V_list <- Get_V_NA(Xt, V_list, U, W)
    } else {
      V_list <- Get_V(Xt, V_list, U, W)
    }
    
    ## Core tensor update
    if (any(is.na(X))) {
      U.list <-
        lapply(1:P[num_modes], function(i)
          U_samp_NA(
            tens_s(as.tensor(Xt), i)@data,
            V_list,
            tens_s(as.tensor(Wc), i)@data,
            ranks
          ))
    } else {
      U.list <-
        lapply(1:P[num_modes], function(i)
          U_samp(
            tens_s(as.tensor(Xt), i)@data,
            V_list,
            tens_s(as.tensor(Wc), i)@data,
            ranks
          ))
    }
    
    U <- abind::abind(U.list, along = num_modes)
    Xhat <- ttl(as.tensor(U), V_list, ms = 1:L)
    
    ## Center update
    Nu <- array(0, P[-num_modes])
    De <- array(0, P[-num_modes])
    
    if (any(is.na(X))) {
      for (i in 1:P[num_modes]) {
        D.miss <- (tens_s(as.tensor(X), i)@data - tens_s(Xhat, i)@data)
        D.miss[which(is.na(D.miss))] <- 0
        Nu <- Nu + (D.miss * tens_s(as.tensor(W), i)@data)
        De <- De + tens_s(as.tensor(W), i)@data
      }
      
    } else {
      for (i in 1:P[num_modes]) {
        Nu <-
          Nu + ((tens_s(as.tensor(X), i)@data - tens_s(Xhat, i)@data) * tens_s(as.tensor(W), i)@data)
        De <- De + tens_s(as.tensor(W), i)@data
      }
      
    }
    
    C <- Nu/(De+1e-10)
    Xt <- tnsr_cent(as.tensor(X), mean_tens = (C))@data
    
    ## Weight update
    Weight.est <- weight_tanh_tanh(Xt, Xhat@data, b_1 = b,
                                   scale.cell = scale.cell, 
                                   scale.case = scale.case,
                                   bb = par[1], cc = par[2], 
                                   q1 = par[3], q2 = par[4])
    W <- Weight.est$W
    Wc <- Weight.est$w1
    Wr <- Weight.est$w2
    
    if (any(is.na(X))) {
      W[miss.idx] <- 0
      Wc[miss.idx] <- 0
    }
    
    ## Convergence
    ssDe <- get_loss_tanh(Xt, Xhat@data, b_1 = b,
                          scale.cell = scale.cell, 
                          scale.case = scale.case,
                          bb = par[1], cc = par[2], 
                          q1 = par[3], q2 = par[4])
    
    EE <- rbind(EE, c(itr, ssDe))
    if (abs(ssDe - E)/E < tol){
      converged <- TRUE
      if (silent == FALSE) {
        setTxtProgressBar(pb, max_itr)
      }
      break
    }
    
    if (itr == max_itr && silent == FALSE) {
      setTxtProgressBar(pb, max_itr)
    }
    
    E <- ssDe
  }
  
  if (silent == FALSE) {
    close(pb)
  }
  
  #### Compute standardized residuals ####
  R.rompca <- X - tnsr_cent(Xhat, mean_tens = (-C))@data
  scale.cell.re <- get_scale_tanh(X, tnsr_cent(Xhat, mean_tens = (-C))@data, b)
  R.std <- R.rompca / scale.cell.re$scale.cell
  
  # compute RD
  RD <- sapply(1:N, function(i) {
    x <- as.vector(tens_s(R.std, i))
    sum(x^2, na.rm = T)^(1/2)
  })
  
  if (L == 3){
    scale.cell1 <- scale.cell.re$scale.cell[, , , 1]
  } else {
    scale.cell1 <- scale.cell.re$scale.cell[, , 1]
  }
  
  if (cut_out == TRUE) {
    X.idx <- sample(seq_len(N), size = n.clean, replace = T)
    dime <- c((dimension[-num_modes]), length(X.idx))
    X.clean <- array(rnorm(prod(dime)), dime)
    
    scale.cell.clean <- apply(X.clean, 1:L, scale_tanh)
    scale.cell.clean <- array(rep(scale.cell.clean, times = n.clean), dime)
    Res.final <- X.clean/scale.cell.clean
    
    RD.simu <- sapply(1:n.clean, function(i) {
      frobnorm(tens_s(Res.final, i))
    })
    RD.cut <- quantile(RD.simu, 0.99)
  }
  
  #### Correct the center ####
  # Update the mean to cope with the translational ambiguity
  Nu <- array(0, P[-num_modes])
  De <- array(0, P[-num_modes])
  
  for (i in 1:P[num_modes]) {
    Nu <- Nu + ((tens_s(as.tensor(X), i)@data) * tens_s(as.tensor(W), i)@data)
    De <- De + tens_s(as.tensor(W), i)@data
  }
  
  C.new <- Nu/(De)
  C.old <- C
  
  Center.prime <- C.new - C.old
  
  flipcolumn <- function(x) { 
    if (x[which.max(abs(x))] < 0) {-x} else {x} }
  V_list <- lapply(V_list, function(V) { apply(V, 2L, FUN = flipcolumn) })
  
  U.mean.diff <- ttl(as.tensor(Center.prime), lapply(V_list, t), ms = 1:(num_modes - 1))@data
  Center.new <- C.old + ttl(as.tensor(U.mean.diff), V_list, ms = 1:(num_modes - 1))@data
  U.new <- tnsr_cent(as.tensor(U), mean_tens = U.mean.diff)@data
 
  #### Results ####
  res <- list()
  res$X <- X
  res$X.tilde <- Xt
  res$U.tilde <- U
  res$U.tilde.corr <- U.new
  res$V <- V_list
  res$Xhat.decenter <- tnsr_cent(Xhat, mean_tens = (-C))
  res$Xhat <- Xhat@data
  res$Center <- C
  res$Center.corr <- Center.new
  res$W <- W
  res$W.cell <- Wc
  res$W.case <- Wr
  res$loss <- EE
  res$itr <- itr
  res$converged <- converged
  res$scale.cell <- scale.cell
  res$scale.cell.re <- scale.cell.re$scale.cell
  res$scale.case <- scale.case
  res$R.std <- R.std
  
  if (cut_out == TRUE) {
    res$RD <- RD
    res$RD.cut <- RD.cut
  }
  
  if (cinit == TRUE) {
    res$DDC.MPCA.init <- DDC.MPCA.init
    res$L1.init <- L1.init
  }
  
  return(res)
}

# Auxiliary function ------------------------------------------------------
perm_idx <- function(tnsr, n){
  # permutation index
  num_modes <- length(dim(tnsr))
  if (n == 1) {
    perm.idx <- c(n, (num_modes:(n+1)))
  } else if(n == num_modes) {
    perm.idx <- c((num_modes:(1)))
  } else {
    perm.idx <- c(n, (n -1):1,(num_modes:(n+1)))
  }
  return(perm.idx)
}

tnsr_tnsr <- function(tnsr, mat_list, ms) {
  # tensor product
  num_modes <- length(dim(tnsr))
  tnsr_fold <- tnsr
  for (m in ms) {
    tnsr_unf <- n_unfold(tnsr_fold, n = m)
    mat_list_m <- mat_list[[m]]
    tnsr_prod <- mat_list_m %*% tnsr_unf
    tnsr_fold <- n_fold(tnsr_prod, tnsr_fold, modes.out = dim(mat_list_m)[1], n = m)
  }
  return(tnsr_fold)
}

n_unfold <- function(tnsr, n) {
  # unfold the tensor
  perm_idx <- perm_idx(tnsr, n) # get the permutation index
  tnsr_perm <- aperm(tnsr, perm_idx)
  tnsr_unf <- matrix(tnsr_perm, nrow = dim(tnsr_perm)[1], ncol = prod(dim(tnsr_perm)[-1]))
  return(tnsr_unf)
}

n_fold <- function(unf_tnsr, tnsr, modes.out, n) {
  # fold back the tensor
  perm.idx <- perm_idx(tnsr, n)
  dime <- dim(tnsr)
  tnsr_fold <- array(unf_tnsr, c(modes.out, dime[perm.idx][-1]))
  tnsr_fold <- aperm(tnsr_fold, order(perm.idx))
  return(tnsr_fold)
}

tens_s <- function(tnsr, i) {
  # get one slice from the tensor
  num_modes <- length(dim(tnsr))
  tnsr.slice <- do.call("[", c(list(tnsr), c(rep(list(TRUE), num_modes - 1), i)))
  
  if (inherits(tnsr, "Tensor")) {
    tnsr.slice <- as.tensor(array(tnsr.slice@data, dim(tnsr)[-num_modes]))
    return(tnsr.slice)
  } else {
    tnsr.slice <- array(tnsr.slice, dim(tnsr)[-num_modes])
    return(tnsr.slice)
  }
}

tnsr_cent <- function(tnsr, mean_tens = NULL) {
  # center the tensor according to the sample mode
  if (is.null(mean_tens)) {
    mean_tens <- tnsr_mean(tnsr)
    tnsr.list <- lapply(1:tail(tnsr@modes, n =1), 
                        function(i) do.call("[", c(list(tnsr@data), c(rep(list(TRUE), tnsr@num_modes - 1), i))))
    
    tnsr.centered.list <- lapply(tnsr.list, function(x) x - mean_tens)
    tnsr.centered <- as.tensor(abind::abind(tnsr.centered.list, along = tnsr@num_modes))
  } else {
    tnsr.list <- lapply(1:tail(tnsr@modes, n =1), 
                        function(i) do.call("[", c(list(tnsr@data), c(rep(list(TRUE), tnsr@num_modes - 1), i))))
    
    tnsr.centered.list <- lapply(tnsr.list, function(x) x - mean_tens)
    tnsr.centered <- as.tensor(abind::abind(tnsr.centered.list, along = tnsr@num_modes))
  }
  return(tnsr.centered)
}

frobnorm <- function(x) {
  # compute the Frobenius norm
  x <- as.vector(x)
  sum(x^2)^(1/2)
}

L1_weights <- function(X, Xhat, delta = 1e-5, scale) {
  # function to compute the L1 weights
  P <- dim(X)
  num_modes <- length(P)
  L <- (num_modes - 1)
  D <- X - Xhat
  
  scale.cell <- array(rep(scale, times = P[num_modes]), P)
  D <- D/scale.cell
  
  L1_w <- 1 /pmax.int(delta, abs(D))
  L1_weight <- array(1, dim = dim(X)) * L1_w
  
  return(L1_weight)
}

calculateq1q2 <- function(b, c, maxit = 500, precScale = 1e-10) {
  # This function calculates the necessary parameters to make 
  # the wrapping psi function continuous.
  #
  # Input:
  # b: corner point of the wrapping psi function
  # c: rejection point of the wrapping psi function
  
  A <- 2 * pnorm(c) - 1 - 2 * c * dnorm(c)
  B <- 2 * pnorm(c) - 1
  k <- max(1,c)
  
  Anew <- A
  Bnew <- B
  knew <- k
  converged <- FALSE
  iter <- 0
  while (!converged & iter < maxit) {
    A <- Anew
    B <- Bnew
    k <- knew
    
    knew <- optimize(f = function(y) 
      abs(b - (A * (y - 1)) ^ (0.5) *
            tanh(0.5 * ((y - 1) * B ^ 2 / A) ^ 0.5*(c - b))),
      interval = c(1 + precScale, 1000),tol = precScale)$minimum
    Anew <- integrate(f = function(y) psiWrap(y, b, c, A, B, k) ^ 2 *
                        dnorm(y), lower = -c, upper = c)$value
    Bnew <- integrate(f = function(y) abs(psiWrap(y, b, c, A, B, k)) *
                        abs(y) * dnorm(y), lower = -c, upper = c)$value
    iter <- iter + 1
    converged <- max(abs(Anew - A), abs(Bnew - B), abs(knew - k)) < precScale
  }
  q1 <- sqrt(Anew * (knew - 1))
  q2 <- Bnew / 2 * sqrt((knew - 1) / Anew)
  return(list(q1 = q1, q2 = q2))
}

rho_tanh <- function(x, dime, b = 1.5, bb = NULL, cc = NULL, q1 = NULL, q2 = NULL) { 
  # The rho function of wrapping.
  if(is.null(bb) | is.null(cc)) {
    xx <- 1.5*x/b
    bb <- 1.5
    cc <- 4 
    q1 <- 1.540793
    q2 <- 0.8622731
    q12 <- q1/q2 
    dd <- 3.7622126668 
    rhos <- array(NA, dime)
    
    indsmall <- which(abs(xx) <= bb)
    rhos[indsmall] <- (xx[indsmall]^2)/2
    
    indmid <- which(abs(xx) > bb & abs(xx) < cc)
    rhos[indmid] <- (dd - q12*log(cosh(q2*(cc-abs(xx[indmid])))))
    
    indbig <- which(abs(xx) >= cc)
    rhos[indbig] <- dd
    rho <- rhos*(b/1.5)^2
  } else {
    if (bb > 100) {
      rhos <- array(NA, dime)
      rhos <- x^2
    } else {
      xx <- x
      if (is.null(q1)) {
        params <- calculateq1q2(bb, cc)
        q1 <- params$q1
        q2 <- params$q2
      }
      q12 <- q1 / q2
      dd <- (bb ^ 2 / 2) + (q1 / q2) * log(cosh(q2 * (cc - bb)))
      
      rhos <- array(NA, dime)
      
      indsmall <- which(abs(xx) <= bb)
      rhos[indsmall] <- (xx[indsmall]^2)/2
      
      indmid <- which(abs(xx) > bb & abs(xx) < cc)
      rhos[indmid] <- (dd - q12*log(cosh(q2*(cc-abs(xx[indmid])))))
      
      indbig <- which(abs(xx) >= cc)
      rhos[indbig] <- dd
    }
  }
  
  return(rhos)
}

get_tuning_const_tanh <- function(dime, b_1 = 1.5, b_2 = 1) {
  # Function that calculates the tuning constants under tanh rho
  
  D <- array(rnorm(prod(dime), mean = 0, sd = 1), dime)
  
  I <- dim(D)
  num_modes <- length(I)
  N <- (num_modes - 1)
  
  scale.cell <- apply(D, 1:N, scale_tanh)
  scale.cell <- array(rep(scale.cell, times = I[num_modes]), I)
  
  rho1 <- rho_tanh(D/scale.cell, dime = I, b = b_1)
  rho1_scaled <- scale.cell^2 * rho1
  rho1 <- sapply(1:tail(dim(D), 1), function(i) {
    sqrt(sum(tens_s(rho1_scaled, i))/prod(I[1:N]))
  })
  
  scale.row <- scale_tanh(rho1)
  
  rowres <- rho1/scale.row
  bb <- max(b_2 * quantile(rowres, 0.7), 0)
  cc <- max(b_2 * quantile(rowres, 0.99), 0.3)
  
  if (bb < 100) {
    params <- calculateq1q2(bb, cc)
    q1 <- params$q1 
    q2 <- params$q2
  }
  else {
    q1 <- q2 <- NA
  }
  par <- c(bb, cc, q1, q2)
  return(par)
}

get_c_scaletanh <- function(delta = 1.8811) {
  set.seed(123)
  x <- rnorm(5000)
  c_vec <- seq(0.1, 10, 0.0001)
  m_vec <- numeric()
  for (ii in 1:length(c_vec)) {
    m_vec[ii] <- mean(rho_tanh(x/c_vec[ii]))
  }
  dist <- abs(m_vec-delta)
  c <- c_vec[which.min(dist)]
  return(c)
}

scale_tanh <- function (u, delta = 1.8811, max.it = 100, tol = 1e-06, tolerancezero = .Machine$double.eps){
  # get scale using tanh rho
  rho_tanh_vec <- function(x, b = 1.5, bb = NULL, cc = NULL, q1 = NULL, q2 = NULL) { 
    # The rho function of wrapping.
    if(is.null(bb) | is.null(cc)) {
      xx <- 1.5 * x / b
      bb <- 1.5
      cc <- 4
      q1 <- 1.540793
      q2 <- 0.8622731
      q12 <- q1 / q2
      dd <- 3.7622126668
      rhos <- rep(NA, length(xx))
      indsmall <- which(abs(xx) <= bb)
      rhos[indsmall] <- (xx[indsmall] ^ 2) / 2
      indmid <- which(abs(xx) > bb & abs(xx) < cc)
      rhos[indmid] <- (dd - q12 * log(cosh(q2 * (cc - abs(xx[indmid])))))
      indbig <- which(abs(xx) >= cc)
      rhos[indbig] <- dd
    }
    else {
      if (bb > 100) {
        rhos <- rep(NA, length(x))
        rhos <- (x ^ 2)
      }
      else {
        xx <- x
        if (is.null(q1)) {
          params <- calculateq1q2(bb, cc)
          q1 <- params$q1
          q2 <- params$q2
        }
        
        q12 <- q1 / q2
        dd <- (bb ^ 2 / 2) + (q1 / q2) * log(cosh(q2 * (cc - bb)))
        
        rhos <- rep(NA, length(xx))
        indsmall <- which(abs(xx) <= bb)
        rhos[indsmall] <-  (xx[indsmall] ^ 2) / 2
        indmid <- which(abs(xx) > bb & abs(xx) < cc)
        rhos[indmid] <-
          (dd - q12 * log(cosh(q2 * (cc - abs(
            xx[indmid]
          )))))
        indbig <- which(abs(xx) >= cc)
        rhos[indbig] <- dd
      }
    }
    return(rhos)
  }
  
  #### main ####
  if (delta == 1.8811) {
    c <- 0.34308
  }
  else {
    c <- get_c_scaletanh(delta)
  }
  s0 <- median(abs(u), na.rm = T)/0.6745
  if (s0 < tolerancezero) 
    return(0)
  err <- tol + 1
  it <- 0
  while ((err > tol) && (it < max.it)) {
    it <- it + 1
    s1 <- sqrt(s0^2 * mean(rho_tanh_vec(u/(c*s0)), na.rm = T)/delta)
    err <- abs(s1 - s0)/s0
    s0 <- s1
  }
  return(s0)
}

psiWrap <- function(x, b, c, A, B, k) {
  # Wrapping psi function
  indmid <- which(abs(x) >= b & abs(x) <= c)
  indup  <- which(abs(x) >= c)
  x[indmid] <- (A * (k - 1)) ^ (0.5) *
    tanh(0.5 * ((k - 1) * B ^ 2 / A) ^ 0.5 *
           (c - abs(x[indmid]))) * sign(x[indmid])
  x[indup] <- 0
  return(x)
}

get_scale_tanh <- function(Xt, Xhat, b_1 = 1.5) {
  res <- list()
  
  P <- dim(Xt)
  num_modes <- length(P)
  L <- (num_modes - 1)
  D <- (Xt - Xhat)
  
  # Cellwise scale
  scale.cell <- apply(D, 1:L, scale_tanh) # new scale using tanh
  scale.cell <- array(rep(scale.cell, times = P[num_modes]), P)
  res$scale.cell <- scale.cell
  rho1 <- rho_tanh(D/scale.cell, dime = P, b = b_1)
  rho1 <- rho1 * scale.cell^2
  
  # Rowwise scale
  if (any(is.na(Xt))) {
    res_N <- sapply(1:tail(dim(Xt), 1), function(i) {
      numNA <- length(which(!is.na(n_unfold(rho1, num_modes)[i,])))
      sqrt(sum(tens_s(rho1, i), na.rm = T)/numNA)
    })
  } else {
    res_N <- sapply(1:tail(dim(Xt), 1), function(i) {
      sqrt(sum(tens_s(rho1, i))/prod(P[1:L]))
    }) 
  }
  
  res$scale.case <- scale_tanh(res_N) # new scale using tanh
  
  return(res)
}

weight_tanh <- function(x, dime, b = 1.5, bb = NULL, cc = NULL, q1 = NULL, q2 = NULL){
  # The weight function of wrapping.
  psitanh <- function(xx, bb, cc, q1, q2) {
    abs_xx <- abs(xx)
    psi <- xx
    
    # boolean indexing instead of which
    indb <- abs_xx <= bb
    indc <- abs_xx > bb & abs_xx <= cc
    indbig <- abs_xx > cc
    
    if (any(is.na(indc))) {
      indc[is.na(indc)] <- FALSE
    }
    
    if (any(is.na(indbig))) {
      indbig[is.na(indbig)] <- FALSE 
    }
    
    psi[indc] <- q1 * tanh(q2 * (cc - abs_xx[indc])) * sign(xx[indc])
    psi[indbig] <- 0
    
    psi
  }
  
  if (is.null(bb) | is.null(cc)) {
    xx <- 1.5 * x / b
    bb <- 1.5
    cc <- 4
    q1 <- 1.540793
    q2 <- 0.8622731
    q12 <- q1 / q2
    dd <- 3.7622126668
    
    tanh_w <- ifelse(is.na(xx), NA, ifelse(xx == 0, 1, psitanh(xx, bb, cc, q1, q2) / xx))
    tanh_w <- array(tanh_w, dime)
    
  } else {
    if (bb > 100) {
      xx <- x
      tanh_w <- array(sapply(xx, function(t){ ifelse(is.na(t), NA,  1 )}), dime)
    } else {
      xx <- x
      if (is.null(q1)) {
        params <- calculateq1q2(bb, cc)
        q1 <- params$q1
        q2 <- params$q2
      }
      q12 <- q1 / q2
      dd <- (bb ^ 2 / 2) + (q1 / q2) * log(cosh(q2 * (cc - bb)))
      
      tanh_w <- ifelse(is.na(xx), NA, ifelse(xx == 0, 1, psitanh(xx, bb, cc, q1, q2) / xx))
      tanh_w <- array(tanh_w, dime)
    }
  }
  
  return(tanh_w)
}

weight_tanh_tanh <- function(Xt, Xhat, scale.cell, scale.case, b_1 = 1.5, bb, cc, q1, q2) {
  # The weight function of wrapping 
  # combined for both casewise and cellwise.
  P <- dim(Xt)
  num_modes <- length(P)
  L <- (num_modes - 1)
  D <- (Xt - Xhat)
  
  w1 <- weight_tanh(D/scale.cell, dime = P, b = b_1)
  
  rho1 <- rho_tanh(D/scale.cell, dime = P, b = b_1)
  rho1_scaled <- scale.cell^2 * rho1
  
  if (any(is.na(Xt))) {
    rho1 <- sapply(1:tail(dim(Xt), 1), function(i) {
      numNA <- length(which(!is.na(n_unfold(rho1_scaled, num_modes)[i, ])))
      sqrt(sum(tens_s(rho1_scaled, i), na.rm = T) / numNA)
    })
  } else {
    rho1 <- sapply(1:tail(dim(Xt), 1), function(i) {
      sqrt(sum(tens_s(rho1_scaled, i)) / prod(P[1:L]))
    })
  }
  
  w2_vec <- weight_tanh(rho1/scale.case, length(rho1), bb = bb, cc = cc, q1 = q1, q2 = q2)
  w2 <- array(rep(w2_vec, each = prod(P[-num_modes])), dim = P)
  W <- w1 * w2
  
  res <- list(w1 = w1, w2 = w2, w2_vec = w2_vec, W = W)
  return(res)
}

get_loss_tanh <- function(Xt, Xhat, scale.cell, scale.case, b_1 = 1.5, bb, cc, q1, q2){
  # Loss function using tanh rhos
  P <- dim(Xt)
  num_modes <- length(P)
  L <- (num_modes - 1)
  D <- (Xt - Xhat)
  
  rho1 <- rho_tanh(D/scale.cell, dime = P, b = b_1)
  rho1_scaled <- scale.cell^2 * rho1
  
  if (any(is.na(Xt))) {
    rho1 <- sapply(1:tail(dim(Xt), 1), function(i) {
      numNA <- length(which(!is.na(n_unfold(rho1_scaled, num_modes)[i, ])))
      sqrt(sum(tens_s(rho1_scaled, i), na.rm = T)/numNA)
    })
    
    numNA <- sapply(1:tail(dim(Xt), 1), function(i) length(which(!is.na(n_unfold(rho1_scaled, num_modes)[i,]))))
    rho2 <- rho_tanh(rho1/scale.case, dime = length(rho1), bb = bb, cc = cc, q1 = q1, q2 = q2)*numNA
    
  } else {
    rho1 <- sapply(1:tail(dim(Xt), 1), function(i) {
      sqrt(sum(tens_s(rho1_scaled, i))/prod(P[1:L]))
    })
    
    rho2 <- rho_tanh(rho1/scale.case, dime = length(rho1), bb = bb, cc = cc, q1 = q1, q2 = q2)
  }
  
  return(sum(rho2))
}

Get_V <-  function(Xt, V_list, U, W) {
  # Get V without missing values
  tnsr <- as.tensor(Xt)
  mode_seq <- 1:(length(dim(tnsr)) - 1)
  V_list.update <- vector("list", (length(dim(tnsr))  - 1))
  
  for (n in mode_seq) {
    ms <- mode_seq[-n]
    Rn <- dim(V_list[[n]])[2]
    mat1 <- matrix(0, dim(tnsr)[n]*Rn, dim(tnsr)[n]*Rn)
    mat2 <- matrix(0, dim(tnsr)[n]*Rn, 1)
    
    # Iterate over all samples
    for (i in 1:tail(tnsr@modes, 1)) {
      U_red <- (tnsr_tnsr(tens_s(U, i), V_list, ms = mode_seq[-n]))
      U_red_unf <- n_unfold(U_red, n)
      W_unf <- n_unfold(tens_s(as.tensor(W), i)@data, n)
      Xt_unf <- n_unfold(tens_s(tnsr, i)@data, n)
      
      kr.first.1 <- Matrix::Matrix(fastmatrix::kronecker.prod(U_red_unf, diag(dim(tnsr)[n])))
      kr.sec.1 <- Matrix::Matrix(t(kr.first.1))
      mat1 <- mat1 + (kr.first.1 %*% (kr.sec.1 * c(W_unf)))
      mat2 <- mat2 + (kr.first.1 %*% (matrix(c(Xt_unf)) * c(W_unf)))
    }
    
    mat1 <- as.matrix(mat1)
    mat2 <- as.matrix(mat2)
    Vn.vec <- MASS::ginv(mat1) %*% mat2
    Vn <- matrix(c(Vn.vec), dim(Xt)[n], Rn)
    Vn <- OmicsPLS::orth(Vn)
    
    V_list.update[[n]] <- Vn
  }
  
  return(V_list.update)
}

Get_V_NA <-  function(Xt, V_list, U, W) {
  # Get V with missing values
  miss.idx <- which(is.na(Xt))
  Xt[miss.idx] <- 0
  
  tnsr <- as.tensor(Xt)
  mode_seq <- 1:(length(dim(tnsr)) - 1)
  V_list.update <- vector("list", length(mode_seq))
  
  for (n in mode_seq) {
    ms <- mode_seq[-n]
    Rn <- dim(V_list[[n]])[2]
    mat1 <- matrix(0, dim(tnsr)[n] * Rn, dim(tnsr)[n] * Rn)
    mat2 <- matrix(0, dim(tnsr)[n] * Rn, 1)
    
    # Iterate over all samples
    for (i in 1:tail(tnsr@modes, 1)) {
      U_red <- (tnsr_tnsr(tens_s(U, i), V_list, ms = mode_seq[-n]))
      U_red_unf <- n_unfold(U_red, n)
      W_unf <- n_unfold(tens_s(as.tensor(W), i)@data, n)
      Xt_unf <- n_unfold(tens_s(tnsr, i)@data, n)
      
      kr.first.1 <- Matrix::Matrix(fastmatrix::kronecker.prod(U_red_unf, diag(dim(tnsr)[n])))
      kr.sec.1 <- Matrix::Matrix(t(kr.first.1))
      mat1 <- mat1 + (kr.first.1 %*% (kr.sec.1 * c(W_unf)))
      mat2 <- mat2 + (kr.first.1 %*% (matrix(c(Xt_unf)) * c(W_unf)))
    }
    
    mat1 <- as.matrix(mat1)
    mat2 <- as.matrix(mat2)
    
    # Compute the updated Vn
    Vn.vec <- MASS::ginv(mat1) %*% mat2
    Vn <- matrix(c(Vn.vec), dim(Xt)[n], Rn)
    Vn <- OmicsPLS::orth(Vn)
    V_list.update[[n]] <- Vn
  }
  
  return(V_list.update)
}

U_samp <- function(Xt, V_list, W, ranks) {
  # Get U without missing values
  N <- length(dim(Xt))
  kr.v <- V_list[[N]]
  
  for(i in (N-1):1) {
    kr.v <- fastmatrix::kronecker.prod(kr.v, V_list[[i]])
  }
  kr.v.t <- t(kr.v)
  
  U.vec1 <- MASS::ginv(kr.v.t %*% (c(W) * kr.v))
  U.vec2  <- kr.v.t %*% (c(W) * matrix(c(Xt)))
  U.vec <- U.vec1 %*% U.vec2
  U.new <- array(c(U.vec), ranks)
  return(U.new)
}

U_samp_NA <- function(Xt, V_list, W, ranks) {
  # Get U with missing values
  miss.idx <- which(is.na(Xt))
  Xt[miss.idx] <- 0
  
  N <- length(dim(Xt))
  kr.v <- V_list[[N]]
  
  Xt[miss.idx] <- 0
  
  for(i in (N-1):1){
    kr.v <- fastmatrix::kronecker.prod(kr.v, V_list[[i]])
  }
  kr.v.t <- t(kr.v)
  
  U.vec1 <- MASS::ginv(kr.v.t %*% (c(W) * kr.v))
  U.vec2  <- kr.v.t %*% (c(W) * matrix(c(Xt)))
  U.vec <- U.vec1 %*% U.vec2
  U.new <- array(c(U.vec), ranks)
  return(U.new)
}

init.scale.comp <- function(X, b = 1.5, init, m.name = NULL){
  #### parameters ####
  tnsr <- as.tensor(X)
  num_modes <- tnsr@num_modes
  L <- (num_modes - 1)
  modes <- tnsr@modes
  X <- tnsr@data
  P <- dim(X)
  
  #### Initialisation ####
  Cent <- init$Center
  Xt <- tnsr_cent(as.tensor(X), mean_tens = (Cent))@data
  U <- init$U.tilde
  V_list <- init$V
  Xhat <- init$Xhat
  
  #### Scale from initialization ####
  scale.out <- get_scale_tanh(Xt, Xhat, b)
  scale.case <- scale.out$scale.case
  scale.cell <- scale.out$scale.cell
  
  #### Results ####
  if(!is.null(m.name)) {
    scale.case <- as.matrix(scale.case)
    colnames(scale.case) <- m.name
  }
  
  return(scale.case)
}

# Functions for case studies ----------------------------------------------
# function for Dog Walker
downsample_slice_decimation <- function(slice, factor_x, factor_y) {
  # downsample the Dog Walker frames
  downsampled_slice <- slice[seq(1, nrow(slice), by = factor_x), seq(1, ncol(slice), by = factor_y)]
  return(downsampled_slice)
}

downsample_image_decimation <- function(image_data, target_dim) {
  # downsample the Dog Walker frames
  orig_dim <- dim(image_data)
  factor_x <- ceiling(orig_dim[1] / target_dim[1])
  factor_y <- ceiling(orig_dim[2] / target_dim[2])
  
  downsampled_image <- array(0, dim = c(length(seq(1, orig_dim[1], by = factor_x)), 
                                        length(seq(1, orig_dim[2], by = factor_y)), 
                                        orig_dim[3]))
  
  for (i in 1:orig_dim[3]) {
    downsampled_image[,,i] <- downsample_slice_decimation(image_data[,,i], factor_x, factor_y)
  }
  
  return(downsampled_image)
}

correct_orientation <- function(file) {
  # image orientation
  img.rev <- array(NA, c(180,144,length(dim(file))))
  for (i in 1:length(dim(file))) {
    img <- t(apply(file[,,i], 2, rev))
    img.rev[,,i] <- img
  }
  
  return(img.rev)
}

add.git <- function(X) {
  # gittering for Dog Walker
  locScaleX <- estLocScale(X, precScale = 1e-12)
  zeropix <- which(locScaleX$scale < 1e-12)
  zeropix <- c(zeropix, 19305)
  nzero <- length(zeropix)
  filler <- seq_len(dims[4])/(dims[4] + 1)
  filler <- 0.9 / 255 * matrix(rep(filler, nzero), ncol = nzero, byrow = F)
  centers <- apply(X[, zeropix], 2, FUN = median)
  centers <- pmax(0, pmin(1, centers))
  indpos <- which(centers > 0)
  filler[, indpos] <- -filler[, indpos] 
  filler <- sweep(filler, 2, centers, "+")
  X[, zeropix] <- filler
  locScaleX$scale[zeropix] <- estLocScale(X[, zeropix])$scale
  X.out <- n_fold(X, X.cont, dim(X.cont)[4], n = 4)
  return(X.out)
}

# function for Dorrit
postprocesParafac <- function(A, B, C) {
  # post process the loadings from PARAFAC
  I <- dim(A)[1]; J <- dim(B)[1]; K <- dim(A)[1]; F <- dim(A)[2]
  
  ### All variance put in the first mode
  A <- sweep(A, 2, (apply(B, 2, rrcov::vecnorm) * apply(C, 2, rrcov::vecnorm)), '*')
  B <- sweep(B, 2, apply(B, 2, rrcov::vecnorm), '/')
  C <- sweep(C, 2, apply(C, 2, rrcov::vecnorm), '/')
  
  ### Sign convention
  prodsign <- rep(1, F)
  
  maxB <- apply(abs(B), 2, max)
  maxC <- apply(abs(C), 2, max)
  indB <- match(apply(abs(B), 2, max), abs(B))
  indC <- match(apply(abs(C), 2, max), abs(C))
  
  signB <- apply(B, 2, sign)[indB]
  signC <- apply(C, 2, sign)[indC]
  prodsign <- signB * signC * prodsign
  
  B <- B %*% diag(signB)
  C <- C %*% diag(signC)
  A <- A %*% diag(prodsign)
  
  ## Permutation of the components: maximal variance in the first
  Var1 <- apply(A, 2, robustbase::covMcd)
  Var <- rep(NA, F)
  
  for (i in 1:F) Var[i] <- Var1[[i]]$cov
  idx <- sort(Var, index.return = T)
  
  order <- idx$ix
  out <- idx$x
  
  A <- A[, order]
  B <- B[, order]
  C <- C[, order]
  
  res <- list(A = A, B = B, C = C)
  return(res)
}

landscape.Dorrit <- function(data, main, postion = list(x=-1.8, y=-1.8, z=1.5)) {
  # plot a landscape from the Dorrit data
  scene <- list(camera = list(eye = postion),
               xaxis = list(title = 'Excitation', ticktext=list("300", "350", "400", "450"), 
                            tickvals=list("0", "5", "10", "15")), 
               yaxis = list(title='Emission', ticktext=list("240", "260", "280", "300"), 
                            tickvals=list("0", "30", "60", "90")),
               zaxis = list(title='Intensity')
  )
  
  fig <- plot_ly(z = data, type = "surface") %>% 
    layout(
      title = list(text = main, 
                   font = list(size = 18),
                   y = 0.85,
                   x = 1.55),
      margin=list( l = 50, r = 50, b = 40, t = 40,  pad = 4),
      scene = scene
    ) %>% 
    config(displayModeBar = FALSE) %>% hide_colorbar()
  
  return(fig)
}

match_loadings <- function(estimated, true_loadings) {
  # matching the loadings from PARAFAC
  permutations <- combinat::permn(1:ncol(estimated))
  best_perm <- permutations[[which.min(sapply(permutations, function(perm) {
    sum((estimated[, perm] - true_loadings)^2)
  }))]]
  
  return(best_perm)
}

add.git.dor <- function(X) {
  # gittering for Dorrit
  locScaleX <- estLocScale(X, precScale = 1e-12)
  zeropix <- which(locScaleX$scale < 1e-12)
  git <- matrix(runif(prod(dim(X[, zeropix])), 0, 0.0001), dim(X[, zeropix]))
  X[, zeropix] <- X[, zeropix] + git
  X.out <- n_fold(X, dorrit, dim(dorrit)[1], 1)
  return(X.out)
}

# Plot index plot
plot_RD <- function(W.case, R.std, RD, RD.cut, ylim = NULL, NA.idx = NULL, n.clean = 100, cut.cell = sqrt(qchisq(0.998, df = 1))){
  dimension <- dim(W.case)
  num_modes <- length(dimension)
  N <- tail(dimension, 1); L <- (num_modes - 1)
  
  if (is.null(RD.cut)) {
    X.idx <- sample(seq_len(N), size = n.clean, replace=T)
    dime <- c((dimension[-num_modes]), length(X.idx))
    X.clean <- array(rnorm(prod(dime)), dime)
    
    scale.cell.clean <- apply(X.clean, 1:L, scale_tanh)
    scale.cell.clean <- array(rep(scale.cell.clean, times = n.clean), dime)
    Res.final <- X.clean/scale.cell.clean
    
    RD.simu <- sapply(1:n.clean, function(i) {
      frobnorm(tens_s(Res.final, i))
    })
    RD.cut <- quantile(RD.simu, 0.99)
  }
  
  #### Index plot ####
  Wr.vec <- n_unfold(W.case, num_modes)[,1]
  color.gradient <- colorRampPalette(c("firebrick", "gold1"))(100)
  color.values <- color.gradient[as.numeric(cut(Wr.vec, breaks=100))]
  R.std.unf <- n_unfold(R.std, num_modes)
  R.std.ind <- abs(R.std.unf) > cut.cell
  R.std.ind.ave <- rowMeans(R.std.ind, na.rm = T)
  point.sizes <- scales::rescale(R.std.ind.ave, to = c(1, 5))
  
  plot(log(RD), pch = 16, ylim = (range(log(RD)) + c(0, 0.5)),
       xaxt = "n", type =  "n", xlab = 'Cases', 
       ylab = bquote(log(paste("||", tilde(R)[n], "||"))),
       cex.lab = 1.2
  )
  axis(1, at = 1:length(RD), labels = 1:length(RD), cex.axis = 0.7)
  segments(x0 = 1:length(RD), y0 = log(RD),
           x1 = 1:length(RD), y1 = log(RD),
           col = color.values, lty = 1, lwd = 1.5)
  points(log(RD), pch = 16, col = color.values, cex = point.sizes)
  abline(h = log(RD.cut), col = "red", lty = 2)
  title(main = "Residual distance plot", line = 1)
}

my.cellMap <- function (R, indcells = NULL, indrows = NULL, outrows = NULL, 
                        showcellvalues = NULL, D = NULL, rowlabels = NULL, columnlabels = NULL, 
                        mTitle = "cell map", rowtitle = "cases", columntitle = "variables", 
                        showrows = NULL, showcolumns = NULL, nrowsinblock = NULL, 
                        ncolumnsinblock = NULL, manualrowblocksizes = NULL, manualcolumnblocksizes = NULL, 
                        rowblocklabels = NULL, columnblocklabels = NULL, sizemain = 1.5, 
                        sizetitles = 1.2, sizerowlabels = 1, sizecolumnlabels = 1, 
                        sizecellvalues = 1, adjustrowlabels = 1, adjustcolumnlabels = 1, 
                        columnangle = 90, colContrast = 1, outlyingGrad = TRUE, 
                        darkestColor = sqrt(qchisq(0.999, 1)), drawCircles = FALSE, 
                        showVals = NULL, autolabel = TRUE){
  # customized cellMap
  colorBlocks <- function(Xin, rowblocksizes, columnblocksizes, 
                          colContrast) {
    n <- length(rowblocksizes)
    d <- length(columnblocksizes)
    Xblock <- matrix(0, nrow = n, ncol = d)
    Xblockgrad <- matrix(0, nrow = n, ncol = d)
    rind <- cumsum(c(0, rowblocksizes))
    cind <- cumsum(c(0, columnblocksizes))
    for (i in seq_len(n)) {
      for (j in seq_len(d)) {
        Xsel <- Xin[(rind[i] + 1):rind[i + 1], (cind[j] + 
                                                  1):cind[j + 1]]
        seltable <- tabulate(Xsel, nbins = 4)
        if (sum(seltable) > 0) {
          indmax <- which(seltable == max(seltable))[1]
          cntmax <- seltable[indmax]
          ncells <- rowblocksizes[i] * columnblocksizes[j]
          gradmax <- (cntmax/ncells)^(1/colContrast)
        }
        else {
          indmax <- 0
          gradmax <- 1
        }
        Xblock[i, j] <- indmax
        Xblockgrad[i, j] <- gradmax
      }
    }
    return(list(X = Xblock, Xgrad = Xblockgrad))
  }
  isVectorInteger <- function(x, tol = .Machine$double.eps^0.5) {
    y <- abs(x - round(x)) < tol
    sum(1 - y) == 0
  }
  variable <- rownr <- rescaleoffset <- x <- y <- NULL
  n <- nrow(R)
  d <- ncol(R)
  if (is.null(showcellvalues)) {
    showcellvalues <- showVals
  }
  if (!is.null(showcellvalues)) {
    if (!showcellvalues %in% c("D", "R")) {
      stop(paste("Invalid \"showcellvalues\" argument. Should be one of: NULL, \"D\", \"R\""))
    }
  }
  if (is.null(showcellvalues)) {
    D <- R
  }
  else if (showcellvalues == "D" & is.null(D)) {
    stop("When showcellvalues=\"D\" you must input the argument D")
  }
  if (is.null(D)) {
    D <- R
  }
  else {
    if (!all(dim(D) == dim(R))) 
      stop("The dimensions of D and R must match")
  }
  if (is.null(indcells)) {
    indcells <- which(abs(R) > sqrt(qchisq(0.99, 1)))
  }
  if (is.null(indrows) & is.null(outrows)) {
    drawCircles <- FALSE
  }
  if (!is.null(rowlabels)) {
    if (length(rowlabels) != n) {
      stop(paste0("Number of rowlabels does not match n = ", 
                  n))
    }
  }
  else {
    if (is.null(rownames(R))) {
      rowlabels <- seq_len(n)
    }
    else {
      rowlabels <- rownames(R)
    }
  }
  if (!is.null(columnlabels)) {
    if (length(columnlabels) != d) {
      stop(paste0("Number of columnlabels does not match d = ", 
                  d))
    }
  }
  else {
    if (is.null(colnames(R))) {
      columnlabels <- seq_len(d)
    }
    else {
      columnlabels <- colnames(R)
    }
  }
  if (!is.null(showcolumns) | !is.null(showrows)) {
    if (is.null(showrows)) {
      showrows <- seq_len(n)
    }
    else {
      if (!(all(showrows %in% seq_len(n)))) 
        stop(" showrows goes out of bounds")
    }
    if (is.null(showcolumns)) {
      showcolumns <- seq_len(d)
    }
    else {
      if (!(all(showcolumns %in% seq_len(d)))) 
        stop(" showcolumns goes out of bounds")
    }
    tempMat <- matrix(0, n, d)
    tempMat[indcells] <- 1
    tempMat <- tempMat[showrows, showcolumns]
    indcells <- which(tempMat == 1)
    tempVec <- rep(0, n)
    tempVec[indrows] <- 1
    tempVec <- tempVec[showrows]
    indrows <- which(tempVec == 1)
    rm(tempMat, tempVec)
    R <- R[showrows, showcolumns]
    D <- D[showrows, showcolumns]
    rowlabels <- rowlabels[showrows]
    columnlabels <- columnlabels[showcolumns]
    n <- nrow(R)
    d <- ncol(R)
    if (!is.null(outrows)) 
      outrows <- outrows[showrows]
  }
  blockRows <- blockColumns <- FALSE
  if (!is.null(manualrowblocksizes)) {
    if (!is.null(nrowsinblock)) {
      cat(paste0("Input argument manualrowblocksizes ", 
                 "has overruled argument nrowsinblock.\n"))
      blockRows <- TRUE
    }
    msg <- paste0("manualrowblocksizes should be a vector with strictly \n", 
                  "  positive integers, adding up to at most n = ", 
                  n)
    if (!is.vector(manualrowblocksizes)) 
      stop(msg)
    if (!is.numeric(manualrowblocksizes)) 
      stop(msg)
    if (!isVectorInteger(manualrowblocksizes)) 
      stop(msg)
    if (sum(manualrowblocksizes < 1) > 0) 
      stop(msg)
    if (sum(manualrowblocksizes) > n) 
      stop(msg)
    if (sum(manualrowblocksizes != 1) == 0) {
      stop("All manualrowblocksizes are 1")
    }
    blockRows <- TRUE
  }
  else {
    if (!is.null(nrowsinblock)) {
      if (nrowsinblock > 1) {
        if (nrowsinblock > n) 
          stop(paste0("Input argument nrowsinblock cannot be ", 
                      "more than n = ", n))
        blockRows <- TRUE
      }
    }
  }
  if (!is.null(manualcolumnblocksizes)) {
    if (!is.null(ncolumnsinblock)) {
      cat(paste0("Input argument manualcolumnblocksizes ", 
                 "has overruled argument ncolumnsinblock.\n"))
    }
    msg <- paste0("manualcolumnblocksizes should be a vector with strictly \n", 
                  "  positive integers, adding up to at most d = ", 
                  d)
    if (!is.vector(manualcolumnblocksizes)) 
      stop(msg)
    if (!is.numeric(manualcolumnblocksizes)) 
      stop(msg)
    if (!isVectorInteger(manualcolumnblocksizes)) 
      stop(msg)
    if (sum(manualcolumnblocksizes < 1) > 0) 
      stop(msg)
    if (sum(manualcolumnblocksizes) > d) 
      stop(msg)
    if (sum(manualcolumnblocksizes != 1) == 0) {
      stop("All manualcolumnblocksizes are 1")
    }
    blockColumns <- TRUE
  }
  else {
    if (!is.null(ncolumnsinblock)) {
      if (ncolumnsinblock > 1) {
        if (ncolumnsinblock > d) 
          stop(paste0("Input argument ncolumnsinblock cannot be ", 
                      "more than d = ", d))
        blockColumns <- TRUE
      }
    }
  }
  if ((blockRows | blockColumns) & !is.null(showcellvalues)) {
    warning(paste0("The option showcellvalues=\"D\" or showcellvalues=\"R\" cannot be\n", 
                   "combined with blocking rows and/or columns,\n", 
                   "so showcellvalues is set to NULL here."))
    showcellvalues <- NULL
  }
  X <- matrix(0, n, d)
  Xrow <- matrix(0, n, 1)
  Xrow[indrows, 1] <- 3
  if (blockRows | blockColumns) {
    pcells <- indcells[indcells %in% which(R >= 0)]
    ncells <- indcells[indcells %in% which(R < 0)]
  }
  else {
    pcells <- which(R >= 0)
    ncells <- which(R < 0)
  }
  X[ncells] <- 1
  X[pcells] <- 2
  X[is.na(R)] <- 4
  if (blockRows | blockColumns) {
    rowblocksizes <- rep(1, n)
    if (blockRows) {
      if (!is.null(manualrowblocksizes)) {
        rowblocksizes <- manualrowblocksizes
        n <- length(rowblocksizes)
      }
      else {
        if (!is.null(nrowsinblock)) {
          if (nrowsinblock > 1) {
            n <- floor(n/nrowsinblock)
            rowblocksizes <- rep(nrowsinblock, n)
          }
        }
      }
    }
    columnblocksizes <- rep(1, d)
    if (blockColumns) {
      if (!is.null(manualcolumnblocksizes)) {
        columnblocksizes <- manualcolumnblocksizes
        d <- length(columnblocksizes)
      }
      else {
        if (!is.null(ncolumnsinblock)) {
          if (ncolumnsinblock > 1) {
            d <- floor(d/ncolumnsinblock)
            columnblocksizes <- rep(ncolumnsinblock, 
                                    d)
          }
        }
      }
    }
    result <- colorBlocks(X, rowblocksizes, columnblocksizes, 
                          colContrast)
    X <- result$X
    Xgrad <- result$Xgrad
    if (drawCircles) {
      result <- colorBlocks(Xrow, rowblocksizes, c(1), 
                            colContrast)
      Xrowgrad <- result$Xgrad
      Xrowgrad[result$X == 0] <- 0
    }
    if (blockRows) {
      if (is.null(rowblocklabels)) {
        cat(paste0("No rowblocklabels were given, so they ", 
                   "are constructed automatically.\n"))
        laby <- rowlabels
        rowlabels <- rep(0, n)
        rind <- cumsum(c(0, rowblocksizes))
        for (i in seq_len(n)) {
          if (rowblocksizes[i] == 1) {
            rowlabels[i] <- laby[rind[i] + 1]
          }
          else {
            rowlabels[i] <- paste0(laby[rind[i] + 1], 
                                   "-", laby[rind[i + 1]])
          }
        }
      }
      else {
        if (length(rowblocklabels) != n) {
          stop(paste0("The number of rowblocklabels is ", 
                      length(rowblocklabels), " but there are ", 
                      n, " row blocks."))
        }
        rowlabels <- rowblocklabels
      }
    }
    if (blockColumns) {
      if (is.null(columnblocklabels)) {
        cat(paste0("No columnblocklabels were given, so they ", 
                   "are constructed automatically.\n"))
        labx <- columnlabels
        columnlabels <- rep(0, d)
        cind <- cumsum(c(0, columnblocksizes))
        for (j in seq_len(d)) {
          if (columnblocksizes[j] == 1) {
            columnlabels[j] <- labx[cind[j] + 1]
          }
          else {
            columnlabels[j] <- paste0(labx[cind[j] + 
                                             1], "-", labx[cind[j + 1]])
          }
        }
      }
      else {
        if (length(columnblocklabels) != d) {
          stop(paste0("The number of columnblocklabels is ", 
                      length(columnblocklabels), " but there are ", 
                      d, " column blocks."))
        }
        columnlabels <- columnblocklabels
      }
    }
    Xdf <- data.frame(cbind(seq(1, n, 1), X))
    colnames(Xdf) <- c("rownr", seq(1, d, 1))
    rownames(Xdf) <- NULL
    Xdf$rownr <- with(Xdf, reorder(rownr, seq(n, 1, -1)))
    mX <- reshape2::melt(Xdf, id.var = "rownr", value.name = "CatNr")
    Xgraddf <- data.frame(cbind(seq(1, n, 1), Xgrad))
    colnames(Xgraddf) <- c("rownr", seq(1, d, 1))
    rownames(Xgraddf) <- NULL
    Xgraddf$rownr <- with(Xgraddf, reorder(rownr, seq(n, 
                                                      1, -1)))
    mXgrad <- reshape2::melt(Xgraddf, id.var = "rownr", 
                             value.name = "grad")
    mX$grad <- mXgrad$grad
    mX$rescaleoffset <- mXgrad$grad + 10 * mX$CatNr
    if (drawCircles) {
      mXrow <- data.frame(rownr = seq_len(n), rescaleoffset = Xrowgrad + 
                            10 * 3)
    }
    scalerange <- c(0, 1)
    gradientends <- scalerange + rep(c(0, 10, 20, 30, 40), 
                                     each = 2)
    colorends <- c("yellow", "yellow", "yellow", "blue", 
                   "yellow", "red", "white", "black", "yellow", "white")
  }
  else {
    Ddf <- data.frame(cbind(seq(1, n, 1), D))
    colnames(Ddf) <- c("rownr", seq(1, d, 1))
    rownames(Ddf) <- NULL
    Ddf$rownr <- with(Ddf, reorder(rownr, seq(n, 1, -1)))
    mD <- reshape2::melt(Ddf, id.var = "rownr")
    Rdf <- data.frame(cbind(seq(1, n, 1), R))
    colnames(Rdf) <- c("rownr", seq(1, d, 1))
    rownames(Rdf) <- NULL
    Rdf$rownr <- with(Rdf, reorder(rownr, seq(n, 1, -1)))
    mR <- reshape2::melt(Rdf, id.var = "rownr")
    Xdf <- data.frame(cbind(seq(1, n, 1), X))
    colnames(Xdf) <- c("rownr", seq(1, d, 1))
    rownames(Xdf) <- NULL
    Xdf$rownr <- with(Xdf, reorder(rownr, seq(n, 1, -1)))
    mX <- reshape2::melt(Xdf, id.var = "rownr", value.name = "CatNr")
    if (!is.null(showcellvalues)) {
      if (showcellvalues == "D") 
        mX$data <- mD$value
      if (showcellvalues == "R") 
        mX$data <- mR$value
    }
    if (!outlyingGrad) {
      mX$rescaleoffset <- 10 * mX$CatNr
      scalerange <- c(0, 1)
      gradientends <- scalerange + rep(c(0, 10, 20, 30, 
                                         40), each = 2)
      gradientends
      colorends <- c("yellow", "yellow", "blue", "blue", 
                     "red", "red", "white", "black", "white", "white")
    }
    else {
      Xgrad <- matrix(NA, n, d)
      Xgrad[indcells] <- abs(R[indcells])
      limL <- sqrt(qchisq(0.9, 1))
      limH <- darkestColor
      Xgrad[Xgrad > limH] <- limH
      Xgrad <- ((Xgrad - limL)/(limH - limL))^colContrast
      Xgrad[is.na(Xgrad)] <- 0
      Xgraddf <- data.frame(cbind(seq(1, n, 1), Xgrad))
      colnames(Xgraddf) <- c("rownr", seq(1, d, 1))
      rownames(Xgraddf) <- NULL
      Xgraddf$rownr <- with(Xgraddf, reorder(rownr, seq(n, 
                                                        1, -1)))
      mXgrad <- reshape2::melt(Xgraddf, id.var = "rownr", 
                               value.name = "grad")
      mX$grad <- mXgrad$grad
      mX$rescaleoffset <- mXgrad$grad + 10 * mX$CatNr
      scalerange <- c(0, 1)
      gradientends <- scalerange + rep(c(0, 10, 20, 30, 
                                         40), each = 2)
      colorends <- c("yellow", "yellow", "yellow", "blue", 
                     "yellow", "red", "white", "black", "white", 
                     "white")
    }
    if (drawCircles) {
      tempVec <- rep(0, n)
      tempVec[indrows] <- 1
      mXrow <- data.frame(rownr = seq_len(n), rescaleoffset = 40 - 
                            (10 * tempVec))
      rm(tempVec)
      if (is.null(outrows)) {
        mXrow$rescaleoffset[indrows] <- mXrow$rescaleoffset[indrows] + 
          1
      }
      else {
        limL <- 1
        limH <- 3
        outrows[outrows > limH] <- limH
        outrows <- ((outrows - limL)/(limH - limL))^colContrast
        mXrow$rescaleoffset[indrows] <- mXrow$rescaleoffset[indrows] + 
          outrows[indrows]
      }
    }
  }
  if (drawCircles) {
    circleFun <- function(centerx, centery, r, npoints) {
      tt <- seq(0, 2 * pi, length.out = npoints)
      xx <- centerx + r * cos(tt)
      yy <- centery + r * sin(tt)
      return(c(xx, yy))
    }
    columnlabels <- c(columnlabels, "", "")
    centerx <- d + 1
    centery <- n:1
    radius <- 0.4
    npoints <- 100
    circlePoints <- mapply(circleFun, centerx, centery, 
                           radius, npoints)
    positions <- data.frame(rownr = rep(seq_len(n), each = npoints), 
                            x = c(circlePoints[seq_len(npoints), ]), y = c(circlePoints[(npoints + 
                                                                                           1):(2 * npoints), ]))
    datapoly <- merge(mXrow, positions, by = c("rownr"))
  }
  rowlabels <- rev(rowlabels)
  base_size <- 10
  ggp <- ggplot(data = mX, aes(variable, rownr)) + {
    geom_tile(aes(fill = scales::rescale(rescaleoffset, 
                                         from = range(gradientends))), color = "white")
  } + {
    if (drawCircles) {
      geom_polygon(data = datapoly, aes(x = x, y = y, 
                                        fill = scales::rescale(rescaleoffset, from = range(gradientends)), 
                                        group = rownr), colour = "black")
    }
  } + scale_fill_gradientn(colours = colorends, values = scales::rescale(gradientends), 
                           rescaler = function(x, ...) x, oob = scales::squish) + 
    coord_fixed() + 
    theme_classic(base_size = base_size * 1) + labs(x = columntitle, y = rowtitle) + {
      if (drawCircles) {
        scale_x_discrete(expand = c(0, 0), limits = as.factor(seq(1, 
                                                                  d + 1, 1)), labels = columnlabels)
      }
      else {
        scale_x_discrete(expand = c(0, 0), limits = as.factor(seq(1, 
                                                                  d, 1)), labels = columnlabels)
      }
    } + scale_y_discrete(expand = c(0, 0), labels = rowlabels) + 
    ggtitle(mTitle) +
    theme(legend.position = "none", axis.ticks = element_blank(), 
          plot.title = element_text(size = base_size * sizemain, hjust = 0.5, vjust = 2, 
                                    face = "bold"), 
          axis.text.x = element_text(size = base_size * sizecolumnlabels, 
                                     angle = columnangle, hjust = adjustcolumnlabels,
                                     vjust = 0.5, colour = "black"), 
          axis.text.y = element_text(size = base_size * sizerowlabels, angle = 0, 
                                     hjust = adjustrowlabels, colour = "black"), 
          axis.title.x = element_text(colour = "black", size = base_size * sizetitles, 
                                      vjust = 1, margin = margin(t = 5)), 
          axis.title.y = element_text(colour = "black", size = base_size * sizetitles, 
                                      vjust = 0, margin = margin(r = 10)), 
          axis.line.x = element_blank(), axis.line.y = element_blank(),
          panel.border = element_blank()) + 
    annotate(geom = "segment", x = 0.5, xend = d + 0.5, y = 0.5, yend = 0.5) + 
    annotate(geom = "segment", x = 0.5, xend = d + 0.5, y = n + 0.5, yend = n + 0.5) + 
    annotate(geom = "segment", x = 0.5, xend = 0.5, y = 0.5, yend = n + 0.5) +
    annotate(geom = "segment", x = d + 0.5, xend = d + 0.5, y = 0.5, yend = n + 0.5)
  if (!is.null(showcellvalues)) {
    txtcol <- mX$CatNr
    txtcol[txtcol == 0] <- "black"
    txtcol[txtcol == 1] <- "white"
    txtcol[txtcol == 2] <- "white"
    txtcol[txtcol == 4] <- "black"
    ggp = ggp + geom_text(aes(label = ifelse(is.na(data), 
                                             sprintf("%1.0f", data), round(data, 1))), size = base_size * 
                            sizecellvalues * 0.5, colour = txtcol, na.rm = TRUE)
  }
  return(ggp)
}

cellMap_new <- function(R, indcells = NULL, indrows = NULL, 
                        outrows = NULL, showcellvalues = NULL,
                        D = NULL, rowlabels = NULL, columnlabels = NULL, 
                        mTitle = "cell map", rowtitle = "cases", 
                        columntitle = "variables", 
                        showrows = NULL, showcolumns = NULL, 
                        nrowsinblock = NULL, 
                        ncolumnsinblock = NULL, 
                        manualrowblocksizes = NULL,
                        manualcolumnblocksizes = NULL,
                        rowblocklabels = NULL,
                        columnblocklabels = NULL,
                        sizemain = 1.5, sizetitles = 1.2, sizerowlabels = 1,
                        sizecolumnlabels = 1, sizecellvalues = 1, 
                        adjustrowlabels = 1, adjustcolumnlabels = 1,
                        columnangle = 90, 
                        colContrast = 1, outlyingGrad = TRUE, 
                        darkestColor = sqrt(qchisq(0.999, 1)), 
                        drawCircles = FALSE,
                        showVals = NULL, # only for backward compatibility
                        autolabel = TRUE # but will be ignored
) {
  
  colorBlocks <- function(Xin, rowblocksizes, columnblocksizes, 
                          colContrast) {
    # Auxiliary function, which mixes the colors of the cells
    # in each block.
    n <- length(rowblocksizes)
    d <- length(columnblocksizes)
    Xblock <- matrix(0, nrow = n, ncol = d)
    Xblockgrad <- matrix(0, nrow = n, ncol = d)
    rind <- cumsum(c(0,rowblocksizes))
    cind <- cumsum(c(0,columnblocksizes))
    for (i in seq_len(n)) {
      for (j in seq_len(d)) {
        # select the cells of Xin in the block (i,j):
        Xsel <- Xin[(rind[i]+1):rind[i+1],
                    (cind[j]+1):cind[j+1]]
        seltable <- tabulate(Xsel, nbins = 4)
        if (sum(seltable) > 0) {
          indmax <- which(seltable == max(seltable))[1]
          cntmax <- seltable[indmax]
          ncells <- rowblocksizes[i] * columnblocksizes[j] 
          gradmax <- (cntmax/ncells)^(1/colContrast)
        }
        else {
          indmax <- 0
          gradmax <- 1
        }
        Xblock[i, j] <- indmax
        Xblockgrad[i, j] <- gradmax
      }
    }
    return(list(X = Xblock, Xgrad = Xblockgrad))
  }
  
  isVectorInteger <- function(x, tol = .Machine$double.eps^0.5){
    y <- abs(x - round(x)) < tol 
    sum(1-y) == 0
  }
  
  # Here the main function starts
  variable <- rownr <- rescaleoffset <- x <- y <- NULL
  n <- nrow(R)
  d <- ncol(R)
  if (is.null(showcellvalues)) { showcellvalues <- showVals}
  if (!is.null(showcellvalues)) {
    if (!showcellvalues %in% c("D", "R")) {
      stop(paste("Invalid \"showcellvalues\" argument. Should be one of: NULL, \"D\", \"R\""))
    }
  }
  if (is.null(showcellvalues)) {
    D <- R
  } else if (showcellvalues == "D" & is.null(D)) {
    stop("When showcellvalues=\"D\" you must input the argument D")
  }
  if (is.null(D)) {
    D <- R
  } else { # D exists
    if (!all(dim(D) == dim(R))) 
      stop("The dimensions of D and R must match")
  }
  if (is.null(indcells)) {
    # indcells <- which(abs(R) > sqrt(qchisq(0.99, 1)))
    indcells <- which(abs(R) > sqrt(qchisq(0.998, 1)))
  }
  if (is.null(indrows) & is.null(outrows)){ drawCircles <- FALSE }
  
  if (!is.null(rowlabels)){ # rowlabels are given
    if (length(rowlabels) != n) {
      stop(paste0("Number of rowlabels does not match n = ",n))
    }
  } else { # no rowlabels are given
    if (is.null(rownames(R))) {
      rowlabels <- seq_len(n)
    } else { rowlabels <- rownames(R) }  
  } 
  if (!is.null(columnlabels)){ # columnlabels are given
    if (length(columnlabels) != d) {
      stop(paste0("Number of columnlabels does not match d = ",d))
    }
  } else { # no columnlabels are given
    if (is.null(colnames(R))) {
      columnlabels <- seq_len(d)
    } else { columnlabels <- colnames(R) }
  }
  # From here on we have n rowlabels and d columnnames. 
  # They are actually case names and variable names.
  
  
  if (!is.null(showcolumns) | !is.null(showrows)) {
    if (is.null(showrows)) {
      showrows <- seq_len(n)
    }
    else {
      if (!(all(showrows %in% seq_len(n))))
        stop(" showrows goes out of bounds")
    }
    if (is.null(showcolumns)) {
      showcolumns <- seq_len(d)
    }
    else {
      if (!(all(showcolumns %in% seq_len(d))))
        stop(" showcolumns goes out of bounds")
    }
    tempMat <- matrix(0, n, d)
    tempMat[indcells] <- 1
    tempMat <- tempMat[showrows, showcolumns]
    indcells <- which(tempMat == 1)
    tempVec <- rep(0, n)
    tempVec[indrows] <- 1
    tempVec <- tempVec[showrows]
    indrows <- which(tempVec == 1)
    rm(tempMat, tempVec)
    R <- R[showrows, showcolumns]
    D <- D[showrows, showcolumns]
    rowlabels <- rowlabels[showrows]
    columnlabels <- columnlabels[showcolumns]
    n <- nrow(R)
    d <- ncol(R)
    if (!is.null(outrows)) 
      outrows <- outrows[showrows]
  }
  
  blockRows <- blockColumns <- FALSE
  if (!is.null(manualrowblocksizes)) {
    if (!is.null(nrowsinblock)) {
      cat(paste0("Input argument manualrowblocksizes ",
                 "has overruled argument nrowsinblock.\n"))
      blockRows <- TRUE # the rows will be blocked
    }
    msg <- paste0(
      "manualrowblocksizes should be a vector with strictly \n",
      "  positive integers, adding up to at most n = ",n)
    if (!is.vector(manualrowblocksizes)) stop(msg)
    if (!is.numeric(manualrowblocksizes)) stop(msg)
    if (!isVectorInteger(manualrowblocksizes)) stop(msg)
    if (sum(manualrowblocksizes < 1) > 0) stop(msg)
    if (sum(manualrowblocksizes) > n) stop(msg)
    if (sum(manualrowblocksizes != 1) == 0 ) {
      stop("All manualrowblocksizes are 1") }
    blockRows <- TRUE # the rows will be blocked
  } else { # manualrowblocksizes was not specified
    if (!is.null(nrowsinblock)) {
      if (nrowsinblock > 1) {
        if (nrowsinblock > n) stop(paste0(
          "Input argument nrowsinblock cannot be ",
          "more than n = ",n))
        blockRows <- TRUE # the rows will be blocked
      }
    }
  }
  
  if(!is.null(manualcolumnblocksizes)) {
    if(!is.null(ncolumnsinblock)){
      cat(paste0("Input argument manualcolumnblocksizes ",
                 "has overruled argument ncolumnsinblock.\n"))
    }
    msg <- paste0(
      "manualcolumnblocksizes should be a vector with strictly \n",
      "  positive integers, adding up to at most d = ",d)
    if(!is.vector(manualcolumnblocksizes)) stop(msg)
    if(!is.numeric(manualcolumnblocksizes)) stop(msg)
    if(!isVectorInteger(manualcolumnblocksizes)) stop(msg)
    if(sum(manualcolumnblocksizes < 1) > 0) stop(msg)
    if(sum(manualcolumnblocksizes) > d) stop(msg)
    if(sum(manualcolumnblocksizes != 1) == 0 ) {
      stop("All manualcolumnblocksizes are 1") }
    blockColumns <- TRUE # the columns will be blocked
  } else {
    if (!is.null(ncolumnsinblock)){
      if(ncolumnsinblock > 1){
        if(ncolumnsinblock > d) stop(paste0(
          "Input argument ncolumnsinblock cannot be ",
          "more than d = ",d)) 
        blockColumns <- TRUE # the columns will be blocked
      }
    } 
  }
  
  if((blockRows | blockColumns) & !is.null(showcellvalues)) {
    warning(paste0(
      "The option showcellvalues=\"D\" or showcellvalues=\"R\" cannot be\n", 
      "combined with blocking rows and/or columns,\n", 
      "so showcellvalues is set to NULL here."))
    showcellvalues <- NULL
  }
  
  X <- matrix(0, n, d)
  Xrow <- matrix(0, n, 1) # one entry per row, for circles
  Xrow[indrows, 1] <- 3   # on the right hand side
  if (blockRows | blockColumns) { 
    pcells <- indcells[indcells %in% which(R >= 0)]
    ncells <- indcells[indcells %in% which(R < 0)]
  } else {
    pcells <- which(R >= 0)
    ncells <- which(R < 0)
  }
  X[ncells] <- 1
  X[pcells] <- 2
  X[is.na(R)] <- 4
  
  if (blockRows | blockColumns) { # starts blocked situation
    rowblocksizes <- rep(1,n)
    if(blockRows){
      if(!is.null(manualrowblocksizes)){
        rowblocksizes <- manualrowblocksizes
        n <- length(rowblocksizes)
      } else {
        if(!is.null(nrowsinblock)){
          if(nrowsinblock > 1){
            n <- floor(n/nrowsinblock)
            rowblocksizes <- rep(nrowsinblock,n)
          }  
        }
      }
    }
    columnblocksizes <- rep(1,d)
    if (blockColumns) {
      if(!is.null(manualcolumnblocksizes)){
        columnblocksizes <- manualcolumnblocksizes
        d <- length(columnblocksizes)
      } else {
        if(!is.null(ncolumnsinblock)){
          if(ncolumnsinblock > 1){
            d <- floor(d/ncolumnsinblock)
            columnblocksizes <- rep(ncolumnsinblock,d)
          }
        }
      }
    }
    
    # For coloring the blocks inside the matrix:
    result <- colorBlocks(X, rowblocksizes, columnblocksizes,
                          colContrast)
    X <- result$X
    Xgrad <- result$Xgrad
    if(drawCircles){
      # For coloring (in grey) the circles on the right:
      result <- colorBlocks(Xrow, rowblocksizes, c(1), colContrast)
      Xrowgrad <- result$Xgrad
      Xrowgrad[result$X == 0] <- 0
    }
    
    # Now label the blocks as if they were cells:
    if (blockRows){
      if(is.null(rowblocklabels)){
        cat(paste0("No rowblocklabels were given, so they ", 
                   "are constructed automatically.\n"))
        laby <- rowlabels
        rowlabels <- rep(0, n) # this is the new (smaller) n
        rind <- cumsum(c(0,rowblocksizes))
        for (i in seq_len(n)) {
          if(rowblocksizes[i] == 1){
            rowlabels[i] <- laby[rind[i]+1]
          } else {
            rowlabels[i] <- paste0(
              laby[rind[i]+1],"-",laby[rind[i+1]])
          }
        }
      } else { # the user has given rowblocklabels
        if (length(rowblocklabels) != n) {
          stop(paste0("The number of rowblocklabels is ", 
                      length(rowblocklabels), 
                      " but there are ",n," row blocks."))
        }        
        rowlabels <- rowblocklabels
      }
    }
    if (blockColumns) {
      if(is.null(columnblocklabels)){
        cat(paste0("No columnblocklabels were given, so they ",
                   "are constructed automatically.\n"))
        labx <- columnlabels
        columnlabels <- rep(0, d)
        cind <- cumsum(c(0,columnblocksizes))
        for (j in seq_len(d)) {
          if(columnblocksizes[j] == 1){
            columnlabels[j] <- labx[cind[j]+1]
          } else {
            columnlabels[j] <- paste0(
              labx[cind[j]+1],"-",labx[cind[j+1]])
          }
        }
      } else { # the user has given columnblocklabels
        if (length(columnblocklabels) != d) {
          stop(paste0("The number of columnblocklabels is ", 
                      length(columnblocklabels), 
                      " but there are ",d," column blocks."))
        }
        columnlabels <- columnblocklabels
      }        
    } 
    # From here on the blocks are treated as cells,
    # with lower n and d, and with their own labels.
    
    Xdf <- data.frame(cbind(seq(1, n, 1), X))
    colnames(Xdf) <- c("rownr", seq(1, d, 1))
    rownames(Xdf) <- NULL
    Xdf$rownr <- with(Xdf, reorder(rownr, seq(n, 1, -1)))
    mX <- reshape2::melt(Xdf, id.var = "rownr", value.name = "CatNr")
    Xgraddf <- data.frame(cbind(seq(1, n, 1), Xgrad))
    colnames(Xgraddf) <- c("rownr", seq(1, d, 1))
    rownames(Xgraddf) <- NULL
    Xgraddf$rownr <- with(Xgraddf, reorder(rownr, seq(n, 1, -1)))
    mXgrad <- reshape2::melt(Xgraddf, id.var = "rownr", value.name = "grad")
    mX$grad <- mXgrad$grad
    mX$rescaleoffset <- mXgrad$grad + 10 * mX$CatNr
    if(drawCircles){
      mXrow <- data.frame(rownr = seq_len(n), 
                          rescaleoffset = Xrowgrad + 10 * 3)
    }
    scalerange <- c(0, 1)
    gradientends <- scalerange + rep(c(0, 10, 20, 30, 40), each = 2)
    colorends <- c("yellow", "yellow", "yellow", 
                   "blue", "yellow", "red", "white", 
                   "black", "yellow", "white")
    # ends blocked situation
  } else { # no blocking
    Ddf <- data.frame(cbind(seq(1, n, 1), D))
    colnames(Ddf) <- c("rownr", seq(1, d, 1))
    rownames(Ddf) <- NULL
    Ddf$rownr <- with(Ddf, reorder(rownr, seq(n, 1, -1)))
    mD <- reshape2::melt(Ddf, id.var = "rownr")
    Rdf <- data.frame(cbind(seq(1, n, 1), R))
    colnames(Rdf) <- c("rownr", seq(1, d, 1))
    rownames(Rdf) <- NULL
    Rdf$rownr <- with(Rdf, reorder(rownr, seq(n, 1, -1)))
    mR <- reshape2::melt(Rdf, id.var = "rownr")
    Xdf <- data.frame(cbind(seq(1, n, 1), X))
    colnames(Xdf) <- c("rownr", seq(1, d, 1))
    rownames(Xdf) <- NULL
    Xdf$rownr <- with(Xdf, reorder(rownr, seq(n, 1, -1)))
    mX <- reshape2::melt(Xdf, id.var = "rownr", value.name = "CatNr")
    if (!is.null(showcellvalues)) {
      if (showcellvalues == "D") 
        mX$data <- mD$value
      if (showcellvalues == "R") 
        mX$data <- mR$value
    }
    if (!outlyingGrad) {
      mX$rescaleoffset <- 10 * mX$CatNr
      scalerange <- c(0, 1)
      gradientends <- scalerange + rep(c(0, 10, 20, 30, 40), each = 2)
      gradientends
      colorends <- c("yellow", "yellow", "blue", 
                     "blue", "red", "red", "white", 
                     "black", "white", "white")
    } else { # if outlyingGrad
      Xgrad <- matrix(NA, n, d)
      Xgrad[indcells] <- abs(R[indcells])
      limL <- sqrt(qchisq(0.998, 1))
      limH <- darkestColor
      Xgrad[Xgrad > limH] <- limH
      Xgrad <- ((Xgrad - limL)/(limH - limL))^colContrast
      Xgrad[is.na(Xgrad)] <- 0
      Xgraddf <- data.frame(cbind(seq(1, n, 1), Xgrad))
      colnames(Xgraddf) <- c("rownr", seq(1, d, 1))
      rownames(Xgraddf) <- NULL
      Xgraddf$rownr <- with(Xgraddf, reorder(rownr, seq(n, 1, -1)))
      mXgrad <- reshape2::melt(Xgraddf, id.var = "rownr", value.name = "grad")
      mX$grad <- mXgrad$grad
      mX$rescaleoffset <- mXgrad$grad + 10 * mX$CatNr
      scalerange <- c(0, 1)
      gradientends <- scalerange + rep(c(0, 10, 20, 30, 40), each = 2)
      colorends <- c("yellow", "yellow", 
                     "yellow", "blue", "yellow", 
                     "red", "white", "black", 
                     "white", "white")
    } # ends outlyingGrad
    
    if(drawCircles){
      tempVec <- rep(0, n)
      tempVec[indrows] <- 1
      mXrow <- data.frame(rownr = seq_len(n), rescaleoffset = 40 - 
                            (10 * tempVec))
      rm(tempVec)
      if (is.null(outrows)) {
        mXrow$rescaleoffset[indrows] <- mXrow$rescaleoffset[indrows] + 1
      } else { # if there is an outrows
        limL <- 1
        limH <- 3
        outrows[outrows > limH] <- limH
        outrows <- ((outrows - limL)/(limH - limL))^colContrast
        mXrow$rescaleoffset[indrows] <- mXrow$rescaleoffset[indrows] + 
          outrows[indrows]
      } # ends outrows
    } # ends drawCircles
  } # ends unblocked situation
  
  if (drawCircles) { # Xrow is only used here
    circleFun <- function(centerx, centery, r, npoints) {
      tt <- seq(0, 2 * pi, length.out = npoints)
      xx <- centerx + r * cos(tt)
      yy <- centery + r * sin(tt)
      return(c(xx, yy))
    }
    columnlabels <- c(columnlabels, "", "") 
    # else it ends in the plot with NA NA when d+2
    # or still NA now it was changed to d+1
    centerx <- d + 1
    centery <- n:1
    radius <- 0.4
    npoints <- 100
    circlePoints <- mapply(circleFun, centerx, centery, radius, 
                           npoints)
    positions <- data.frame(rownr = rep(seq_len(n), each = npoints), 
                            x = c(circlePoints[seq_len(npoints), ]), y = c(circlePoints[(npoints + 
                                                                                           1):(2 * npoints), ]))
    datapoly <- merge(mXrow, positions, by = c("rownr"))
  } # ends if(drawCircles)
  
  rowlabels <- rev(rowlabels)
  base_size <- 10
  
  ##### Here ggplot starts
  
  ggp <- ggplot(data = mX, aes(variable, rownr)) + {
    geom_tile(aes(fill = scales::rescale(rescaleoffset, from = range(gradientends))), 
              color = "white")  } +
    { if (drawCircles){ 
      geom_polygon(data = datapoly, aes(x = x, y = y, fill = scales::rescale(rescaleoffset, from = range(gradientends)), group = rownr), colour = "black")} } + 
    scale_fill_gradientn(colours = colorends, values = scales::rescale(gradientends), 
                         rescaler = function(x, ...) x, oob = scales::squish) + coord_fixed() + theme_classic(base_size = base_size * 
                                                                                                                1) + labs(x = columntitle, y = rowtitle) + 
    { if(drawCircles){ scale_x_discrete(expand = c(0,0), limits = as.factor(seq(1, d+1 , 1)), labels = columnlabels) } else { scale_x_discrete(expand = c(0,0), limits = as.factor(seq(1, d , 1)), labels = columnlabels) } } + 
    scale_y_discrete(expand = c(0, 0), labels = rowlabels) + 
    ggtitle(mTitle) + 
    theme(legend.position = "none", axis.ticks = element_blank(), 
          plot.title = element_text(size = base_size * sizemain,
                                    hjust = 0.5, vjust = 1, face = "bold"),
          axis.text.x = element_text(size = base_size * sizecolumnlabels, 
                                     angle = columnangle, hjust = adjustcolumnlabels, 
                                     vjust = 0.5, colour = "black"), axis.text.y = element_text(size = base_size * sizerowlabels, angle = 0, hjust = adjustrowlabels, colour = "black"), 
          axis.title.x = element_text(colour = "black", 
                                      size = base_size * sizetitles, vjust = 1), axis.title.y = element_text(colour = "black",                                                                                                              size = base_size * sizetitles, vjust = 0), axis.line.x = element_blank(), 
          panel.border = element_blank()) + annotate(geom = "segment", 
                                                     x = 0.5, xend = d + 0.5, y = 0.5, yend = 0.5) + annotate(geom = "segment", 
                                                                                                              x = 0.5, xend = d + 0.5, y = n + 0.5, yend = n + 0.5) + 
    annotate(geom = "segment", x = d + 0.5, xend = d + 
               0.5, y = 0.5, yend = n + 0.5) 
  if (!is.null(showcellvalues)) {
    txtcol <- mX$CatNr
    txtcol[txtcol == 0] <- "black"
    txtcol[txtcol == 1] <- "white"
    txtcol[txtcol == 2] <- "white"
    txtcol[txtcol == 4] <- "black"
    ggp = ggp + geom_text(aes(label = ifelse(is.na(data), sprintf("%1.0f", data), round(data, 1))), 
                          size = base_size * sizecellvalues * 0.5, colour = txtcol, na.rm = TRUE)
  }
  return(ggp)
}
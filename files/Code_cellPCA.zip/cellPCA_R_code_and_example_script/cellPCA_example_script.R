
# Example script for the cellPCA method.

rm(list = ls()); 
setwd(dirname(rstudioapi::getSourceEditorContext()$path))

library(rrcov) # for ionosphere dataset
library(cellWise)
library(ggplot2)
library(purrr)
library(dplyr)
library(tidyr)

source("cellPCA_code.R")

## Ionosphere data (n=225, p = 32)
## (Section 3 of the paper)
################################## 

data("ionosphere")
X_orig <- ionosphere[ionosphere$Class == "good", 
                         -c(1, 2, 35)]
rownames(X_orig) = 1:225
# put variables in usual order, first odd then even:
order_var <- c(seq(1, 31, 2), seq(2, 32, 2))
X <- X_orig[, order_var]


## Select the subspace dimension:
ionorank <- select_q(as.matrix(X), 1:3, 
                     ncores = 5, plot = T, fev = 0.8) 
( q <- ionorank$q ) # gives q = 2


## Run cellPCA:
ionoCellPCA <- cellPCA(as.matrix(X), q = 2, trace = F)


## Enhanced outlier map (Figure 6 in paper):
outlier <- enh.outliermap(ionoCellPCA, cutoffOD = NULL, 
                          n_clean = 1000, id = 0)
outlier$cutoffOD # 7.309655

# now with labels added
sel <- c(79, 37, 156, 119, 40, 172)
( df <- data.frame(x = outlier$SD[sel], y = outlier$OD[sel], 
                 text = as.character(sel)) )
#             x         y text
# 79  0.1048495  1.856296   79
# 37  7.2233079  2.650680   37
# 156 6.7193745 31.677192  156
# 119 2.0706246 15.269527  119
# 40  9.9834510 15.515608   40
# 172 5.5967598 68.677393  172

{
outlier$plot + 
    geom_text(x = 0,  y = 0, label = "79", color = "blue", size = 5) +
    geom_text(x = 7.6,  y = 2.65, label = "37", color = "blue", size = 5) +
    geom_text(x = 7.2,  y = 32, label = "156", color = "blue", size = 5) + 
    geom_text(x = 2,  y = 18, label = "119", color = "blue", size = 5) +
    geom_text(x = 10.2,  y = 18, label = "40", color = "blue", size = 5) +
    geom_text(x = 5.1,  y = 70, label = "172", color = "blue", size = 5) 
ggsave("ionos_outliermap.pdf", width = 8, height = 7)
}


## Maps of curves (Figure 4 in paper)

# Create data frames for each set
sel <-  c(119, 40, 172, 79, 37, 156)
X_long <- data.frame(ID = rep(sel, each = 32), index = rep(1:32, length(sel)), X_value = as.vector(t(X[sel, 1:32])))
Xfit_long <- data.frame(ID = rep(sel, each = 32), index = rep(1:32, length(sel)), Xfit_value = as.vector(t(ionoCellPCA$Xfit[sel, ])))
Ximp_long <- data.frame(ID = rep(sel, each = 32), index = rep(1:32, length(sel)), Ximp_value = as.vector(t(ionoCellPCA$Ximp[sel, ])))

# Combine all data into a single data frame
combined_data <- left_join(X_long, Xfit_long, by = c("ID", "index"))
combined_data <- left_join(combined_data, Ximp_long, by = c("ID", "index"))
combined_data$ID <- factor(combined_data$ID, levels = as.character(sel))

# Create a new column to indicate the data type
combined_data_long <- combined_data %>%
  pivot_longer(cols = c(X_value, Xfit_value, Ximp_value), names_to = "type", values_to = "value")

# Replace type names with custom labels
combined_data_long$type <- recode(combined_data_long$type,
                                  "X_value" = "observed",
                                  "Xfit_value" = "fitted",
                                  "Ximp_value" = "imputed")

{
  # observed and fitted and imputed
  p <- ggplot(combined_data_long, aes(x = index)) +
    geom_line(data = subset(combined_data_long, type == "observed"), aes(y = value, color = "observed"), size = 1.7) +
    geom_line(data = subset(combined_data_long, type == "fitted"), aes(y = value, color = "fitted"), size = 1.5) +
    geom_line(data = subset(combined_data_long, type == "imputed"), aes(y = value, color = "imputed"), linetype = "dashed", size = 1.5) +
    scale_color_manual(values = c("observed" = "purple", 
                                  "fitted" = rgb(46/225, 170/255, 87/255, alpha = 0.9), 
                                  "imputed" = "orange"),
                       labels = c("observed" = "Observed", "fitted" = "Fitted", "imputed" = "Imputed")) +
    labs(x = "", y = "", color = "") +
    facet_wrap(~ID, scales = "fixed", ncol = 3) +
    #theme_minimal() +
    theme(
      strip.background = element_rect(fill = "grey80", color = NA),
      strip.text = element_text(size = 20, face = "bold"),
      legend.position = "bottom",
      legend.text = element_text(size = 20),
      axis.text.x =  element_text(size = 18),
      axis.text.y =  element_text(size = 18),
    )  +
    ylim(-1.6, 2)
  
  # Print the plot
  print(p)
}  
ggsave("ionos_curves.pdf", width = 16, height = 9)
dev.off()

## Cellmap of the selected points (Figure 5 in paper)

pdf("ionos_cellmap.pdf", width = 12, height = 7)
sel_iono <-  c(79, 37, 156, 119, 40, 172)
outrows <- 2*(1 - ionoCellPCA$weights_r) + 1
cellMap(ionoCellPCA$Ri_std, 
        columnlabels = 1:dim(X)[2],
        sizecolumnlabels = 1.2,
        rowlabels =  1:dim(X)[1],
        sizerowlabels = 1.2, 
        columntitle = "",
        showrows = sel_iono,
        rowtitle =  "", 
        sizemain = 2, 
        mTitle = paste0("cellPCA residual cellmap"),
        indrows = sel_iono,
        drawCircles = T,
        showcellvalues  = NULL, 
        outrows = outrows, 
        colContrast = 1,
        darkestColor = 6)  
dev.off()


## Detailed plots in Section I of Supplementary Material:

# case 119:

ionoCellPCA$weights_c[119, ]
{
  pdf("ionos_119.pdf", width = 8, height = 7)
  i = 1
  sel_var <- 17:24
  plot(sel_var, X[sel[i], sel_var, drop = F], 
       col="purple", type = "o", xlab = "", ylab = "", 
       main = "Observation 119", 
       ylim = c(-1.1, 0.5), lwd = 3)
  for (j in 1:length(sel_var))
    abline(v = sel_var[j], lty = 3, col = "grey", lwd = 1)
  axis(3, at = sel_var, labels = round(ionoCellPCA$weights_c[119, sel_var], digits = 2), line = -4.6, tick = FALSE)
  text(24.5, 0.36, labels=expression(w^c), xpd = TRUE)
  lines(sel_var, ionoCellPCA$Xfit[sel[i], sel_var], lwd = 3, 
        col = rgb(46/225, 170/255, 87/255, alpha = 0.9), 
        type = "o")
  lines(sel_var, ionoCellPCA$Ximp[sel[i], sel_var], col = "orange", lty = 2, lwd = 3, type = "o")
  dev.off()
}

# case 156:

ionoCellPCA$weights_c[156, ]
{
  pdf("ionos_156.pdf", width = 8, height = 7)
  sel <-  c(119, 40, 172, 79, 37, 156)
  i <- 6
  sel_var <- 21:28
  plot(sel_var, X[sel[i], sel_var, drop = F], col="purple", type = "o", xlab = "", ylab = "", main = "Observation 156", ylim = c(0.1, 1.4), lwd = 3, yaxt = "n")
  for (j in 1:length(sel_var))
    abline(v = sel_var[j], lty = 3, col = "grey", lwd = 1)
  axis(3, at = sel_var, labels = round(ionoCellPCA$weights_c[sel[i], sel_var], digits = 2), line = - 4.5, tick = FALSE)
  text(28.5, 1.3, labels=expression(w^c), xpd = TRUE)
  lines(sel_var, ionoCellPCA$Xfit[sel[i], sel_var], lwd = 3, 
        col = rgb(46/225, 170/255, 87/255, alpha = 0.9), 
        type = "o")
  lines(sel_var, ionoCellPCA$Ximp[sel[i], sel_var], col = "orange", lty = 2, lwd = 3, type = "o")
dev.off()
}

#################################################

## Solfatara data (n=205, p = 40000)
## (Section 7 of the paper)
#################################### 

rm(list = ls()); 
source("cellPCA_code.R")

# The file "solfatara.RData" can be dowloaded from
# https://figshare.com/s/82bcfb64d5130712aeef?file=48764191
# Load the data
load(file = "solfatara.RData")
# This produces X

# # Running cellPCA takes rather long, so we do it once
# # and save the result:
# solfaCellPCA<- cellPCA(X, q = 2, trace = FALSE,
#                      nu=10^-6, max_iter = 100)
# save(solfaCellPCA, file = "outsolfatara.RData")
load(file = paste0("outsolfatara.RData"))
# loads solfaCellPCA 

# Run only once, to compute cutoffOD, the cutoff for
# the horizontal line in the enhanced outlier map:
# outlier <- enh.outliermap(solfaCellPCA, cutoffOD = NULL, 
#                           id = 0, n_clean = 100)
# outlier$cutoffOD # 204.8372

outlier <- enh.outliermap(solfaCellPCA, id=0, 
                          cutoffOD = 204.8372)
# Two cases that will be studied below:
sel = c(14, 203)
ID = cbind(outlier$SD, outlier$OD)
ID[sel,]
# [1,] 1.434541 502.2649
# [2,] 3.110903 512.4504

## Outlier map with labels (Figure 11 in the paper):
{
  outlier <- enh.outliermap(solfaCellPCA, cutoffOD = 204.8372, 
                            id = 0)
  outlier$plot + 
    geom_text(x = 1.58, y = 503, label = "14", color = "blue", size = 5) +
    geom_text(x = 3.33, y = 513, label = "203", color = "blue", size = 5)
  ggsave("solfa_outliermap.pdf", width = 8, height = 7)
  dev.off()
}


## Images and residual cellmaps for frames 14 and 203
## (Figures 12 and 20 in the paper):

sel=c(14, 203)

## the frames themselves

dim(X) # 205 40000
# For each case, the standardized residuals are in
# a row of this matrix with 40,000 entries. To turn 
# them into images we use the following function:

mattolist<-function(X,res){
  # X has n very long rows of length res^2 .
  # This function turns X into a list of n matrices
  # (images) that each have: res columns and res rows.
  # 
  fit_list<-list()
  for (ii in 1:dim(X)[1]) {
    fit_list[[ii]]<-matrix(X[ii,],res,res)
  }
  return(fit_list)
}

res<-200
# Put the frames in a list:
data_list_down<-mattolist(X,res)
# This is a list of n square matrices.
#
for (ii in sel) {
  pdf(paste0("solfa_",ii,"_data.pdf"),width = 6,height = 6)
  par(mar = c(5, 4, 2, 2))
  plot3D::image2D(t((data_list_down[[ii]])),main=paste0("Observed frame ", ii),xaxt="n",xlab="",ylab="",yaxt="n",zlim=c(-15,50))
  dev.off()
}


## the fitted frames

pred_list<-mattolist(solfaCellPCA$Xfit,res)
#
for (ii in sel) {
  pdf(paste0("solfa_",ii,"_pred.pdf"),width = 6,height = 6)
  par(mar = c(5, 4, 2, 2))
  plot3D::image2D(t((pred_list[[ii]])),main=paste0("Predicted frame ", ii),xaxt="n",xlab="",ylab="",yaxt="n",zlim=c(-15,50))
  dev.off()
}


## the residual cellmaps:

R_mat_list <- mattolist(solfaCellPCA$Ri_std,res)
#
for (ii in sel) {
  Risel = R_mat_list[ii][[1]]
  # dim(Risel) # 200 200
  Risel = Risel[200:1,1:200] # else image is upside down
  pdf(paste0("solfa_",ii,"_cellmap.pdf"), width = 6.5, height = 6)
  print(cellMap(Risel*0.7,
        columntitle = "",
        rowtitle =  "", 
        nrowsinblock = 2,
        ncolumnsinblock = 2,
        rowblocklabels = rep("",100),
        columnblocklabels = rep("",100),
        sizemain = 1.5, 
        mTitle = paste0("cellPCA residual cellmap of frame ",ii),
        drawCircles = F,
        showcellvalues = NULL, 
        colContrast = 1.0,
        darkestColor = 100) )
dev.off()
}

#######################################################
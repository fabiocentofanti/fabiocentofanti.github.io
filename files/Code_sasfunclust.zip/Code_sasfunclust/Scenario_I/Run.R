
###############################################################################################
######################### RUN #################################################################
###############################################################################################



# In this form, this implementation takes around 12 hours to complete on a server where each node has two 24 cores Intel(R) Xeon(R) Platinum 8160 with clock frequency of 2.10GHz.
# Therefore, to run this script on a less powerful system, we suggest to modify the script to reduce the computational cost.
# For instance, either the size of CV search grids and the maxit for the Sas-Funclust method could be decreased or only the computation with fixed G could be considered...


##Load libraries and functions
library(fda.usc)
library(parallel)
library(clValid)
library(mclust)
library(factoextra)
# install.packages("sasfunclust")
library(sasfunclust)
# install.packages("curvclust_0.0.1.tar.gz", repos = NULL, type="source"), the package could be downloaded from https://cran.r-project.org/src/contrib/Archive/curvclust/
library(curvclust)
library(funHDDC)
library(matrixcalc)
source("functions_competitors.R")
source("utils.R")


##Fix simulation parameters
sd_vec<-c(1,1.5,2,2.5,3)
sd_2_vec<-c(0.5,1)
sd_i<-1
sd_2_i<-1
scenario_i<-1
n_i=100

scenario_vec=c("Scenario I","Scenario II","Scenario III","Scenario IV")

###Generate the data
train<-simulate_data(scenario_vec[scenario_i],n_i=n_i,length_tot = 50,var_e=sd_vec[sd_i]^2,var_b = sd_2_vec[sd_2_i]^2)
G=dim(train$mu_fd$coefs)[2]
clus_true<-rep(1:G,each=n_i)
n_obs<-dim(train$X)[2]


# Sas-Funclust-------------------------------------------------------
lambda_s_seq=10^seq(-7,-2,by=1)
lambda_l_seq=10^seq(0,4,by=0.25)
mod_sasfunclust_cv<-sasfclust_cv(X=as.numeric(vec(train$X)),timeindex=rep(1:length(train$grid),n_obs),curve=rep(1:n_obs,each=length(train$grid)),
                               lambda_l_seq = lambda_l_seq,lambda_s_seq =lambda_s_seq,G_seq = 1:5,
                               K_fold = 5,grid = train$grid,maxit=500,q=30,trace=FALSE,m1=0.5,m3 = 0.5,ncores = detectCores())


mod_sasfunclust=sasfclust(X=as.numeric(vec(train$X)),timeindex=rep(1:length(train$grid),n_obs),curve=rep(1:n_obs,each=length(train$grid)),
                               lambda_s = mod_sasfunclust_cv$lambda_s_opt,lambda_l = mod_sasfunclust_cv$lambda_l_opt,G = mod_sasfunclust_cv$G_opt,
                               grid = train$grid,maxit=500,q=30)
measure_sasfunclust=get_measure( clus_true,mod_sasfunclust$clus$classes)[3]
RMSE_sasfunclust=get_RMSE(mod_sasfunclust$mean_fd,train$mu_fd)

G_sasfunclust<-mod_sasfunclust_cv$G
# Sas-Funclust with fixed G-------------------------------------------------------
mod_cv_fG<-sasfunclust_fG(mod_sasfunclust_cv,K_fixed = G)
mod_sparse_fG=sasfclust(X=as.numeric(vec(train$X)),timeindex=rep(1:length(train$grid),n_obs),curve=rep(1:n_obs,each=length(train$grid)),
                             lambda_s = mod_cv_fG$lambda_s_opt,lambda_l = mod_cv_fG$lambda_l_opt,G =G,
                             grid = train$grid,maxit=500,q=30)
measure_sasfunclust_fG=get_measure( clus_true,mod_sparse_fG$clus$classes)[3]
RMSE_sasfunclust_fG=get_RMSE(mod_sparse_fG$mean_fd,train$mu_fd)
pairwise_zero<-get_pairwise_zero(scenario_vec[scenario_i],mu_hat = mod_sparse_fG$mean_fd,mu_fd = train$mu_fd)



# Curvclust ---------------------------------------------------------------
print("curveclust")
mod_curvclust_cv<-curvclust_ms(train,num_cluster_seq=1:5)
mod_curvclust<-curvclust(train,mod_curvclust_cv$par_opt_BIC)
measure_curvclust=get_measure( clus_true,mod_curvclust$cluster)[3]
RMSE_curvclust=get_RMSE(mod_curvclust$mean_fd,train$mu_fd)
G_curvclust<-mod_curvclust_cv$par_opt_BIC

# Curvclust with fixed G ---------------------------------------------------------------
mod_curvclust_fG<-curvclust(train,G)
measure_curvclust_fG=get_measure( clus_true,mod_curvclust_fG$cluster)[3]
RMSE_curvclust_fG=get_RMSE(mod_curvclust_fG$mean_fd,train$mu_fd)

# funHDDC -----------------------------------------------------------------
print("funHDDC")
mod_funHDDC_cv<-fit_funHDDC_ms(train,num_cluster_seq=1:5,threshold_seq=c(0.2,0.5,0.9,0.95))# FunHDCC could have inizialization problem, if it is so you should re-run the function
mod_funHDDC<-mod_funHDDC_cv$mod_opt
measure_funHDDC=get_measure( clus_true,mod_funHDDC$class)[3]
RMSE_funHDDC=get_RMSE(mod_funHDDC$mean_fd,train$mu_fd)
G_funHDDC<-mod_funHDDC$K




# funHDDC fixed G -----------------------------------------------------------------
print("funHDDC_fG")
mod_funHDDC_fG_cv<-fit_funHDDC_ms(train,num_cluster_seq=G,threshold_seq=c(0.2,0.5,0.9,0.95))# FunHDCC could have inizialization problem, if it is so you should re-run the function
mod_funHDDC_fG<-mod_funHDDC_fG_cv$mod_opt
measure_funHDDC_fG=get_measure( clus_true,mod_funHDDC_fG$class)[3]
RMSE_funHDDC_fG=get_RMSE(mod_funHDDC_fG$mean_fd,train$mu_fd)




# Distance-based ----------------------------------------------------------
print("Distance-based")
mod_dist_cv<-distance_ms(train,num_cluster_seq=2:5,met="sil")
mod_dist<-mod_dist_cv$mod_opt_sil
measure_dist=get_measure( clus_true,mod_dist$clus)[3]
RMSE_dist=get_RMSE(mod_dist$mean_fd,train$mu_fd)
G_dist<-dim(mod_dist$mean_fd$coefs)[2]

# Distance-based fixed G----------------------------------------------------------
print("Distance-based_fG")
mod_dist_fG_cv<-distance_ms(train,num_cluster_seq=G,met="sil")
mod_dist_fG<-mod_dist_fG_cv$mod_opt_sil
measure_dist_fG=get_measure( clus_true,mod_dist_fG$clus)[3]
RMSE_dist_fG=get_RMSE(mod_dist_fG$mean_fd,train$mu_fd)


# Filtering B-spline ------------------------------------------------------
print("Filtering B-spline")
mod_bspline_cv<-try(fil_bspline_ms_nclust(train,num_cluster_seq=2:5,nbasis=30),TRUE)# if the number of basis is too large to cause the problem to be ill-conditioned, it is reduced
if(class(mod_bspline_cv)=="try-error")mod_bspline_cv<-try(fil_bspline_ms_nclust(train,num_cluster_seq=2,nbasis=20),TRUE)
if(class(mod_bspline_cv)=="try-error")mod_bspline_cv<-try(fil_bspline_ms_nclust(train,num_cluster_seq=2,nbasis=10),TRUE)
if(class(mod_bspline_cv)=="try-error")mod_bspline_cv<-try(fil_bspline_ms_nclust(train,num_cluster_seq=2,nbasis=5),TRUE)
measure_bspline_hc=get_measure( clus_true,mod_bspline_cv$mod_opt$hc$cluster)[3]
measure_bspline_km=get_measure( clus_true,mod_bspline_cv$mod_opt$km$cluster)[3]
measure_bspline_mb=get_measure( clus_true,mod_bspline_cv$mod_opt$mb$classification)[3]

RMSE_bspline_hc=get_RMSE(mod_bspline_cv$mean_fd$hc,train$mu_fd)
RMSE_bspline_km=get_RMSE(mod_bspline_cv$mean_fd$km,train$mu_fd)
RMSE_bspline_mb=get_RMSE(mod_bspline_cv$mean_fd$mb,train$mu_fd)

G_bspline_hc=dim(mod_bspline_cv$mean_fd$hc$coefs)[2]
G_bspline_km=dim(mod_bspline_cv$mean_fd$km$coefs)[2]
G_bspline_mb=dim(mod_bspline_cv$mean_fd$mb$coefs)[2]
mod_bspline_cv<-fil_bspline_ms_nclust(train,num_cluster_seq=2,nbasis=5)# nbasis=5 for B-FMM because better performance
measure_bspline_mb=get_measure( clus_true,mod_bspline_cv$mod_opt$mb$classification)[3]
RMSE_bspline_mb=get_RMSE(mod_bspline_cv$mean_fd$mb,train$mu_fd)
G_bspline_mb=dim(mod_bspline_cv$mean_fd$mb$coefs)[2]

# Filtering B-spline fixed G ------------------------------------------------------
print("Filtering B-spline_fG")
mod_bspline_fG_cv<-try(fil_bspline_ms_nclust(train,num_cluster_seq=G,nbasis=30),TRUE)# if the number of basis is too large to cause the problem to be ill-conditioned, it is reduced
if(class(mod_bspline_fG_cv)=="try-error")mod_bspline_fG_cv<-try(fil_bspline_ms_nclust(train,num_cluster_seq=G,nbasis=20),TRUE)
if(class(mod_bspline_fG_cv)=="try-error")mod_bspline_fG_cv<-try(fil_bspline_ms_nclust(train,num_cluster_seq=G,nbasis=10),TRUE)
if(class(mod_bspline_fG_cv)=="try-error")mod_bspline_fG_cv<-try(fil_bspline_ms_nclust(train,num_cluster_seq=G,nbasis=5),TRUE)

measure_bspline_hc_fG=get_measure( clus_true,mod_bspline_fG_cv$mod_opt$hc$cluster)[3]
measure_bspline_km_fG=get_measure( clus_true,mod_bspline_fG_cv$mod_opt$km$cluster)[3]
measure_bspline_mb_fG=get_measure( clus_true,mod_bspline_fG_cv$mod_opt$mb$classification)[3]

RMSE_bspline_hc_fG=get_RMSE(mod_bspline_fG_cv$mean_fd$hc,train$mu_fd)
RMSE_bspline_km_fG=get_RMSE(mod_bspline_fG_cv$mean_fd$km,train$mu_fd)
RMSE_bspline_mb_fG=get_RMSE(mod_bspline_fG_cv$mean_fd$mb,train$mu_fd)

mod_bspline_fG_cv<-fil_bspline_ms_nclust(train,num_cluster_seq=G,nbasis=5)# nbasis=5 for B-FMM because better performance
measure_bspline_mb_fG=get_measure( clus_true,mod_bspline_fG_cv$mod_opt$mb$classification)[3]
RMSE_bspline_mb_fG=get_RMSE(mod_bspline_fG_cv$mean_fd$mb,train$mu_fd)

# Filtering FPCA ----------------------------------------------------------
print("Filtering FPCA")
mod_fpca_cv<-fil_fpca_ss_nbclust(train,num_cluster_seq=2:5,per_comp=0.95)
measure_fpca_hc=get_measure( clus_true,mod_fpca_cv$mod_opt$hc$cluster)[3]
measure_fpca_km=get_measure( clus_true,mod_fpca_cv$mod_opt$km$cluster)[3]
measure_fpca_mb=get_measure( clus_true,mod_fpca_cv$mod_opt$mb$classification)[3]

RMSE_fpca_hc=get_RMSE(mod_fpca_cv$mean_fd$hc,train$mu_fd)
RMSE_fpca_km=get_RMSE(mod_fpca_cv$mean_fd$km,train$mu_fd)
RMSE_fpca_mb=get_RMSE(mod_fpca_cv$mean_fd$mb,train$mu_fd)
G_fpca_hc=dim(mod_fpca_cv$mean_fd$hc$coefs)[2]
G_fpca_km=dim(mod_fpca_cv$mean_fd$km$coefs)[2]
G_fpca_mb=dim(mod_fpca_cv$mean_fd$mb$coefs)[2]

# Filtering FPCA fixed G----------------------------------------------------------
print("Filtering FPCA_fG")
mod_fpca_fG_cv<-fil_fpca_ss_nbclust(train,num_cluster_seq=G,per_comp=0.95)
measure_fpca_hc_fG=get_measure( clus_true,mod_fpca_fG_cv$mod_opt$hc$cluster)[3]
measure_fpca_km_fG=get_measure( clus_true,mod_fpca_fG_cv$mod_opt$km$cluster)[3]
measure_fpca_mb_fG=get_measure( clus_true,mod_fpca_fG_cv$mod_opt$mb$classification)[3]
RMSE_fpca_hc_fG=get_RMSE(mod_fpca_fG_cv$mean_fd$hc,train$mu_fd)
RMSE_fpca_km_fG=get_RMSE(mod_fpca_fG_cv$mean_fd$km,train$mu_fd)
RMSE_fpca_mb_fG=get_RMSE(mod_fpca_fG_cv$mean_fd$mb,train$mu_fd)



###Results
results<-data.frame( G=c(G_sasfunclust,G_curvclust,G_funHDDC,G_dist,G_bspline_hc,G_bspline_km,G_bspline_mb,G_fpca_hc,G_fpca_km,G_fpca_mb),
                     aRand=c(measure_sasfunclust,measure_curvclust,measure_funHDDC,measure_dist,measure_bspline_hc,measure_bspline_km,measure_bspline_mb,measure_fpca_hc,measure_fpca_km,measure_fpca_mb),
                 RMSE=c(RMSE_sasfunclust,RMSE_curvclust,RMSE_funHDDC,RMSE_dist,RMSE_bspline_hc,RMSE_bspline_km,RMSE_bspline_mb,RMSE_fpca_hc,RMSE_fpca_km,RMSE_fpca_mb),
                 aRand_fG=c(measure_sasfunclust_fG,measure_curvclust_fG,measure_funHDDC_fG,measure_dist_fG,measure_bspline_hc_fG,measure_bspline_km_fG,measure_bspline_mb_fG,measure_fpca_hc_fG,measure_fpca_km_fG,measure_fpca_mb_fG),
                 RMSE_fG=c(RMSE_sasfunclust_fG,RMSE_curvclust_fG,RMSE_funHDDC_fG,RMSE_dist_fG,RMSE_bspline_hc_fG,RMSE_bspline_km_fG,RMSE_bspline_mb_fG,RMSE_fpca_hc_fG,RMSE_fpca_km_fG,RMSE_fpca_mb_fG)
)

rownames(results)<-c("sasfunclust","curvclust","funHDDC","distance","bspline_hc","bspline_km","bspline_mb","fpca_hc","fpca_km","fpca_mb")

print(results)


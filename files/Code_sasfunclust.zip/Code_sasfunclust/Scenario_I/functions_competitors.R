#######################
## COMPETING METOHODS##
#######################

# Curvclust Giacifci et al. (2013)---------------------------------------------------------------


curvclust<-function(data,K){

  N<-ncol(data$X)
  q<-nrow(data$X)
  fdat= list()
  for (j in 1:N) fdat[[j]] =data$X[,j]
  CCD = new("CClustData",Y=fdat,filter.number=1)
  CCDred = getUnionCoef(CCD)
  CCO = new("CClustO")
  CCO@nbclust= K
  CCO@Gamma2.structure = "constant"
  CCO@loglikplot=FALSE
  CCO@init="SEM"
  CCO["burn"] = 100
  CCO["eps"] = 0.001
  CCR = if(K==1) getFMM(CCDred,CCO) else getFCMM(CCDred,CCO)
  mu<-matrix(unlist(getwr.mu(CCR,CCO,CCDred)),q,K)
  basis<-create.bspline.basis(c(0,1),nbasis = nrow(mu),norder = 2)
  mean_fd<-fd(mu,basis)
  cluster = if(K==1) rep(1,N) else apply(CCR@Tau,1,which.max)
  BIC<--getBIC(CCR,CCDred)
  ILC<-getICL(CCR,CCDred)

  out<-list(CCR=CCR,
            mean_fd=mean_fd,
            cluster=cluster,
            BIC=BIC,
            ILC=ILC)
  return(out)
}

curvclust_ms<-function(data,num_cluster_seq=1:3){
  parr_fun<-function(ii){
    cat(ii)
    num_cluster<-num_cluster_seq[ii]
    fit_curvclust<-curvclust(data=data,K=num_cluster)
    BIC<- fit_curvclust$BIC
    ILC<- fit_curvclust$ILC
    out<-list(ILC=ILC,
              BIC=BIC)
  }
  cores <- detectCores()
  vec_par<-mclapply(seq(1,length(num_cluster_seq)),parr_fun,mc.cores = 1)
  ILC<-sapply(vec_par,"[[",1)
  BIC<-sapply(vec_par,"[[",2)
  par_opt_ILC<-num_cluster_seq[max(which(ILC==min(ILC)))]
  par_opt_BIC<-num_cluster_seq[max(which(BIC==min(BIC)))]
  out<-list(par_opt_ILC=par_opt_ILC,
            par_opt_BIC=par_opt_BIC,
            ILC=ILC,
            BIC=BIC)
  return(out)
}





# funHDDC Bouveyron and Jacques (2011)-----------------------------------------------------------------




fit_funHDDC_ms<-function(data,num_cluster_seq=2:3,threshold_seq=seq(0.1,0.99,length.out =5),lambda_s=NA){

  basis<- create.bspline.basis(c(0,1), nbasis=20)
  loglam         = seq(-10, 10, 0.25)
  Gcvsave        = numeric()
  for(i in 1:length(loglam)){
    fdPari  = fdPar(basis, Lfdobj=2, 10^loglam[i])
    Sm.i    = smooth.basis(data$grid, data$X, fdPari)
    Gcvsave[i] = sum(Sm.i$gcv)

  }

  lambda_s=10^loglam[which.min(Gcvsave)]
  fdPari  = fdPar(basis, Lfdobj=2,lambda_s)
  X_fd<-smooth.basis(data$grid, data$X, fdPari)$fd
  mod<-funHDDC(X_fd,num_cluster_seq,model=c('AkjBkQkDk', 'AkjBQkDk', 'AkBkQkDk', 'ABkQkDk', 'AkBQkDk', 'ABQkDk'),show=FALSE,threshold=threshold_seq,kmeans.control =list(nstart=100, iter.max = 100),nb.rep = 20)
  mu_fd<-fd(t(mod$mu),basis)
  SH<- slopeHeuristic_mod(mod)
  K_opt<-mod$allCriteria[SH[1],]$K
  thr_opt<-mod$allCriteria[SH[1],]$threshold
  mod_names<-mod$allCriteria[SH[1],]$model
  mod_opt<-funHDDC(X_fd,K_opt,model=c(mod_names),threshold=thr_opt,kmeans.control = list(nstart=100, iter.max = 100),nb.rep = 20,show=FALSE)
  mod_opt$mean_fd<-mu_fd
  out<-list(mod=mod,mod_opt=mod_opt,par_opt=c(K_opt,thr_opt,SH[2]))
  return(out)
}


slopeHeuristic_mod<-function (mod)
{
  main_data = mod$allCriteria
  who_notNA_norInfinite = !is.na(main_data$complexity) & is.finite(main_data$LL)
  n_valid = sum(who_notNA_norInfinite)
  if (n_valid == 0) {
    stop("There is not any valid model to be selected.")
  }
  else if (n_valid <= 2) {
    stop("At least 3 valid models are necessary to perform the slope heuristic. Otherwise, use another criterion.")
  }
  main_data = main_data[who_notNA_norInfinite, ]
  fit = MASS::rlm(LL ~ complexity, data = main_data, method = "MM")
  fit_coef = fit$coefficients
  if (fit_coef[2] < 0) {
    fit_coef[2] = 0
  }
  llpen = main_data$LL - 2 * fit_coef[2] * main_data$complexity
  SH = 2 * llpen
  return(c(main_data$rank[which.max(llpen)],SH[which.max(llpen)]))
  
}


# Distance-based Ieva et al. (2013)----------------------------------------------------------

distance_ss<-function(data,num_cluster=3){

  if(class(data)!="fd"){
    basis<- create.bspline.basis(c(0,1), nbasis=20)
    loglam         = seq(-10, 10, 0.25)
    Gcvsave        = numeric()
    for(i in 1:length(loglam)){
      fdPari  = fdPar(basis, Lfdobj=2, 10^loglam[i])
      Sm.i    = smooth.basis(data$grid, data$X, fdPari)
      Gcvsave[i] = sum(Sm.i$gcv)

    }


    lambda_s=10^loglam[which.min(Gcvsave)]
    fdPari  = fdPar(basis, Lfdobj=2,lambda_s)
    X_fd<-smooth.basis(data$grid, data$X, fdPari)$fd
  }
  else{
    X_fd=data
  }
  X_fdata<-fdata(X_fd)
  mod<-kmeans.fd(X_fdata,ncl = num_cluster,par.metric = list(lp=2),par.dfunc = list(trim=0),cluster.size = 1,max.iter = 10000,draw=FALSE)
  dist<-dist(metric.lp(X_fdata,p=2))
  clus<-mod$cluster
  mean_fd<-fdata2fd(mod$centers)
  out<-list(clus=clus,
            mean_fd=mean_fd,
            dist=dist)
  return(out)

}


distance_ms<-function(data,num_cluster_seq=2:7,met="sil"){

  basis<- create.bspline.basis(c(0,1), nbasis=20)
  loglam         = seq(-10, 4, 0.25)
  Gcvsave        = numeric()
  for(i in 1:length(loglam)){
    fdPari  = fdPar(basis, Lfdobj=2, 10^loglam[i])
    Sm.i    = smooth.basis(data$grid, data$X, fdPari)
    Gcvsave[i] = sum(Sm.i$gcv)

  }


  lambda_s=10^loglam[which.min(Gcvsave)]
  fdPari  = fdPar(basis, Lfdobj=2,lambda_s)
  X_fd<-smooth.basis(data$grid, data$X, fdPari)$fd

  parr_fun<-function(lll){
    cat(lll)
    num_cluster_i<-num_cluster_seq[lll]

    mod<-distance_ss(X_fd,num_cluster_i)
    con<-connectivity(distance = mod$dist,mod$clus, neighbSize = 20)
    dunn<-dunn(mod$dist,mod$clus)
    sil<-silhouette(mod$clus,mod$dist)
    sil<-summary(sil)$avg.width
    out<-list(con=con,
              dunn=dunn,
              sil=sil)
    return(out)

  }

  vec_par<-lapply(seq(1,length(num_cluster_seq)),parr_fun  )
  con<-sapply(vec_par,"[[",1)
  dunn<-sapply(vec_par,"[[",2)
  sil<-sapply(vec_par,"[[",3)

  con_opt<-as.numeric(num_cluster_seq[min(which(con==min(con)))])
  dunn_opt<-as.numeric(num_cluster_seq[min(which(dunn==max(dunn)))])
  sil_opt<-as.numeric(num_cluster_seq[min(which(sil==max(sil)))])

  mod_opt_con<-distance_ss(X_fd,con_opt)
  mod_opt_dunn<-distance_ss(X_fd,dunn_opt)
  mod_opt_sil<-distance_ss(X_fd,sil_opt)

  if(met=="sil"){
    out<-list(mod_opt_sil=mod_opt_sil,
              sil_opt=sil_opt,
              sil=sil)
  }
  else if(met=="con"){
    out<-list(mod_opt_con=mod_opt_con,
              con_opt=con_opt,
              con=con)
  }
  else if(met=="dunn"){
    out<-list(mod_opt_dunn=mod_opt_dunn,
              dunn_opt=dunn_opt,
              dunn=dunn)
  }
  else{
    out<-list(mod_opt_con=mod_opt_con,
              mod_opt_dunn=mod_opt_dunn,
              mod_opt_sil=mod_opt_sil,
              con_opt=con_opt,
              dunn_opt=dunn_opt,
              sil_opt=sil_opt,
              con=con,
              dunn=dunn,
              sil=sil)
  }
  return(out)

}

# Filtering B-spline ------------------------------------------------------


fil_bspline_ms_nclust<-function(data,num_cluster_seq=2:5,nbasis=20,lambda_s=NA,modelNames="EII",...){
  basis<- create.bspline.basis(range(data$grid), nbasis=nbasis,...)
  print(range(data$grid))
  loglam         = seq(-10, 10, 0.25)
  Gcvsave        = numeric()
  for(i in 1:length(loglam)){
    fdPari  = fdPar(basis, Lfdobj=2, 10^loglam[i])
    Sm.i    = smooth.basis(data$grid, data$X, fdPari)
    Gcvsave[i] = sum(Sm.i$gcv)

  }

 if(is.na(lambda_s)) lambda_s=10^loglam[which.min(Gcvsave)]
  fdPari  = fdPar(basis, Lfdobj=2,lambda_s)
  X_fd<-smooth.basis(data$grid, data$X, fdPari)$fd
  B<-t(X_fd$coefs)
  if(length(num_cluster_seq)==1){
    K_opt_hc=K_opt_km=num_cluster_seq
    mod_km=mod_hc=NA
  }
  else{
  if(num_cluster_seq[1]==1){
    mod_km<-fviz_nbclust(B, hcut, method = "gap",k.max=num_cluster_seq[length(num_cluster_seq)],verbose = TRUE)$data$gap
    mod_hc<-fviz_nbclust(B, kmeans, method = "gap",k.max=num_cluster_seq[length(num_cluster_seq)],verbose = TRUE)$data$gap


    K_opt_hc<-(1:num_cluster_seq[length(num_cluster_seq)])[which.max(mod_km)]
    K_opt_km<-(1:num_cluster_seq[length(num_cluster_seq)])[which.max(mod_hc)]
  }
  else{

    mod_km<-MyNbClust(data = B,  method = "kmeans",min.nc = 2, max.nc = num_cluster_seq[length(num_cluster_seq)])
    mod_hc<-MyNbClust(data = B,  method = "ward.D2",min.nc = 2, max.nc = num_cluster_seq[length(num_cluster_seq)])


    mod_km_kopt<-(mod_km$Best.nc[1,])[!mod_km$Best.nc[1,]==0]
    mod_hc_kopt<-(mod_hc$Best.nc[1,])[!mod_hc$Best.nc[1,]==0]
    K_opt_km<-as.numeric(names(sort(table(mod_km_kopt),decreasing=TRUE))[1])
    K_opt_hc<-as.numeric(names(sort(table(mod_hc_kopt),decreasing=TRUE))[1])

  }
  }
  model<-Mclust(B,G=num_cluster_seq,verbose = FALSE)
  mod_opt_hc<-hcut(B,k =K_opt_hc,hc_method = "ward.D2")
  mod_opt_km<-kmeans(B,centers =K_opt_km ,nstart = 1000,iter.max = 100 )

  mod_opt_mod<-model
  mean_fd<-list()
  mean_fd_hc<-fd(sapply(1:K_opt_hc, function(ll)if(length(which(mod_opt_hc$cluster==ll))==1) B[mod_opt_hc$cluster==ll,] else colMeans(B[mod_opt_hc$cluster==ll,])),basis)
  mean_fd_km<-fd(t(mod_opt_km$centers),basis)
  mean_fd_model<-fd(mod_opt_mod$parameters$mean,basis)


  out<-list(mod_opt=list(hc = mod_opt_hc,km = mod_opt_km,mb = mod_opt_mod),
            mean_fd=list(hc = mean_fd_hc,km = mean_fd_km,mb = mean_fd_model),
            mod_km=mod_km,
            mod_hc=mod_hc)
  return(out)

}
fil_bspline_ms<-function(data,num_cluster_seq=2:5,grid=NULL,met="sil"){

  
  basis_vec         = seq(5,40, by=5)
  Gcvsave        = numeric()
  for(i in 1:length(basis_vec)){
    basis<- create.bspline.basis(c(0,1), nbasis=basis_vec[i])
    Sm.i    = smooth.basis(data$grid, data$X, basis)
    Gcvsave[i] = sum(Sm.i$gcv)
    
  }
  
  basis_opt=basis_vec[which.min(Gcvsave)]
  
  basis<- create.bspline.basis(c(0,1), nbasis=basis_opt)
  X_fd<-smooth.basis(data$grid, data$X, basis)$fd
  
  B<-t(X_fd$coefs)
  mod<-clValid(B, num_cluster_seq, clMethods=c("hierarchical","kmeans"),
               validation="internal",method = "ward",neighbSize = 30
  )
  model<-Mclust(B,G = num_cluster_seq)
  
  con<-mod@measures[1,,]
  dunn<-mod@measures[2,,]
  sil<-mod@measures[3,,]
  K_opt_con<-apply(con, 2, which.min)
  K_opt_dunn<-apply(dunn, 2, which.max)
  K_opt_sil<-apply(sil, 2, which.max)
  K_opt<-list(K_opt_con,K_opt_dunn,K_opt_sil)
  mod_opt_hc<-lapply(1:3,function(ii)cutree(mod@clusterObjs$hierarchical,num_cluster_seq[K_opt[[ii]][1]]))
  mod_opt_km<-lapply(1:3,function(ii)mod@clusterObjs$kmeans[[K_opt[[ii]][2]]])
  mod_opt_mod<-model

  mean_fd<-list()
  mean_fd_hc<-lapply(1:3,function(ii)fd(sapply(1:length(unique(mod_opt_hc[[ii]])), function(ll)colMeans(B[mod_opt_hc[[ii]]==ll,])),basis))
  mean_fd_km<-lapply(1:3,function(ii)fd(t(mod_opt_km[[ii]]$centers),basis))
  mean_fd_model<-fd(mod_opt_mod$parameters$mean,basis)

  if(met=="sil"){
    ind=3
    out<-list(mod_opt_sil=list(hc = mod_opt_hc[[ind]],km = mod_opt_km[[ind]],mb = mod_opt_mod),
              mean_fd=list(hc = mean_fd_hc[[ind]],km = mean_fd_km[[ind]],mb = mean_fd_model),
              sil=sil)
  }
  else if(met=="con"){
    ind=1
    out<-list(mod_opt_con=list(ind_hc = mod_opt_hc[[ind]],ind_km = mod_opt_km[[ind]],mod_opt = mod_opt_mod),
              mean_fd=list(hc = mean_fd_hc[[ind]],km = mean_fd_km[[ind]],model = mean_fd_model),
              con=con)
  }
  else if(met=="dunn"){
    ind=2
    out<-list(mod_opt_dunn=list(ind_hc = mod_opt_hc[[ind]],ind_km = mod_opt_km[[ind]],mod_opt = mod_opt_mod),
              mean_fd=list(hc= mean_fd_hc[[ind]],km = mean_fd_km[[ind]],model = mean_fd_model),
              dunn=dunn)
  }
  else{
    out<-list(mod_opt_con=mod_opt_con,
              mod_opt_dunn=mod_opt_dunn,
              mod_opt_sil=mod_opt_sil,
              mean_fd_hc=mean_fd_hc,
              mean_fd_km=mean_fd_km,
              mean_fd_model=mean_fd_model,
              con=con,
              dunn=dunn,
              sil=sil)
  }
  return(out)

}
# Filtering FPCA ----------------------------------------------------------




fil_fpca_ss_nbclust<-function(data,num_cluster_seq=3:4,per_comp=0.9,grid=NULL,modelNames="EII",...){


  basis<- create.bspline.basis(c(0,1), nbasis=20)
  loglam         = seq(-10, 10, 0.25)
  Gcvsave        = numeric()
  for(i in 1:length(loglam)){
    fdPari  = fdPar(basis, Lfdobj=2, 10^loglam[i])
    Sm.i    = smooth.basis(data$grid, data$X, fdPari)
    Gcvsave[i] = sum(Sm.i$gcv)

  }


  lambda_s=10^loglam[which.min(Gcvsave)]
  fdPari  = fdPar(basis, Lfdobj=2,lambda_s)
  X_fd<-smooth.basis(data$grid, data$X, fdPari)$fd
  mean_fd_ini<-mean.fd(X_fd)
  princomp<-pca.fd(X_fd,min(X_fd$basis$nbasis, 30),centerfns=FALSE)
  cum<-cumsum(princomp$values)/sum(princomp$values)
  num_com<-min(which(cum>per_comp))
  print(num_com)
  princomp<-pca.fd(X_fd,num_com)
  B<-princomp$scores
   if(length(num_cluster_seq)==1){
    K_opt_hc=K_opt_km=num_cluster_seq
    mod_km=mod_hc=NA
  }
  else{
  if(num_cluster_seq[1]==1){
    mod_km<-fviz_nbclust(B, hcut, method = "gap",k.max=num_cluster_seq[length(num_cluster_seq)],verbose=FALSE)$data$gap
    mod_hc<-fviz_nbclust(B, kmeans, method = "gap",k.max=num_cluster_seq[length(num_cluster_seq)],verbose=FALSE)$data$gap


    K_opt_hc<-(1:num_cluster_seq[length(num_cluster_seq)])[which.max(mod_km)]
    K_opt_km<-(1:num_cluster_seq[length(num_cluster_seq)])[which.max(mod_hc)]
  }
  else{

    mod_km<-MyNbClust(data = B,  method = "kmeans",min.nc = 2, max.nc = num_cluster_seq[length(num_cluster_seq)])
    mod_hc<-MyNbClust(data = B,  method = "ward.D2",min.nc = 2, max.nc = num_cluster_seq[length(num_cluster_seq)])


    mod_km_kopt<-(mod_km$Best.nc[1,])[!mod_km$Best.nc[1,]==0]
    mod_hc_kopt<-(mod_hc$Best.nc[1,])[!mod_hc$Best.nc[1,]==0]
    K_opt_km<-as.numeric(names(sort(table(mod_km_kopt),decreasing=TRUE))[1])
    K_opt_hc<-as.numeric(names(sort(table(mod_hc_kopt),decreasing=TRUE))[1])

  }
  }
  model<-Mclust(B,G=num_cluster_seq,verbose=FALSE)
  mod_opt_hc<-hcut(B,k =K_opt_hc )
  mod_opt_km<-kmeans(B,centers =K_opt_km,nstart = 1000,iter.max = 100 )
  mod_opt_mod<-model
  mean_fd<-list()

  mean_fd_hc<-fd(sapply(1:K_opt_hc, function(ll)colMeans(B[mod_opt_hc$cluster==ll,])%*%t(princomp$harmonics$coefs)),princomp$harmonics$basis) +
    fd(matrix(mean_fd_ini$coefs, nrow = nrow(mean_fd_ini$coefs), ncol = K_opt_hc), mean_fd_ini$basis)
  mean_fd_km<-fd(t(mod_opt_km$centers%*%t(princomp$harmonics$coefs)),princomp$harmonics$basis) +
    fd(matrix(mean_fd_ini$coefs, nrow = nrow(mean_fd_ini$coefs), ncol = K_opt_km), mean_fd_ini$basis)
  mean_fd_model<-fd(t(t(mod_opt_mod$parameters$mean)%*%t(princomp$harmonics$coefs)),princomp$harmonics$basis) +
    fd(matrix(mean_fd_ini$coefs, nrow = nrow(mean_fd_ini$coefs), ncol = model$G), mean_fd_ini$basis)


  out<-list(mod_opt=list(hc = mod_opt_hc,km = mod_opt_km,mb = mod_opt_mod),
            mean_fd=list(hc = mean_fd_hc,km = mean_fd_km,mb = mean_fd_model),
            mod_km=mod_km,
            mod_hc=mod_hc)

}

fil_fpca_ss<-function(data,num_clusters=3:4,per_comp=0.9,grid=NULL,met="sil",...){


  basis_vec         = seq(5,40, by=5)
  Gcvsave        = numeric()
  for(i in 1:length(basis_vec)){
    basis<- create.bspline.basis(c(0,1), nbasis=basis_vec[i])

    Sm.i    = smooth.basis(data$grid, data$X, basis)
    Gcvsave[i] = sum(Sm.i$gcv)

  }


  basis_opt=basis_vec[which.min(Gcvsave)]
  basis<- create.bspline.basis(c(0,1), nbasis=basis_opt)
  X_fd<-smooth.basis(data$grid, data$X, basis)$fd


  sd_fd<-sd.fd(X_fd)
  mean_fd<-mean.fd(X_fd)
  X_std<-center.fd(X_fd)*(sd_fd)^-1
  princomp<-pca.fd(X_std,min(X_std$basis$nbasis, 50))
  cum<-cumsum(princomp$values)/(X_fd$basis$rangeval[2]-X_fd$basis$rangeval[1])
  num_com<-min(which(cum>per_comp))
  princomp<-pca.fd(X_std,num_com)
  B<-princomp$scores
  mod<-clValid(B, num_clusters, clMethods=c("hierarchical","kmeans"),
               validation="internal",method = "ward")


  model<-Mclust(B,G=num_clusters)

  con<-mod@measures[1,,]
  dunn<-mod@measures[2,,]
  sil<-mod@measures[3,,]
  K_opt_con<-apply(con, 2, which.min)
  K_opt_dunn<-apply(dunn, 2, which.max)
  K_opt_sil<-apply(sil, 2, which.max)
  K_opt<-list(K_opt_con,K_opt_dunn,K_opt_sil)
  mod_opt_hc<-lapply(1:3,function(ii)cutree(mod@clusterObjs$hierarchical,num_clusters[K_opt[[ii]][1]]))
  mod_opt_km<-lapply(1:3,function(ii)mod@clusterObjs$kmeans[[K_opt[[ii]][2]]])
  mod_opt_mod<-model


  mean_fd_hc<-lapply(1:3,function(ii)fd(sapply(1:length(unique(mod_opt_hc[[ii]])), function(ll)colMeans(B[mod_opt_hc[[ii]]==ll,])%*%t(princomp$harmonics$coefs)),princomp$harmonics$basis)*sd_fd+mean_fd)
  mean_fd_km<-lapply(1:3,function(ii)fd(t(mod_opt_km[[ii]]$centers%*%t(princomp$harmonics$coefs)),princomp$harmonics$basis)*sd_fd+mean_fd)
  mean_fd_model<-fd(t(t(mod_opt_mod$parameters$mean)%*%t(princomp$harmonics$coefs)),princomp$harmonics$basis)*sd_fd+mean_fd

  if(met=="sil"){
    ind=3
    out<-list(mod_opt_sil=list(hc=mod_opt_hc[[ind]],km=mod_opt_km[[ind]],mb=mod_opt_mod),
              mean_fd=list(hc=mean_fd_hc[[ind]],km=mean_fd_km[[ind]],mb=mean_fd_model),
              sil=sil)
  }
  else if(met=="con"){
    ind=1
    out<-list(mod_opt_con=list(mod_opt_hc[[ind]],mod_opt_km[[ind]],mod_opt_mod),
              mean_fd=list(mean_fd_hc[[ind]],mean_fd_km[[ind]],mean_fd_model),
              con=con)
  }
  else if(met=="dunn"){
    ind=2
    out<-list(mod_opt_dunn=list(mod_opt_hc[[ind]],mod_opt_km[[ind]],mod_opt_mod),
              mean_fd=list(mean_fd_hc[[ind]],mean_fd_km[[ind]],mean_fd_model),
              dunn=dunn)
  }
  else{
    out<-list(mod_opt_con=mod_opt_con,
              mod_opt_dunn=mod_opt_dunn,
              mod_opt_sil=mod_opt_sil,
              mean_fd_hc=mean_fd_hc,
              mean_fd_km=mean_fd_km,
              mean_fd_model=mean_fd_model,
              con=con,
              dunn=dunn,
              sil=sil)
  }

}


fil_fpca_ms<-function(data,num_cluster_seq=2:5,per_comp_vec=0.9,met="sil",...){

  if(length(per_comp_vec)==1){
    mod_opt<-fil_fpca_ss(data,num_clusters = num_cluster_seq,per_comp = per_comp_vec,...)
    par_opt_vec=mod_opt[[2]]
  }
  else{
    mod<-list()
    for (ii in 1:length(per_comp_vec)) {
      mod[[ii]]<-fil_fpca_ss(data,num_clusters = num_cluster_seq,per_comp = per_comp_vec[ii],met="sil")
    }

    par_opt_vec<-sapply(mod, "[[", 3)
    if(met=="sil"|met=="dunn")
      mod_opt<-mod[[which.max(apply(par_opt_vec,2,max))]]
    else if(met=="con")
      mod_opt<-mod[[which.min(apply(par_opt_vec,2,min))]]
    else
      mod_opt=mod

  }
  out<-list(mod_opt=mod_opt,par_opt_vec=par_opt_vec)
  return(out)
}


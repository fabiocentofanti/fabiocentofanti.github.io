# This script could be used to obtain all the figures in the Simulation Study 
# of the manuscript by appropriately setting the simulation parameters.
# By default, it provides the top-left panel of Figure 7 of the main text 
# of the manuscript for:
#       - Scenario S3 (both componentwise and casewise outliers)
#       - Contamination model Out-E
#       - Contamination probability 0.05
#       - Contamination level C1
#       - OC condition OC-E
#       - OC pattern ONE

# Assuming that the working directory is the folder containing this script,
# the following code produces the aforementioned plot using ggplot2,
# which is then stored in the object p, and,
# finally, the figure is saved in a file "fig.pdf"


# This code has been run on computing system with 2 sockets with 24 cores each,
# equipped with Intel(R) Xeon(R) Platinum 8160 processors
# running at a clock frequency of 2.10GHz, and 192 GB of RAM.
# The main information output by the system
# after running the script is reported as follows:

# Resource usage summary:
#
# CPU time :                                   1245561.25 sec.
# Max Memory :                                 61845 MB
# Average Memory :                             47722.70 MB
# Total Requested Memory :                     -
# Delta Memory :                               -
# Max Swap :                                   -
# Max Processes :                              53
# Max Threads :                                505
# Run time :                                   19847 sec.
# Turnaround time :                            22075 sec.


# We also report the output of sessionInfo() obtained from this script as follows:

# R version 3.6.1 (2019-07-05)
# Platform: x86_64-pc-linux-gnu (64-bit)
# Running under: CentOS Linux 7 (Core)
#
# Matrix products: default
# BLAS:   /afs/.enea.it/software/rproj/R-3.6.1/build/lib64/R/lib/libRblas.so
# LAPACK: /afs/.enea.it/software/rproj/R-3.6.1/build/lib64/R/lib/libRlapack.so
#
# locale:
#  [1] LC_CTYPE=en_US.UTF-8       LC_NUMERIC=C
#  [3] LC_TIME=en_US.UTF-8        LC_COLLATE=en_US.UTF-8
#  [5] LC_MONETARY=en_US.UTF-8    LC_MESSAGES=en_US.UTF-8
#  [7] LC_PAPER=en_US.UTF-8       LC_NAME=C
#  [9] LC_ADDRESS=C               LC_TELEPHONE=C
# [11] LC_MEASUREMENT=en_US.UTF-8 LC_IDENTIFICATION=C
#
# attached base packages:
# [1] parallel  splines   stats     graphics  grDevices utils     datasets
# [8] methods   base
#
# other attached packages:
#  [1] Matrix_1.5-4         forcats_1.0.0        stringr_1.5.0
#  [4] dplyr_1.1.2          purrr_1.0.1          readr_2.1.4
#  [7] tidyr_1.3.0          tibble_3.2.1         ggplot2_3.4.2
# [10] tidyverse_1.3.0      roahd_1.4.3          funcharts_1.4.1
# [13] rofanova_1.0.0       robustbase_0.99-0    fda.usc_2.1.0
# [16] mgcv_1.8-32          nlme_3.1-162         fda_6.1.4
# [19] deSolve_1.35         fds_1.8              RCurl_1.98-1.12
# [22] rainbow_3.6          pcaPP_1.9-74         MASS_7.3-51.6
#
# loaded via a namespace (and not attached):
#  [1] httr_1.4.5         jsonlite_1.8.4     foreach_1.5.2      modelr_0.1.8
#  [5] hdrcde_3.4         cellranger_1.1.0   pillar_1.9.0       backports_1.4.1
#  [9] lattice_0.20-41    glue_1.6.2         rvest_1.0.3        colorspace_1.4-1
# [13] pkgconfig_2.0.3    broom_1.0.4        haven_2.5.2        mvtnorm_1.1-3
# [17] scales_1.2.1       tzdb_0.3.0         pracma_2.4.2       timechange_0.2.0
# [21] generics_0.1.3     withr_2.5.0        cli_3.6.1          crayon_1.3.4
# [25] magrittr_2.0.3     readxl_1.4.2       mclust_6.0.0       ks_1.14.0
# [29] fs_1.6.2           fansi_0.4.1        doParallel_1.0.17  xml2_1.3.4
# [33] SuppDists_1.1-9.7  tools_3.6.1        hms_1.1.3          lifecycle_1.0.3
# [37] munsell_0.5.0      reprex_2.0.2       cluster_2.1.0      kSamples_1.2-9
# [41] compiler_3.6.1     rlang_1.1.1        grid_3.6.1         rstudioapi_0.14
# [45] iterators_1.0.14   bitops_1.0-7       gtable_0.3.0       codetools_0.2-16
# [49] DBI_1.1.3          R6_2.4.1           lubridate_1.9.2    utf8_1.1.4
# [53] KernSmooth_2.23-20 stringi_1.7.12     Rcpp_1.0.4.6       vctrs_0.6.2
# [57] DEoptimR_1.0-8     dbplyr_2.3.2       tidyselect_1.2.0



# Libraries ---------------------------------------------------------------
library(rofanova)
library(fda.usc)
library(funcharts)
library(roahd)
library(tidyverse)
library(Matrix)
library(parallel)
source("functions.R")

# Setting simulation parameters -------------------------------------------

# Choose the probability of outlier contamination in Phase I between 0, 0.05, or 0.1
p_contamination <- 0.05
p_cellwise <- p_casewise <- 0.05

# Choose only componentwise outliers ("cellwise"),
# only casewise ("casewise"), or both ("casewise_cellwise")
outlier <- "casewise_cellwise"
if (outlier == "cellwise")
  p_casewise <- 0
if (outlier == "casewise")
  p_cellwise <- 0

# Choose contamination model Out-E ("outlier_E") or Out-P ("outlier_P")
outlier_str <- "outlier_E"

# Choose contamination size C1, C2, or C3 as 1, 2, or 3, respectively
ind_size_outlier <- 1

# Choose between "OC_E" and "OC_P
OC <- "OC_E"

# Choose OC pattern, use 5 if ONE, or 1:10 if ALL
which_oc <- 5


fun <- function(seed, idx_size_OC) {
  
  set.seed(seed) # Set a seed from 1 to 50 for the simulation run
  
  # Choose the Severity Level (SL) among
  # 1 (SL=0), 2 (SL=1), 3 (SL=2), 4 (SL=3), or 5 (SL=4)
  ind_size_OC_vec <- 1:5
  ind_size_OC <- ind_size_OC_vec[idx_size_OC]

  # Fixed simulation parameters --------------------------------------------------------
  # Number of functional variables p is 10
  p <- 10

  # Number of B-spline basis functions for each function is 15
  nb <- 15

  # Training sample size is 1000
  sample_size <- 1000

  # Tuning sample size is 2000
  sample_size <- 1000
  sample_size_tun <- 2000
  nobs_IC <- sample_size + sample_size_tun

  # Phase II sample size is 4000
  nobs_OC <- 4000

  # Functional data are observed at 100 discrete points
  P <- 100

  # nominal type-I error rate is 0.05, corresponding to ARL0=20
  alpha <- 0.05
  alpha_sid <- 1 - (1 - alpha) ^ (1 / 2)

  # k is rho_cor in Equation (9)
  k <- 1

  # sd is sigma below Equation (14)
  sd <- 0.0125

  # sd_e is sigma_e below Equation (14)
  sd_e <- 0.0025

  # parameters M_E and M_P to generate Phase I outliers according to Table 1
  M_outlier_cell_vec_E <- c(0.02, 0.03, 0.04) * 1.5
  M_outlier_cell_vec_P <- c(0.27, 0.34, 0.40) * 1.25
  M_outlier_case_vec_E <- c(0.02, 0.03, 0.04)
  M_outlier_case_vec_P <- c(0.27, 0.34, 0.40) * 0.625

  if (outlier_str == "outlier_E") {
    M_outlier_cell_vec <- M_outlier_cell_vec_E
    M_outlier_case_vec <- M_outlier_case_vec_E
  }
  if (outlier_str == "outlier_P") {
    M_outlier_cell_vec <- M_outlier_cell_vec_P
    M_outlier_case_vec <- M_outlier_case_vec_P
  }

  # parameters M_E and M_P to generate the Phase II OC data according to Table 2
  if (length(which_oc) == 1) {
    # OC pattern ONE
    if (OC == "OC_E")
      M_OC_vec <- c(0, 0.01, 0.02, 0.03, 0.04) * 1.5
    if (OC == "OC_P")
      M_OC_vec <- c(0, 0.20, 0.27, 0.34, 0.40) * 1.25
    if (OC == "mix_OC_P_OC_E") {
      M_OC_vec_P = c(0, 0.20, 0.27, 0.34, 0.40) * 1.25
      M_OC_vec_E = c(0, 0.01, 0.02, 0.03, 0.04) * 1.5
    }
  }
  if (length(which_oc) == 10) {
    # OC pattern ALL
    if (OC == "OC_E")
      M_OC_vec <- c(0, 0.01, 0.02, 0.03, 0.04)
    if (OC == "OC_P")
      M_OC_vec <- c(0, 0.20, 0.27, 0.34, 0.40) * 0.625
    if (OC == "mix_OC_P_OC_E") {
      M_OC_vec_P <- c(0, 0.20, 0.27, 0.34, 0.40) * 0.625
      M_OC_vec_E <- c(0, 0.01, 0.02, 0.03, 0.04)
    }
  }

  # Generate Phase I data
  if (outlier == "casewise_cellwise") {
    dat_ic_case <- simulate_data(
      nobs_IC / 2,
      p = p,
      p_casewise = p_casewise,
      p_cellwise = 0,
      outlier = outlier_str,
      M_outlier_case = M_outlier_case_vec[ind_size_outlier],
      M_outlier_cell = M_outlier_cell_vec[ind_size_outlier],
      OC = "no",
      M_OC = 0,
      sd_e = sd_e,
      sd = sd,
      P = P,
      T_exp = 0.5,
      k = k,
      correlation = "decreasing"
    )
    dat_ic_cell <- simulate_data(
      nobs_IC / 2,
      p = p,
      p_casewise = 0,
      p_cellwise = p_cellwise,
      outlier = outlier_str,
      M_outlier_case = M_outlier_case_vec[ind_size_outlier],
      M_outlier_cell = M_outlier_cell_vec[ind_size_outlier],
      OC = "no",
      M_OC = 0,
      sd_e = sd_e,
      sd = sd,
      P = P,
      T_exp = 0.5,
      k = k,
      correlation = "decreasing"
    )
    dat_ic <-
      list(X_mat_list = list(), ind_out = dat_ic_case$ind_out)
    for (jj in 1:p) {
      dat_ic$X_mat_list[[jj]] <- rbind(dat_ic_case$X_mat_list[[jj]],
                                       dat_ic_cell$X_mat_list[[jj]])
    }
    names(dat_ic$X_mat_list) <- names(dat_ic_case$X_mat_list)

  } else {
    dat_ic <- simulate_data(
      nobs_IC,
      p = p,
      p_casewise = p_casewise,
      p_cellwise = p_cellwise,
      outlier = outlier_str,
      M_outlier_case = M_outlier_case_vec[ind_size_outlier],
      M_outlier_cell = M_outlier_cell_vec[ind_size_outlier],
      OC = "no",
      M_OC = 0,
      sd_e = sd_e,
      sd = sd,
      P = P,
      T_exp = 0.5,
      k = k,
      correlation = "decreasing"
    )
  }


  # Generate Phase II data
  dat_oc <- simulate_data(
    nobs_OC,
    p = p,
    p_casewise = 0,
    p_cellwise = 0,
    outlier = "no",
    OC = OC,
    M_OC = M_OC_vec[ind_size_OC],
    sd_e = sd_e,
    sd = sd,
    P = P,
    T_exp = 0.5,
    k = k,
    correlation = "decreasing",
    which_OC = which_oc
  )



  # Smoothing ---------------------------------------------------------------
  x <- funcharts::get_mfd_list(dat_ic$X_mat_list, n_basis  = nb)
  x_oc <- funcharts::get_mfd_list(dat_oc$X_mat_list, n_basis  = nb)
  x$raw <- NULL
  x_oc$raw <- NULL

  # RoMFCC -------------------------------------------------------------------
  print("RoMFCC")

  mod1 <- funcharts::RoMFCC_PhaseI(mfdobj = x[1:sample_size],
                                   mfdobj_tuning = x[(sample_size + 1):nobs_IC])
  mod2 <- RoMFCC_PhaseII(mfdobj_new = x_oc, mod_phase1 = mod1)
  p_RoFCC <- mean(mod2$T2 > mod2$T2_lim | mod2$spe > mod2$spe_lim)


  # MCC ---------------------------------------------------------------------
  print("MCC")

  mod_phase_I_M1 <-
    phase1_multiv_iter(
      dat_ic$X_mat_list,
      alpha = 0.05,
      max_iter = 1,
      plot = F,
      print = F
    )
  mod_phase_II_M1 <-
    phase2_multiv(
      dat_oc$X_mat_list,
      mod_Phase_I = mod_phase_I_M1,
      plot = F,
      print = F
    )
  p_M1 = mod_phase_II_M1$frac_out

  # iterMCC ---------------------------------------------------------------------
  print("iterMCC")

  mod_phase_I_Miter <-
    phase1_multiv_iter(
      dat_ic$X_mat_list,
      alpha = 0.05,
      max_iter = 20,
      plot = F,
      print = F
    )
  mod_phase_II_Miter <-
    phase2_multiv(
      dat_oc$X_mat_list,
      mod_Phase_I = mod_phase_I_Miter,
      plot = F,
      print = F
    )
  p_Miter = mod_phase_II_Miter$frac_out

  # RoMCC ---------------------------------------------------------------------
  print("RoMCC")

  mod_phase_I_MRo <-
    phase1_multiv_robust(
      dat_ic$X_mat_list,
      alpha = 0.05,
      plot = F,
      print = F
    )
  mod_phase_II_MRo <-
    phase2_multiv(
      dat_oc$X_mat_list,
      mod_Phase_I = mod_phase_I_MRo,
      plot = F,
      print = F
    )
  p_MRo = mod_phase_II_MRo$frac_out

  # MFCC ---------------------------------------------------------------
  print("MFCC")

  mod_phase_I_FCC1 <- phase1_funcharts(
    X = x[1:sample_size],
    max_iter = 1,
    fev = 0.7,
    adjust = "tuning_set",
    X_mfd_tuning = x[(sample_size + 1):nobs_IC],
    plot = F,
    print = F
  )
  mod_phase_II_FCC1 <-
    phase2_funcharts(
      X_new = x_oc,
      mod_Phase_I = mod_phase_I_FCC1,
      plot = F,
      print = F
    )
  p_FCC1 <- mod_phase_II_FCC1$frac_out

  # iterMFCC ---------------------------------------------------------------
  print("iterMFCC")

  mod_phase_I_FCCiter <- phase1_funcharts(
    X = x[1:sample_size],
    max_iter = 20,
    fev = 0.7,
    adjust = "tuning_set",
    X_mfd_tuning =  x[(sample_size + 1):nobs_IC],
    plot = F,
    print = F
  )
  mod_phase_II_FCCiter <- phase2_funcharts(
    X_new = x_oc,
    mod_Phase_I = mod_phase_I_FCCiter,
    plot = F,
    print = F
  )
  p_FCCiter <- mod_phase_II_FCCiter$frac_out

  # OutMFCC ---------------------------------------------------------------
  print("OutMFCC")

  mod_phase_I_FCCoutgram <-
    phase1_funcharts_out(
      X = x[1:sample_size],
      max_iter = 20,
      fev = 0.7,
      adjust = "tuning_set",
      X_mfd_tuning = x[(sample_size + 1):nobs_IC],
      plot = F,
      print = F
    )
  mod_phase_II_FCCoutgram <- phase2_funcharts(
    X_new = x_oc,
    mod_Phase_I = mod_phase_I_FCCoutgram,
    plot = F,
    print = F
  )
  p_FCCoutgram <- mod_phase_II_FCCoutgram$frac_out

  p_vec <-
    c(p_M1, p_Miter, p_MRo, p_FCC1, p_FCCiter, p_FCCoutgram, p_RoFCC)
  ARL_vec <- 1 / p_vec
  names(ARL_vec) <-
    c("MCC",
      "iterMCC",
      "RoMCC",
      "MFCC",
      "iterMFCC",
      "OutMFCC",
      "RoMFCC")

  return(ARL_vec)

}


nsim <- 50
ncores <- 10 # Select the number of cores to be used for parallel computation
if(.Platform$OS.type == "unix"){
  ncores <- min(ncores, parallel::detectCores())
} else if(.Platform$OS.type == "windows"){
  ncores <- 1 # Parallelization not implemented for windows systems
}
out_list <- list()
methods_names <-
  c("MCC",
    "iterMCC",
    "RoMCC",
    "MFCC",
    "iterMFCC",
    "OutMFCC",
    "RoMFCC")
TDR_mean <- matrix(NA, nrow = 5, ncol = length(methods_names))
TDR_sd <- matrix(NA, nrow = 5, ncol = length(methods_names))
for (idx_size_OC in 1:5) {
  out_list[[idx_size_OC]] <-
    mclapply(1:nsim, function(ii)
      fun(seed = ii, idx_size_OC = idx_size_OC), mc.cores = ncores)
  out_list[[idx_size_OC]] <- do.call(rbind, out_list[[idx_size_OC]])
  TDR_mean[idx_size_OC,] <- colMeans(out_list[[idx_size_OC]])
  TDR_sd[idx_size_OC,] <-
    apply(out_list[[idx_size_OC]], 2, sd) / sqrt(nrow(out_list[[idx_size_OC]]))
}
out_list[[idx_size_OC]]

p <- plot_fun(TDR_mean, TDR_sd)
# p

ggsave("fig.pdf", width = 11, height = 9.5)

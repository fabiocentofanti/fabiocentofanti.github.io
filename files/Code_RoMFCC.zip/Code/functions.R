######################################################################
##                                                                   #
## Functions to simulate data and compute the competing approaches   #
## Note: the RoMFCC functions are in the R package funcharts v1.4.1  #
## This code contains all the functions required by Run.R            #
##                                                                   #
######################################################################

# Competitors: multivariate methods (MCC, iterMCC, RoMCC) ----------------------------

phase1_multiv_robust <- function(X_mat_list,
                                 alpha = 0.05,
                                 plot = TRUE,
                                 print = TRUE,
                                 nsample_tun = 100,
                                 tuning = T) {
  Xmeans <- sapply(X_mat_list, rowMeans)
  p <- ncol(Xmeans)
  nobs <- nrow(Xmeans)


  CL_T2 <- (((nobs ^ 2 - 1) * p) / (nobs * (nobs - p))) * qf(1 - alpha, p, nobs - p)
  mod <- rrcov::CovMcd(Xmeans, alpha = 0.8)
  m <- mod$center
  S <- mod$cov
  Sinv <- solve(S)
  Xcen <- t(t(Xmeans) - m)
  T2 <- rowSums((Xcen %*% Sinv) * Xcen)

  if (plot) {
    par(mfrow = c(1, 1))
    plot(T2)
    abline(h = CL_T2)
  }
  frac_out <- mean(T2 > CL_T2)
  ARL <- 1 / frac_out
  if (print) {
    print(paste0("T2 ", frac_out))
    print(paste0("ARL ", ARL))
  }
  list(
    m = m,
    Sinv = Sinv,
    T2 = T2,
    CL_T2 = CL_T2,
    ARL = ARL,
    Xmeans = Xmeans
  )
}

phase1_multiv_iter <- function(X_mat_list,
                               alpha = 0.05,
                               alpha_out = 0.0027,
                               plot = TRUE,
                               print = TRUE,
                               max_iter = 10) {
  Xmeans <- sapply(X_mat_list, rowMeans)
  p <- ncol(Xmeans)
  Xmeans_pul <- Xmeans

  iter <- 1
  ind_out <- rep(1, 2)
  ind_out_tot <- NULL
  nobs <- dim(Xmeans)[1]
  ind_obs <- 1:nobs
  while (length(ind_out) > 0 & iter <= max_iter) {
    nobs <- nrow(Xmeans_pul)
    m <- colMeans(Xmeans_pul)
    S <- cov(Xmeans_pul)
    Sinv <- MASS::ginv(S)
    Xcen <- t(t(Xmeans_pul) - m)
    T2 <- rowSums((Xcen %*% Sinv) * Xcen)
    CL_T2 <- (((nobs ^ 2 - 1) * p) / (nobs * (nobs - p))) * qf(1 - alpha_out, p, nobs - p)
    if (plot) {
      par(mfrow = c(1, 1))
      plot(T2)
      abline(h = CL_T2)
    }

    ind_out <- which(T2 > CL_T2)
    if (length(ind_out) > 0)
      Xmeans_pul <- Xmeans_pul[-ind_out,]
    iter <- iter + 1
    ind_out_tot <- c(ind_out_tot, ind_obs[ind_out])
    ind_obs <- ind_obs[-ind_out]
  }
  CL_T2 <-
    (((nobs ^ 2 - 1) * p) / (nobs * (nobs - p))) * qf(1 - alpha, p, nobs - p)
  frac_out <- mean(T2 > CL_T2)
  ARL <- 1 / frac_out
  if (print) {
    print(paste0("T2 ", frac_out))
    print(paste0("ARL ", ARL))
  }
  list(
    m = m,
    Sinv = Sinv,
    T2 = T2,
    CL_T2 = CL_T2,
    ARL = ARL,
    ind_out_tot = ind_out_tot
  )
}

phase2_multiv <- function(X_mat_list_new,
                          mod_Phase_I,
                          plot = TRUE,
                          print = TRUE) {
  Xmeans_new <- sapply(X_mat_list_new, rowMeans)
  p <- ncol(Xmeans_new)
  m <- mod_Phase_I$m
  Sinv <- mod_Phase_I$Sinv
  Xcen <- t(t(Xmeans_new) - m)
  T2 <- rowSums((Xcen %*% Sinv) * Xcen)
  CL_T2 <- mod_Phase_I$CL_T2
  if (plot) {
    par(mfrow = c(1, 1))
    plot(T2)
    abline(h = CL_T2)
  }
  frac_out <- mean(T2 > CL_T2)
  ARL <- 1 / frac_out
  if (print) {
    print(paste0("T2 ", frac_out))
    print(paste0("ARL ", ARL))
  }
  list(
    T2 = T2,
    CL_T2 = CL_T2,
    ARL = ARL,
    Xmeans_new = Xmeans_new,
    frac_out = frac_out
  )
}


# Competitors: profile monitoring methods (MFCC, iterMFCC, OutMFCC) -------------------

phase1_funcharts_i <- function(X,
                               alpha = 0.05,
                               fev = 0.8,
                               plot = TRUE,
                               print = TRUE,
                               max_iter = 100,
                               ind_out = NULL) {
  mfdobj_pul <- X
  iter <- 1
  if (is.null(ind_out)) {
    ind_out <- rep(1, 2)
  } else {
    mfdobj_pul <- X[-ind_out]
  }
  ind_out_tot <- NULL
  nobs <- dim(mfdobj_pul$coefs)[2]
  ind_obs <- 1:nobs
  while (length(ind_out) > 0 & iter <= max_iter) {
    nobs <- dim(mfdobj_pul$coefs)[2]
    nb <- mfdobj_pul$basis$nbasis
    nvars <- dim(mfdobj_pul$coefs)[3]
    nharm_max <- min(nobs - 1, nb * nvars)

    mod_pca <- pca_mfd(mfdobj_pul, nharm = nharm_max)
    K <- which(cumsum(mod_pca$varprop) >= fev)[1]
    cc <- funcharts:::get_T2_spe(
      mod_pca,
      1:K,
      newdata_scaled = scale_mfd(
        mfdobj_pul,
        center = mod_pca$center_fd,
        scale = mod_pca$scale_fd
      )
    )
    T2 <- cc$T2
    SPE <- cc$spe
    nobs <- length(T2)
    alpha_sid <- 1 - (1 - alpha) ^ (1 / 2)
    CL_T2 <- qchisq(1 - alpha_sid, K)

    ### Jackson and Mudholkar
    values_spe <- mod_pca$values[(K + 1):length(mod_pca$values)]
    teta_1 <- sum(values_spe)
    teta_2 <- sum(values_spe ^ 2)
    teta_3 <- sum(values_spe ^ 3)
    h0 = 1 - (2 * teta_1 * teta_3) / (3 * teta_2^2)

    c_alpha <- sign(h0) * abs(qnorm(alpha_sid))
    CL_SPE <- teta_1 * (((c_alpha * sqrt(2 * teta_2 * h0^2)) / teta_1) + 1 + (teta_2 * h0 * (h0 - 1)) / teta_1^2) ^ (1 / h0)

    if (plot) {
      par(mfrow = c(1, 2))
      plot(T2)
      abline(h = CL_T2)
      plot(SPE)
      abline(h = CL_SPE)
      par(mfrow = c(1, 1))
    }
    ind_out <- which(T2 > CL_T2 | SPE > CL_SPE)
    if (length(ind_out) > 0) {
      mfdobj_pul <- mfdobj_pul[-ind_out]
      ind_out_tot <- c(ind_out_tot, ind_obs[ind_out])
      ind_obs <- ind_obs[-ind_out]
    }

    iter <- iter + 1

  }
  if (max_iter == 1)
    ind_out_tot <- NULL
  cc <- funcharts:::get_T2_spe(
    mod_pca,
    1:K,
    newdata_scaled = scale_mfd(X,
                               center = mod_pca$center_fd,
                               scale = mod_pca$scale_fd)
  )
  T2 <- cc$T2
  SPE <- cc$spe

  nout <- sum(T2 > CL_T2 | SPE > CL_SPE)

  frac_out <- length(which(T2 > CL_T2 | SPE > CL_SPE)) / nobs
  ARL <- 1 / frac_out
  if (print) {
    print(paste0("T2 " , mean(T2 > CL_T2)))
    print(paste0("SPE " , mean(SPE > CL_SPE)))
    print(paste0("Fraction OC " , frac_out))
    print(paste0("ARL ", ARL))
  }

  list(
    mod_pca = mod_pca,
    T2 = T2,
    CL_T2 = CL_T2,
    SPE = SPE,
    CL_SPE = CL_SPE,
    ARL = ARL,
    K = K,
    nout = nout,
    X_mfd = X,
    ind_out_tot = ind_out_tot
  )
}

phase1_funcharts <- function(X,
                             alpha = 0.05,
                             alpha_out = 0.0027,
                             fev = 0.8,
                             plot = TRUE,
                             print = TRUE,
                             max_iter = 100,
                             ind_out = NULL,
                             adjust = "no",
                             X_mfd_tuning = NULL,
                             K_fold = 10) {
  mod_phase_I <- phase1_funcharts_i(
    X = X,
    alpha = alpha_out,
    fev = fev,
    plot = FALSE,
    print = FALSE,
    max_iter = max_iter,
    ind_out = ind_out
  )
  mod_pca <- mod_phase_I$mod_pca
  CL_T2 <- mod_phase_I$CL_T2
  CL_SPE <- mod_phase_I$CL_SPE
  K <- mod_phase_I$K
  mod_T2_spe_all <- funcharts:::get_T2_spe(
    mod_phase_I$mod_pca,
    1:K,
    newdata_scaled = scale_mfd(
      mod_phase_I$X_mfd,
      center = mod_phase_I$mod_pca$center_fd,
      scale = mod_phase_I$mod_pca$scale_fd
    )
  )
  T2_all <- mod_T2_spe_all$T2
  SPE_all <- mod_T2_spe_all$spe

  if (adjust == "no") {
    if (plot) {
      par(mfrow = c(1, 2))

      plot(T2_all, ylim = c(0, max(T2_all)))
      abline(h = mod_phase_I$CL_T2)
      plot(SPE_all, ylim = c(0, max(SPE_all)))
      abline(h = mod_phase_I$CL_SPE)
    }

    T2_tun <- SPE_tun <- X_mfd_tuning <- NULL

  } else if (adjust == "tuning_set") {
    if (is.null(X_mfd_tuning))
      stop("You should provide the tuning set!")

    mod_phase_I_tun <- phase1_funcharts_i(
      X = X_mfd_tuning,
      alpha = alpha_out,
      fev = fev,
      plot = FALSE,
      print = FALSE,
      max_iter = max_iter,
      ind_out = ind_out
    )
    X_mfd_tuning_nout <- X_mfd_tuning
    if (!is.null(mod_phase_I_tun$ind_out_tot)) {
      X_mfd_tuning_nout <- X_mfd_tuning[-mod_phase_I_tun$ind_out_tot]
    }
    X_tuning_scaled <- scale_mfd(X_mfd_tuning_nout,
                                 center = mod_pca$center_fd,
                                 scale =  mod_pca$scale_fd)
    scores_tuning <- funcharts:::get_scores(
      mod_pca,
      components = 1:dim(mod_pca$harmonics$coefs)[2],
      newdata_scaled = X_tuning_scaled
    )

    mean_scores_tuning_rob_mean <- colMeans(scores_tuning)
    S_scores_tuning_rob <- cov(scores_tuning)

    T_mean <- apply(S_scores_tuning_rob, 1:2, mean)

    T_T2 <- S_scores_tuning_rob[1:K, 1:K]
    T_T2_inv <- solve(T_T2)
    T_SPE <- S_scores_tuning_rob[-(1:K), -(1:K)]

    scores_tuning_cen <- t(t(scores_tuning[, 1:K]) - mean_scores_tuning_rob_mean[1:K])
    T2_tun <- rowSums((scores_tuning_cen %*% T_T2_inv) * scores_tuning_cen)

    alpha_sid <- 1 - (1 - alpha) ^ (1 / 2)
    ntun <- nrow(scores_tuning)
    CL_T2 <- qf(1 - alpha_sid, K, ntun - K) * (K * (ntun - 1) * (ntun + 1)) / ((ntun - K) * ntun)

    scores_tun_SPE <- t(t(scores_tuning[,-(1:K)]) - mean_scores_tuning_rob_mean[-(1:K)])
    SPE_tun <- rowSums(scores_tun_SPE ^ 2)

    e <- eigen(T_SPE)

    ###Jackson and Mudholkar
    values_spe <- e$values
    teta_1 <- sum(values_spe)
    teta_2 <- sum(values_spe ^ 2)
    teta_3 <- sum(values_spe ^ 3)
    h0 <- 1 - (2 * teta_1 * teta_3) / (3 * teta_2 ^ 2)

    c_alpha <- sign(h0) * abs(qnorm(alpha_sid))
    CL_SPE <- teta_1 * (((c_alpha * sqrt(2 * teta_2 * h0^2)) / teta_1) + 1 + (teta_2 * h0 * (h0 - 1)) / teta_1^2)^(1 / h0)

    if (plot) {
      par(mfrow = c(2, 2))
      plot(T2_all, ylim = c(0, max(T2_all)))
      abline(h = mod_phase_I$CL_T2)
      plot(SPE_all, ylim = c(0, max(SPE_all)))
      abline(h = mod_phase_I$CL_SPE)
      plot(T2_tun, ylim = c(0, max(T2_all)))
      abline(h = CL_T2, col = 2)
      abline(h = mod_phase_I$CL_T2)
      plot(SPE_tun, ylim = c(0, max(SPE_all)))
      abline(h = CL_SPE, col = 2)
      abline(h = mod_phase_I$CL_SPE)
    }
    frac_out <- mean(T2_tun > CL_T2 | SPE_tun > CL_SPE)
    ARL <- 1 / frac_out
    if (print) {
      print(paste0("T2 " , mean(T2_tun > CL_T2)))
      print(paste0("SPE " , mean(SPE_tun > CL_SPE)))
      print(paste0("Fraction OC  " , frac_out))
      print(paste0("ARL ", ARL))
    }
  }

  out <- list(
    T2 = T2_all,
    SPE = SPE_all,
    T2_tun = T2_tun,
    SPE_tun = SPE_tun,
    CL_T2 = CL_T2,
    CL_SPE = CL_SPE,
    X_mfd = mod_phase_I$X_mfd,
    X_mfd_tuning = X_mfd_tuning,
    mod_phase_I = mod_phase_I,
    mod_phase_I_tun = mod_phase_I_tun,
    adjust = adjust,
    T_T2_inv = T_T2_inv,
    mean_scores_tuning_rob_mean = mean_scores_tuning_rob_mean,
    mod_phase_I_tun = mod_phase_I_tun,
    scores_tuning = scores_tuning
  )
  return(out)
}

phase2_funcharts <- function(X_new,
                             mod_Phase_I,
                             plot = TRUE,
                             print = TRUE) {
  new_mod <- mod_Phase_I$mod_phase_I
  mod_pca <- new_mod$mod_pca
  K <- new_mod$K
  X_mfd_new_std <- scale_mfd(X_new,
                             center = mod_pca$center_fd,
                             scale = mod_pca$scale_fd)
  cc <- funcharts:::get_T2_spe(mod_pca, 1:K, newdata_scaled = X_mfd_new_std)
  T2 <- cc$T2
  SPE <- cc$spe

  if (mod_Phase_I$adjust == "tuning_set") {
    scores_tuning <- funcharts:::get_scores(
      mod_pca,
      components = 1:dim(mod_pca$harmonics$coefs)[2],
      newdata_scaled = X_mfd_new_std
    )
    scores_tuning_cen <- t(t(scores_tuning[, 1:K]) - mod_Phase_I$mean_scores_tuning_rob_mean[1:K])
    T2 <- rowSums((scores_tuning_cen %*% mod_Phase_I$T_T2_inv) * scores_tuning_cen)
    scores_tuning_cen <- t(t(scores_tuning[, -(1:K)]) - mod_Phase_I$mean_scores_tuning_rob_mean[-(1:K)])
    SPE <- rowSums(scores_tuning_cen ^ 2)
  }
  if (plot) {
    par(mfrow = c(1, 2))
    plot(T2)
    abline(h = mod_Phase_I$CL_T2)
    plot(SPE)
    abline(h = mod_Phase_I$CL_SPE)
    par(mfrow = c(1, 1))
  }
  frac_out <- mean(T2 > mod_Phase_I$CL_T2 | SPE > mod_Phase_I$CL_SPE)
  ARL <- 1 / frac_out
  if (print) {
    print(paste0("T2 " , mean(T2 > mod_Phase_I$CL_T2)))
    print(paste0("SPE " , mean(SPE > mod_Phase_I$CL_SPE)))
    print(paste0("Fraction OC " , frac_out))
    print(paste0("ARL ", ARL))
  }

  list(
    mod_pca = mod_pca,
    T2 = T2,
    T2_lim = mod_Phase_I$CL_T2,
    SPE = SPE,
    SPE_lim = mod_Phase_I$CL_SPE,
    ARL = ARL,
    frac_out = frac_out,
    scores_tuning = scores_tuning
  )
}


phase1_funcharts_out_i <- function(X,
                                   alpha = 0.05,
                                   fev = 0.8,
                                   plot = TRUE,
                                   print = TRUE,
                                   max_iter = 100,
                                   ind_out = NULL) {
  grid <- seq(0, 1, length.out = 200)

  mfdobj_pul <- X
  iter <- 1
  if (is.null(ind_out)) {
    ind_out <- rep(1, 2)
  } else {
    mfdobj_pul <- X[-ind_out]
  }
  ind_out_tot <- NULL
  nobs <- dim(mfdobj_pul$coefs)[2]
  ind_obs <- 1:nobs
  while (length(ind_out) > 0 & iter <= max_iter) {
    eval_mfd <- fda::eval.fd(grid, mfdobj_pul)
    Data <-
      lapply(seq(dim(eval_mfd)[3]), function(x)
        t(eval_mfd[, , x]))
    mfD <- mfData(grid, Data)
    out <- suppressWarnings(multivariate_outliergram(mfD, display = F, Fvalue = 2))
    ind_out <- out$ID_outliers
    if (length(ind_out) != 0)
      mfdobj_pul <- mfdobj_pul[-ind_out]

    nobs <- dim(mfdobj_pul$coefs)[2]
    nb <- mfdobj_pul$basis$nbasis
    nvars <- dim(mfdobj_pul$coefs)[3]
    nharm_max <- min(nobs - 1, nb * nvars)

    mod_pca <- pca_mfd(mfdobj_pul, nharm = nharm_max)
    K <- which(cumsum(mod_pca$varprop) >= fev)[1]
    cc <- funcharts:::get_T2_spe(
      mod_pca,
      1:K,
      newdata_scaled = scale_mfd(
        mfdobj_pul,
        center = mod_pca$center_fd,
        scale = mod_pca$scale_fd
      )
    )
    T2 <- cc$T2
    SPE <- cc$spe
    nobs <- length(T2)
    alpha_sid <- 1 - (1 - alpha) ^ (1 / 2)
    CL_T2 <- qchisq(1 - alpha_sid, K)

    ###Jackson and Mudholkar
    values_spe <- mod_pca$values[(K + 1):length(mod_pca$values)]
    teta_1 <- sum(values_spe)
    teta_2 <- sum(values_spe ^ 2)
    teta_3 <- sum(values_spe ^ 3)
    h0 <- 1 - (2 * teta_1 * teta_3) / (3 * teta_2 ^ 2)

    c_alpha  <- sign(h0) * abs(qnorm(alpha_sid))
    CL_SPE <- teta_1 * (((c_alpha * sqrt(2 * teta_2 * h0 ^ 2)) / teta_1) + 1 + (teta_2 * h0 * (h0 - 1)) / teta_1 ^ 2) ^ (1 / h0)

    if (plot) {
      par(mfrow = c(1, 2))
      plot(T2)
      abline(h = CL_T2)
      plot(SPE)
      abline(h = CL_SPE)
      par(mfrow = c(1, 1))
    }
    iter <- iter + 1

    ind_out_tot = c(ind_out_tot, ind_obs[ind_out])
    ind_obs <- ind_obs[-ind_out]
  }

  cc <- funcharts:::get_T2_spe(
    mod_pca,
    1:K,
    newdata_scaled = scale_mfd(X,
                               center = mod_pca$center_fd,
                               scale = mod_pca$scale_fd)
  )
  T2 <- cc$T2
  SPE <- cc$spe

  nout <- sum(T2 > CL_T2 | SPE > CL_SPE)

  frac_out <- length(which(T2 > CL_T2 | SPE > CL_SPE)) / nobs
  ARL <- 1 / frac_out
  if (print) {
    print(paste0("T2 " , mean(T2 > CL_T2)))
    print(paste0("SPE " , mean(SPE > CL_SPE)))
    print(paste0("Fraction OC " , frac_out))
    print(paste0("ARL ", ARL))
  }

  list(
    mod_pca = mod_pca,
    T2 = T2,
    CL_T2 = CL_T2,
    SPE = SPE,
    CL_SPE = CL_SPE,
    ARL = ARL,
    K = K,
    nout = nout,
    X_mfd = X,
    ind_out_tot = ind_out_tot
  )
}


phase1_funcharts_out <- function(X,
                                 alpha = 0.05,
                                 alpha_out = 0.0027,
                                 fev = 0.8,
                                 plot = TRUE,
                                 print = TRUE,
                                 max_iter = 100,
                                 ind_out = NULL,
                                 adjust = "no",
                                 X_mfd_tuning = NULL,
                                 K_fold = 10) {
  mod_phase_I <- phase1_funcharts_out_i(
    X = X,
    alpha = alpha_out,
    fev = fev,
    plot = FALSE,
    print = FALSE,
    max_iter = max_iter,
    ind_out = ind_out
  )
  mod_pca <- mod_phase_I$mod_pca
  CL_T2 <- mod_phase_I$CL_T2
  CL_SPE <- mod_phase_I$CL_SPE
  K <- mod_phase_I$K
  mod_T2_spe_all <- funcharts:::get_T2_spe(
    mod_phase_I$mod_pca,
    1:K,
    newdata_scaled = scale_mfd(
      mod_phase_I$X_mfd,
      center = mod_phase_I$mod_pca$center_fd,
      scale = mod_phase_I$mod_pca$scale_fd
    )
  )
  T2_all <- mod_T2_spe_all$T2
  SPE_all <- mod_T2_spe_all$spe

  if (adjust == "no") {
    if (plot) {
      par(mfrow = c(1, 2))

      plot(T2_all, ylim = c(0, max(T2_all)))
      abline(h = mod_phase_I$CL_T2)
      plot(SPE_all, ylim = c(0, max(SPE_all)))
      abline(h = mod_phase_I$CL_SPE)
    }

    T2_tun <- SPE_tun <- X_mfd_tuning <- NULL

  }   else if (adjust == "tuning_set") {
    if (is.null(X_mfd_tuning))
      stop("You should provide the tuning set!")

    mod_phase_I_tun <- phase1_funcharts_out_i(
      X = X_mfd_tuning,
      alpha = alpha_out,
      fev = fev,
      plot = FALSE,
      print = FALSE,
      max_iter = max_iter,
      ind_out = ind_out
    )

    if (length(mod_phase_I_tun$ind_out_tot) > 0) {
      X_mfd_tuning_nout <- X_mfd_tuning[-mod_phase_I_tun$ind_out_tot]
    } else {
      X_mfd_tuning_nout <- X_mfd_tuning
    }

    X_tuning_scaled <- scale_mfd(X_mfd_tuning_nout,
                                 center = mod_pca$center_fd,
                                 scale =  mod_pca$scale_fd)
    scores_tuning <- funcharts:::get_scores(
      mod_pca,
      components = 1:dim(mod_pca$harmonics$coefs)[2],
      newdata_scaled = X_tuning_scaled
    )

    mean_scores_tuning_rob_mean <- colMeans(scores_tuning)
    S_scores_tuning_rob <- cov(scores_tuning)

    T_mean <- apply(S_scores_tuning_rob, 1:2, mean)

    T_T2 <- S_scores_tuning_rob[1:K, 1:K]
    T_T2_inv <- solve(T_T2)
    T_SPE <- S_scores_tuning_rob[-(1:K), -(1:K)]

    scores_tuning_cen <-
      t(t(scores_tuning[, 1:K]) - mean_scores_tuning_rob_mean[1:K])
    T2_tun <-
      rowSums((scores_tuning_cen %*% T_T2_inv) * scores_tuning_cen)

    alpha_sid <- 1 - (1 - alpha) ^ (1 / 2)

    ntun <- nrow(scores_tuning)
    CL_T2 = qf(1 - alpha_sid, K, ntun - K) * (K * (ntun - 1) * (ntun + 1)) / ((ntun - K) * ntun)


    scores_tun_SPE <-
      t(t(scores_tuning[, -(1:K)]) - mean_scores_tuning_rob_mean[-(1:K)])
    SPE_tun <- rowSums(scores_tun_SPE ^ 2)

    e <- eigen(T_SPE)


    ###Jackson and Mudholkar
    values_spe <- e$values
    teta_1 <- sum(values_spe)
    teta_2 <- sum(values_spe ^ 2)
    teta_3 <- sum(values_spe ^ 3)
    h0 <- 1 - (2 * teta_1 * teta_3) / (3 * teta_2 ^ 2)

    c_alpha <- sign(h0) * abs(qnorm(alpha_sid))
    CL_SPE <- teta_1 * (((c_alpha * sqrt(2 * teta_2 * h0 ^ 2)) / teta_1) + 1 + (teta_2 * h0 * (h0 - 1)) / teta_1 ^ 2) ^ (1 / h0)

    if (plot) {
      par(mfrow = c(2, 2))

      plot(T2_all, ylim = c(0, max(T2_all)))
      abline(h = mod_phase_I$CL_T2)
      plot(SPE_all, ylim = c(0, max(SPE_all)))
      abline(h = mod_phase_I$CL_SPE)
      plot(T2_tun, ylim = c(0, max(T2_all)))
      abline(h = CL_T2, col = 2)
      abline(h = mod_phase_I$CL_T2)
      plot(SPE_tun, ylim = c(0, max(SPE_all)))
      abline(h = CL_SPE, col = 2)
      abline(h = mod_phase_I$CL_SPE)
    }
    frac_out <- mean(T2_tun > CL_T2 | SPE_tun > CL_SPE)
    ARL <- 1 / frac_out
    if (print) {
      print(paste0("T2 " , mean(T2_tun > CL_T2)))
      print(paste0("SPE " , mean(SPE_tun > CL_SPE)))
      print(paste0("Fraction OC  " , frac_out))
      print(paste0("ARL ", ARL))
    }
  }

  out <- list(
    T2 = T2_all,
    SPE = SPE_all,
    T2_tun = T2_tun,
    SPE_tun = SPE_tun,
    CL_T2 = CL_T2,
    CL_SPE = CL_SPE,
    X_mfd = mod_phase_I$X_mfd,
    X_mfd_tuning = X_mfd_tuning,
    mod_phase_I = mod_phase_I,
    mod_phase_I_tun = mod_phase_I_tun,
    adjust = adjust,
    T_T2_inv = T_T2_inv,
    mean_scores_tuning_rob_mean = mean_scores_tuning_rob_mean
  )
  return(out)
}


# Simulation functions ----------------------------------------------------
generate_cov_str <- function(p = 3,
                             P = 100,
                             correlation = "decreasing",
                             k = 1) {
  n_comp_x <- 100
  x_seq <- seq(0, 1, l = P)

  get_mat <- function(cov) {
    P <- length(cov)
    covmat <- matrix(0, nrow = P, ncol = P)
    for (ii in 1:P) {
      covmat[ii, ii:P] <- cov[1:(P - ii + 1)]
      covmat[P - ii + 1, 1:(P - ii + 1)] <- rev(cov[1:(P - ii + 1)])
    }
    covmat
  }
  eig <- covmatList <- list()
  cov1 <- besselJ(x_seq * 32, 0)
  covmat1 <- get_mat(cov1)
  eig1 <- eigen(covmat1)
  w <- 1 / P
  eig1$vectors <- eig1$vectors / sqrt(w)
  eig1$values <- eig1$values * w
  for (ii in 1:p) {
    covmatList[[ii]] <- covmat1
    eig[[ii]] <- eig1
  }
  eigList <- eig

  eigenvalues <- rowMeans(sapply(1:p, function(ii)
    eig[[ii]]$values))

  corr_mat <- vector("list", p)
  for (ii in 1:p) {
    corr_mat[[ii]] <- vector("list", p)
  }

  for (ii in 1:p) {
    for (jj in ii:p) {
      if (jj == ii) {
        corr_mat[[ii]][[jj]] <- covmatList[[ii]]
      } else {
        V <- eigList[[ii]]$vectors[, 1:n_comp_x]
        lambdas <- eigenvalues[1:n_comp_x]

        if (correlation == "decreasing") {
          sum <- V %*% (t(V) * lambdas) / (1 + abs(ii - jj) / k)
        }
        if (correlation == "equal") {
          sum <- V %*% (t(V) * lambdas) / (1 + 1 / k)
        }
        if (!(correlation %in% c("decreasing", "equal"))) {
          stop("correlation must be either decreasing or equal")
        }

        corr_mat[[ii]][[jj]] <- sum
        corr_mat[[jj]][[ii]] <- t(sum)
      }
    }
    corr_mat[[ii]] <- do.call("cbind", corr_mat[[ii]])
  }
  corr_mat <- do.call("rbind", corr_mat)
  e <- eigen(corr_mat, n_comp_x * p)

  list(e = e, P = P)
}

simulate_data <- function(nobs = 1000,
                          p = 3,
                          p_cellwise = 0,
                          p_casewise = 0,
                          sd_e = 0.005,
                          sd = 0.002,
                          T_exp = 0.6,
                          outlier = "no",
                          M_outlier_case = 0,
                          M_outlier_cell = 0,
                          OC = "no",
                          M_OC = 0,
                          P = 100,
                          max_n_cellwise = Inf,
                          correlation = "decreasing",
                          k = 1,
                          which_OC = 5) {
  cov_str <- generate_cov_str(p, P, correlation = correlation, k = k)
  e <- cov_str$e
  P <- cov_str$P
  x_seq <- seq(0, 1, l = P)

  w <- 1 / P
  n_comp_x <- max(which((cumsum(e$values) / sum(e$values)) < 1))

  meig <- list()
  for (ii in 1:p) {
    index <- 1:P + (ii - 1) * P
    meig[[ii]] <- e$vectors[index, 1:n_comp_x] / sqrt(w)
  }
  meigenvalues <- e$values[1:n_comp_x] * w
  meigenvalues[meigenvalues < 0] <- 0

  csi_X <- rnorm(
    n = length(meigenvalues) * nobs,
    mean = 0,
    sd = sqrt(rep(meigenvalues, each = nobs))
  )
  csi_X <- matrix(csi_X, nrow = nobs)


  fun_phase <- function(x_ini, M_g) {
    x <- numeric(P)
    T1 <- 0.0
    T2 <- 0.6
    a <- (T2 - M_g / 1.5 - T1) / (T2 - T1)
    b <- T1 - a * T1
    xx <- x_ini * a + b
    a <- (T2 - M_g / 1.5 - 1) / (T2 - 1)
    b <- 1 - a
    xx2 <- x_ini * a + b
    x[1:(T1 * P)] <- x_ini[1:(T1 * P)]
    x[((T1 * P) + 1):(T2 * P)] <- xx[((T1 * P) + 1):(T2 * P)]
    x[(T2 * P + 1):(P)] <- xx2[(T2 * P + 1):(P)]
    x <-
      (x - min(x)) / (max(x) - min(x)) * (0.15 - 0.0045) + 0.0045

    x3 <- x_ini ^ (1 + M_g / 0.6)
    x3 <-
      (x3 - min(x3)) / (max(x3) - min(x3)) * (0.15 - 0.0045) + 0.0045
    x <- x3

    - (M_g / 5) * x_ini + 0.45 * (M_g / 5) + 0.2074 + 0.3117 * exp((-(371.4)) * x) + 0.5284 * (1 - exp((-(-0.8217)) * x)) - 423.3 * (1 + tanh(-26.15 * (x - (-0.1715))))
  }
  fun_m <- function(x_ini, M_g) {
    x <- x_ini
    x <- (x - min(x)) / (max(x) - min(x)) * (0.15 - 0.0045) + 0.0045
    0.2074 + 0.3117 * exp((-(371.4)) * x) + 0.5284 * (1 - exp((-(-0.8217)) * x)) - 423.3 * (1 + tanh(-26.15 * (x - (-0.1715))))
  }
  if (OC == "OC_P") {
    f1_m <- fun_m
  } else {
    f1_m <- fun_m
  }

  if (outlier == "no") {
    cont_function <- function(n_g, p_g, M_g, T_exp)
      0
  } else if (outlier == "outlier_M") {
    cont_function <- function(nobs, p_g, M_g, T_exp) {
      rb <-
        stats::rbinom(nobs, 1, p_g) * sample(c(-1, 1), nobs, replace = T)
      M_g * matrix(rb , P, nobs, byrow = T)
    }
  } else if (outlier == "outlier_E") {
    cont_function <- function(nobs, p_g, M_g, T_exp) {
      rb <- stats::rbinom(nobs, 1, p_g)
      grid <- 1:P
      grid_new <- (grid - min(grid)) / (max(grid) - min(grid))
      a <- -M_g / (1 - T_exp)
      y <- a * (grid_new - T_exp)
      y[y > 0] <- 0

      grid <- 1:P
      grid_new <- (grid - min(grid)) / (max(grid) - min(grid))
      a <- -M_g * 0.5 / (1 - T_exp)
      y2 <- a * (grid_new - T_exp)
      y[y2 > 0] <- y2[y2 > 0]
      if (nobs == 1) {
        out_values <- (y * matrix(rb, P, nobs, byrow = T))
      } else {
        out_values <- (y * matrix(rb, P, nobs, byrow = T))
      }

      return(out_values)
    }
  }
  else if (outlier == "outlier_P") {
    cont_function <- function(nobs, p_g, M_g, T_exp) {
      rb <- stats::rbinom(nobs, 1, p_g)
      (-fun_m(x_seq, 0) + fun_phase(x_seq, M_g)) * matrix(rb, P, nobs, byrow = T)
    }
  }
  if (OC == "no") {
    out_function <- function(n_g, p_g, M_g, T_exp)
      rep(0, P)
  }
  else if (OC == "OC_M") {
    out_function <- function(nobs, M_g, T_exp) {
      rep(M_g, P)
    }
  }
  else if (OC == "OC_E") {
    out_function <- function(nobs,  M_g, T_exp) {
      out_values <- rep(0 , P)
      grid <- 1:P
      grid_new <- (grid - min(grid)) / (max(grid) - min(grid))
      a <- -M_g / (1 - T_exp)
      y <- a * (grid_new - T_exp)
      y[y > 0] <- 0


      out_values <- rep(0 , P)
      grid <- 1:P
      grid_new <- (grid - min(grid)) / (max(grid) - min(grid))
      a <- -M_g * 0.5 / (1 - T_exp)
      y2 <- a * (grid_new - T_exp)
      y[y2 > 0] <- y2[y2 > 0]

      out_values <- (y)

      return(out_values)
    }
  }
  else if (OC == "OC_P") {
    out_function <-
      function(n_g, M_g, T_exp)
        fun_phase(x_seq, M_g) - f1_m(x_seq, M_g)
  }
  cont_cell_mat <- matrix(0, nobs, P * p)
  for (ii in 1:p) {
    index <- 1:P + (ii - 1) * P
    cont_cell_mat[, index] <-
      t(cont_function(nobs, p_cellwise, M_outlier_cell, T_exp))
  }
  if (max_n_cellwise < p) {
    cont_cell_mat_which <-
      sapply(1:10, function(jj)
        round(rowSums(abs(cont_cell_mat[, P * (jj - 1) + (1:P)])) , 5) > 0)
    rows_greater_than_allowed <-
      rowSums(cont_cell_mat_which) > max_n_cellwise

    for (ii in 1:nobs) {
      if (rows_greater_than_allowed[ii]) {
        idx <- which(cont_cell_mat_which[ii,])
        which_to_retain <- sample(idx, max_n_cellwise)
        which_to_exclude <- setdiff(idx, which_to_retain)
        for (jj in which_to_exclude) {
          cont_cell_mat[ii, P * (jj - 1) + (1:P)] <- 0
        }
      }
    }
  }

  cont_case_mat <- matrix(0, nobs, P * p)
  ind_out_case <- stats::rbinom(nobs, 1, p_casewise)
  for (ii in 1:nobs) {
    if (ind_out_case[ii] == 1) {
      cont_case_mat[ii,] <-
        as.numeric(sapply(1:p, function(iii)
          t(
            cont_function(1, 1, M_outlier_case, T_exp)
          )))
    }
  }
  cont_mat <- cont_cell_mat + cont_case_mat
  ind_out <-
    lapply(1:p, function(ii)
      which((abs(
        rowSums(cont_mat[, 1:P + (ii - 1) * P])
      ) > 0)))
  cont_list <- list()
  for (ii in 1:p) {
    index <- 1:P + (ii - 1) * P
    cont_list[[ii]] <- cont_mat[, index]
  }
  oc_case_mat <- matrix(0, nobs, P * p)
  for (ii in 1:nobs) {
    oc_case_mat[ii, ] <- as.numeric(sapply(1:p, function(jj) {
      if (!(jj %in% which_OC)) {
        ret <- rep(0, P)
      } else {
        ret <- t(out_function(1, M_OC, T_exp))
      }
      return(ret)
    }))

  }
  oc_mat <- oc_case_mat
  oc_list <- list()
  for (ii in 1:p) {
    index <- 1:P + (ii - 1) * P
    oc_list[[ii]] <- oc_mat[, index]
  }

  X_mat_list <- list()
  for (ii in 1:p) {
    X1_scaled <- csi_X %*% t(meig[[ii]])
    X_mat_list[[ii]] <-
      t(f1_m(x_seq, M_OC) + t(X1_scaled) * sd) + rnorm(prod(dim(X1_scaled)), sd = sd_e) + cont_list[[ii]] + oc_list[[ii]]
  }
  names(X_mat_list) <- paste0("X", sprintf(1:p, fmt = "%02d"))
  out <- list(X_mat_list = X_mat_list, ind_out = ind_out)
  return(out)
}


# plot results ------------------------------------------------------------
gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
}
plot_fun <- function(TDR_mean, TDR_sd) {
  severity = rep(0:4, ncol(TDR_mean))
  rownames(TDR_mean) = seq(1:5)
  colnames(TDR_mean) <- methods_names
  df_mean <- data.frame(TDR_mean) %>% gather(method, mean, 1:ncol(TDR_mean))
  df_TD <- data.frame(df_mean,
                      sd = stack(as.data.frame(TDR_sd, drop = TRUE))[, 1],
                      d = severity)
  df_TD$method <- factor(df_TD$method, levels = c(methods_names[!(methods_names %in% "RoMFCC")], "RoMFCC"))

  gg_color_hue <- function(n) {
    hues = seq(15, 375, length = n + 1)
    hcl(h = hues, l = 65, c = 100)[1:n]
  }
  pal <- gg_color_hue(6)
  pal[6] <- "#FB61D7"
  pal[length(methods_names)] <- "black"
  p <- ggplot(df_TD, aes(x = d, y = mean))

  p <- p + geom_hline(yintercept = 20,
                      color = "grey",
                      linewidth = 0.8) +
    labs(y = expression(widehat(ARL))) +
    coord_cartesian(ylim = c(1, 30))

  shape_levels <- c(8, 9, 25:21)
  shape_levels[length(methods_names)] <- 21
  linetype_levels <- 7:1
  linetype_levels[length(methods_names)] <- 1
  p <- p +
    scale_shape_manual(values = shape_levels) +
    scale_color_manual(values = pal) +
    scale_fill_manual(values = pal) +
    scale_linetype_manual(values = linetype_levels) +
    geom_line(aes(
      group = method,
      linetype = method,
      color = method
    ),
    linewidth = 0.8) +
    geom_point(aes(
      group = method,
      color = method,
      fill = method,
      shape = method
    ),
    size = 5) +
    geom_errorbar(
      aes(
        ymin = mean - 2 * sd,
        ymax = mean + 2 * sd,
        group = method,
        linetype = method,
        color = method
      ),
      width = 0.5
    ) +
    xlab("SL") +
    theme_bw() +
    theme(
      plot.title = element_text(hjust = 0.5, size = 55),
      legend.title = element_blank(),
      axis.title.y = element_text(size = 60),
      axis.title.x = element_text(size = 60),
      axis.text.x =  element_text(size = 50),
      axis.text.y =  element_text(size = 50),
      legend.text = element_text(size = 30),
      legend.key.width = unit(2, "cm"),
      legend.position = c(0.153, 0.7775) ,
      legend.background = element_rect(colour = "black")
    ) +
    theme(legend.position = c(0.83, 0.8))

  p <- p +
    geom_point(
      aes(d, mean),
      data = df_TD %>% filter(method == "RoMFCC") %>% dplyr::select(mean, d, sd),
      size = 5
    ) +
    geom_line(
      aes(d, mean),
      data = df_TD %>% filter(method == "RoMFCC") %>% dplyr::select(mean, d, sd),
      linewidth = 0.8
    ) +
    geom_errorbar(
      aes(d, ymin = mean - 2 * sd, ymax = mean + 2 * sd),
      data = df_TD %>% filter(method == "RoMFCC") %>% dplyr::select(mean, d, sd),
      width = 0.5
    )
  p
}

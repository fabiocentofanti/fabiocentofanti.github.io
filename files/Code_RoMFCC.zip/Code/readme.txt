The folder contains the R files for replicating the simulation study.

The Run.R script could be used to obtain all the figures in the Simulation Study of the manuscript by appropriately setting the simulation parameters.
By default, it provides the top-left panel of Figure 7 of the main text of the manuscript for:
      - Scenario S3 (both componentwise and casewise outliers)
      - Contamination model Out-E
      - Contamination probability 0.05
      - Contamination level C1
      - OC condition OC-E
      - OC pattern ONE

The file functions.R contains the functions to simulate data and implement the proposed and competing methods used in Run.R.




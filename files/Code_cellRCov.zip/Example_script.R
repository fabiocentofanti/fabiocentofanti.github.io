
# Example script for the cellRCov method. 

# Anomaly detection in a welding process 
######################################## 

rm(list = ls()); 
setwd(dirname(rstudioapi::getSourceEditorContext()$path))
library(parallel)
library(cellWise)  
library(pROC)
library(robustbase)  
source("cellPCA_code.R")
source("cellRCov_code.R")

Xtot <- read.table("X_RSW.txt")
labels <- Xtot[, 1]
X <- Xtot[, -1]
X <- checkDataSet(X)$remX

set.seed(1)
( ncores <- parallel::detectCores() )
n <- dim(X)[1]
p <- dim(X)[2] 
get_roc <- function(mu, S_est, X, labels, method) {
  md <- sqrt(mahalanobis(X, mu, S_est))
  roc_curve <- roc(
    labels,
    md,
    plot = F,
    print.auc = F,
    main = method,
    quite = T
  )
  return(roc_curve)
}
methods <- c("cellRCov", "RCov", "RSpearman", "caseMRCD")
lll <- 1
roc_models <- list()
for (method in methods) {
  if (method == "RCov") {
    fit <- cellRCov(
      X,
      k = 0,
      reg = T,
      onlyreg = T,
      scale = F) 
    S_est <- fit$S
    mu <- colMeans(X)
  }
  else if (method == "cellRCov") {
    fit <- cellRCov(
      X,
      k = 8,
      kmax = min(30, p),
      reg = T,
      quantile_diff = NULL,
      ncores = ncores
    ) # k=8 is selected
    S_est <- fit$S
    mod_cellPCA <- fit$mod_cellPCA
    k_cellPCA <- dim(fit$mod_cellPCA$V)[2]
    mu <- fit$mu
  }
  else if (method == "RSpearman") {
    fit <- cov_spearman(X)
    S_est <- fit
    mu <- apply(X, 2, median)
  } else if (method == 'caseMRCD') {
    fit <- try(rrcov::CovMrcd (X, alpha = 0.5))
    S_est <- fit$cov
    mu <- fit@center
  }
  roc_models[[lll]] <- get_roc(mu, S_est, X, labels, paste(method, pout))
  lll = lll + 1
}

##### Figure 4
{
  pdf(file = "Plot_data_rsw.pdf",width = 12,height = 6)
  par(mar=c(5,5,4,2)+0.1)
  matplot(t(X),type = 'l',col=(labels==1)+1, lwd = 2,
          ylab = expression(paste(m,Omega)),
          xlab = "",xaxt="n",cex.axis=2,cex.lab=2.5,cex=2)
  axis(1,at = floor(seq(1,dim(X)[2],l=6)),
       labels = floor(seq(1,dim(X)[2],l=6)),cex.axis=2)
  dev.off()
}


##### Figure 5
{
pdf(file = "Plot_roc.pdf",width = 9,height = 9)
names_vec<-c("cellRCov","RCov","RSpearman","caseMRCD")
lty_vec<-c(1,4,12,10)
col_vec<-c(1,'darkgreen','darkorange','blue')
pch_vec<-c(16,4,11,10)

par(mar=c(5,5,4,2)+0.1)
plot(1-roc_models[[1]]$sensitivities,roc_models[[1]]$specificities,
     type="l",lwd=4,ylim=c(0,1),xlim=c(0,1),xlab='FPR',ylab='TPR',
     lty=lty_vec[1],col=col_vec[1],pch=pch_vec[1],cex.axis=2,
     cex.lab=2.5,cex=2)
legend("bottomright",legend =names_vec,lty=lty_vec,col=col_vec,
       cex=2,lwd = 4)
for (hh in 2:4) {
  lines(1-roc_models[[hh]]$sensitivities,
        roc_models[[hh]]$specificities,type='l',lwd=4,
        lty=lty_vec[hh] ,col=col_vec[hh], pch=pch_vec[hh],
        cex.axis=2, cex.lab=2.5, cex=2)
}
dev.off()
}


##### AUC
auc_vec<-numeric()
for (hh in 1:length(names_vec)) {
  auc_vec[hh]<-roc_models[[hh]]$auc
  print(paste('AUC',methods[hh], "=", 
              round(roc_models[[hh]]$auc,digits = 3)))
  
}


# Robust canonical correlation analysis of the corn dataset 
###########################################################

rm(list = ls()); 
setwd(dirname(rstudioapi::getSourceEditorContext()$path))

library(parallel)
library(cellWise)  
library(CCA)
source("cellPCA_code.R")
source("cellRCov_code.R")

X<-read.table("X_corn.txt")
Y<-read.table("Y_corn.txt")

X<-checkDataSet(X)$remX
Y<-checkDataSet(Y)$remX


#### Cross-validation to calculate MCC 
set.seed(1)

cv_rCCA <- cross_validation_residual_score(X, Y, method = 'rCCA')

cv_cellRCCA <- cross_validation_residual_score(X, Y, method = 'cellRCCA', 
                                    ncores = parallel::detectCores() - 2)
cor_rCCA <- sapply(1:2, function(x)
  cor(
    cbind(
      cv_rCCA$xscorestest[, x],
      cv_rCCA$yscorestest[, x]
    ),
    method = "spearman"
  )[2, 1])
cor_cellRCCA <- sapply(1:2, function(x)
  cor(
    cbind(
      cv_cellRCCA$xscorestest[, x],
      cv_cellRCCA$yscorestest[, x]
    ),
    method = "spearman"
  )[2, 1])


##### MCC
print(paste0(
  "rCCA: MCC=",
  round(mean(cor_rCCA),digits = 3),
  "; cellRCCA MCC=",
  round(mean
  (cor_cellRCCA), digits = 3)
))

##### Figure 6
{
  for (ll in 1:2) {
    pdf(
      file = paste0("rCCA_", ll, ".pdf"),
      width = 9,
      height = 9
    )
    par(mar = c(5, 5, 4, 2) + 0.1)
    plot((
      cv_rCCA$xscorestest[, ll] - median(cv_rCCA$xscorestest[, ll])
    ) / mad(cv_rCCA$xscorestest[, ll]),
    (
      cv_rCCA$yscorestest[, ll] - median(cv_rCCA$yscorestest[, ll])
    ) / mad(cv_rCCA$yscorestest[, ll]),
    xlab = bquote(U[.(ll)]),
    ylab = bquote(V[.(ll)]),
    ylim = c(-3.5, 3.5),
    xlim = c(-3.5, 3.5),
    cex.axis = 2,
    cex.lab = 2.5,
    cex = 2,
    pch = 16
    )
    abline(a = 0, b = cor_rCCA[ll], lty = 2)
    dev.off()
    
    pdf(
      file = paste0("cellRCCA_", ll, ".pdf"),
      width = 9,
      height = 9
    )
    par(mar = c(5, 5, 4, 2) + 0.1)
    plot((
      cv_cellRCCA$xscorestest[, ll] - 
        median(cv_cellRCCA$xscorestest[, ll])) / 
        mad(cv_cellRCCA$xscorestest[, ll]),
    (
      cv_cellRCCA$yscorestest[, ll] - 
        median(cv_cellRCCA$yscorestest[, ll])) / 
      mad(cv_cellRCCA$yscorestest[, ll]),
    xlab = bquote(U[.(ll)]),
    ylab = bquote(V[.(ll)]),
    ylim = c(-3.5, 3.5),
    xlim = c(-3.5, 3.5),
    cex.axis = 2,
    cex.lab = 2.5,
    cex = 2,
    pch = 16
    )
    abline(a = 0, b = cor_cellRCCA[ll], lty = 2)
    dev.off()
  }
}

################################################################
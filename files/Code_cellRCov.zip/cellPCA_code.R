
#############################################################
##                                                          #
## Functions to carry out cellPCA                           #
##                                                          #
#############################################################

### Generic functions

psiWrap <- function(x, b, c, A, B, k) {
  # Wrapping psi function
  indmid <- which(abs(x) >= b & abs(x) <= c)
  indup  <- which(abs(x) >= c)
  x[indmid] <- (A * (k - 1)) ^ (0.5) *
    tanh(0.5 * ((k - 1) * B ^ 2 / A) ^ 0.5 *
           (c - abs(x[indmid]))) * sign(x[indmid])
  x[indup] <- 0
  return(x)
}


calculateq1q2 <- function(b, c, maxit = 500, precScale = 1e-10) {
  # This function calculates the necessary parameters to make 
  # the wrapping psi function continuous.
  #
  # Input:
  # b: corner point of the wrapping psi function
  # c: rejection point of the wrapping psi function
  
  A <- 2 * pnorm(c) - 1 - 2 * c * dnorm(c)
  B <- 2 * pnorm(c) - 1
  k <- max(1,c)
  
  Anew <- A
  Bnew <- B
  knew <- k
  converged <- FALSE
  iter <- 0
  while (!converged & iter < maxit) {
    A <- Anew
    B <- Bnew
    k <- knew
    
    knew <- optimize(f = function(y) 
      abs(b - (A * (y - 1)) ^ (0.5) *
            tanh(0.5 * ((y - 1) * B ^ 2 / A) ^ 0.5*(c - b))),
      interval = c(1 + precScale, 1000),tol = precScale)$minimum
    Anew <- stats::integrate(f = function(y) psiWrap(y, b, c, A, B, k) ^ 2 *
                        dnorm(y), lower = -c, upper = c)$value
    Bnew <-  stats::integrate(f = function(y) abs(psiWrap(y, b, c, A, B, k)) *
                        abs(y) * dnorm(y), lower = -c, upper = c)$value
    iter <- iter + 1
    converged <- max(abs(Anew - A), abs(Bnew - B), abs(knew - k)) < precScale
  }
  q1 <- sqrt(Anew * (knew - 1))
  q2 <- Bnew / 2 * sqrt((knew - 1) / Anew)
  return(list(q1 = q1, q2 = q2))
}


rho_tanh <- function(x, b = 1.5, bb = NULL, cc = NULL, q1 = NULL, q2 = NULL) { 
  # The rho function of wrapping.
  if(is.null(bb) | is.null(cc)){
    xx <- 1.5 * x / b
    bb <- 1.5
    cc <- 4
    q1 <- 1.540793
    q2 <- 0.8622731
    q12 <- q1 / q2
    dd <- 3.7622126668
    rhos <- rep(NA, length(xx))
    indsmall <- which(abs(xx) <= bb)
    rhos[indsmall] <- (xx[indsmall] ^ 2) / 2
    indmid <- which(abs(xx) > bb & abs(xx) < cc)
    rhos[indmid] <- (dd - q12 * log(cosh(q2 * (cc - abs(xx[indmid])))))
    indbig <- which(abs(xx) >= cc)
    rhos[indbig] = dd
  }
  else{
    if(bb > 100) {
      rhos <- rep(NA, length(x))
      rhos <- (x ^ 2)
    }
    else{
      xx <- x
      if (is.null(q1)) {
        params <- calculateq1q2(bb, cc)
        q1 <- params$q1
        q2 <- params$q2
      }
      
      q12 <- q1 / q2
      dd <- (bb ^ 2 / 2) + (q1 / q2) * log(cosh(q2 * (cc - bb)))
      
      rhos <- rep(NA, length(xx))
      indsmall <- which(abs(xx) <= bb)
      rhos[indsmall] <-  (xx[indsmall] ^ 2) / 2
      indmid <- which(abs(xx) > bb & abs(xx) < cc)
      rhos[indmid] <-
        (dd - q12 * log(cosh(q2 * (cc - abs(
          xx[indmid]
        )))))
      indbig <- which(abs(xx) >= cc)
      rhos[indbig] <- dd
    }
  }
  return(rhos)
}


weight_tanh <- function(x, b = 1.5, bb = NULL, cc = NULL, q1 = NULL, q2 = NULL) { 
  # the weight function of wrapping.
  #
  psitanh <- function(xx, bb, cc, q1, q2) {
    indb <- which(abs(xx) <= bb)
    indc <- which(bb < abs(xx) & abs(xx) <= cc)
    indbig <- which(abs(xx) > cc)
    psi <- rep(NA, length(xx))
    psi[indb] <- xx[indb]
    psi[indc] <- q1 * tanh(q2 * (cc - abs(xx[indc]))) * sign(xx[indc])
    psi[indbig] <- 0
    psi
  }
  
  if (is.null(bb) | is.null(cc)) {
    xx <- 1.5 * x / b
    bb <- 1.5
    cc <- 4
    q1 <- 1.540793
    q2 <- 0.8622731
    q12 <- q1 / q2
    dd <- 3.7622126668
    tt <- xx
    tt[is.na(tt)] <- NA
    tt[!is.na(tt)] <-
      psitanh(tt[!is.na(tt)], bb, cc, q1, q2) /  tt[!is.na(tt)]
    tt[xx == 0] <- 1
  }
  else{
    if (bb > 100) {
      tt <- x
      tt[is.na(tt)] <- NA
      tt[!is.na(tt)] <- 1
    }
    else{
      xx <- x
      if (is.null(q1)) {
        params <- calculateq1q2(bb, cc)
        q1 <- params$q1
        q2 <- params$q2
      }
      q12 <- q1 / q2
      dd <- (bb ^ 2 / 2) + (q1 / q2) * log(cosh(q2 * (cc - bb)))
      tt <- xx
      tt[is.na(xx)] <- NA
      tt[!is.na(xx)] <-
        psitanh(tt[!is.na(xx)], bb, cc, q1, q2) /  tt[!is.na(xx)]
      tt[xx == 0] <- 1
    }
    
  }
  return(tt)
}


MSE <- function(X, V, mu, U = NULL, ind = NULL) {
  # Function that computes the mean squared error (MSE).
  n <- dim(X)[1]
  p <- dim(X)[2]
  if(is.null(U)){
    X_fit <- ((X - matrix(mu, n, p, byrow = T)) %*%V)%*%
      solve(t(V) %*% V) %*% t(V) + matrix(mu, n, p, byrow = T)
  } else{
    X_fit <- (U)%*%t(V)+matrix(mu, n, p, byrow = T)
  }
  MSE <- if(is.null(ind)) mean((X - X_fit)^2) else mean(((X - X_fit) ^ 2)[ind])
  return(MSE)
}


### scale tanh
get_c_scaletanh<-function(delta = 1.8811){
  set.seed(123)
  x<-rnorm(5000)
  c_vec<-seq(0.1, 10, 0.0001)
  m_vec<-numeric()
  for (ii in 1:length(c_vec)){
    m_vec[ii]<-mean(rho_tanh(x/c_vec[ii]))
  }
  dist<-abs(m_vec-delta)
  c<-c_vec[which.min(dist)]
  return(c)
}


scale_tanh<-function (u, delta = 1.8811,
                      max.it = 100, tol = 1e-06, 
                      tolerancezero = .Machine$double.eps) {
  if(delta == 1.8811){
    c<-0.34308
  }
  else{
    c<-get_c_scaletanh(delta)
  }
  s0 <- median(abs(u),na.rm=T)/0.6745
  if (s0 < tolerancezero) 
    return(0)
  err <- tol + 1
  it <- 0
  while ((err > tol) && (it < max.it)) {
    it <- it + 1
    s1 <- sqrt(s0^2 * mean(rho_tanh(u/(c*s0)))/delta)
    err <- abs(s1 - s0)/s0
    s0 <- s1
  }
  return(s0)
}


### Functions to compute cellPCA
################################

get_tuning_const_rho2<-function(p, b_1 = 1.5, qmax = 10){  
  # Function that calculates the tuning constants for rho_2.
  set.seed(10)
  n <- 10000
  d <- ceiling(min(p/2, qmax))
  Ri <- matrix(rnorm(n*d),n,d)
  # compute scale_1 as M-scale of residuals:
  scale_1 <- apply(Ri, 2, scale_tanh) 
  # standardized cellwise residuals:
  Ri2 <- Ri/matrix(scale_1, n, d, byrow = T)
  weights_c <- weight_tanh(Ri2, b = b_1)
  # = n by d matrix of cellwise weights
  Ri2 <- rho_tanh(Ri2, b = b_1) # = result of rho_1
  Ri3 <- matrix(Ri2, n, d)*matrix(scale_1^2, n, d, byrow = T)
  # has n rows with d entries rho*scale_1^2
  rowti <- sqrt(apply(Ri3, 1, sum)/d)
  scale_2 <- scale_tanh(rowti) # is a single number
  rowti <- rowti/scale_2 
  bb <- max(quantile(rowti, 0.7), 0)
  cc <- max(quantile(rowti, 0.99), 0.3)
  if(bb<100){
    params <- calculateq1q2(bb, cc)
    q1 <- params$q1 
    q2 <- params$q2
  }
  else{
    q1 <- q2 <- NA
  }
  par <- c(bb, cc, q1, q2) # bb is the real b2, cc is the real c2
  out <- list(par = par, rowti = rowti) 
  set.seed(NULL)
  return(out)
}


cellPCA_obj <- function(Ri, rho1, rho2, scale_1 = 1,
                        scale_2 = 1, b_1, M = NULL){
  # The objective function of cellPCA. It assumes we already 
  # have M, the residuals Ri = X-Xfit = X-mu-U%*%t(V), the 
  # functions rho1 and rho2 with their tuning constants, as 
  # well as scale_1 and scale_2.
  n <- dim(Ri)[1]
  p <- dim(Ri)[2]
  if(is.null(M)) M <- matrix(1, n, p)
  scale1mat = matrix(scale_1, n, p, byrow = T)
  Ri2 <- Ri/scale1mat
  Ri2 <- rho1(Ri2, b = b_1) # = result of rho_1
  Ri3 <- matrix(Ri2, n, p) * scale1mat^2 * M
  m_i <- apply(M, 1, sum)
  rowti <- sqrt(apply(Ri3, 1, sum, na.rm = T)/m_i)
  d03 <- rho2(rowti/scale_2) * m_i # = result of rho_2
  out <- scale_2^2 * mean(d03)
  return(out)
}


upUV_geninv <- function(X, mu, U, V, W, weights_c, update_V = T) {
  # Does V-update and U-update by generalized inverse.
  n = nrow(X)
  p = ncol(X)
  #
  ## V-update:  
  if(update_V){
    Zimp = W * (X - matrix(mu, n, p, byrow = T))
    U_t <- t(U)
    # Computes the loadings per coordinate axis:
    V <- t(sapply(1:p, function(ii) {
      MASS::ginv(U_t %*% (W[, ii] * U)) %*% U_t %*% Zimp[, ii]}))
    if(nrow(V) == 1) V = t(V)
  }
  #
  ## U-update: only uses cellwise weights
  Zimpc <- (weights_c * (X - matrix(mu, n, p, byrow = T)))
  V_t <- t(V)
  U <- t(sapply(1:n, function(ii){
    MASS::ginv(V_t %*% (weights_c[ii,] * V)) %*% V_t %*% (Zimpc)[ii, ]}))
  if(nrow(U) == 1) U = t(U)
  #
  return(list(U, V))
}


normalV <- function(U1, V1, k){ # normalizes V
  e <- svd(V1)
  e <- tcrossprod(e$u, e$v) 
  V2 <- e %*% (sign(crossprod(e, V1)) * diag(1, ncol(e)))
  U2 <- U1 %*% t(V1) %*% V2
  return(list(U2 = U2, V2 = V2))
}


corr_sign <- function(U, V, V_0){
  # Correct the sign of V with respect to V_0.
  sign_e <- sign(crossprod(V, V_0)) * diag(1, ncol(V))
  U2 <- U %*% sign_e
  V2 <- V %*% sign_e
  return(list(U2 = U2, V2 = V2))
}


cellPCA <- function(X, k, b_1 = 1.5, nu = 1e-6, max_iter = 1000,
                    maxColFrac = 0.5, trace = T, signflip = T,
                    update_mu = T, V_est = T, par = NULL, 
                    U0 = NULL, V0 = NULL, mu0 = NULL, 
                    scale_1 = NULL, scale_2 = NULL){
  # Carry out cellwise and casewise robust PCA.
  # 
  # Arguments:
  # X: an n by p data matrix
  # k: the number of principal components
  # b_1: the tuning constant for rho_1 
  # nu: tolerance of the IRLS algorithm (for stopping rule)
  # max_iter: maximum number of iterations
  # maxColFrac: upper bound on the fraction (between 0 
  #    and 1) of cellwise weights of zero in any column. 
  #    If exceeded, the results of the previous iteration step 
  #    are returned.
  # trace: if TRUE the value of the objective function at each 
  #    iteration is printed
  # signflip: logical indicating if the signs of the loadings 
  #    should be flipped such that the absolutely largest value 
  #    is always positive.
  # update_mu: if FALSE, the initial mu is kept.
  # V_est: if TRUE the additional step to obtain principal 
  #    directions and center is performed. 
  # par: parameter vector including b, c, q1, and q2 to tune 
  #    rho_2. Typically NULL and computed internally.  
  # U0, V0, mu0:  initial estimators. Typically NULL and 
  #    computed internally. 
  # scale_1, scale_2: cellwise and rowwise residual scales. 
  #    Typically NULL and computed internally.
  
  X <- as.matrix(X)
  n <- dim(X)[1]
  p <- dim(X)[2]
  remX = checkDataSet(X, fracNA = 0.5, numDiscrete = 3, 
                      precScale = 1e-12, silent = T, 
                      cleanNAfirst = "columns")$remX
  if(nrow(remX) < n | ncol(remX) < p) stop(paste0(
    "checkDataSet has found an issue with this dataset.\n",
    "Please run remX = cellWise::checkDataSet(X)$remX\n",
    "and check why some cases or variables were removed.\n",
    "You could rerun cellPCA on remX instead of X."))
  
  if (k < 1) stop(" k must be at least 1")
  if (k > min(n,p)) stop(" k must be <= min(n,p)")
  if(maxColFrac < 0) stop(" maxColFrac cannot be negative")
  if(maxColFrac > 1) stop(" maxColFrac cannot be > 100%")  
  
  rhofun <- function(resid, b){rho_tanh(resid, b = b)}
  weightfun <- function(resid, b){weight_tanh(resid, b = b)}
  if(is.null(par))
    par <- get_tuning_const_rho2(p, b_1 = b_1)[[1]]
  rhofun2 <- function(resid){rho_tanh(resid, 
                                      bb = par[1], 
                                      cc = par[2],
                                      q1 = par[3], 
                                      q2 = par[4])}
  weightfun2 <- function(resid){weight_tanh(resid, 
                                            bb = par[1], 
                                            cc = par[2],
                                            q1 = par[3], 
                                            q2 = par[4])}
  if (is.null(U0)) {
    # initialization by MacroPCA    
    pars = list(silent = TRUE, scale = F, kmax = k + 1,
                DDCpars = list(tolProb = 0.99, fracNA = 0.5,cleanNAfirst="columns"))
    mod_macropca <- try(cellWise::MacroPCA(X, k = k, MacroPCApars = pars))
    if(class(mod_macropca) == "try-error"){
      print("MacroPCA failed.")
      
      mod_ddc<-cellWise::DDC(X,DDCpars = list(silent=T))
      if(length(mod_ddc$indrows)>0){
        X_imp<-mod_ddc$Ximp[-mod_ddc$indrows,]
      }
      else{
        X_imp<-mod_ddc$Ximp
      }
      mod_clean<-prcomp(X_imp,center =mod_ddc$locX  )
      V  <- mod_clean$rotation[,1:k]
      mu <- mod_ddc$locX
      U  <- mod_clean$x[,1:k]
      if(length(mod_ddc$indrows)>0){
        Un<-matrix(0,n,k)
        Un[-mod_ddc$indrows,]<- U
        Un[mod_ddc$indrows,]<-(X[mod_ddc$indrows,]-matrix(mu,length(mod_ddc$indrows), p, byrow = T))%*%V
        U<-Un
      }
    } else {
      U  <- mod_macropca$Fullimp$scoresfi
      V  <- mod_macropca$loadings
      mu <- mod_macropca$center
    }
    
    if(is.vector(U)) U <- matrix(U, ncol=1)
    if(is.vector(V)) V <- matrix(V, ncol=1)
  } else {
    if(ncol(U0) != k) stop(" k doesn't match U0.")
    U <- U0
    if(ncol(V0) != k) stop(" k doesn't match V0.")    
    V <- V0
    if(length(as.vector(mu0)) != p) stop(paste0(
      "mu0 does not have ", p," components."))
    mu <- mu0
    init_est <- NULL
  }
  
  ind_NA <- which(is.na(X))
  if(length(ind_NA) > 0)
    M <- matrix(as.numeric(!is.na(X)), n, p)
  else
    M <- matrix(1, n, p)
  
  ## Compute the initial weights:
  UVt_old <- U %*% t(V)
  Ri <- X - matrix(mu, n, p, byrow = T) - UVt_old # cell residuals
  # compute M-scale of each column of residuals:
  if(is.null(scale_1)){ 
    scale_1 <- apply(Ri, 2, function(x) scale_tanh(na.omit(x)))
  }
  # scale_1 stays unchanged from here on, it is not updated.
  scale1mat = matrix(scale_1, n, p, byrow = T)# matrix of the 
  # same size as X and Ri, whose columns have the residual scales
  Ri2 <- Ri/scale1mat # standardized cellwise residuals
  Ri2[abs(Ri2)==Inf] <- 0
  Ri2[is.na(Ri2)] <- 0
  weights_c <- weightfun(Ri2, b = b_1)
  # = n by p matrix of cellwise weights
  Ri2 <- rhofun(Ri2, b = b_1) # = result of rho_1
  Ri3 <- matrix(Ri2, n, p) * scale1mat^2 * M
  # has n rows with p entries rho*scale_1^2
  m_i <- apply(M, 1, sum) # number of non-NAs in each row of X
  rowti <- sqrt(apply(Ri3, 1, sum, na.rm = T) / m_i)
  # this is one vector with n rowwise total deviations.
  # Now compute scale_2 on the rowwise total deviations:
  if(is.null(scale_2)){ # is a single number
    scale_2 <- scale_tanh(na.omit(rowti)) 
  }
  weights_r <- weightfun2(rowti/scale_2)
  # This is one vector with n rowwise weights.
  # Now move the rowwise weights into an n by p
  # matrix with constant columns:
  W <- matrix(rep(weights_r, p), n, p, byrow = F)
  W <- W * weights_c * M # Hadamard product
  # This is the n by p matrix W in the paper.
  
  # Make final weights zero in NAs
  if(length(ind_NA) > 0){ # if X has NAs
    W[ind_NA] <- 0
    weights_c[ind_NA] <- 0
    # give the NA cells outlying values:
    X[ind_NA] <- UVt_old[ind_NA] + 1e15 * scale1mat[ind_NA] 
  }
  
  obj_old <- cellPCA_obj(Ri = Ri, rho1 = rhofun, rho2 = rhofun2, 
                         scale_1 = scale_1, scale_2 = scale_2, 
                         b_1 = b_1, M = M)
  obj_vec <- numeric()
  obj_vec[1] <- obj_old
  if (trace) {
    cat(noquote(paste0("Iteration ", 0," Obj = ", 
                       obj_vec[1],"\n")))
  }
  
  ## Update the weights (IRLS loop)
  diff <- Inf
  obj  <- obj_old
  iter <- 1
  while (diff > nu & iter <= max_iter){
    obj_old <- obj
    U_old <- U
    V_old <- V  
    W_old <- W
    # Update estimated U and V:
    UV <- upUV_geninv(X=X, mu=mu, U=U_old, V=V_old, 
                      W=W_old, weights_c=weights_c,
                      update_V=TRUE)
    U <- UV[[1]] # updated U
    V <- UV[[2]] # updated V
    normout <- normalV(U, V, k) # normalizes V
    U <- normout$U2 # U
    V <- normout$V2 # orthonormal V
    
    # Update estimated mu:
    mu_old <- mu
    if(update_mu){
      A <- apply(W,2,sum)
      if(min(A/n) < 1e-5) stop(paste0("Variable ", which.min(A),
                                      " has tiny average weight ",
                                      min(A / n)))
      A <- 1 / A # p by p
      B <- apply(W * (X - U %*% t(V)), 2, sum) # p by p
      mu <-  B * A # from first-order condition
      # Lowers the weighted norm of X-Xfit for current (U,V)
      B <- apply(W * X, 2, sum)
      munew <- B * A # is more centered
      # score of munew relative to (V, mu):
      unew <- t(V) %*% (munew - mu)
      # project munew on the current PC subspace:
      munew <- mu + V %*% unew
      # adjust U to get the same Xfit:
      U <- U - matrix(unew, n, k, byrow = T)
      mu <- munew
    }
    #
    # Update weights:
    UVt <- U %*% t(V)
    Ri <- X - matrix(mu,n,p,byrow = T) - UVt # cell residuals
    Ri2 <- Ri/scale1mat
    Ri2[abs(Ri2)==Inf] <- 0
    Ri2[is.na(Ri2)] <- 0
    weights_c <- weightfun(Ri2, b = b_1) # = cellwise weights w_c
    Ri2 <- rhofun(Ri2, b = b_1)
    Ri3 <- matrix(Ri2, n, p) * scale1mat^2 * M
    m_i <- apply(M, 1, sum)
    rowti <- sqrt(apply(Ri3, 1, sum, na.rm = T)/m_i)
    weights_r <- weightfun2(rowti/scale_2)
    W <- sweep(weights_c, 1, weights_r, "*")*M
    
    if(length(ind_NA) > 0){
      W[ind_NA] <- 0
      weights_c[ind_NA] <- 0
    }
    # compute relative difference of fits:
    diff <- sqrt(mean((UVt - UVt_old)^2))/
      (sqrt(mean(UVt_old^2)) + 1e-20)
    UVt_old <- UVt
    iter <- iter + 1
    UVt <- U %*% t(V)
    obj <- cellPCA_obj(Ri = Ri, rho1 = rhofun, rho2 = rhofun2, 
                       scale_1 = scale_1, scale_2 = scale_2, 
                       b_1 = b_1, M = M) 
    obj_vec[iter] <- obj
    if (trace) {
      cat(noquote(paste0("Iteration ", iter-1," Obj = ", 
                         obj_vec[iter],"\n")))
    }
    if(maxColFrac < 1){
      nflags <- colSums(W == 0)
      maxCount <- max(nflags)
      upbound <- maxColFrac*n
      if(maxCount > upbound){
        whichcol <- which.max(nflags)
        cat(noquote(paste0(
          "Data column ", whichcol, " had ",maxCount,
          " flagged cells.\n"," This is over",
          " maxColFrac*n = ",upbound,",\n",
          " so we use the results of iteration ",iter-2,".\n")))
        cat(noquote(paste0(
          "You may want to check your data, and/or rerun with\n",
          " higher b_1.")))
        U <- U_old
        V <- V_old
        mu <- mu_old
        W <- W_old
        iter <- max_iter + 1 # this will stop the while loop.
      }
    }
  } # end of the while loop with IRLS
  
  # When asked for, compute principal axes inside U:
  eigenvalues <- NULL
  if(V_est){
    rotate_V<-function(U, V, mu, Utot = NULL, U_old = NULL, 
                       alpha = 0.5){
      n <- dim(U)[1]
      if(is.null(Utot)) Utot <- U
      cov_rob <- rrcov::CovMcd(U, alpha = alpha, 
                               nsamp = "deterministic", 
                               use.correction = T)
      mu_2 <- cov_rob$center
      mu_new <- mu + V %*% mu_2
      V_sub <- eigen(cov_rob$cov)$vectors
      V_new <- V %*% V_sub
      U_new <- (Utot - matrix(mu_2, dim(Utot)[1], k, 
                              byrow = T)) %*% V_sub
      if(!is.null(U_old)) 
        U_new <- (U_old - matrix(mu_2, dim(Utot)[1],
                                 k, byrow = T)) %*% V_sub
      sign_e <- sign(crossprod(V_new, V)) * diag(1, ncol(V_new))
      V_new <- V_new %*% sign_e
      U_new <- U_new %*% sign_e
      out <- list(V = V_new,
                  U = U_new,
                  mu = mu_new,
                  cov = cov_rob$cov)
      return(out)
    }
    
    # We take out some suspect cases before fitting:
    indnot <- which(weights_r == 0)
    
    if(length(indnot) > 0 & length(indnot) < n) {
      alpha2 = min( ( (0.5 * dim(U)[1]) /
                        (dim(U)[1] - length(indnot)) ), 0.8)
      rot_V <- rotate_V(U = U[-indnot, ],
                        V = V,
                        mu = mu,
                        Utot = U,
                        U_old = U,
                        alpha = alpha2)
    } else{
      rot_V <- rotate_V(U = U, V = V, mu = mu,
                        U_old = U,
                        alpha = 0.5)
    }
    U <- rot_V$U
    V <- rot_V$V
    mu <- rot_V$mu
    eigenvalues <- eigen(rot_V$cov)$values
  } # ends computation of principal axes
  
  
  # Apply signflip once
  if(signflip){
    csigns <- function(x) {
      if (x[which.max(abs(x))] < 0) { -1 } else { 1 } }
    colsigns <- apply(V, 2L, FUN = csigns)
    V <- sweep(V, 2, colsigns, "*")
    U <- sweep(U, 2, colsigns, "*")
  }
  
  # Fit, and impute cellwise outliers
  Xfit <- matrix(mu,n,p,byrow = T) + U%*%t(V)
  dimnames(Xfit) <- dimnames(X)
  Ximp <- Xfit + weights_c * (X- Xfit)
  
  X_NAimp <- X_NAimppart <- NULL
  if(length(ind_NA) > 0){
    X[ind_NA] <- NA
    X_NAimp <- X_NAimppart <- X
    X_NAimp[ind_NA] <- Xfit[ind_NA]
    X_NAimppart[ind_NA] <- Ximp[ind_NA]
  }
  
  # Compute standardized residuals for graphical display:
  Ri <- X - matrix(mu, n, p, byrow = T) - U %*% t(V)
  scale_1_end <- apply(Ri, 2, function(x) 
    scale_tanh(na.omit(x)))
  Ri_std <- Ri/matrix(scale_1_end, n, p, byrow = T)
  
  # = n by p matrix of cellwise weights W_c
  Ri2 <- rhofun(Ri_std, b = b_1) # = result of \rho_1
  Ri3 <- matrix(Ri2, n, p) * matrix(scale_1_end ^ 2, n, p, byrow = T)
  # has n rows with p entries rho*scale^2
  m_i <- apply(M, 1, sum)
  rowres <- sqrt(apply(Ri3, 1, sum, na.rm = T) / m_i)
  # rowres is one vector with n standardized sums.
  # Now compute scale_2 on residuals:
  scale_2_end <- scale_tanh(rowres) # is a single number
  ## scale_2 stays unchanged from here on, it is not updated.
  rowres_std <- rowres / scale_2 
  
  out <- list(X = X,
              U = U,
              V = V,
              eigenvalues = eigenvalues,
              W = W,
              M = M, 
              mu = mu,
              k = k,
              scale_1 = scale_1,
              scale_2 = scale_2,
              weights_c = weights_c,
              weights_r = weights_r,
              cellres = Ri,
              rowti = rowti,
              obj = obj,
              obj_vec = obj_vec,
              maxColFrac = maxColFrac,
              Xfit = Xfit,
              b_1 = b_1,
              max_iter = max_iter,
              nu = nu,
              signflip = signflip,
              par = par,
              Ximp = Ximp,
              X_NAimp = X_NAimp,
              X_NAimppart = X_NAimppart,
              Ri_std = Ri_std,
              scale_1_end = scale_1_end,
              rowres_std=rowres_std,
              scale_2_end=scale_2_end)
  return(out)
}


cellPCA_predict <- function(X, outPCA, nu = 1e-6, 
                            trace = T, U0 = NULL) {
  # Fit new (out of sample) data.
  
  # The following results from outPCA will not change:
  k        <- outPCA$k
  V        <- outPCA$V
  mu       <- outPCA$mu
  scale_1  <- outPCA$scale_1
  scale_2  <- outPCA$scale_2
  b_1      <- outPCA$b_1
  par      <- outPCA$par
  max_iter <- outPCA$max_iter
  if(is.null(nu)) nu <- outPCA$nu
  
  if(length(dim(X))!= 2) stop(
    "X must be a matrix. It is allowed to have only 1 row.")
  X = as.matrix(X)
  n <- dim(X)[1]
  p <- dim(X)[2]
  scale1mat = matrix(scale_1, n, p, byrow = T)
  
  rhofun <- function(resid, b){ rho_tanh(resid, b = b) }
  weightfun <- function(resid, b){ weight_tanh(resid, b = b) }
  rhofun2 <- function(resid){ rho_tanh(resid, 
                                       bb = par[1], 
                                       cc = par[2],
                                       q1 = par[3], 
                                       q2 = par[4]) }
  weightfun2 <- function(resid){ weight_tanh(resid, 
                                             bb = par[1], 
                                             cc = par[2],
                                             q1 = par[3], 
                                             q2 = par[4]) }
  ind_NA <- which(is.na(X))
  if(length(ind_NA) > 0) { M <- matrix(as.numeric(!is.na(X)), n, p)
  } else { M <- matrix(1,n,p) }
  
  validi = rowSums(M) # number of valid cells in each row
  if(min(validi) == 0){ # some rows are entirely missing
    print("Row numbers of X with only NA's:")
    print(which(validi == 0))
    stop("Rows of X without valid cells need to be removed first.")    
  }
  
  if(is.null(U0)) {
    if(length(ind_NA) > 0){
      U <- matrix(0,n,k)
      for (i in 1:n) {
        ind_NA_i <- which(M[i,] == 0)
        U[i,] <- as.numeric(X[i, -ind_NA_i] - 
                              mu[-ind_NA_i]) %*% V[-ind_NA_i,]
        # No X[i,] is entirely missing, so U[i,] exists.
      }
    } else { U <- (X - matrix(mu,n,p,byrow=T)) %*% V }
  } else {
    if(ncol(U0) != k) stop(" k doesn't match U0.")
    U <- U0
  }
  UVt_old <- U %*% t(V)
  
  # Give missing cells non-missing values for the computations:
  if(length(ind_NA) > 0){ # if X has NAs
    X[ind_NA] <- UVt_old[ind_NA]
  }
  
  ## Compute the initial weights:
  Ri <- X-matrix(mu,n,p,byrow = T)-UVt_old # cell residuals
  # standardized cellwise residuals:
  Ri2 <- Ri/scale1mat
  weights_c <- weightfun(Ri2, b = b_1)*M
  # The *M makes the cell weights zero in NAs.
  
  ## Update U (IRLS loop)
  diffU <- Inf
  iter <- 1
  while (diffU > nu & iter <= max_iter){
    U_old <- U
    U <- upUV_geninv(X, mu, U_old, V, W = NULL, 
                     weights_c, update_V=F)[[1]]
    if(n!=1 & k==1) U = matrix(U,ncol=1)
    if(n==1 & k!=1) U = matrix(U,nrow=1)
    diffU <- sqrt(sum((U-U_old)^2))/(sqrt(sum(U_old^2))+1e-20)
    if (trace) {
      cat(noquote(paste0("Iteration ", iter, " difference in U is ",
                         diffU, "\n")))
    }
    iter <- iter + 1
    # Update weights:
    Ri <- X - matrix(mu,n,p,byrow = T) - U %*% t(V)
    Ri2 <- Ri/scale1mat
    weights_c <- weightfun(Ri2, b = b_1)*M 
    # The *M makes the cell weights zero in NAs.
  } # ends IRLS loop
  
  Xfit <- matrix(mu, n, p, byrow = T) + U %*% t(V)
  dimnames(Xfit) <- dimnames(X)
  Ri2 <- rhofun(Ri2, b = b_1)
  Ri3 <- matrix(Ri2, n, p) * scale1mat^2 * M
  m_i <- apply(M, 1, sum)
  rowti <- sqrt(apply(Ri3, 1, sum, na.rm = T)/m_i)
  weights_r <- weightfun2(rowti/scale_2)
  W <- matrix(rep(weights_r, p), n, p, byrow = F)
  W <- W * weights_c * M
  if(length(ind_NA) > 0) W[ind_NA] <- 0
  Ximp = Xfit + weights_c * (X - Xfit)
  
  out <- list(U = U,
              Xfit = Xfit,
              Ximp = Ximp, 
              weights_c = weights_c,
              weights_r = weights_r,
              W = W,
              outPCA = outPCA)
  return(out)
}


get_obj <- function(X, Xfit, b_1, par = NULL) {
  # Computes cellPCa objective. It first computes the
  # tuning constants of rho2, M, Ri, scale_1 and scale_2.
  n <- dim(X)[1]
  p <- dim(X)[2]
  rhofun <- function(resid, b){rho_tanh(resid, b = b)}
  if(is.null(par))
    par <- get_tuning_const_rho2(p, b_1 = b_1)[[1]]
  rhofun2 <- function(resid){rho_tanh(resid, bb = par[1], cc = par[2],
                                      q1 = par[3], q2 = par[4])}
  ind_NA <- which(is.na(X))
  if(length(ind_NA) > 0)
    M <- matrix(as.numeric(!is.na(X)), n, p)
  else
    M <- matrix(1, n, p)
  Ri <- X-Xfit # cell residuals
  scale_1 <- apply(Ri, 2, function(x)scale_tanh(na.omit(x)))
  scale1mat = matrix(scale_1, n, p, byrow = T)
  Ri2 <- Ri/scale1mat
  Ri2 <- rhofun(Ri2, b = b_1) # = result of \rho_1
  Ri3 <- matrix(Ri2, n, p) * matrix(scale_1 ^ 2, n, p, byrow = T) * M
  # has n rows with p entries rho*scale^2
  m_i <- apply(M, 1, sum)
  rowti <- sqrt(apply(Ri3, 1, sum, na.rm = T) / m_i)
  # rowti is one vector with n rowwise total deviations
  scale_2 <- scale_tanh(rowti) # is a single number
  d03 <- rhofun2(rowti/scale_2) * m_i # = result of rho_2
  myobj <- scale_2^2 * sum(d03)/sum(M)
  out <- list(myobj = myobj, par = par)
  return(out)
}


select_k <- function(X, k_vec, b_1 = 1.5, par = NULL, ncores = 1, 
                     fev = 0.9, plot = F,maxiter=100){
  # Select the dimension of the principal subspace
  
  n <- dim(X)[1]
  p <- dim(X)[2]

  parr_fun<-function(ii){ # computes objective for k = k_vec[ii]
    if(k_vec[ii] != dim(X)[2]){
      if(is.null(par)){
        par <- get_tuning_const_rho2(p, b_1 = b_1)[[1]]
      }
      outRPCA <- cellPCA(X, k = k_vec[ii], max_iter = maxiter,
                         V0 = NULL, U0 = NULL, mu0 = NULL, b_1 = b_1,
                         nu = 10 ^ -6, update_mu = T, signflip = T, 
                         V_est = T, par = par,trace=F)
      objs <- get_obj(X, outRPCA$Xfit, b_1 = outRPCA$b_1, 
                      par = outRPCA$par)[[1]]
    }
    else{
      objs<-outRPCA<-0
    }
    out <- list(mod = outRPCA, objs = objs)
    return(out)
  }
  
  if(ncores > 1){
    if(.Platform$OS.type == "unix"){
      out <- parallel::mclapply( 1:length(k_vec), parr_fun, mc.cores = ncores)
    } else if(.Platform$OS.type == "windows"){
    cl <- parallel::makeCluster(ncores)
    parallel::clusterExport(cl, c("cellPCA","get_obj","k_vec",
                                  "b_1","X","checkDataSet",
                                  "get_tuning_const_rho2",
                                  "weight_tanh","maxiter",
                                  "rho_tanh","upUV_geninv",
                                  "calculateq1q2",
                                  "psiWrap","cellPCA_obj",
                                  "normalV","scale_tanh"),
                            envir = environment())
    out <- parallel::parLapply(cl, 1:length(k_vec), parr_fun)
    parallel::stopCluster(cl)
    }
  }
  else{
    out <- lapply(1:length(k_vec), parr_fun )
  }
  
  mod_list <- lapply(out, "[[", 1)
  objs <- as.numeric(sapply(out, "[[", 2))
  mu0 <- apply(X, 2, median, na.rm = T)
  
  v0 <- get_obj(X, matrix(mu0, n, p, byrow = T), b_1, par)[[1]]
  mod_listtot <- list()
  mod_listtot[[1]] <- NULL
  mod_listtot[2:(length(k_vec) + 1)] <- mod_list
  objs <- c(v0, objs)
  
  k <- which((1 - objs[-1]/objs[1]) > fev)[1]
  
  if(plot){
    vec<-c(0,1-(objs[-1]/objs[1]))
    plot(c(0,k_vec),vec,ylim=c(0,1),xlab="k",
         ylab="Fraction of explained variability")
    lines(c(0,k_vec),vec,ylim=c(0,1))
    # abline(h=vec[k+1])
    abline(h = fev, col = "red", lty = 3, lwd = 2)
  }
  
  out <- list(k = k, objs = objs, mod_list = mod_list)
  return(out)
}


enh.outliermap <- function(outPCA, col = "black", pch = 16,
                           labelOut = TRUE, id = 3, xlim = NULL, 
                           ylim = NULL, cex = 1, cex.main = 1.2, 
                           cex.lab = NULL, cex.axis = NULL,
                           namesout = NULL, cutoffOD = NULL,
                           n_clean = NULL, crit = 0.99, 
                           ylab = expression(tilde(OD)), xlab = "SD", 
                           title = "Enhanced Outlier Map") {
  # Function that draws the enhanced outlier map.
  # 
  # id: number of points to identify automatically: those
  #     with id highest vertical and horizontal coordinates
  #     in the outlier map.
  weights_r <- outPCA$weights_r
  weights_c <- outPCA$weights_c
  R <- outPCA$Ri_std
  n <- dim(R)[1]
  p <- dim(R)[2]
  k <- outPCA$k
  U <- outPCA$U
  V <- outPCA$V
  mu <- outPCA$mu
  scale_1_end <- outPCA$scale_1_end
  lambda <- outPCA$eigenvalues
  
  # Distances on the vertical axis:
  OD <- apply(R, 1, function(x) sqrt(sum(x ^ 2, na.rm = T)))
  if(is.null(cutoffOD)){
    # Compute cutoffOD, which uses U and V as well as 
    # the scales sigma_{1,j}:
    X0 = U%*%t(V)
    set.seed(0)
    if (is.null(n_clean)) n_clean <- min(n, 500)
    Xindex  = sample(seq_len(n), size=n_clean, replace=T)
    X_clean = matrix(rnorm(n_clean*p), nrow=n_clean, ncol=p)
    X_clean = X_clean*matrix(scale_1_end, n_clean, p, byrow = T) 
    # = error terms with appropriate scales
    X_clean = X0[Xindex,] + X_clean # artificial clean dataset
    mod_clean <- cellPCA(X_clean, k = k, trace = FALSE, b_1 = outPCA$b_1)
    OD_clean <- apply(mod_clean$Ri_std, 1, function(x) sqrt(sum(x ^ 2, na.rm = T)))
    cutoffOD <- quantile(OD_clean, crit)
  }
  
  # Score distances on the horizontal axis:
  U_orig <- scale(outPCA$X, center = mu, scale = FALSE) %*% V 
  # these actual projections can be outlying
  if(k > 1) SD <- sqrt(mahalanobis(as.matrix(U_orig),
                                   rep(0, k), diag(lambda)))
  if(k == 1) SD = abs(U_orig)/sqrt(lambda) 
  cutoffSD <- sqrt(qchisq(crit, k))
  
  # Draw outlier map:
  if (is.null(SD)) 
    stop(" No score distances are given.")
  if (is.null(cutoffSD)) 
    stop(" No cutoff for score distances is given.")
  if (is.null(OD)) 
    stop(" No orthogonal distances are given.")
  if (is.null(cutoffOD)) 
    stop(" No cutoff for orthogonal distances is given.")
  if (is.null(xlim)) {
    xlim <- c(0, max(SD) * 1.1)
  }
  if (is.null(ylim)) {
    ylim <- c(0, max(OD) * 1.1)
  }
  if (is.null(pch)) {
    pch <- ifelse(is.null(col), 1, 16)
  }
  if (is.null(col)) {
    col <- "black"
  }
  mycex = cex
  mycex.main = 1
  if (!is.null(cex.main)) {
    mycex.main = cex.main
  }
  mycex.lab = 1
  if (!is.null(cex.lab)) {
    mycex.lab = cex.lab
  }
  mycex.axis = 1
  if (!is.null(cex.axis)) {
    mycex.axis = cex.axis
  }
  
  indrows <- 1:n
  tempVec <- rep(0, n)
  tempVec[indrows] <- 1
  mXrow <- data.frame(rownr = seq_len(n), rescaleoffset = 40 -
                        (10 * tempVec))
  scalerange <- c(0, 1)
  gradientends <- scalerange + rep(c(0, 10, 20, 30, 
                                     40), each = 2)
  colorends <- c("yellow", "yellow", "yellow", "blue", 
                 "yellow", "red", "white", "black", "white", 
                 "white")
  
  outrows <- 2*(1 - weights_r) + 1
  colContrast <- 1
  limL <- 1
  limH <- 3
  outrows <- ((outrows - limL)/(limH - limL))^colContrast
  mXrow$rescaleoffset <- mXrow$rescaleoffset + 
    outrows
  
  fill <- scales::rescale(mXrow$rescaleoffset, from = range(gradientends))
  min_size <- 1.5 # Change this to your desired minimum size
  max_size <- 5  # Change this to your desired maximum size
  ww <- 1 - apply(weights_c, 1, mean)
  normalized_weights <- ww # (ww -0.75) / 0.25
  normalized_weights[normalized_weights < 0] <- 0
  
  # Map the normalized weights to your size range
  sizes <- min_size + (max_size - min_size) * normalized_weights
  id.n.SD = id; id.n.OD = id
  if (id.n.SD > 0 && id.n.OD > 0) {
    off = 0.02
    x=SD
    y=OD
    xrange <- range(x)
    xrange <- xrange[2] - xrange[1]
    # Identify points to highlight
    indexSD <- order(x, decreasing = TRUE)[1:id.n.SD]
    indexOD <- order(y, decreasing = TRUE)[1:id.n.OD]
    
    # Prepare labels
    labOD <- if (is.character(names(y))) names(y)[indexOD] else indexOD
    labSD <- if (is.character(names(x))) names(x)[indexSD] else indexSD
  }
  
  if (is.list(col)) {
    for (i in seq_len(length(col))) {
      if (i == 1) {
        plot(SD[col[[i]]$index], OD[col[[i]]$index], 
             xlab = "", ylab = "", main = "", pch = pch, 
             col = col[[i]]$col, xlim = xlim, ylim = ylim, 
             cex = mycex, cex.axis = mycex.axis)
      }
      points(SD[col[[i]]$index], OD[col[[i]]$index], pch = pch, 
             col = col[[i]]$col, cex = mycex)
    }
  }
  else {
    data <- data.frame(SD = SD, OD = OD, color_palette = fill, sizes = sizes)
    pp <- ggplot(data, aes(x = SD, y = OD)) +
      geom_point(aes(fill = fill, size = sizes), shape = 21, color = "black") +
      scale_fill_gradientn(colours = colorends, values = scales::rescale(gradientends), rescaler = function(x, ...) x, oob = scales::squish) +
      scale_size(range = range(sizes)) +
      #theme_bw() + # was minimal
      xlim(xlim) +
      ylim(ylim) +
      geom_hline(yintercept = cutoffOD, linetype = "dashed", color = "red") + 
      geom_vline(xintercept = cutoffSD, linetype = "dashed", color = "red") +
      labs(y = bquote(paste("||", tilde(r)[i], "||"))) +
      ggtitle("cellPCA outlier map") +
      #theme_bw() + 
      {
        if (id.n.SD > 0 ) {
          geom_text(data = data[indexOD, ], aes(label = labOD), 
                    nudge_x = -off * xrange, hjust = 1, color = "black") 
        }
      } +       {
        if ( id.n.OD > 0) {
          geom_text(data = data[indexSD, ], aes(label = labSD), 
                    nudge_x = -off * xrange, hjust = 1, color = "black") 
        }
      } +
      theme(plot.title = element_text(hjust = 0.5, size = 18, face = "bold"),
            panel.border = element_rect(color = "black",
                                        fill = NA,
                                        linewidth = 1),
            legend.title = element_blank(), 
            axis.title.y = element_text(size = 15),
            axis.title.x = element_text(size = 15),
            axis.text.x =  element_text(size = 13),
            axis.text.y =  element_text(size = 13),
            legend.position = "none"
      )  
    
    print(pp)
  }
  out <- list(SD = SD, OD = OD, cutoffSD = cutoffSD, 
              cutoffOD = cutoffOD, colors_r = fill, plot = pp)
  return(out)
}


###' @import quantmod

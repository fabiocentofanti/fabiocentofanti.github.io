
#############################################################
##                                                          #
## Functions to compute cellRCov                            #
##                                                          #
#############################################################


# Main functions --------------------------------------------------

multifold_cv <- function(X,
                         Xfit,
                         W,
                         H = 5,
                         n1_fraction = 1 / 3,
                         delta_reg_values = seq(0, 1, by = 0.01)) {
  
  set.seed(100)
  n <- dim(X)[1]
  n1 <- floor(n * n1_fraction) # Size of the first subset
  n2 <- n - n1 # Size of the second subset
  min_error <- Inf
  best_delta_shr <- NA
  ind <- 1
  avg_error <- numeric()
  for (delta_reg in delta_reg_values) {
    errors <- numeric()
    
    for (h in 1:H) {
      shuffled_indices <- sample(1:n)
      ind_1 <- shuffled_indices[1:n1]
      ind_2 <- shuffled_indices[(n1 + 1):n]
      
      W1 <- W[ind_1, ]
      W2 <- W[ind_2, ]
      X1 <- X[ind_1, ]
      X2 <- X[ind_2, ]
      Xfit1 <- Xfit[ind_1, ]
      Xfit2 <- Xfit[ind_2, ]
      
      S_err1 <- get_S_err(X = X1,
                          Xfit = Xfit1,
                          W = W1)
      S_err2 <- get_S_err(X2, Xfit2, W2)
      
      Sigma_shr <- cov_ridge(S_err1, delta_reg)
      Sigma_unreg <- S_err2
      
      errors[h] <- norm(Sigma_shr - Sigma_unreg, "F")
    }
    
    avg_error[ind] <- mean(errors)
    
    if (avg_error[ind] < min_error) {
      min_error <- avg_error[ind]
      best_delta_shr <- delta_reg
    }
    ind <- ind + 1
  }
  return(
    list(
      best_delta_shr = best_delta_shr,
      min_error = min_error,
      avg_error = avg_error
    )
  )
}


get_S_err <- function(X, Xfit, W) {
  C <- 1 / mean(crossprod(W))
  wx <- as.matrix(W * (X - Xfit))
  wx[is.na(wx)] <- 0
  dd_list <- list()
  for (ll in 1:dim(X)[1]) {
    dd_list[[ll]] <- wx[ll, ] %*% t(wx[ll, ])
    
  }
  S_err <- Reduce("+", dd_list) * C
  S_err[is.na(S_err)] <- 0
  return(S_err)
}


cov_ridge <- function(S_err, delta_reg) {
  sigma_diag <- diag(S_err)
  S_err <- (1 - delta_reg) * S_err + delta_reg * diag(sigma_diag)
  S_err <- (S_err + t(S_err)) / 2
  return(S_err)
}


par.MFCV <- function(H = 5, n1_fraction = 1 / 3,
           delta_reg_values = seq(0.01, 1, l=10)) {
  list(
    H = H,
    n1_fraction = n1_fraction,
    delta_reg_values = delta_reg_values
  )
}


par.cellPCA <-
  function(b_1 = 1.5, nu = 1e-6, max_iter = 100,
           maxColFrac = 0.8, trace = F, signflip = T,
           update_mu = T, V_est = T, par = NULL, 
           U0 = NULL, V0 = NULL, mu0 = NULL, 
           scale_1 = NULL, scale_2 = NULL) {
    list(
      b_1 = b_1,
      nu = nu,
      max_iter = max_iter,
      maxColFrac = maxColFrac,
      trace = trace,
      signflip = signflip,
      update_mu = update_mu,
      V_est = V_est,
      par = par,
      U0 = U0,
      V0 = V0,
      mu0 = mu0,
      scale_1 = scale_1,
      scale_2 = scale_2
    )
  }


cellRCov <- function(X,
                     k = NULL,
                     kmax = 20,
                     reg = T,
                     delta_reg = NULL,
                     onlyreg = F,
                     quantile_diff = NULL,
                     control.CV = list(),
                     control.cellPCA = list(),
                     scale = T,
                     ncores = 1) {
  
  # Carry out cellwise and casewise robust Covariance estimation.
  # 
  # Arguments:
  # X: an n by p data matrix
  # k: the number of principal components, if NULL, it is selected.
  # reg: If TRUE, the covariance matrix is regularized. 
  # delta_reg: delta for regularization. If NULL, it is selected 
  #            by cross-validation.
  # onlyreg: if TRUE, only the regularized covariance matrix is returned.
  # quantile_diff: quantile of the difference of the objective functions 
  #                to select k.
  # control.CV: list of parameters for the cross-validation.
  #    H: number of folds for cross-validation.
  #    n1_fraction: fraction of the first subset for cross-validation.
  #    delta_reg_values: values of delta for cross-validation.
  # control.cellPCA: list of parameters for the cellwise PCA, see the 
  #                  documantaion of cellPCA.
  # scale: if TRUE, the data is standardized.
  # ncores: number of cores for parallel computation. If 1, no parallel 
  #         computation is used.
  
  par.CV <- do.call("par.MFCV", control.CV)
  H <- par.CV$H
  n1_fraction <- par.CV$n1_fraction
  delta_reg_values <- par.CV$delta_reg_values
  par.cellPCA <- do.call("par.cellPCA", control.cellPCA)
  b_1 <- par.cellPCA$b_1
  nu <- par.cellPCA$nu
  max_iter <- par.cellPCA$max_iter
  maxColFrac <- par.cellPCA$maxColFrac
  trace <- par.cellPCA$trace
  signflip <- par.cellPCA$signflip
  update_mu <- par.cellPCA$update_mu
  V_est <- par.cellPCA$V_est
  U0 <- par.cellPCA$U0
  V0 <- par.cellPCA$V0
  mu0 <- par.cellPCA$mu0
  scale_1 <- par.cellPCA$scale_1
  scale_2 <- par.cellPCA$scale_2
  
  X_orig <- X
  mod_DDC <- try(cellWise::DDC(X, DDCpars = list(tolProb = 0.998)))
  Ximp <- X
  Ximp[mod_DDC$indcells] <- try(mod_DDC$Ximp[mod_DDC$indcells])
  X <- Ximp
  
  remX <- checkDataSet(
    X,
    fracNA = 0.5,
    numDiscrete = 3,
    precScale = 1e-12,
    silent = T,
    cleanNAfirst = "columns"
  )$remX
  X <- remX
  n <- dim(X)[1]
  p <- dim(X)[2]
  
  ### standardize data
  Xuns <- X
  if (scale) {
    scaleX <- apply(Xuns, 2, function(x)
      scale_tanh(na.omit(x) - median(x, na.rm = T)))
    X <- scale(X, center = F, scale = scaleX)
  }
  else{
    scaleX <- rep(1, p)
  }
  n <- dim(X)[1]
  p <- dim(X)[2]
 
  mod_k <- diff_obj<-delta_reg<-delta_err<-NULL
  if(!onlyreg) {
    if (is.null(k)) {
      mod_k <- select_k(
        as.matrix(X),
        1:min(kmax, p),
        ncores = ncores,
        plot = F,
        fev = 0.8,
        maxiter = max_iter
      )
      diff_obj <- abs(diff(mod_k$objs, decreasing = T))
      
      if (is.null(quantile_diff)) {
        ss <- get_ranscree_app(
          n = n,
          p = p,
          n_rep = 100,
          b_1 = b_1,
          ncores = ncores,
          kmax = kmax
        )
        quantile_diff <- ss$obj_diff_quantile99
      }
      xseq <- seq(1, length(diff_obj))
      
      k <- which(diff_obj < quantile_diff)[1] - 1
      if (is.na(k)) {
        k <- kmax
      }
      k <- max(0, k)
    } 
    
    if(k==0) {
      V <- matrix(1, dim(X)[2], 2)
      U <- matrix(0, nrow = dim(X)[1], ncol = 2)
      mu <- apply(X, 2, median, na.rm = T)
      mod_cellPCA <- cellPCA(
        as.matrix(X),
        k = 2,
        trace = trace,
        V_est = V_est,
        maxColFrac = maxColFrac,
        b_1 = b_1,
        max_iter = 0,
        U0 = U0,
        V0 = V0,
        mu0 = mu0,
        scale_1 = scale_1,
        scale_2 = scale_2
      )
      S_sub <- 0
      Xfit <- matrix(
        mod_cellPCA$mu,
        nrow = dim(X)[1],
        ncol = dim(X)[2],
        byrow = T
      )
      W <- sweep(mod_cellPCA$weights_c, 1, sqrt(mod_cellPCA$weights_r), 
                 "*") * mod_cellPCA$M
      S_err <- get_S_err(X, Xfit = Xfit, W)
    }
    else{
      mod_cellPCA <- cellPCA(
        as.matrix(X),
        k = k,
        trace = trace,
        V_est = V_est,
        maxColFrac = maxColFrac,
        b_1 = b_1,
        max_iter = max_iter,
        U0 = U0,
        V0 = V0,
        mu0 = mu0,
        scale_1 = scale_1,
        scale_2 = scale_2
      )
      
      k <- length(mod_cellPCA$eigenvalues)
      if (k == 1) {
        S_sub <-
          mod_cellPCA$V %*% t(mod_cellPCA$V) * mod_cellPCA$eigenvalues
      }
      else{
        S_sub <-
          mod_cellPCA$V %*% diag(mod_cellPCA$eigenvalues) %*% t(mod_cellPCA$V)
      }
      W <-
        sweep(mod_cellPCA$weights_c, 1, sqrt(mod_cellPCA$weights_r), "*") * mod_cellPCA$M
      Xfit <- mod_cellPCA$Xfit
      S_err <- get_S_err(X, Xfit = Xfit, W)
    }
    eigen_decomp <- eigen(S_err)
    eigen_decomp$values[eigen_decomp$values < 0] <- 0 
    # thresholds negative eigenvalues to zero
    S_err <- eigen_decomp$vectors %*% diag(eigen_decomp$values) %*%
      t(eigen_decomp$vectors)
  }
  else{
    S_sub <- 0
    S_err <- cov(X, use = 'pairwise.complete.obs')
    mod_cellPCA <- NULL
    Xfit <- matrix(
      colMeans(X, na.rm = T),
      nrow = dim(X)[1],
      ncol = p,
      byrow = T
    )
    W <- matrix(1, n, p)
  }
  
  if(reg) {
    if (is.null(delta_reg)) {
      cv_results <- multifold_cv(
        X,
        Xfit = Xfit,
        W = W,
        H = H,
        n1_fraction = n1_fraction,
        delta_reg_values =
          delta_reg_values
      )
      
      delta_err <- cv_results$avg_error
      delta_reg <- cv_results$best_delta_shr
      
    }
    S_err <- cov_ridge(S_err, delta_reg)
  }
  R <- S_sub + S_err
  
  S <- diag(scaleX) %*% R %*% diag(scaleX)
  if(onlyreg){
    mu <- apply(Xuns, 2, mean,na.rm=T)
    
  }
  else{
    mu <- diag(scaleX) %*% (mod_cellPCA$mu)
  }
  out <- list(
    S = S,
    S_sub = S_sub,
    S_err = S_err,
    mod_cellPCA = mod_cellPCA,
    mod_k = mod_k,
    Xuns = Xuns,
    Xstd = X,
    mu = mu,
    delta_reg = delta_reg,
    delta_err = delta_err,
    k = k,
    diff_obj=diff_obj,
    X_orig = X_orig
  )
  return(out)
}


get_ranscree_app<-function(n, p, n_rep = 30, b_1 = 1.5, 
                           ncores = 1, kmax = NULL){
  
  set.seed(100)
  par <- get_tuning_const_rho2(p, b_1 = b_1)[[1]]
  if (is.null(kmax))
    kmax <- min(n, p)
  obj <- matrix(0, n_rep, kmax + 1)
  
  parr_fun <- function(rr) {
    print(rr)
    set.seed(rr)
    X <- matrix(rnorm(n * p), n, p)
    scaleX <- apply(X, 2, function(x)
      scale_tanh(na.omit(x) - median(x)))
    X <- sweep(X, 2, scaleX, "/")
    
    mod_pc <- prcomp(X, center = T, scale = F)
    V <- as.matrix(mod_pc$rotation)
    U <- as.matrix(mod_pc$x)
    obj <- numeric()
    for (ii in 1:(kmax)) {
      X_fit_k <- matrix(mod_pc$center, n, p, byrow = T) + U[, 1:ii] %*% t(V[, 1:ii])
      obj[ii] <- get_obj(X, X_fit_k, b_1, par)[[1]]
    }
    obj_0 <- get_obj(X, matrix(mod_pc$center, n, p, byrow = T), b_1, par)[[1]]
    obj <- c(obj_0, obj)
    return(obj)
  }
  
  if (ncores > 1) {
    if (.Platform$OS.type == "unix") {
      out <- parallel::mclapply(1:n_rep, parr_fun, mc.cores = ncores)
    } else if (.Platform$OS.type == "windows") {
      cl <- parallel::makeCluster(ncores)
      parallel::clusterExport(
        cl,
        c(
          "n",
          "p",
          "get_obj",
          "kmax",
          "b_1",
          "get_tuning_const_rho2",
          "weight_tanh",
          "par",
          "rho_tanh",
          "psiWrap",
          "scale_tanh"
        ),
        envir = environment()
      )
      out <- parallel::parLapply(cl, 1:n_rep, parr_fun)
      parallel::stopCluster(cl)
    }
  }
  else{
    out <- lapply(1:n_rep, parr_fun)
  }
  obj <- do.call(rbind, out)
  obj_diff <- t(abs(apply(obj, 1, diff)))
  obj_diff_mean <- apply(obj_diff, 2, mean)
  obj_diff_sd <- apply(obj_diff, 2, sd)
  obj_diff_quantile99 <- apply(obj_diff, 2, quantile, 0.99)
  
  out_list <- list(
    obj = obj,
    obj_diff = obj_diff,
    obj_diff_mean = obj_diff_mean,
    obj_diff_sd =
      obj_diff_sd,
    obj_diff_quantile99 = obj_diff_quantile99
    
  )
  return(out_list)
}


# Functions for the Spearman method

easy.psd<-function(sigma,method="perturb") {
  if (method=="perturb")
  {
    p <- ncol(sigma)
    eig <- eigen(sigma, symmetric = T, only.values = T)
    const <- abs(min(eig$values, 0))
    sigma.psd <- sigma + diag(p) * const
  }
  if (method == "npd")
  {
    eig <- eigen(sigma, symmetric = T)
    d <- pmax(eig$values, 0)
    sigma.psd <- eig$vectors %*% diag(d) %*% t(eig$vectors)
  }
  return(sigma.psd)
}


cov_spearman <- function(X, reg = T){
  x.r <- apply(X, 2, rank)
  x.q <- apply(X, 2, Qn, na.rm = T)
  cor.sp <- 2 * sin(pi * cor(x.r, use = 'pairwise.complete.obs') / 6)
  sigma.sp <- diag(x.q) %*% cor.sp %*% diag(x.q)
  cov_un <- easy.psd(Matrix::forceSymmetric(sigma.sp, "L"), method = "npd")
  if (reg) {
    n <- dim(X)[1]
    huge.out <- huge::huge(cov_un, method = "glasso", verbose = F)
    my.bic <- -huge.out$loglik + huge.out$df * log(n) / n
    opt.i <- which.min(my.bic)
    return(solve(as.matrix(
      Matrix::forceSymmetric(huge.out$icov[[opt.i]], "L")
    )))
  }
  else{
    return(cov_un)
  }
}


# Functions for CCA

hfold_cv <- function(X, Y, lambda1, lambda2, H = 5) {
  n <- nrow(X)
  folds <- sample(rep(1:H, length.out = n))
  
  xscore <- numeric(n)
  yscore <- numeric(n)
  for (fold in 1:H) {
    test_idx <- which(folds == fold)
    train_idx <- setdiff(1:n, test_idx)
    
    X_train <- X[train_idx, , drop = FALSE]
    Y_train <- Y[train_idx, , drop = FALSE]
    X_test  <- X[test_idx, , drop = FALSE]
    Y_test  <- Y[test_idx, , drop = FALSE]
    
    res <- try(rcc(X_train, Y_train, lambda1, lambda2))
    if (class(res) == "try-error") {
      xscore[test_idx] <- NA
      yscore[test_idx] <- NA
    } else{
      xscore[test_idx] <- X_test %*% res$xcoef[, 1]
      yscore[test_idx] <- Y_test %*% res$ycoef[, 1]
    }
  }
  cv_score <- cor(xscore, yscore, use = "pairwise")
  return(cv_score)
}


estpar_hfold <- function(X, Y, grid1 = NULL, grid2 = NULL, 
                         H = 5, plt = TRUE) {
  if (is.null(grid1)) {
    grid1 <- seq(0.1, 1, length.out = 6)
  }
  if (is.null(grid2)) {
    grid2 <- seq(0.1, 1, length.out = 6)
  }
  grid <- expand.grid(lambda1 = grid1, lambda2 = grid2)
  cv_results <- apply(grid, 1, function(params) {
    hfold_cv(X, Y, params[1], params[2], H)
  })
  grid$cv_score <- cv_results
  mat <- matrix(cv_results, nrow = length(grid1), 
                ncol = length(grid2), byrow = FALSE)
  best_idx <- which.max(grid$cv_score)
  best_params <- grid[best_idx, ]
  return(list(lambda1 = best_params$lambda1, 
              lambda2 = best_params$lambda2,
              CVscore = best_params$cv_score, 
              grid1 = grid1, 
              grid2 = grid2, 
              mat = mat))
}


geigen2<-function (Amat, Bmat, Cmat) {
  Bdim <- dim(Bmat)
  Cdim <- dim(Cmat)
  if (Bdim[1] != Bdim[2]) 
    stop("BMAT is not square")
  if (Cdim[1] != Cdim[2]) 
    stop("CMAT is not square")
  p <- Bdim[1]
  q <- Cdim[1]
  s <- min(c(p, q))
  if (max(abs(Bmat - t(Bmat)))/max(abs(Bmat)) > 1e-10) 
    stop("BMAT not symmetric.")
  if (max(abs(Cmat - t(Cmat)))/max(abs(Cmat)) > 1e-10) 
    stop("CMAT not symmetric.")
  Bmat <- (Bmat + t(Bmat))/2
  Cmat <- (Cmat + t(Cmat))/2
  Bfac <- chol(Bmat)
  Cfac <- chol(Cmat)
  Bfacinv <- MASS::ginv(Bfac)
  Cfacinv <- MASS::ginv(Cfac)
  Dmat <- t(Bfacinv) %*% Amat %*% Cfacinv
  if (p >= q) {
    result <- try(svd(Dmat))
    while (class(result) == "try-error") {
      Dmat <- Dmat + 0.0001 * diag(p)
      result <- try(svd(Dmat))
      
    }
    values <- result$d
    Lmat <- Bfacinv %*% result$u
    Mmat <- Cfacinv %*% result$v
  }
  else {
    result <- try(svd(t(Dmat)))
    while (class(result) == "try-error") {
      Dmat <- Dmat + 0.0001 * diag(q)
      result <- try(svd(t(Dmat)))
    }
    values <- result$d
    Lmat <- Bfacinv %*% result$v
    Mmat <- Cfacinv %*% result$u
  }
  geigenlist <- list(values, Lmat, Mmat)
  names(geigenlist) <- c("values", "Lmat", "Mmat")
  return(geigenlist)
}


comput2<-function (X, Y, res) {
  X.aux <- scale(X, center = F, scale = FALSE)
  Y.aux <- scale(Y, center = F, scale = FALSE)
  X.aux[is.na(X.aux)] <- 0
  Y.aux[is.na(Y.aux)] <- 0
  xscores <- X.aux %*% res$xcoef
  yscores <- Y.aux %*% res$ycoef
  corr.X.xscores <- cor(X, xscores, use = "pairwise")
  corr.Y.xscores <- cor(Y, xscores, use = "pairwise")
  corr.X.yscores <- cor(X, yscores, use = "pairwise")
  corr.Y.yscores <- cor(Y, yscores, use = "pairwise")
  return(list(xscores = xscores, yscores = yscores, corr.X.xscores = corr.X.xscores, 
              corr.Y.xscores = corr.Y.xscores, corr.X.yscores = corr.X.yscores, 
              corr.Y.yscores = corr.Y.yscores))
}


rcc2<-function (S, X, Y, lambda1 = 0.00001, lambda2 = 0.00001) {
  n <- dim(X)[1]
  p <- dim(X)[2]
  q <- dim(Y)[2]
  if (is.null(S))
    S <- cov(cbind(X, Y))
  Sxx <- S[1:p, 1:p] + diag(lambda1, p)
  Syy <- S[(p + 1):(p + q), (p + 1):(p + q)] + diag(lambda2, q)
  Sxy <- S[1:p, (p + 1):(p + q)]
  res <- geigen2(Sxy, Sxx, Syy)
  names(res) <- c("cor", "xcoef", "ycoef")
  scores <- comput2(X, Y, res)
  res$xcoef <- t(t(res$xcoef) / sqrt(colSums(res$xcoef^2)))
  res$ycoef <- t(t(res$ycoef) / sqrt(colSums(res$ycoef^2)))
  
  return(list(
    cor = res$cor,
    xcoef = res$xcoef,
    ycoef = res$ycoef,
    scores = scores
  ))
}


cross_validation_residual_score <- function(X,Y, n_folds = 10,ncores=1,
                                            method='rCCA') {
  n <- nrow(X) 
  p <- ncol(X)
  fold_size <- floor(n / n_folds) # Size of each fold
  Xunc <- X
  Yunc <- Y
  if(method=='rCCA'){
    muX<-apply(X,2,mean)
    muY<-apply(Y,2,mean)
    sdX<-apply(X,2,sd)
    sdY<-apply(Y,2,sd)
  } else{
    muX<-apply(X,2,median)
    muY<-apply(Y,2,median)
    sdX <- apply(X, 2, function(x) scale_tanh(na.omit(x)-median(na.omit(x))))
    sdY <- apply(Y, 2, function(x) scale_tanh(na.omit(x)-median(na.omit(x))))
  }
  X<-scale(X,center = muX,scale = sdX)
  Y<-scale(Y,center = muY,scale = sdY)
  Xunc<-scale(Xunc,center = muX,scale = sdX)
  Yunc<-scale(Yunc,center = muY,scale = sdY)
  
  fold_results <- numeric(n_folds)
  fold_results<-list()
  outtest_list<-xscorestest<- yscorestest<- list()
  set.seed(0) 
  folds <- caret::createFolds(1:n, k = n_folds, list = TRUE)
  for (fold in 1:n_folds) {
    set.seed(fold) # For reproducibility
    
    test_indices <- folds[[fold]]
    train_indices <- setdiff(1:n, test_indices)
    
    X_train <- X[train_indices, , drop = FALSE]
    Y_train <- Y[train_indices, , drop = FALSE]
    X_test  <- X[test_indices, , drop = FALSE]
    Y_test  <- Y[test_indices, , drop = FALSE]
    Xtest_unc  <- Xunc[test_indices, , drop = FALSE]
    Ytest_unc  <- Yunc[test_indices, , drop = FALSE]
    
    indx <- 1:ncol(X_train)
    indy <- (ncol(X_train) + 1):(ncol(X_train) + ncol(Y_train))
    Ztrain <- cbind(X_train, Y_train)
    mm <- checkDataSet(Ztrain, silent = T)
    Ztrain <- Ztrain[mm$rowInAnalysis, mm$colInAnalysis]
    indx <- mm$colInAnalysis[mm$colInAnalysis <= ncol(X_train)]
    indy <- mm$colInAnalysis[mm$colInAnalysis > ncol(X_train)] - ncol(X_train)
    if (method == 'cellRCCA') {
      fit <- try(cellRCov(
        Ztrain,
        k = 1,
        kmax = min(8, p),
        reg = T,
        quantile_diff = NULL,
        ncores = ncores
      ))
      #k=1 selected
      S_est <- fit$S
      mod <- rcc2(S_est, X_train[mm$rowInAnalysis, indx], 
                  Y_train[mm$rowInAnalysis, indy], 0, 0)
    }
    else if (method == 'rCCA') {
      res.regul = estpar_hfold(X_train[mm$rowInAnalysis, indx], Y_train[mm$rowInAnalysis, indy], plt = TRUE, H =
                                 5)
      mod <- rcc(X_train[mm$rowInAnalysis, indx],
                 Y_train[mm$rowInAnalysis, indy],
                 lambda1 = res.regul$lambda1,
                 lambda2 = res.regul$lambda2)
      
    }
    mod$xcoef <- t(t(mod$xcoef) / sqrt(apply(mod$xcoef, 2, function(x)
      t(x) %*% x)))
    mod$ycoef <- t(t(mod$ycoef) / sqrt(apply(mod$ycoef, 2, function(x)
      t(x) %*% x)))
    
    xscorestest[[fold]] = Xtest_unc[, indx] %*% mod$xcoef
    yscorestest[[fold]] = Ytest_unc[, indy] %*% mod$ycoef
  }
  dimx <- min(sapply(xscorestest, function(x)
    dim(x)[2]))
  dimy <- min(sapply(yscorestest, function(x)
    dim(x)[2]))
  yscorestest <- lapply(yscorestest, function(x)
    x[, 1:dimy])
  xscorestest <- lapply(xscorestest, function(x)
    x[, 1:dimx])
  xscorestest <- do.call(rbind, xscorestest)
  yscorestest <- do.call(rbind, yscorestest)
  
  out <- list(xscorestest = xscorestest, yscorestest = yscorestest)
  return(out)
}



######################################################################
##                                                                   #
## Functions to perform AMFCC and compting approaches               #
##                                                                   #
## This code contains all the functions required by Run.R            #
##                                                                   #
######################################################################

# Utility functions -------------------------------------------------------

plot_function<-function(ARL_mean,ARL_sd, type = "ARL", Type_OC = "Shift A",
                        save = T,cost_cov=1){
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(ggtext)
  if (type == "ARL") {
    names <-
      c(
        "AMFCC<sub>F</sub>",
        "AMFCC<sub>T</sub>",
        "MFCC<sub>09</sub>",
        'MFCC<sub>08</sub>',
        'MFCC<sub>07</sub>',
        "RenCC",
        "ZouCC",
        "MCC",
        "DCC"
      )
    
    
    ARL_mean = ARL_mean[, c(1:5, 8:9, 6:7)]
    ARL_sd = ARL_sd[, c(1:5, 8:9, 6:7)]
    severity <- rep(0:4, 9)
    method <- as.factor(rep(names, each = 5))
    df_TD <-
      data.frame(
        mean = c(ARL_mean),
        sd = stack(as.data.frame(ARL_sd, drop = TRUE))[, 1],
        d =
          severity
      )
    df_TD <-
      data.frame(df_TD, method = as.factor(rep(names, each = 5))) %>%
      mutate(method = factor(method, levels = names))
    
    gg_color_hue <- function(n) {
      hues = seq(15, 375, length = n + 1)
      hcl(h = hues, l = 65, c = 100)[1:n]
    }
    pal <-  c(1:8,  "#6a3d9a")
    p <- ggplot(
      df_TD,
      aes(
        x = d,
        y = mean,
        group = method,
        linetype = method,
        color = method,
        fill = method,
        shape = method
      )
    ) +
      geom_hline(yintercept = 20,
                 color = "grey",
                 linewidth = 0.8) +
      geom_hline(yintercept = 0,
                 color = "black",
                 linewidth = 0.8) +
      scale_shape_manual(values = c(16, 15, 17, 18, 25, 4, 8, 9, 10)) +
      scale_color_manual(values = pal) +
      scale_fill_manual(values = pal) +
      scale_linetype_manual(values = 1:9) +
      geom_line(linewidth = 0.8) +
      geom_point(size = 5) +
      geom_errorbar(aes(ymin = mean - 3 * sd, ymax = mean + 3 * sd),
                    width = .8,
                    position = position_dodge(0)) +
      xlim(-0.08, 4.05) +
      ylab(expression(widehat(ARL))) +
      xlab("d") +
      scale_y_log10(breaks = c(1, 2, 5, 10, 20), limits = c(1, 24)) +
      theme_bw() +
      theme(legend.text = element_markdown(size = 30)) +
      ggtitle(Type_OC) +
      theme(
        plot.title = element_text(hjust = 0.5, size = 50),
        legend.title = element_blank(),
        axis.title.y = element_text(size = 40),
        axis.title.x = element_text(size = 40),
        axis.text.x =  element_text(size = 30),
        axis.text.y =  element_text(size = 30),
        legend.key.width = unit(2, "cm"),
        legend.position = c(0.85, 0.70) ,
        legend.background = element_rect(colour = "black")
      )
    print(p)
    if (save)
      ggsave(paste0("ARL.pdf"), width = 11, height = 9.5)
  }
  if (type == "cARL") {
    names <-
      c(
        "AMFCC<sub>F</sub>",
        "AMFCC<sub>T</sub>",
        "MFCC<sub>09</sub>",
        'MFCC<sub>08</sub>',
        'MFCC<sub>07</sub>'
      )
    severity <- rep(0:4, 5)
    method <- as.factor(rep(names, each = 5))
    df_TD <-
      data.frame(
        mean = c(ARL_mean),
        sd = stack(as.data.frame(ARL_sd, drop = TRUE))[, 1],
        d = severity
      )
    df_TD <-
      data.frame(df_TD, method = as.factor(rep(names, each = 5))) %>%
      mutate(method = factor(method, levels = names))
    
    gg_color_hue <- function(n) {
      hues = seq(15, 375, length = n + 1)
      hcl(h = hues, l = 65, c = 100)[1:n]
    }
    pal <- 1:5
    p <- ggplot(
      df_TD,
      aes(
        x = d,
        y = mean,
        group = method,
        linetype = method,
        color = method,
        fill = method,
        shape = method
      )
    ) +
      geom_hline(yintercept = (20),
                 color = "grey",
                 size = 0.8) +
      geom_hline(yintercept = 0,
                 color = "black",
                 size = 0.8) +
      scale_shape_manual(values = c(16, 15, 17, 18, 25, 4, 8)) +
      scale_color_manual(values = pal) +
      scale_fill_manual(values = pal) +
      scale_linetype_manual(values = 1:5) +
      geom_line(size = 0.8) +
      geom_point(size = 5) +
      geom_errorbar(aes(ymin = mean - 3 * sd, ymax = mean + 3 * sd),
                    width = .8,
                    position = position_dodge(0)) +
      # ylim(-0.05, 1)+
      xlim(-0.08, 4.05) +
      ylab(expression(widehat(cARL))) +
      xlab("d") +
      scale_y_log10(breaks = c(1, 2, 5, 10, 20), limits = c(1, 24)) +
      theme_bw() +
      theme(legend.text = element_markdown(size = 30)) +
      ggtitle(Type_OC) +
      theme(
        plot.title = element_text(hjust = 0.5, size = 50),
        legend.title = element_blank(),
        axis.title.y = element_text(size = 40),
        axis.title.x = element_text(size = 40),
        axis.text.x =  element_text(size = 30),
        axis.text.y =  element_text(size = 30),
        legend.key.width = unit(2, "cm"),
        legend.position = c(0.15, 0.20) ,
        legend.background = element_rect(colour = "black")
      )
    print(p)
    
    if (save)
      ggsave(paste0("cARL_D",cost_cov,"_",Type_OC,".pdf"), width = 11, height = 9.5)
  }
}

# Data generation ---------------------------------------------------------

simulate_data <-
  function(N = 50,
           nbasis = 50,
           length_tot = 50,
           sd = 0.1,
           sd2_basis = 0.01,
           p = 5,
           FOC = 0,
           delta = 0,
           type = "center",
           cost_cov = 1,
           cov_type = "Bessel") {
    grid <- seq(0, 1, length.out = length_tot)
    domain <- c(0, 1)
    X_basis <-
      fda::create.bspline.basis(domain, norder = 4, nbasis = nbasis)
    mean_mat <- matrix(0, length_tot, p)
    
    if (FOC != 0) {
      if (type == "center") {
        x_c=ceiling(length_tot/2)
        x_e1=x_c-(length_tot/2*0.5)
        x_e2=x_c+(length_tot/2*0.5)
        a1=delta/(x_c-x_e1)
        a2=-delta/(x_e2-x_c)
        c1=-a1*x_e1
        c2=-a2*x_c+delta
        p_pc2 <- p
        mean_mat[x_e1:x_c, 1:p_pc2] <- a1 * (x_e1:x_c) + c1
        mean_mat[x_c:x_e2, 1:p_pc2] <- a2 * (x_c:x_e2) + c2
        mean_mat[x_e1:x_e2, 1:p_pc2] <-
          (delta / (x_e1 - x_c) ^ 2) * ((x_e1:x_e2) - x_c) ^ 2 - delta
        
      }
      if (type == "end") {
        p_pc2 <- p
        x_c <- ceiling(length_tot * (1 - 0.5))
        x_e <- length_tot
        a <- -delta / (x_e - x_c)
        c <- -a * x_c
        mean_mat[(ceiling(length_tot * (1 - 0.5)):length_tot), 1:p_pc2] <-
          a * (ceiling(length_tot * (1 - 0.5)):length_tot) + c
      }
      if (type == "sin") {
        aa <- delta * sin(grid * 2 * pi)
        p_pc2 <- p
        mean_mat[, 1:p_pc2] <- aa
      }
      if (type == "quadr") {
        aa <- 2 * delta * grid ^ 2 - delta
        p_pc2 <- p
        mean_mat[, 1:p_pc2] <- aa
      }
    }
    
    
    if (cov_type == "Bessel") {
      func_cov <- function(x, cost_cov) {
        besselJ(grid * 50 / ((3)), 0) / ((-(1 - grid) * 10 / (1 + (cost_cov - 1) *
                                                                4)) + 1 + 10 / (1 + (cost_cov - 1) * 4))
      }
    }
    if (cov_type == "Gauss") {
      func_cov <- function(x, cost_cov) {
        geoR::cov.spatial(grid * 40 / cost_cov,
                          cov.model = "gaussian",
                          c(1, 1),
                          0.5)
      }
    }
    
    get_mat <- function(cov) {
      P <- length(cov)
      covmat <- matrix(0, nrow = P, ncol = P)
      for (ii in 1:P) {
        covmat[ii, ii:P] <- cov[1:(P - ii + 1)]
        covmat[P - ii + 1, 1:(P - ii + 1)] <-
          rev(cov[1:(P - ii + 1)])
      }
      covmat
    }
    
    cor_mat <- matrix(0, p * length_tot, p * length_tot)
    K_fd <- list()
    for (ii in 1:p) {
      K_fd[[ii]] <- list()
      for (jj in 1:p) {
        ind1 <- ((ii - 1) * length_tot + 1):(ii * length_tot)
        ind2 <- ((jj - 1) * length_tot + 1):(jj * length_tot)
        matrix3 <-
          func_cov(grid, cost_cov) * (1 / ((8 / cost_cov) * abs(ii - jj) + 1))
        cor_mat[ind1, ind2] <- get_mat(matrix3)
      }
    }
    K_0_mat <- cor_mat * sd2_basis
    
    X_coef <-
      t(MASS::mvrnorm(N, mu = rep(0, length_tot * p) , Sigma = K_0_mat))
    X_mat_list <- list()
    X_array <- array(0, dim = c(length_tot, N, p))
    for (ii in 1:p) {
      X1_scaled <-
        t(X_coef)[, ((ii - 1) * (length_tot) + 1):(ii * length_tot)]
      X_mat_list[[ii]] <-
        t(X1_scaled) + matrix(mean_mat[, ii], length_tot, N) + rnorm(prod(dim(X1_scaled)), sd = sd)
      X_array[, , ii] <- X_mat_list[[ii]]
    }
    X <- do.call("rbind", X_mat_list)
    data <-
      data.frame(
        x = c(X),
        timeindex = rep(1:length(grid), p * (N)),
        curve = rep(1:(N), each = length(grid) * p),
        var = rep(1:p, each = length(grid), (N))
      )
    mu_fd <- NULL
    out <- list(
      data = data,
      X = X_array,
      mu_fd = mu_fd,
      K_fd = K_fd,
      sigma_0 = sd ^ 2,
      grid = grid,
      K_0_mat = K_0_mat
    )
    return(out)
  }




# MFCC -------------------------------------------------------------------
Phase_I_MFCC <-
  function(data_tra,
           data_tun,
           grid,
           nb = 30,
           fev = 0.8,
           alpha_mon = 0.05,
           alpha_diagn = 0.05,
           ncores=1) {
    
    p_var <- max(data_tra$var)
    
    ## Data smoothing training data
    N_IC <- length(unique(data_tra$curve))
    grid2 <- seq(0, 1, l = 100)
    basis <-
      create.bspline.basis(c(grid[1], grid[length(grid)]), nbasis = nb)
    par_fun <- function(ii, data) {
      coef_mat <- array(0, c(nb, 1, p_var))
      for (jj in 1:p_var) {
        X <- data$x[data$curve == ii & data$var == jj]
        grid_i <-
          grid[data$timeindex[data$curve == ii & data$var == jj]]
        y <- mgcv::gam(X ~ s(
          grid_i,
          k = nb,
          m = c(3, 2),
          bs = "bs"
        ))
        y_pred = predict(y, newdata = data.frame(grid_i = seq(0, 1, l = 200)))
        coef_mat[, 1, jj] <-
          t(smooth.basis(seq(0, 1, l = 200), t(t(y_pred)), basis)$fd$coefs)
      }
      return(coef_mat)
    }
    
    
    if (.Platform$OS.type == "unix" | ncores == 1) {
      out <-
        parallel::mclapply(1:N_IC, par_fun, mc.cores = ncores, data = data_tra)
    } else {
      cl <- parallel::makeCluster(ncores)
      parallel::clusterEvalQ(cl,{
        source("functions.R")
        library(funcharts)
        library(fda)
      })
      out <- parallel::parLapply(cl, 1:N_IC, par_fun, data = data_tra)
      # parallel::stopCluster(cl)
    }
    coeff <- abind::abind(out, along = 2)
    dimnames(coeff)[[3]] <- as.character(1:p_var)
    x_IC <- mfd(
      coeff,
      basis,
      fdnames = list("arg",
                     as.character(1:N_IC), as.character(1:p_var)),
      raw = data.frame(
        id = factor(rep(1:N_IC)),
        arg = factor(rep(1:N_IC)),
        matrix(0, N_IC, p_var, dimnames = list(
          as.character(1:N_IC), c(as.character(1:(p_var)))
        ))
      ),
      id_var = "id",
      B = eval.penalty(basis)
    )
    
    ## MFPCA
    mod_pca <- pca_mfd(x_IC, scale = T, nharm = 300)
    varprop <- mod_pca$values / sum(mod_pca$values)
    K <- which(cumsum(varprop) >= fev)[1]
    mean_IC <- mean.fd(x_IC)
    sd_IC <- sd.fd(x_IC)
    
    ## Data Smoothing tuning data
    N_tun <- length(unique(data_tun$curve))
    
    if (.Platform$OS.type == "unix" |
        ncores == 1) {
      out <-
        parallel::mclapply(1:N_tun, par_fun, mc.cores = ncores, data = data_tun)
    } else {
      out <- parallel::parLapply(cl, 1:N_tun, par_fun, data = data_tun)
      parallel::stopCluster(cl)
    }
    
    coeff <- abind::abind(out, along = 2)
    x_tun <- mfd(
      coeff,
      basis,
      fdnames = list("arg",
                     as.character(1:N_tun), as.character(1:p_var)),
      raw = data.frame(
        arg = factor(rep(1:N_tun)),
        id = factor(rep(1:N_tun)),
        matrix(0, N_tun, p_var, dimnames = list(
          as.character(1:N_tun), c(as.character(1:(p_var)))
        ))
      ),
      id_var = "id"
    )
    
    ## Calculation of the statistics
    cc <-
      funcharts:::get_T2_spe(
        mod_pca,
        1:K,
        newdata_scaled = funcharts::scale_mfd(
          x_tun,
          center = mod_pca$center_fd,
          scale = mod_pca$scale_fd
        )
      )
    T2 <- cc$T2
    SPE <- cc$spe
    nobs <- length(T2)
    
    ## Control limits computation
    alpha_sid <- 1 - (1 - alpha_mon) ^ (1 / 2)
    CL_T2 <- quantile(T2, 1 - alpha_sid)
    CL_SPE <- quantile(SPE, 1 - alpha_sid)
    ind_T2 <- str_detect(names(cc), "contribution_T2")
    contribution_T2 <- cc[, ind_T2]
    CL_cont_T2 <-
      apply(contribution_T2, 2, quantile, 1 - alpha_diagn / 2)
    ind_SPE <- str_detect(names(cc), "contribution_spe")
    contribution_SPE <- cc[, ind_SPE]
    CL_cont_SPE <-
      apply(contribution_SPE, 2, quantile, 1 - alpha_diagn /
              2)
    out <- list(
      CL_T2 = CL_T2,
      CL_SPE = CL_SPE,
      mean_IC = mean_IC,
      T2 = T2,
      SPE = SPE,
      K = K,
      x_tra = x_IC,
      x_tun = x_tun,
      grid = grid,
      mod_pca = mod_pca,
      CL_cont_T2 = CL_cont_T2,
      CL_cont_SPE = CL_cont_SPE
    )
    return(out)
  }
Phase_II_MFCC <- function(data, mod_Phase_I,ncores=1) {
  
  p_var <- max(data$var)
  N <- length(unique(data$curve))
  x_tra <- mod_Phase_I$x_tra
  grid <- mod_Phase_I$grid
  mean_IC <- mod_Phase_I$mean_IC
  cov_scores <- mod_Phase_I$cov_scores
  mean_scores <- mod_Phase_I$mean_scores
  lambda <- mod_Phase_I$lambda
  CL <- mod_Phase_I$CL
  basis <- x_tra$basis
  nb <- basis$nbasis
  n_seq <- length(data)
  K <- mod_Phase_I$K
  mod_pca <- mod_Phase_I$mod_pca
  
  ## Data smoothing of the Phase II data
  par_fun <- function(ii, data) {
    coef_mat <- array(0, c(nb, 1, p_var))
    for (jj in 1:p_var) {
      X <- data$x[data$curve == ii & data$var == jj]
      grid_i <-
        grid[data$timeindex[data$curve == ii & data$var == jj]]
      y <- mgcv::gam(X ~ s(
        grid_i,
        k = nb,
        m = c(3, 2),
        bs = "bs"
      ))
      y_pred <-
        predict(y, newdata = data.frame(grid_i = seq(0, 1, l = 200)))
      coef_mat[, 1, jj] <-
        t(smooth.basis(seq(0, 1, l = 200), t(t(y_pred)), basis)$fd$coefs)
    }
    return(coef_mat)
  }
  # out <- parallel::mclapply(1:N, par_fun, data, mc.cores = cores)
  if (.Platform$OS.type == "unix" |
      ncores == 1) {
    out <-
      parallel::mclapply(1:N, par_fun, mc.cores = ncores, data = data)
  } else {
    cl <- parallel::makeCluster(ncores)
    parallel::clusterEvalQ(cl,{
      source("functions.R")
      library(funcharts)
      library(fda)
    })
    out <- parallel::parLapply(cl, 1:N, par_fun, data = data)
    parallel::stopCluster(cl)
  }
  
  coeff <- abind::abind(out, along = 2)
  dimnames(coeff)[[3]] <- as.character(1:p_var)
  x <- mfd(
    coeff,
    basis,
    fdnames = list("arg",
                   as.character(1:N), as.character(1:p_var)),
    raw = data.frame(
      arg = factor(rep(1:N)),
      id = factor(rep(1:N)),
      matrix(0, N, p_var, dimnames = list(as.character(1:N), c(
        as.character(1:(p_var))
      )))
    ),
    id_var = "id"
  )
  
  ## Computation of the statistics
  cc <-
    funcharts:::get_T2_spe(
      mod_pca,
      1:K,
      newdata_scaled = funcharts::scale_mfd(x, center = mod_pca$center_fd, scale = mod_pca$scale_fd)
    )
  inprods <-
    funcharts:::get_pre_scores(
      mod_pca,
      1:K,
      funcharts::scale_mfd(x, center = mod_pca$center_fd, scale = mod_pca$scale_fd)
    )
  scores <- apply(inprods, 1:2, sum)
  T2 <- cc$T2
  SPE <- cc$spe
  
  ## ARL computation
  frac_out <-
    mean(T2 > mod_Phase_I$CL_T2 | SPE > mod_Phase_I$CL_SPE)
  ind_T2 <- str_detect(names(cc), "contribution_T2")
  contribution_T2 <- cc[, ind_T2]
  ind_SPE <- str_detect(names(cc), "contribution_spe")
  contribution_SPE <- cc[, ind_SPE]
  ind_out <- 1:N
  mat_out <- matrix(0, N, p_var)
  for (ii in 1:p_var) {
    mat_out[ind_out, ii] <-
      as.numeric((
        contribution_T2[ind_out, ii] > mod_Phase_I$CL_cont_T2[ii] |
          contribution_SPE[ind_out, ii] > mod_Phase_I$CL_cont_SPE[ii]
      )
      )
    
  }
  
  frac_out_vs <- apply(mat_out, 2, mean)
  frac_out_vs_mean <- mean(frac_out_vs)
  out <- list(
    frac_out = frac_out,
    T2 = T2,
    SPE = SPE,
    frac_out_vs_mean = frac_out_vs_mean,
    x_OC = x
  )
  return(out)
}

# MCC and DCC -------------------------------------------------------------------
Phase_I_II_MCC <-
  function(data,
           data_IC,
           alpha = 0.05,
           type = "mean" ,
           grid_dis = NULL) {
    p_var <- dim(data)[3]
    X_mat_list_new <- lapply(1:p_var, function(ii)
      t(data[, , ii]))
    X_mat_list_new_IC <- lapply(1:p_var, function(ii)
      t(data_IC[, , ii]))
    if (type == "mean") {
      Xmeans_new <- sapply(X_mat_list_new, rowMeans)
      Xmeans_new_IC <- sapply(X_mat_list_new_IC, rowMeans)
    }
    else if (type == "discrete") {
      Xmeans_new <- do.call("cbind", X_mat_list_new)
      Xmeans_new_IC <- do.call("cbind", X_mat_list_new_IC)
      if (is.null(grid_dis))
        grid_dis <- seq(1, dim(Xmeans_new)[2])
      Xmeans_new <- Xmeans_new[, grid_dis]
      Xmeans_new_IC <- Xmeans_new_IC[, grid_dis]
    }
    
    mean <- apply(Xmeans_new_IC, 2, mean)
    S <- cov(Xmeans_new_IC)
    Sinv <- solve(S)
    Xcen <- t(t(Xmeans_new_IC) - mean)
    T2_IC <- rowSums((Xcen %*% Sinv) * Xcen)
    CL_T2 <- quantile(T2_IC, 1 - alpha)
    Sinv <- solve(S)
    Xcen <- t(t(Xmeans_new) - mean)
    T2 <- rowSums((Xcen %*% Sinv) * Xcen)
    
    frac_out <- mean(T2 > CL_T2)
    ARL <- 1 / frac_out
    out <-
      list(
        T2 = T2,
        CL_T2 = CL_T2,
        frac_out = frac_out,
        Xmeans_new = Xmeans_new,
        Xmeans_new_IC = Xmeans_new_IC
      )
    
    return(out)
  }


# Ren and Zou -------------------------------------------------------------
Phase_I_RenCC <- function(x_tra,
                          x_tun,
                          fev = 0.90,
                          ARL0_pre = 20) {
  
  lambda <- 1
  nobs_transient <- 0
  nseq <- 1
  l_xseq <- 25
  cost_k <- 100
  lseq <- dim(x_tra$coefs)[2]
  lseq_tun <- dim(x_tun$coefs)[2]
  nbasis <- dim(x_tra$coefs)[1]
  nobs <- dim(x_tra$coefs)[2]
  nvar <- dim(x_tra$coefs)[3]
  
  mean_mfdobj_x <- fda::mean.fd(x_tra)
  
  xseq <- seq(0, 1, l = l_xseq)
  basis <- x_tra$basis
  
  # (TRAINING)
  mfdobj_x_cen <-
    funcharts::scale_mfd(x_tra, center = mean_mfdobj_x, scale = FALSE)
  Xeval_cen <- fda::eval.fd(xseq, mfdobj_x_cen)
  
  nobs <- dim(Xeval_cen)[2]
  nvar <- dim(Xeval_cen)[3]
  n <- dim(Xeval_cen)[1]
  
  
  Xeval_cen <- aperm(Xeval_cen, c(2, 1, 3))
  mua <- apply(Xeval_cen, 2:3, mean)
  
  cov_list <- lapply(1:nvar, function(jj)
    cov(Xeval_cen[, , jj]))
  cova <- Reduce("+", cov_list)
  
  eio <- eigen(cova)
  eval <- eio$values
  evec <- eio$vectors
  varprop <- cumsum(eval) / sum(eval)
  d <- which(varprop >= 0.95)[1]
  evec <- evec * n ^ 0.5
  eval <- eval / n
  
  scores <- lapply(1:d, function(ll) {
    sapply(1:nvar, function(jj)
      Xeval_cen[, , jj] %*% evec[, ll] / (n))
  })
  scores <- do.call(cbind, scores)
  
  Y <- scores * lambda
  for (ii in 2:nrow(Y)) {
    Y[ii, ] <- lambda * scores[ii, ] + (1 - lambda) * Y[ii - 1, ]
  }
  sigmaY_list <- lapply(1:d, function(ll) {
    idx_ll <- (ll - 1) * nvar + 1:nvar
    Rfast::cova(Y[, idx_ll])
  })
  sigmaY <- as.matrix(bdiag(sigmaY_list))
  eigen <- eigen(sigmaY)
  var_spiegata <- cumsum(eigen$values) / sum(eigen$values)
  n_eigenvalues <- which(var_spiegata >= 1)[1]
  A <- eigen$values[1:n_eigenvalues]
  B <- eigen$vectors[, 1:n_eigenvalues]
  inv_sigmaY_reg <- B %*% diag(1 / A) %*% t(B)
  
  
  # (TUNING)
  mfdobj_x_tun_cen <-
    funcharts::scale_mfd(x_tun, center = mean_mfdobj_x, scale = FALSE)
  Xeval_tun_cen <- fda::eval.fd(xseq, mfdobj_x_tun_cen)
  nobs_tun <- dim(Xeval_tun_cen)[2]
  Xeval_tun_cen <- aperm(Xeval_tun_cen, c(2, 1, 3))
  Xeval_tun_cen_mat <-
    matrix(Xeval_tun_cen, nrow = dim(Xeval_tun_cen)[1])
  
  
  scores_tun <- lapply(1:d, function(ll) {
    sapply(1:nvar, function(jj)
      Xeval_tun_cen[, , jj] %*% evec[, ll] / (n))
  })
  scores_tun <- do.call(cbind, scores_tun)
  
  par_fun_tun <- function(qq) {
    idx_tun <- sample(1:dim(x_tun$coefs)[2], lseq_tun, replace = TRUE)
    Y_array_tun <- statisticY_EWMA_cpp(
      scores_tun,
      lambda = lambda,
      k = rep(100, ncol(scores_tun)),
      huber = TRUE,
      idx = idx_tun
    )
    V2 <- colSums(t(Y_array_tun %*% B) ^ 2 / A)
    return(V2)
  }
  
  V2_mat <-
    do.call(rbind, lapply(1:nseq, function(x)
      par_fun_tun(x)))
  
  h <- quantile(as.numeric(V2_mat), 1 - (1 / ARL0_pre))
  
  
  out <- list(
    inv_sigmaY_reg = inv_sigmaY_reg,
    mean_mfdobj_x = mean_mfdobj_x,
    h = h,
    ARL0 = ARL0_pre,
    lambda = lambda,
    k = rep(100, ncol(scores_tun)),
    xseq = xseq,
    V2_mat = V2_mat,
    nobs_transient = nobs_transient,
    huber = TRUE,
    vectors = B,
    values = A,
    evec = evec,
    eval = eval,
    d = d
  )
  return(out)
}


Phase_II_RenCC <- function(data,
                           data_IC,
                           mod_1) {
  
  
  
  nobs_transient <- 100
  nseq <- 1
  lseq_II <- dim(data$coefs)[2]
  
  nobs2 <- dim(data$coefs)[2]
  nobs_IC <- dim(data_IC$coefs)[2]
  nvar <- dim(data$coefs)[3]
  xseq <- mod_1$xseq
  mean_mfdobj_x <- mod_1$mean_mfdobj_x
  vectors <- mod_1$vectors
  values <- mod_1$values
  lambda <- mod_1$lambda
  huber<-mod_1$huber
  k <- mod_1$k
  h <- mod_1$h
  d <- mod_1$d
  
  RL <- numeric(nseq)
  
  data_IC_cen <- funcharts::scale_mfd(data_IC, center = mean_mfdobj_x, scale = FALSE)
  data_IC_cen_eval <- fda::eval.fd(xseq, data_IC_cen)
  data_IC_cen_eval <- aperm(data_IC_cen_eval, c(2, 1, 3))
  n <- dim(data_IC_cen_eval)[2]
  
  scores_IC <- lapply(1:d, function(ll) {
    sapply(1:nvar, function(jj)
      data_IC_cen_eval[, , jj] %*% mod_1$evec[, ll] / (n))
  })
  scores_IC <- do.call(cbind, scores_IC)
  
  data2_cen <- funcharts::scale_mfd(data, center = mean_mfdobj_x, scale = FALSE)
  data2_cen_eval <- fda::eval.fd(xseq, data2_cen)
  data2_cen_eval <- aperm(data2_cen_eval, c(2, 1, 3))
  
  scores2 <- lapply(1:d, function(ll) {
    sapply(1:nvar, function(jj)
      data2_cen_eval[, , jj] %*% mod_1$evec[, ll] / (n))
  })
  scores2 <- do.call(cbind, scores2)
  
  
  
  par_fun_tun <- function(qq) {
    idx_tun <- sample(1:dim(data2_cen$coefs)[2], lseq_II, replace = TRUE)
    Y_array_tun <- statisticY_EWMA_cpp(
      scores2,
      lambda = lambda,
      k = rep(100, ncol(scores2)),
      huber = huber,
      idx = idx_tun
    )
    V2 <- colSums(t(Y_array_tun %*% vectors) ^ 2 / values)
    return(V2)
  }
  
  V2_mat <- do.call(rbind, lapply(1:nseq, function(x) par_fun_tun(x)))
  
  
  ARL<-1/(length(which(as.numeric(V2_mat)>h))/length(V2_mat))
  return(list(frac_out = 1 / ARL,
              RL = RL,
              V2 = V2_mat))
}
larewma.apply2 <- function (chart, y, mu = 0, plot = TRUE)
{
  y <- t(as.matrix(y))
  ny <- NCOL(y)
  n <- NROW(y)
  if (chart$ipar[2] != n)
    stop("Number of variables in y and chart do not match")
  if (!missing(mu))
    y <- y - mu
  ans <-
    .C(
      "ggcomputecharts",
      as.integer(chart$ipar),
      as.double(chart$par),
      as.integer(ny),
      as.double(y),
      as.double(chart$stat0),
      ans = double(ny * chart$ipar[3]),
      DUP = FALSE,
      PACKAGE = "larewma"
    )$ans
  ans <- ts(matrix(ans, ncol = chart$ipar[3], byrow = TRUE))
  if (plot) {
    plot(
      ans[, 1],
      type = "b",
      ylim = c(min(ans[, 1]), 1.05 *
                 max(ans[, 1], chart$par[1])),
      xlab = "t",
      ylab = expression(W[t])
    )
    abline(h = chart$par[1], lty = "dotted")
  }
  p <- chart$ipar[8]
  js <- 2:(p + 2)
  jb <- (p + 4):(p + 3 + p * p)
  select <- function(i) {
    w <- as.numeric(ans[i, 1])
    d <-
      cbind(ans[i, js], rbind(matrix(ans[i, jb], p, byrow = TRUE),
                              0))
    rownames(d) <- 1:(p + 1)
    colnames(d) <- c("(S-a)/b", paste("beta", 1:p, sep = ""))
    list(t = i, W = w, stat = d)
  }
  alarms <- which(ans[, 1] > chart$par[1])
  alarms <- 1:length(ans[, 1])
  if (length(alarms)) {
    lapply(alarms, select)
  }
  else {
    list()
  }
}
Phase_I_II_ZouCC <-
  function(X_OC,
           X_IC,
           X_tun,
           plot = F,
           print = F,
           iter = 5000,
           grid,
           fev = 0.9999,
           alpha = 0.05) {
    mod_pca <- pca_mfd(X_IC, scale = T, nharm = 300)
    varprop <- mod_pca$values / sum(mod_pca$values)
    K <- which(cumsum(varprop) >= fev)[1]
    K <- min(K, 50)
    inprods <-
      funcharts:::get_pre_scores(
        mod_pca,
        1:K,
        funcharts::scale_mfd(X_IC, center = mod_pca$center_fd, scale = mod_pca$scale_fd)
      )
    scores_IC <- apply(inprods, 1:2, sum)
    
    inprods <-
      funcharts:::get_pre_scores(
        mod_pca,
        1:K,
        funcharts::scale_mfd(
          X_tun,
          center = mod_pca$center_fd,
          scale = mod_pca$scale_fd
        )
      )
    scores_tun <- apply(inprods, 1:2, sum)
    
    
    inprods <-
      funcharts:::get_pre_scores(
        mod_pca,
        1:K,
        funcharts::scale_mfd(X_OC, center = mod_pca$center_fd, scale = mod_pca$scale_fd)
      )
    scores_OC <- apply(inprods, 1:2, sum)
    
    
    
    Xmeans_new_IC <- scores_IC
    Xmeans_new_tun <- scores_tun
    Xmeans_new <- scores_OC
    
    mean <- apply(Xmeans_new_IC, 2, mean)
    S_dis <- cov(Xmeans_new_IC)
    
    F_mat <- diag(dim(Xmeans_new)[2])
    chart <-
      larewma(
        F_mat,
        S_dis,
        1,
        1 / alpha,
        iter = 1000,
        seed = 1,
        burnin = 10,
        only.mean = F ,
        horiz = 1000
      )
    out <- larewma.apply2(chart, Xmeans_new_tun, mean, plot = F)
    W_tun <- sapply(out, "[[", 2)
    limit <- quantile(W_tun, 1 - alpha)
    
    out <- larewma.apply2(chart, Xmeans_new, mean, plot = TRUE)
    W <- sapply(out, "[[", 2)
    
    
    ARL <- 1 / (length(which(W > limit)) / dim(Xmeans_new)[1])
    
    
    if (print) {
      print(paste0("Frac_out ", 1 / ARL))
      print(paste0("ARL ", ARL))
    }
    
    
    out <- list(
      W = W,
      CL = limit,
      ARL = ARL,
      Xmeans_new = Xmeans_new,
      Xmeans_new_IC = Xmeans_new_IC,
      frac_out = 1 / ARL
    )
    return(out)
  }



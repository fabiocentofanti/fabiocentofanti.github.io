


# In this script the AMFCC and MFCC_0.7 control charts are applied
# to the real data set and the panels of Figure 3 and 4 are saved as pdf files.

setwd(dirname(rstudioapi::getSourceEditorContext()$path))
# Libraries ---------------------------------------------------------------
library(fda)
library(funcharts)#Version 1.7.0
library(stringr)
library(Matrix)
library(Rcpp)
library(roahd)
source("functions.R")

# Load data ---------------------------------------------------------------
load(file = "data_cs.RData")

# Set parameters
grid <- seq(0, 1, l = 200)
ncores <- parallel::detectCores() - 2 # Number of cores to use, if 1 the parallelization is not used

# AMFCC -------------------------------------------------------------------
print("AMFCC")
mod_phase_I_AMFCC <- AMFCC_PhaseI(
  data_tra = X_tra,
  data_tun =
    X_tun,
  grid = grid,
  ncores = ncores
)

mod_phase_II_AMFCC <- AMFCC_PhaseII(data = X_II,
                                    mod_Phase_I = mod_phase_I_AMFCC,
                                    ncores = ncores)

# Panels 1 of Figure 3
{
  pdf("AMFCC_rc.pdf", width = 6, height = 3)
  plot(
    c(
      mod_phase_I_AMFCC$p_values_combined[[1]],
      mod_phase_II_AMFCC$p_values_combined[[1]]
    ),
    ylim = c(0, 20),
    cex.axis = 0.7,
    cex.lab = 0.8,
    ylab = expression(paste("T"["i,F"]^"2")),
    xlab = "Observation",
    mgp = c(1.5, 0.5, 0),
    pch = 16,
    cex = 0.3
  )
  lines(
    c(
      mod_phase_I_AMFCC$p_values_combined[[1]],
      mod_phase_II_AMFCC$p_values_combined[[1]]
    ),
    lwd = 0.6
  )
  abline(h = mod_phase_I_AMFCC$CL[1], lty = 2)
  segments(354, -1, 354, 100, lty = 3)
  dev.off()
}



# MFCC_0.7 ----------------------------------------------------------------

print("MFCC 0.7")
mod_Phase_I_MFCC <-
  Phase_I_MFCC(X_tra, X_tun, grid, fev = 0.7, ncores = ncores)
mod_phase_II_MFCC <-
  Phase_II_MFCC(data = X_II, mod_Phase_I_MFCC, ncores = ncores)
frac_MFCC_07 <- 1 / mod_phase_II_MFCC$frac_out
frac_var_sel_MFCC_07 <- 1 / mod_phase_II_MFCC$frac_out_vs_mean



# Panels 2 and 3 of Figure 3
{
  pdf("MFCC07_T2_rc.pdf", width = 6, height = 3)
  plot(
    c(mod_Phase_I_MFCC$T2, mod_phase_II_MFCC$T2),
    ylim = c(0, 70),
    cex.axis = 0.7,
    cex.lab = 0.8,
    ylab = expression(paste("T"["i"]^"2")),
    xlab = "Observation",
    mgp = c(1.5, 0.5, 0),
    pch = 16,
    cex = 0.3
  )
  lines(c(mod_Phase_I_MFCC$T2, mod_phase_II_MFCC$T2), lwd = 0.6)
  abline(h = mod_Phase_I_MFCC$CL_T2, lty = 2)
  segments(354, -1, 354, 100, lty = 3)
  dev.off()
  
  pdf("MFCC07_SPE_rc.pdf", width = 6, height = 3)
  plot(
    c(mod_Phase_I_MFCC$SPE, mod_phase_II_MFCC$SPE),
    ylim = c(0, 25),
    cex.axis = 0.7,
    cex.lab = 0.8,
    ylab = expression(paste("SPE"["i"]^"2")),
    xlab = "Observation",
    mgp = c(1.5, 0.5, 0),
    pch = 16,
    cex = 0.3
  )
  lines(c(mod_Phase_I_MFCC$SPE, mod_phase_II_MFCC$SPE), lwd = 0.6)
  abline(h = mod_Phase_I_MFCC$CL_SPE, lty = 2)
  segments(354, -1, 354, 100, lty = 3)
  dev.off()
}

# Figure 4
{
  plot(mod_phase_II_AMFCC, type = 'cont', ind_obs = 30)
  ggplot2::ggsave("contribution_plot.pdf",
                  width = 11,
                  height = 9.5)
}

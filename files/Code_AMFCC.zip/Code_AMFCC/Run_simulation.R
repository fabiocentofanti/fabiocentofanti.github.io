



# This script provides Fig. 2 of the main text of the manuscript and saves the
# panels of the figure as "cARL_D1_Shift_A.pdf", "cARL_D1_Shift_B.pdf",...,
# "cARL_D3_Shift_D.pdf".
# Producing all the panels of Fig. 2 requires a long computational time.
# If you want to produce just one panel, you can set the parameters "cost_cov"
# and "type_OC" to the desired values in the script.


# This code has been run on computing system with 2 sockets with 24 cores each,
# equipped with Intel(R) Xeon(R) Platinum 8160 processors
# running at a clock frequency of 2.10GHz, and 192 GB of RAM.
# The main information output by the system
# after running the script is reported as follows:

# CPU time :                                   14445438 sec.
# Max Memory :                                 54043 MB
# Average Memory :                             13607.33 MB
# Total Requested Memory :                     -
# Delta Memory :                               -
# Max Swap :                                   4 MB
# Max Processes :                              51
# Max Threads :                                53
# Run time :                                   685080 sec.
# Turnaround time :                            704304 sec.



setwd(dirname(rstudioapi::getSourceEditorContext()$path))
# Libraries ---------------------------------------------------------------
library(fda)
library(funcharts)#Version 1.7.0
library(stringr)
library(Matrix)
library(Rcpp)
source("functions.R")

# Setting simulation parameters -------------------------------------------
cov_type <- "Bessel"
type_OC_vec<-c("Shift A","Shift B","Shift C","Shift D")
ncores <- parallel::detectCores() - 2 # select the number of cores to use

iter_k <- 0
extra <- nchar('||100%')
width <- options()$width
step <- round((iter_k / (3 * 4 * 5 * 100)) * (width - extra))
text <- sprintf(
  '|%s%s|% 3s%%',
  strrep('=', step),
  strrep(' ', width - step - extra),
  round((iter_k / (3 * 4 * 5 * 100)) * 100, digits = 2)
)

cat(text)
cat('\n')
for (cost_cov in 1:3) {
  # To produce just one panel, set cost_cov to the desired value
  for (type_OC in 1:4) {
    # To produce just one panel, set type_OC to the desired value
    
    n_rep <- 100
    n_tra <- 1000
    n_tun <- 1000
    n_OC <- 500
    
    p <- 5
    type_vec_OC <- c("center", "end", "sin", "quadr")
    if (type_OC == 1)
      delta_vec <- c(0, 0.2, 0.4, 0.6, 0.8) * 0.35
    if (type_OC == 2)
      delta_vec <- c(0, 0.2, 0.4, 0.6, 0.8) * 0.45
    if (type_OC == 3)
      delta_vec <- c(0, 0.2, 0.4, 0.6, 0.8) * 0.25
    if (type_OC == 4)
      delta_vec <- c(0, 0.2, 0.4, 0.6, 0.8) * 0.3
    
    
    cARL_mat <- cARL_sd_mat <- matrix(rnorm(25), 5, 5)
    
    
    for (d in 1:5) {
      cARL_mat_ii <- matrix(0, n_rep, 5)
      for (n in 1:n_rep) {
        delta <- delta_vec[d]
        # Simulate data -----------------------------------------------------------
        train_IC_fun <- simulate_data(
          N = n_tra,
          p = p,
          cost_cov = cost_cov,
          cov_type = cov_type
        )
        train_IC_fun_tun <- simulate_data(
          N = n_tun,
          p = p,
          cost_cov = cost_cov,
          cov_type = cov_type
        )
        train_IC_mul <- simulate_data(
          N = n_tra + n_tun,
          p = p,
          cost_cov = cost_cov,
          cov_type = cov_type
        )
        train_OC <- simulate_data(
          N = n_OC,
          p = p,
          FOC = 0.5,
          delta = delta,
          type = type_vec_OC[type_OC],
          cost_cov = cost_cov,
          cov_type = cov_type
        )
        grid <- train_IC_fun$grid
        # AMFCC -------------------------------------------------------------------
        # print("AMFCC")
        mod_phase_I_AMFCC <- AMFCC_PhaseI(
          data_tra = train_IC_fun$data,
          data_tun =
            train_IC_fun_tun$data,
          grid,
          ncores = ncores
        )
        
        mod_phase_II_AMFCC <- AMFCC_PhaseII(
          data = train_OC$data,
          mod_Phase_I = mod_phase_I_AMFCC,
          ncores = ncores
        )
        cARL_AMFCC <- mod_phase_II_AMFCC$ARL_cont
        # MFCC 0.9 -------------------------------------------------------------------
        # print("MFCC 0.9")
        
        mod_Phase_I_MFCC <-
          Phase_I_MFCC(
            train_IC_fun$data,
            train_IC_fun_tun$data,
            grid,
            fev = 0.9,
            ncores = ncores
          )
        mod_phase_II_MFCC <-
          Phase_II_MFCC(data = train_OC$data,
                        mod_Phase_I_MFCC,
                        ncores = ncores)
        frac_var_sel_MFCC_09 <- mod_phase_II_MFCC$frac_out_vs_mean
        # MFCC 0.8 -------------------------------------------------------------------
        # print("MFCC 0.8")
        
        mod_Phase_I_MFCC <-
          Phase_I_MFCC(
            train_IC_fun$data,
            train_IC_fun_tun$data,
            grid,
            fev = 0.8,
            ncores = ncores
          )
        mod_phase_II_MFCC <-
          Phase_II_MFCC(data = train_OC$data,
                        mod_Phase_I_MFCC,
                        ncores = ncores)
        frac_var_sel_MFCC_08 <- mod_phase_II_MFCC$frac_out_vs_mean
        # MFCC 0.7 -------------------------------------------------------------------
        # print("MFCC 0.7")
        
        mod_Phase_I_MFCC <-
          Phase_I_MFCC(
            train_IC_fun$data,
            train_IC_fun_tun$data,
            grid,
            fev = 0.7,
            ncores = ncores
          )
        mod_phase_II_MFCC <-
          Phase_II_MFCC(data = train_OC$data,
                        mod_Phase_I_MFCC,
                        ncores = ncores)
        frac_var_sel_MFCC_07 <- mod_phase_II_MFCC$frac_out_vs_mean
        
        
        cARL_mat_ii[n, ] <- c(
          cARL_AMFCC,
          1 / c(
            frac_var_sel_MFCC_09,
            frac_var_sel_MFCC_08,
            frac_var_sel_MFCC_07
          )
        )
        iter_k <- iter_k + 1
        # progress(iter_k, 3*4*5*100)
        
        extra <- nchar('||100%')
        width <- options()$width
        step <- round((iter_k / (3 * 4 * 5 * 100)) * (width - extra))
        text <- sprintf(
          '|%s%s|% 3s%%',
          strrep('=', step),
          strrep(' ', width - step - extra),
          round((iter_k / (3 * 4 * 5 * 100)) * 100, digits = 2)
        )
        cat(text)
        cat('\n')
        
        
      }
      cARL_mat[d, ] <- apply(cARL_mat_ii, 2, mean)
      cARL_sd_mat[d, ] <- apply(cARL_mat_ii, 2, sd) / sqrt(n_rep)
    }
    colnames(cARL_mat) <- c("AMFCC_F", "AMFCC_T", "MFCC_09", "MFCC_08", "MFCC_07")
    
    ## Print results
    print(cARL_mat)
    
    ## Plot results
    plot_function(
      cARL_mat,
      cARL_sd_mat,
      type = "cARL",
      cost_cov = cost_cov,
      Type_OC = type_OC_vec[type_OC]
    )
  }
}

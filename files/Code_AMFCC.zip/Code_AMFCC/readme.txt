In the file Run_casestudy.R, the AMFCC and MFCC_0.7 control charts are applied to the real data set and all the panels of Figure 3 are produced and saved as .pdf files. Figure 4 is produced as well.

The file Run_simulation.R provides Figure 2 of the main text of the manuscript and saves the panels of the figure as "cARL_D1_Shift_A.pdf", "cARL_D1_Shift_B.pdf",..., "cARL_D3_Shift_D.pdf". 

The file functions.R contains the functions to simulate data and implement the competing methods used in Run_casestudy.R and Run_simulation.R. 

The file data_cs.RData contains the real data.

The AMFCC is implemented in the funcharts R package (https://cran.r-project.org/web/packages/funcharts/index.html), through the AMFCC_PhaseI() and AMFCC_PhaseII() functions.


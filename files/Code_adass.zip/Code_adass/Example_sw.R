

##Swedish Mortality Dataset 

##Download the data_sw.RData file from https://github.com/unina-sfere/Data-for-AdaSS-article or analogously use
## download.file(url="https://github.com/unina-sfere/Data-for-AdaSS-article/archive/main.zip",destfile = "data.zip")
## and put it in your working directory

library(adass)
source(file="Start.R")
load(file="data_sw.RData")
n_obs<-length(X_fd$fdnames$reps)
domain=c(0,1)
tra_obs<-1:n_obs
# Basis s and t
n_basis_s<-50
n_basis_t<-50
breaks_s<-seq(0,1,length.out = (n_basis_s-2))
breaks_t<-seq(0,1,length.out = (n_basis_t-2))
basis_s <- create.bspline.basis(domain,breaks=breaks_s,norder = 4)
basis_t <- create.bspline.basis(domain,breaks=breaks_t,norder = 4)

# Training and Test set
X_fd_tra_nc<-X_fd[tra_obs]
Y_fd_tra_nc<-Y_fd[tra_obs]
X_fd_tra<-center.fd(X_fd_tra_nc)
Y_fd_tra<-center.fd(Y_fd_tra_nc)


# Smooth regression (fda) --------------------------------------------------------
mod_smooth_cv<-fr.usc.cv(Y_fd_tra,X_fd_tra,basis_s,basis_t,K=10,lambdas_s = 10^seq(-12,-8),lambdas_t = 10^seq(-12,-8))
mod_smooth<-fr.usc(Y_fd_tra,X_fd_tra,basis_s,basis_t,lambdas_s=mod_smooth_cv$lambda_s_opt,lambdas_t =mod_smooth_cv$lambda_t_opt)

# TRU regression ---------------------------------------------------------
mod_tru_cv<-fr.tru.cv(Y_fd_tra,X_fd_tra,K=10,nbasiss = seq(5,25,by=3),nbasist = seq(5,25,by=3))
mod_tru<-fr.tru(Y_fd_tra,X_fd_tra,nbasiss = mod_tru_cv$par_opt[1],mod_tru_cv$par_opt[1])

# PCA Regression ----------------------------------------------------------
mod_PCA_cv<-fr.PCA.cv(Y_fd_tra,X_fd_tra,K=10)
mod_PCA<-fr.PCA(Y_fd_tra,X_fd_tra,ncomps = mod_PCA_cv$n_comp_opt_x,ncompt = mod_PCA_cv$n_comp_opt_y)

# Ridge regression --------------------------------------------------------
mod_ridge_cv<-fr.ridge.cv(Y_fd_tra,X_fd_tra,basis_s,basis_t,K = 10,alpha_seq = -4:4)
mod_ridge<-fr.ridge(Y_fd_tra,X_fd_tra,basis_s,basis_t,10^mod_ridge_cv$par_opt)

# Sigcomp -----------------------------------------------------------------
mod_sigcomp<-fr.sigcom(Y_fd_tra,X_fd_tra,basis_s,basis_t,K = 10)

# Smooth adaptive ---------------------------------------------------------
grid_s<-seq(0,1,length.out = 50)
grid_t<-seq(0,1,length.out = 50)
beta_der_eval_s<-eval.bifd(grid_s,grid_t,mod_smooth$Beta_hat_fd,sLfdobj = 2)
beta_der_eval_t<-eval.bifd(grid_s,grid_t,mod_smooth$Beta_hat_fd,tLfdobj = 2) 
mod_adass_eaass<-adass.fr_eaass(Y_fd,X_fd,basis_s,basis_t,
                                     beta_ders=beta_der_eval_s, beta_dert=beta_der_eval_t,
                                     rand_search_par=list(c(-8,4),c(-8,4),c(0,0.1),c(0,4),c(0,0.1),c(0,4)),
                                     grid_eval_ders=grid_s, grid_eval_dert=grid_t,
                                     popul_size = 24,ncores=cores,iter_num=15)
mod_adass<-adass.fr(Y_fd, X_fd, basis_s = basis_s, basis_t = basis_t,
                         tun_par=mod_adass_vero_eaass$tun_par_opt,beta_ders = beta_der_eval_s,
                         beta_dert = beta_der_eval_t,grid_eval_ders=grid_s,grid_eval_dert=grid_t )

plot(mod_adass)


##Single run of the simulation study for Mexican hat function with sample size n=500.

library(adass)
source("Start.R")
case<-"Scenario HAT"
n_obs_tra<-500
n_obs_test<-4000
n_obs<-n_obs_tra+n_obs_test
data<-simulate_data(case,n_obs=n_obs)
X_fd <- data$X_fd
Y_fd <- data$Y_fd
Beta_vero_fd<-data$Beta_vero_fd

# Basis s and t
domain<-c(0,1)
length_grid<-500
norder<-4
grid<-seq(0,1,length.out = length_grid)

n_basis_s<-min(50,length_grid)
n_basis_t<-min(50,length_grid)
breaks_s<-seq(0,1,length.out = (n_basis_s-2))
breaks_t<-seq(0,1,length.out = (n_basis_t-2))
basis_s <- create.bspline.basis(domain,breaks=breaks_s,norder = 4)
basis_t <- create.bspline.basis(domain,breaks=breaks_t,norder = 4)

# Training and Test set
X_fd_tra_nc<-X_fd[1:n_obs_tra]
Y_fd_tra_nc<-Y_fd[1:n_obs_tra]
X_fd_tra<-center.fd(X_fd_tra_nc)
Y_fd_tra<-center.fd(Y_fd_tra_nc)
X_fd_test<-X_fd[(n_obs_tra+1):(n_obs)]-mean_rep(X_fd_tra_nc,n_obs_test)
Y_fd_test<-Y_fd[(n_obs_tra+1):(n_obs)]-mean_rep(Y_fd_tra_nc,n_obs_test)
X_coef_tra<-t(X_fd_tra$coefs)
Y_coef_tra<-t(Y_fd_tra$coefs)
X_coef_test<-t(X_fd_test$coefs)
Y_coef_test<-t(Y_fd_test$coefs)   

cores=detectCores()
# SMOOTH Regression --------------------------------------------------------
mod_smooth_cv<-fr.usc.cv(Y_fd_tra,X_fd_tra,basis_s,basis_t,K=10,lambdas_s = 10^seq(-8,3),lambdas_t = 10^seq(-8,3),cores=cores)
mod_smooth<-fr.usc(Y_fd_tra,X_fd_tra,basis_s,basis_t,lambdas_s=mod_smooth_cv$lambda_s_opt,lambdas_t =mod_smooth_cv$lambda_t_opt)
ISE_smooth<-get_ISE(mod_smooth$Beta_hat_fd,Beta_vero_fd,case)
PMSE_smooth<-get_PMSE(Y_fd_test,X_fd_test,mod_smooth$Beta_hat_fd)

# TRU Regression ---------------------------------------------------------
mod_tru_cv<-fr.tru.cv(Y_fd_tra,X_fd_tra,K=10,nbasiss = seq(5,25,by=3),nbasist = seq(5,25,by=3),cores=cores)
mod_tru<-fr.tru(Y_fd_tra,X_fd_tra,nbasiss = mod_tru_cv$par_opt[1],mod_tru_cv$par_opt[1])
ISE_tru<-get_ISE(mod_tru$Beta_hat_fd,Beta_vero_fd,case)
PMSE_tru<-get_PMSE(Y_fd_test,X_fd_test,mod_tru$Beta_hat_fd)
# PCA Regression ----------------------------------------------------------
mod_PCA_cv<-fr.PCA.cv(Y_fd_tra,X_fd_tra,K=10,cores=cores)
mod_PCA<-fr.PCA(Y_fd_tra,X_fd_tra,ncomps = mod_PCA_cv$n_comp_opt_x,ncompt = mod_PCA_cv$n_comp_opt_y)
ISE_PCA<-get_ISE(mod_PCA$Beta_hat_fd,Beta_vero_fd,case)
PMSE_PCA<-get_PMSE(Y_fd_test,X_fd_test,mod_PCA$Beta_hat_fd)

# RIDGE Regression --------------------------------------------------------
mod_ridge_cv<-fr.ridge.cv(Y_fd_tra,X_fd_tra,basis_s,basis_t,K = 10,alpha_seq = -4:4,cores=cores)
mod_ridge<-fr.ridge(Y_fd_tra,X_fd_tra,basis_s,basis_t,10^mod_ridge_cv$par_opt)
ISE_ridge<-get_ISE(mod_ridge$Beta_hat_fd,Beta_vero_fd,case)
PMSE_ridge<-get_PMSE(Y_fd_test,X_fd_test,mod_ridge$Beta_hat_fd)

# SIGCOMP Regression -----------------------------------------------------------------
mod_sigcomp<-fr.sigcom(Y_fd_tra,X_fd_tra,basis_s,basis_t,K = 10)
ISE_sigcomp<-get_ISE(mod_sigcomp$Beta_hat_fd,Beta_vero_fd,case)
PMSE_sigcomp<-get_PMSE(Y_fd_test,X_fd_test,mod_sigcomp$Beta_hat_fd)

# AdaSS Regression ---------------------------------------------------------
grid_s<-seq(0,1,length.out = 50)
grid_t<-seq(0,1,length.out = 50)
beta_der_eval_s<-eval.bifd(grid_s,grid_t,mod_smooth$Beta_hat_fd,sLfdobj = 2)
beta_der_eval_t<-eval.bifd(grid_s,grid_t,mod_smooth$Beta_hat_fd,tLfdobj = 2)
mod_adass_eaass<-adass.fr_eaass(Y_fd,X_fd,basis_s,basis_t,
                         beta_ders=beta_der_eval_s, beta_dert=beta_der_eval_t,
                         rand_search_par=list(c(-8,4),c(-8,4),c(0,0.1),c(0,4),c(0,0.1),c(0,4)),
                         grid_eval_ders=grid_s, grid_eval_dert=grid_t,
                         popul_size = 24,ncores=cores,iter_num=15)

mod_adass <-adass.fr(Y_fd, X_fd, basis_s = basis_s, basis_t = basis_t,
                   tun_par=mod_adass_eaass$tun_par_opt,beta_ders = beta_der_eval_s,
                   beta_dert = beta_der_eval_t,grid_eval_ders=grid_s,grid_eval_dert=grid_t )

ISE_adass<-get_ISE(mod_adass$Beta_hat_fd,Beta_vero_fd,case)
PMSE_adass<-get_PMSE(Y_fd_test,X_fd_test,mod_adass$Beta_hat_fd)

# AdaSStrue Regression ---------------------------------------------------------
grid_s<-seq(0,1,length.out = 50)
grid_t<-seq(0,1,length.out = 50)
beta_der_eval_s<-eval.bifd(grid_s,grid_t,Beta_vero_fd,sLfdobj = 2)
beta_der_eval_t<-eval.bifd(grid_s,grid_t,Beta_vero_fd,tLfdobj = 2) 
mod_adass_vero_eaass<-adass.fr_eaass(Y_fd,X_fd,basis_s,basis_t,
                                                beta_ders=beta_der_eval_s, beta_dert=beta_der_eval_t,
                                                rand_search_par=list(c(-8,4),c(-8,4),c(0,0.1),c(0,4),c(0,0.1),c(0,4)),
                                                grid_eval_ders=grid_s, grid_eval_dert=grid_t,
                                                popul_size = 24,ncores=cores,iter_num=15)
mod_adass_vero<-adass.fr(Y_fd, X_fd, basis_s = basis_s, basis_t = basis_t,
                         tun_par=mod_adass_vero_eaass$tun_par_opt,beta_ders = beta_der_eval_s,
                         beta_dert = beta_der_eval_t,grid_eval_ders=grid_s,grid_eval_dert=grid_t )

ISE_adass_vero<-get_ISE(mod_adass_vero$Beta_hat_fd,Beta_vero_fd,case)
PMSE_adass_vero<-get_PMSE(Y_fd_test,X_fd_test,mod_adass_vero$Beta_hat_fd)



a= data.frame(matrix(unlist(ISE_tru),ncol=2,byrow = T))
names(a)[2]="ISE_tru"
ISE=a[2]
a= data.frame(matrix(unlist(ISE_smooth),ncol=2,byrow = T))
names(a)[2]="ISE_smooth"
ISE=cbind(ISE,a[2])
a= data.frame(matrix(unlist(ISE_PCA),ncol=2,byrow = T))
names(a)[2]="ISE_PCA"
ISE=cbind(ISE,a[2])
a= data.frame(matrix(unlist(ISE_ridge),ncol=2,byrow = T))
names(a)[2]="ISE_ridge"
ISE=cbind(ISE,a[2])
a= data.frame(matrix(unlist(ISE_sigcomp),ncol=2,byrow = T))
names(a)[2]="ISE_SigCom"
ISE=cbind(ISE,a[2])
a= data.frame(matrix(unlist(ISE_adass),ncol=2,byrow = T))
names(a)[2]="ISE_adass"
ISE=cbind(ISE,a[2])
a= data.frame(matrix(unlist(ISE_adass_vero),ncol=2,byrow = T))
names(a)[2]="ISE_adass_vero"
ISE=cbind(ISE,a[2])

PMSE=data.frame(PMSE_tru,PMSE_smooth,PMSE_PCA,PMSE_ridge,PMSE_sigcomp,PMSE_adass,PMSE_adass_vero)


# Library -----------------------------------------------------------------

library(fda) 
library(parallel) 
library(fda.usc)
library(fdapace)
library(FRegSigCom)

# My sources
source("functions.R",encoding="UTF-8")


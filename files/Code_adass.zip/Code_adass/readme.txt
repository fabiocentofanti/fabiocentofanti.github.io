The file Run_CaseHAT500.R provides the ISE and PMSE values for a single run of the simulation study for Mexican hat function with sample size n=500.
The file Example_sw.R contains the code to reproduce the analysis for the Swedish mortality dataset.
The file Example_gr.R contains the code to reproduce the analysis for the ship CO2 emission dataset.
The file functions_fd.R contains the main functions.
The file Start.R loads the libraries and sources the files needed for the computation. 


FMRCC_phaseI <- function(Y_training_mfd,X_training_mfd,Y_tuning_mfd,X_tuning_mfd,FVEy,FVEx,studentized = T,alpha = 0.01 , intercept = T , SPE = F ,
                         init_met = 'kmeans', num_iterations = 1 , max_group = 3){
  
  #/// FPCA PHASE ///#
  ## FPCA Training ##
  if(is.mfd(X_training_mfd)){
    
    fpca_results <- my_FPCA(X_mfd = X_training_mfd,Y_mfd = Y_training_mfd, FVEy = FVEy, length_grid = 500, FVEx = FVEx)
    score_x <- fpca_results$pcax$pcscores[,1:fpca_results$ncomponents_x]
    score_y <-  fpca_results$pcay$pcscores[,1:fpca_results$ncomponents_y]
    
  }else{
    fpca_results <- my_FPCA(Y_mfd = Y_training_mfd,FVEy = FVEy, length_grid = 500)
    score_x <- as.matrix(X_training_mfd)
    score_y <-  fpca_results$pcay$pcscores[,1:fpca_results$ncomponents_y]
  }
  
  
  if(SPE){
    y_hat_z <- get_fun_from_scores(score_y, fpca_results$pcay$harmonics[1:fpca_results$ncomponents_y])
    y_hat <- descale_mfd(y_hat_z, center = fpca_results$pcay$center_fd, 
                         scale = fpca_results$pcay$scale_fd)
    res_fd <- minus.fd(Y_training_mfd, y_hat)
    res_mfd <- mfd(res_fd$coefs, res_fd$basis, res_fd$fdnames, 
                  B = res_fd$basis$B)
    cont_spe <- inprod_mfd_diag(res_mfd)
    spe <- rowSums(cont_spe)
  
    score_y <- cbind(score_y,log(spe))
  }
  
 #/// MODELS ESTIMATION PHASE ///#
  if(init_met == 'kmeans') num_iterations <- 1
  ## FMR Model estimation ##
  estimate <- estimate_mixture(y = score_y , x = score_x , num_iterations = num_iterations , max_group = max_group ,mode = 'regression',intercept = intercept , init_met = init_met)
  best_model <- estimate$best_model
  num_groups <- length(best_model$prop)  
 
   #/// PHASE I ///#
  if(studentized){
    ## Phase I FMRCC on Studentized Residuals ##
    phaseI <- phaseI_stud(Y_tuning_mfd = Y_tuning_mfd , X_tuning_mfd = X_tuning_mfd , fpca_results = fpca_results , model_estimate = estimate , alpha = alpha , intercept = intercept , SPE = SPE)
    # plot_cc(df = stud_phaseI$df , limits = stud_phaseI$lim_stud)  
  }else{
    ## Phase I FMRCC on Residuals ##
    phaseI <- phaseI_residuals(Y_tuning_mfd = Y_tuning_mfd , X_tuning_mfd = X_tuning_mfd , fpca_results = fpca_results , model = best_model , alpha = alpha, intercept = intercept, SPE = SPE)
    # plot_cc(df = res_phaseI$df , limits = res_phaseI$lim_residuals)
  }
  
  plt <- NULL
  mod <- estimate
  a <- c(as.matrix(mod$BIC))
  a[which(a == 1000000)] <- NA
  b <- rep(c('VVV','EEE','VII','EII'),max_group)
  c <- rep(1:max_group,each = 4)
  BIC <- data.frame(BIC = a , method = b , n_clust = c)
  
  plt <- ggplot(BIC , aes(x = n_clust, y = BIC ,col = method, shape = method))+
    geom_point(size = 3)+
    scale_shape_manual(values=c(16,15,17,18))+
    geom_line(size = 1)+
    theme_bw()
    
  
  
  
  return(list(model = best_model,
              phaseI = phaseI,
              fpca = fpca_results,
              estimate = estimate,
              BIC_plt = plt))
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

FMRCC_phaseII <- function(Y_testing_mfd,X_testing_mfd,phaseI,studentized , intercept = T , SPE = F){
  #/// PHASE II  ///#
  if(studentized){
    ## Phase II FMRCC on Stundentized Residuals ##
    phaseII <- phaseII_stud(Y_testing_mfd = Y_testing_mfd , X_testing_mfd = X_testing_mfd , fpca_results = phaseI$fpca , model_estimate = phaseI$estimate ,limits = phaseI$phaseI$lim_stud , intercept = intercept , SPE = SPE)
    # plot_cc(df = stud_phaseII$df , limits = stud_phaseI$lim_stud)
    ARL <- phaseII$ARL
  }else{
    ## Phase II FMRCC on Residuals ##
    phaseII <- phaseII_residuals(Y_testing_mfd = Y_testing_mfd , X_testing_mfd = X_testing_mfd , fpca_results = phaseI$fpca , model = phaseI$model ,limits = phaseI$phaseI$lim_residuals, intercept = intercept , SPE = SPE)
    # plot_cc(df = res_phaseII$df , limits = res_phaseI$lim_residuals)
    ARL <- phaseII$ARL
  }
  return(list(ARL=ARL,
              phaseII = phaseII))
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

FRCC <- function(Y_training_mfd,X_training_mfd,Y_tuning_mfd,X_tuning_mfd,Y_testing_mfd,X_testing_mfd,FVEy,FVEx,FVEz,studentized = T,alpha = 0.01,SPE=T){
  
  mfdobj_y <- Y_training_mfd
  mfdobj_x <- X_training_mfd
  mfdobj_y_tuning <- Y_tuning_mfd
  mfdobj_x_tuning <- X_tuning_mfd
  mfdobj_y_new <- Y_testing_mfd
  mfdobj_x_new <- X_testing_mfd
  
  alpha_corr <- 1 - ( 1 - alpha )^0.5
  
  if(studentized){
    
    ## Studentized Residuals
    model_fof <- fof_pc(mfdobj_y = mfdobj_y , mfdobj_x = mfdobj_x, tot_variance_explained_x = FVEx , tot_variance_explained_y = FVEy , tot_variance_explained_res = FVEz, type_residuals = 'studentized')
    
    if(SPE){
      frcc_df <- regr_cc_fof(object = model_fof , mfdobj_y_tuning = mfdobj_y_tuning , mfdobj_x_tuning = mfdobj_x_tuning , mfdobj_y_new = mfdobj_y_new , mfdobj_x_new = mfdobj_x_new , alpha = list(T2 = alpha_corr,spe = alpha_corr))
      alpha <- sum(frcc_df$T2 > frcc_df$T2_lim | frcc_df$spe > frcc_df$spe_lim)/length(frcc_df$id)
      ARL_FRCC_stud <- 1 / (1 - ( 1 - alpha ))  
    }else{
      frcc_df <- regr_cc_fof(object = model_fof , mfdobj_y_tuning = mfdobj_y_tuning , mfdobj_x_tuning = mfdobj_x_tuning , mfdobj_y_new = mfdobj_y_new , mfdobj_x_new = mfdobj_x_new , alpha = list(T2 = alpha,spe = alpha_corr))
      alpha_tsq <- sum(frcc_df$T2 > frcc_df$T2_lim)/length(frcc_df$id)
      ARL_FRCC_stud <- 1 /alpha_tsq   
    }
    
    return(list(frcc_df=frcc_df,
                ARL = ARL_FRCC_stud,
                model_fof = model_fof))
  }else{
    ## Residuals
    model_fof <- fof_pc(mfdobj_y = mfdobj_y , mfdobj_x = mfdobj_x, tot_variance_explained_x = FVEx , tot_variance_explained_y = FVEy , tot_variance_explained_res = FVEz, type_residuals = 'standard')
    
    if(SPE){
      frcc_df <- regr_cc_fof(object = model_fof , mfdobj_y_tuning = mfdobj_y_tuning , mfdobj_x_tuning = mfdobj_x_tuning , mfdobj_y_new = mfdobj_y_new , mfdobj_x_new = mfdobj_x_new , alpha = list(T2 = alpha_corr,spe = alpha_corr))
      alpha <- sum(frcc_df$T2 > frcc_df$T2_lim | frcc_df$spe > frcc_df$spe_lim)/length(frcc_df$id)
      ARL_FRCC_res <- 1 / (1 - ( 1 - alpha ))  
    }else{
      frcc_df <- regr_cc_fof(object = model_fof , mfdobj_y_tuning = mfdobj_y_tuning , mfdobj_x_tuning = mfdobj_x_tuning , mfdobj_y_new = mfdobj_y_new , mfdobj_x_new = mfdobj_x_new , alpha = list(T2 = alpha,spe = alpha_corr))
      alpha_tsq <- sum(frcc_df$T2 > frcc_df$T2_lim)/length(frcc_df$id)
      ARL_FRCC_res <- 1 /alpha_tsq   
    }

   return(list(frcc_df=frcc_df,
               ARL = ARL_FRCC_res,
               model_fof = model_fof)) 
  }
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

FCC <- function(Y_training_mfd,Y_tuning_mfd,Y_testing_mfd,FVEy,alpha = 0.01,SPE=T , scale = T){
 
  mfdobj_y <- Y_training_mfd
  mfdobj_y_tuning <- Y_tuning_mfd
  mfdobj_y_new <- Y_testing_mfd
  
  alpha_corr <- 1 - ( 1 - alpha )^0.5
  
  ## FCC ##
  pca <- pca_mfd(mfdobj = mfdobj_y ,scale = scale)
  if(SPE){
    fcc_df <- control_charts_pca(pca = pca , tuning_data =mfdobj_y_tuning , newdata = mfdobj_y_new , tot_variance_explained = FVEy , alpha = list(T2 = alpha_corr,spe = alpha_corr))
    alpha <- sum(fcc_df$T2 > fcc_df$T2_lim | fcc_df$spe > fcc_df$spe_lim)/length(fcc_df$id)
    ARL_FCC <- 1 / (1 - ( 1 - alpha))
    
  }else{
    fcc_df <- control_charts_pca(pca = pca , tuning_data =mfdobj_y_tuning , newdata = mfdobj_y_new , tot_variance_explained = FVEy , alpha = list(T2 = alpha,spe = alpha_corr))
    alpha_tsq <- sum(fcc_df$T2 > fcc_df$T2_lim)/length(fcc_df$id)
    ARL_FCC <- 1 / alpha_tsq
  }
  
  return(list(fcc_df=fcc_df,
              ARL = ARL_FCC,
              pca = pca)) 
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

Clust <- function(Y_training_mfd,Y_tuning_mfd,FVEy,alpha = 0.01 , Y_testing_mfd , SPE =T , init_met = 'kmeans',num_iterations = 1 ,
                  max_group = 3, select_k = NULL){
  
  #/// FPCA PHASE ///#
  ## FPCA Training ##
  fpca_results <- my_FPCA(Y_mfd = Y_training_mfd,FVEy = FVEy, length_grid = 500)
  score_y <-  fpca_results$pcay$pcscores[,1:fpca_results$ncomponents_y]
  score_y <- as.matrix(score_y)
  #/// MODEL ESTIMATION PHASE ///#
  ## Model estimation ##
  if(init_met == 'kmeans') num_iterations <- 1
  if(is.null(select_k)){
    estimate <- estimate_mixture(y = score_y , num_iterations =num_iterations  , max_group = max_group ,mode = 'clustering',init_met = init_met)
  }else{
    estimate <- estimate_mixture(y = score_y , num_iterations =num_iterations  ,selectK = select_k ,mode = 'clustering',init_met = init_met)
  }
  best_model_clust <- estimate$best_model
  num_groups_clust <- length(best_model_clust$prop)  

  plt <- NULL
  mod <- estimate
  a <- c(as.matrix(mod$BIC))
  a[which(a == 1000000)] <- NA
  b <- rep(c('VVV','EEE','VII','EII'),max_group)
  c <- rep(1:max_group,each = 4)
  BIC <- data.frame(BIC = a , method = b , n_clust = c)
  
  plt <- ggplot(BIC , aes(x = n_clust, y = BIC ,col = method, shape = method))+
    geom_point(size = 3)+
    scale_shape_manual(values=c(16,15,17,18))+
    geom_line(size = 1)+
    theme_bw()
  
  
  # Standardization and score calculation tuning
  y_tuning_std_mfd <- scale_mfd(mfdobj = Y_tuning_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  y_score_new <- get_scores(pca = fpca_results$pcay , components = 1:fpca_results$ncomponents_y , newdata_scaled = y_tuning_std_mfd)
  
  
  # Standardization and score calculation testing
  y_testing_std_mfd <- scale_mfd(mfdobj = Y_testing_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  y_score_test <- get_scores(pca = fpca_results$pcay , components = 1:fpca_results$ncomponents_y , newdata_scaled = y_testing_std_mfd)
  
  
  membership_training <- predict_mixture(y = score_y, x = matrix(1 , nrow = nrow(score_y)) ,hard = T , model = best_model_clust)$membership
  membership_tuning <- predict_mixture(y = y_score_new, x = matrix(1 , nrow = nrow(y_score_new)) ,hard = T , model = best_model_clust)$membership
  membership_testing <- predict_mixture(y = y_score_test, x = matrix(1 , nrow = nrow(y_score_test)) ,hard = T , model = best_model_clust)$membership
  
  results <- vector(mode = 'list' , length = num_groups_clust)
  
  n_obs_training <- colsums(membership_training)
  n_obs_tuning <- colsums(membership_tuning)
  n_obs_testing <- colsums(membership_testing)
  
  for(kk in 1:num_groups_clust){
    
    if(sum(membership_testing[,kk]!=0)==0) next
    results[[kk]] <- FCC(Y_training_mfd = Y_training_mfd[which(membership_training[,kk]==1)],
        Y_tuning_mfd = Y_tuning_mfd[which(membership_tuning[,kk]==1)],
        Y_testing_mfd = Y_testing_mfd[which(membership_testing[,kk]==1)],
        FVEy = FVEy,alpha = alpha,SPE = SPE)
    
  }
  
  # ARL
  OC <- 0
  
  if(SPE){
    for(kk in 1:num_groups_clust){
      OC <- OC + sum(results[[kk]]$fcc_df$T2 > results[[kk]]$fcc_df$T2_lim | results[[kk]]$fcc_df$spe > results[[kk]]$fcc_df$spe_lim )
    }
  }else{
    for(kk in 1:num_groups_clust){
      OC <- OC + sum(results[[kk]]$fcc_df$T2 > results[[kk]]$fcc_df$T2_lim)
    }
  }
  
  alpha <- OC/nrow(y_score_test)
  
  
  ARL <- 1 / (1 - ( 1 - alpha))
  
  return(list(ARL = ARL,
              Charts = results,
              model = best_model_clust,
              nobs = list(n_obs_testing = n_obs_testing,
                          n_obs_tuning = n_obs_tuning,
                          n_obs_training = n_obs_training),
              BIC_plt = plt))
}


#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

FRCC_fos <- function(Y_training_mfd , X_training , Y_tuning_mfd , X_tuning , Y_testing_mfd , X_testing , FVEy=0.90 , FVE_res = 0.90 , type_residuals = 'standard' , SPE = T , alpha = 0.01){

    ## FPCA Training ##
  fpca_results <- my_FPCA(Y_mfd = Y_training_mfd,FVEy = FVEy, length_grid = 500)
  score_y <-  fpca_results$pcay$pcscores[,1:fpca_results$ncomponents_y]
  y_training_mfd_scaled <- scale_mfd(mfdobj = Y_training_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  
  y_tuning_scaled_mfd <- scale_mfd(mfdobj = Y_tuning_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  y_tuning <- get_scores(pca = fpca_results$pcay , components = 1:fpca_results$ncomponents_y, newdata_scaled = y_tuning_scaled_mfd)
  y_testing_scaled_mfd <- scale_mfd(mfdobj = Y_testing_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  y_testing <- get_scores(pca = fpca_results$pcay , components = 1:fpca_results$ncomponents_y, newdata_scaled = y_testing_scaled_mfd)

  mod <- lm(score_y ~ as.matrix(X_training))
  y_pred_train <- mod$fitted.values
  y_pred_scaled_mfd <- get_fun_from_scores(scores = y_pred_train , harmonics = fpca_results$pcay$harmonics[1:fpca_results$ncomponents_y])
  y_pred_mfd <- descale_mfd(scaled_mfd = y_pred_scaled_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  res_mfd <- scale_mfd(mfdobj = y_training_mfd_scaled,center = y_pred_scaled_mfd , scale = F)
  res_original_mfd <- scale_mfd(mfdobj = Y_training_mfd,center = y_pred_mfd , scale = F)
  
  
  y_pred_tuning <- as.matrix(cbind(1,X_tuning))%*%mod$coefficients
  y_pred_scaled_tuning_mfd <- get_fun_from_scores(scores = y_pred_tuning , harmonics = fpca_results$pcay$harmonics[1:fpca_results$ncomponents_y])
  y_pred_scaled_tuning_mfd$fdnames[[2]] <- as.character(c(1:nrow(X_tuning)))
  y_pred_tuning_mfd <- descale_mfd(scaled_mfd = y_pred_scaled_tuning_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  attr(y_pred_tuning_mfd$coefs,"dimnames")[[1]] <- attr(y_pred_scaled_tuning_mfd$coefs,"dimnames")[[1]]
  attr(y_pred_tuning_mfd$coefs,"dimnames")[[3]] <- attr(y_pred_scaled_tuning_mfd$coefs,"dimnames")[[3]]
  attr(y_pred_scaled_tuning_mfd$coefs,"dimnames")[[2]] <- attr(y_pred_tuning_mfd$coefs,"dimnames")[[2]]
  res_tuning_mfd <- scale_mfd(mfdobj = y_tuning_scaled_mfd ,center =  y_pred_scaled_tuning_mfd , scale = F)
  res_tuning_original_mfd <- scale_mfd(mfdobj = Y_tuning_mfd ,center =  y_pred_tuning_mfd , scale = F)
  
  
  y_pred_test <- as.matrix(cbind(1,X_testing))%*%mod$coefficients
  y_pred_scaled_test_mfd <- get_fun_from_scores(scores = y_pred_test , harmonics = fpca_results$pcay$harmonics[1:fpca_results$ncomponents_y])
  y_pred_scaled_test_mfd$fdnames[[2]] <- as.character(c(1:nrow(X_testing)))
  y_pred_test_mfd <- descale_mfd(scaled_mfd = y_pred_scaled_test_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  attr(y_pred_test_mfd$coefs,"dimnames")[[1]] <- attr(y_pred_scaled_test_mfd$coefs,"dimnames")[[1]]
  attr(y_pred_test_mfd$coefs,"dimnames")[[3]] <- attr(y_pred_scaled_test_mfd$coefs,"dimnames")[[3]]
  attr(y_pred_scaled_test_mfd$coefs,"dimnames")[[2]] <- attr(y_pred_test_mfd$coefs,"dimnames")[[2]]
  res_test_mfd <- scale_mfd(mfdobj = y_testing_scaled_mfd ,center =  y_pred_scaled_test_mfd , scale = F)
  res_testing_original_mfd <- scale_mfd(mfdobj = Y_testing_mfd ,center =  y_pred_test_mfd , scale = F)
  
  
  
  if(type_residuals=='standard'){
    FRCC_res <- FCC(Y_training_mfd = res_mfd , Y_tuning_mfd = res_tuning_mfd , Y_testing_mfd = res_test_mfd , FVEy = FVE_res , alpha = alpha , SPE = SPE , scale = F)
    ARL_FRCC <- FRCC_res$ARL
    frcc_df <- FRCC_res$fcc_df
    res_pca <- FRCC_res$pca
  }
  
  if(type_residuals=='studentized'){
    basis_y <- Y_training_mfd$basis
    nbasis_y <- basis_y$nbasis
    y_pca <- fpca_results$pcay
    ncomponents_y <- fpca_results$ncomponents_y
    get_studentized_residuals <- NULL
    res_original <- res_original_mfd
    domain <- res_original$basis$rangeval
    bs <- create.bspline.basis(domain, 100)
    bs$B <- inprod.bspline(fd(diag(1, bs$nbasis), bs))
    sd_res <- sd.fd(res_original)
    var_res <- times.fd(sd_res, sd_res, bs)
    sigma_M <- crossprod(mod$residuals)/nrow(mod$residuals)
    gain <- hatvalues(mod)
    xseq <- seq(bs$rangeval[1], bs$rangeval[2], length.out = 1000)
    y_pca_eval <- eval.fd(xseq, y_pca$harmonics)
    y_pca_coef <- project.basis(y_pca_eval, xseq, bs)
    G <- as.numeric(y_pca_coef[, seq_len(ncomponents_y), 
                               1])
    G <- matrix(G, ncol = ncomponents_y)
    psp_coef <- G %*% sigma_M %*% t(G)
    bifd_obj <- bifd(psp_coef, sbasisobj = bs, tbasisobj = bs)
    psp_eval <- fda::evaldiag.bifd(xseq, bifd_obj)
    psp_coef <- as.numeric(project.basis(psp_eval, xseq, 
                                         bs))
    get_studentized_residuals <- function(gain, pred_error) {
      omega_coef <- outer(psp_coef, gain)
      cov_hat_coef <- omega_coef + var_res$coefs[, 1]
      cov_hat_sqrt_inv <- fd(cov_hat_coef, bs)^(-0.5)
      studentized <- times.fd(fd(pred_error$coefs[, , 
                                                  1], basis_y), fd(cov_hat_sqrt_inv$coefs, bs), 
                              basisobj = bs)
      mfd(array(studentized$coefs, dim = c(dim(studentized$coefs), 
                                           1)), bs, pred_error$fdnames, B = bs$B)
    }
    res <- get_studentized_residuals(gain, res_original)
    res_pca <- my_FPCA(Y_mfd = res , FVEy = FVE_res , scale = F)
    
    gain_new_tuning <- rowSums(t(t(X_tuning)^2/colSums(X_training^2)))
    pred_error_tuning <- get_studentized_residuals(gain = gain_new_tuning, 
                                                   pred_error = res_tuning_original_mfd)
    
    gain_new_testing <- rowSums(t(t(X_testing)^2/colSums(X_training^2)))
    pred_error_testing <- get_studentized_residuals(gain = gain_new_testing, 
                                                   pred_error = res_testing_original_mfd)
    
    frcc_df <- control_charts_pca(pca = res_pca$pcay , components = 1:res_pca$ncomponents_y , tuning_data = pred_error_tuning  , newdata =pred_error_testing  , alpha = alpha)
    alpha <- sum(frcc_df$T2 > frcc_df$T2_lim | frcc_df$spe > frcc_df$spe_lim)/length(frcc_df$id)
    ARL_FRCC <- 1 / (1 - ( 1 - alpha ))
  }
  return(list(ARL = ARL_FRCC,
         frcc_df = frcc_df,
         model = mod,
         pca_res = res_pca))
}


#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

## FCC param ##

# FCC_param <- function(Y_training_mfd,Y_tuning_mfd,Y_testing_mfd,FVEy,alpha = 0.01,SPE=T , scale = T){
#   
#   alpha_corr <- 1 - ( 1 - alpha )^0.5
#   
#   pca <- my_FPCA(Y_mfd = Y_training_mfd , FVEy = FVEy , scale = T)
#   
#   y_tun_scaled <- scale_mfd(mfdobj = Y_tuning_mfd , center = pca$pcay$center_fd , scale = pca$pcay$scale_fd)
#   df <- funcharts:::get_T2_spe(pca = pca$pcay , components = 1:pca$ncomponents_y ,newdata_scaled = y_tun_scaled , absolute_error = F )
#   p <- pca$ncomponents_y
#   n <- ncol(Y_tuning_mfd$coefs)
#   c <- (p*(n+1)*(n-1))/(n*(n-p))
#   lim_t2 <- c*qf(p = 1 - alpha_corr , df1 = p , df2 = n - p) 
#   lim_spe <- 
#   
# }
#   
  
#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

Clust_model <- function(Y_training_mfd,FVEy , init_met = 'kmeans',num_iterations = 1 , max_group = 3){
  
  #/// FPCA PHASE ///#
  ## FPCA Training ##
  fpca_results <- my_FPCA(Y_mfd = Y_training_mfd,FVEy = FVEy, length_grid = 500)
  score_y <-  fpca_results$pcay$pcscores[,1:fpca_results$ncomponents_y]
  score_y <- as.matrix(score_y)
  #/// MODEL ESTIMATION PHASE ///#
  ## Model estimation ##
  if(init_met == 'kmeans') num_iterations <- 1
  
  estimate <- estimate_mixture(y = score_y , num_iterations =num_iterations  , max_group = max_group ,mode = 'clustering',init_met = init_met)
  best_model_clust <- estimate
  num_groups_clust <- length(best_model_clust$prop)  
  

  return(list(model = best_model_clust,
              fpca_results = fpca_results))
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

Clust_control_chart <- function(Y_training_mfd,Y_tuning_mfd,alpha = 0.01 , Y_testing_mfd , SPE =T, model){ 
  
  best_model_clust <- model$model
  fpca_results <- model$fpca_results
  num_groups_clust <- length(best_model_clust$prop)  
  
  score_y <-  fpca_results$pcay$pcscores[,1:fpca_results$ncomponents_y]
  score_y <- as.matrix(score_y)
  
  # Standardization and score calculation tuning
  y_tuning_std_mfd <- scale_mfd(mfdobj = Y_tuning_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  y_score_new <- get_scores(pca = fpca_results$pcay , components = 1:fpca_results$ncomponents_y , newdata_scaled = y_tuning_std_mfd)
  
  
  # Standardization and score calculation testing
  y_testing_std_mfd <- scale_mfd(mfdobj = Y_testing_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  y_score_test <- get_scores(pca = fpca_results$pcay , components = 1:fpca_results$ncomponents_y , newdata_scaled = y_testing_std_mfd)
  
  
  membership_training <- predict_mixture(y = score_y, x = matrix(1 , nrow = nrow(score_y)) ,hard = T , model = best_model_clust)$membership
  membership_tuning <- predict_mixture(y = y_score_new, x = matrix(1 , nrow = nrow(y_score_new)) ,hard = T , model = best_model_clust)$membership
  membership_testing <- predict_mixture(y = y_score_test, x = matrix(1 , nrow = nrow(y_score_test)) ,hard = T , model = best_model_clust)$membership
  
  results <- vector(mode = 'list' , length = num_groups_clust)
  
  n_obs_training <- colsums(membership_training)
  n_obs_tuning <- colsums(membership_tuning)
  n_obs_testing <- colsums(membership_testing)
  
  for(kk in 1:num_groups_clust){
    
    if(sum(membership_testing[,kk]!=0)==0) next
    results[[kk]] <- FCC(Y_training_mfd = Y_training_mfd[which(membership_training[,kk]==1)],
                         Y_tuning_mfd = Y_tuning_mfd[which(membership_tuning[,kk]==1)],
                         Y_testing_mfd = Y_testing_mfd[which(membership_testing[,kk]==1)],
                         FVEy = FVEy,alpha = alpha,SPE = SPE)
    
  }
  
  # ARL
  OC <- 0
  
  if(SPE){
    for(kk in 1:num_groups_clust){
      OC <- OC + sum(results[[kk]]$fcc_df$T2 > results[[kk]]$fcc_df$T2_lim | results[[kk]]$fcc_df$spe > results[[kk]]$fcc_df$spe_lim )
    }
  }else{
    for(kk in 1:num_groups_clust){
      OC <- OC + sum(results[[kk]]$fcc_df$T2 > results[[kk]]$fcc_df$T2_lim)
    }
  }
  
  alpha <- OC/nrow(y_score_test)
  
  
  ARL <- 1 / (1 - ( 1 - alpha))
  
  return(list(ARL = ARL,
              Charts = results,
              model = best_model_clust,
              nobs = list(n_obs_testing = n_obs_testing,
                          n_obs_tuning = n_obs_tuning,
                          n_obs_training = n_obs_training)))

}

  
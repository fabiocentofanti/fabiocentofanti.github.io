
mixregfit_multivariate <- function(y,x,k,init_met = 'random',intercept = FALSE,eps = 1e-6,max_iter = 50 , model_Sigma){
  
  #INITIALIZATION
  y<- as.matrix(y)
  x <- as.matrix(x)
  if (intercept) {
    x = cbind(1, x)
  }
  n <- nrow(y)
  p <- ncol(y)
  q <- ncol(x)
  z <- matrix(nrow = n, ncol = k)
  B <- list()
  sing <- 0
  Sigma <- list()
  eps_iter <- 100
  restarts <- 0
  
  if(init_met == 'kmeans'){
    z_kmeans <- kmeans(y, centers = k, nstart = 20)$cluster
  }
  if(init_met == 'random'){
    z_kmeans <- sample(1:k, n, replace=T)
  }
  
  #PARAMETERS CALCULATION FROM Z
  for (kk in 1:k){
    z[,kk] <-as.numeric(z_kmeans == kk)
  }
  
  prop <- apply(z,2,mean)
  
  
  if(intercept){
    for(kk in 1:k){
      B[[kk]] <- lm(y ~ x[,-1], weights = z[,kk])$coef
    }
  }else{
    for(kk in 1:k){
      B[[kk]] <- lm(y ~ x - 1, weights = z[,kk])$coef  
    }
  }
  
  
  if(model_Sigma == 'EEE'){
    s <- 0
    for(kk in 1:k){
      yhat <- x%*%B[[kk]]
      # yhat <- crossprod(x , B[[kk]])
      s <- s + t(y-yhat)%*%((y-yhat)*z[,kk])
      #s <- s + crossprod(y-yhat)*z[,kk]
    }
    
    s <- s/n
    
    if(is.na(rcond(s))){
      sing <- 1
      s <- matrix(nrow = p, ncol = p)
      cat('\nrcond(Sigma is less than 3e-17!\n')
    }else if(rcond(s) < 3e-17){
      s <- matrix(nrow = p, ncol = p)
      cat('\nrcond(Sigma is less than 3e-17!\n')
      sing <- 1
    }
    
    for(kk in 1:k){
      Sigma[[kk]] <- s
    }
    
  }else if (model_Sigma == 'VVV'){
    
    for (kk in 1:k){
      yhat  <- x%*%B[[kk]]
      # yhat <- crossprod(x , B[[kk]])
      
      Sigma[[kk]] <- (t(y-yhat)%*%((y-yhat)* z[,kk]))/sum(z[,kk])
      # Sigma[[kk]] <- (crossprod(y-yhat) * z[,kk])/sum(z[,kk])
      
      # Sigma[[kk]][which(abs(Sigma[[kk]])< 10^-30 , arr.ind = T)] <- 10^-30  
      if(is.na(rcond(Sigma[[kk]]))){
        sing <- 1
        Sigma[[kk]] <- matrix(nrow = p, ncol = p)
        cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
      }else if(rcond(Sigma[[kk]]) < 3e-17){
        Sigma[[kk]] <- matrix(nrow = p, ncol = p)
        cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
        sing <- 1
      }
    }
  }else if (model_Sigma == 'VII'){
    for(kk in 1:k){

      yhat <- x%*%B[[kk]]
      # yhat <- crossprod(x , B[[kk]])
      Sigma[[kk]] <- (psych::tr((t(y-yhat)%*%((y-yhat)*z[,kk])))/(sum(z[,kk])*p))*diag(p)
      #  Sigma[[kk]] <- ((psych::tr((crossprod(y-yhat))*z[,kk]))/(sum(z[,kk])*p)))*diag(p)

      if(is.na(rcond(Sigma[[kk]]))){
        sing <- 1
        Sigma[[kk]] <- matrix(nrow = p, ncol = p)
        cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
      }else if(rcond(Sigma[[kk]]) < 3e-17){
        Sigma[[kk]] <- matrix(nrow = p, ncol = p)
        cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
        sing <- 1
      }
    }
  }else if(model_Sigma == 'EII'){
    s <- 0
    for(kk in 1:k){
      yhat <- x%*%B[[kk]]
      # yhat <- crossprod(x , B[[kk]])
      s <- s + t(y-yhat)%*%((y-yhat)*z[,kk])
      # s <- s + crossprod(y-yhat)*z[,kk]
      
    }
    s <- (psych::tr(s)/(n*p))*diag(p)
    
    if(is.na(rcond(s))){
      sing <- 1
      s <- matrix(nrow = p, ncol = p)
      cat('\nrcond(Sigma is less than 3e-17!\n')
    }else if(rcond(s) < 3e-17){
      s <- matrix(nrow = p, ncol = p)
      cat('\nrcond(Sigma is less than 3e-17!\n')
      sing <- 1
    }
    
    for(kk in 1:k){
      Sigma[[kk]] <- s
    }
  }
  

  # comp <- lapply(1:k, function(i){
  #   yhat <- x%*%B[[i]]
  #   lk <- diag((1/((2*pi)^(p/2)*det(Sigma[[i]])^0.5))*exp(-0.5*(y-yhat)%*%solve(Sigma[[i]],toll = NULL)%*%t(y-yhat)))
  # prop[i] * lk})
  # 
  comp <- lapply(1:k, function(i){
    yhat <- x%*%B[[i]]
    lk <- sapply(1:nrow(y) , function(j) {mvnfast::dmvn(X = y[j,] , mu = yhat[j,] , sigma = Sigma[[i]])})
    prop[i] * lk})
  
  
  
  comp <- sapply(comp, cbind)
  compsum <- apply(comp, 1, sum)
  obsloglik <- sum(log(compsum))
  # Q <-obsloglik
  
  #-----------------------------------------------------------------------------------------------------
  
  iter <- 0
  
  while(eps_iter >= eps & iter < max_iter ){
    
    iter <- iter + 1
    
    for(kk in 1:k){
      z[,kk] <- comp[,kk]/compsum
    }
    
    prop <- apply(z,2,mean)
    
    if (sum(prop < 1e-20) > 0 || is.na(sum(prop))) {
      sing <- 1
    }else{
      for (kk in 1:k){
        if (intercept){
          B[[kk]] <- lm(y ~ x[,-1], weights = z[,kk])$coef
        } else {
          B[[kk]] <- lm(y ~ x - 1, weights = z[,kk])$coef
        }
      }
      
      if(model_Sigma == 'EEE'){
        s <- 0
        for(kk in 1:k){
          yhat <- x%*%B[[kk]]
          # yhat <- crossprod(x , B[[kk]])
          s <- s + t(y-yhat)%*%((y-yhat)*z[,kk])
          #s <- s + crossprod(y-yhat)*z[,kk]
        }
        s <- s/n
        
        if(is.na(rcond(s))){
          sing <- 1
          s <- matrix(nrow = p, ncol = p)
          cat('\nrcond(Sigma is less than 3e-17!\n')
        }else if(rcond(s) < 3e-17){
          s <- matrix(nrow = p, ncol = p)
          cat('\nrcond(Sigma is less than 3e-17!\n')
          sing <- 1
        }
        
        for(kk in 1:k){
          Sigma[[kk]] <- s
        }
      }else if (model_Sigma == 'VVV'){
        
        for (kk in 1:k){
          yhat  <- x%*%B[[kk]]
          # yhat <- crossprod(x , B[[kk]])
          
          Sigma[[kk]] <- (t(y-yhat)%*%((y-yhat)* z[,kk]))/sum(z[,kk])
          # Sigma[[kk]] <- (crossprod(y-yhat) * z[,kk])/sum(z[,kk])
          
          # Sigma[[kk]][which(abs(Sigma[[kk]])< 10^-30 , arr.ind = T)] <- 10^-30  
          if(is.na(rcond(Sigma[[kk]]))){
            sing <- 1
            Sigma[[kk]] <- matrix(nrow = p, ncol = p)
            cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
          }else if(rcond(Sigma[[kk]]) < 3e-17){
            Sigma[[kk]] <- matrix(nrow = p, ncol = p)
            cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
            sing <- 1
          }
        }
      }else if (model_Sigma == 'VII'){
        for(kk in 1:k){
          
          yhat <- x%*%B[[kk]]
          # yhat <- crossprod(x , B[[kk]])
          Sigma[[kk]] <- (psych::tr((t(y-yhat)%*%((y-yhat)*z[,kk])))/(sum(z[,kk])*p))*diag(p)
          if(is.na(rcond(Sigma[[kk]]))){
            sing <- 1
            Sigma[[kk]] <- matrix(nrow = p, ncol = p)
            cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
          }else if(rcond(Sigma[[kk]]) < 3e-17){
            Sigma[[kk]] <- matrix(nrow = p, ncol = p)
            cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
            sing <- 1
          }
        }
      }else if(model_Sigma == 'EII'){
        s <- 0
        for(kk in 1:k){
          yhat <- x%*%B[[kk]]
          # yhat <- crossprod(x , B[[kk]])
          s <- s + t(y-yhat)%*%((y-yhat)*z[,kk])
          # s <- s + crossprod(y-yhat)*z[,kk]
        }
        s <- (psych::tr(s)/(n*p))*diag(p)
        
        if(is.na(rcond(s))){
          sing <- 1
          s <- matrix(nrow = p, ncol = p)
          cat('\nrcond(Sigma is less than 3e-17!\n')
        }else if(rcond(s) < 3e-17){
          s <- matrix(nrow = p, ncol = p)
          cat('\nrcond(Sigma is less than 3e-17!\n')
          sing <- 1
        }
        
        for(kk in 1:k){
          Sigma[[kk]] <- s
        }
      }
      
      
      comp <- lapply(1:k, function(i){
        yhat <- x%*%B[[i]]
        lk <- sapply(1:nrow(y) , function(j) {mvnfast::dmvn(X = y[j,] , mu = yhat[j,] , sigma = Sigma[[i]])})
        prop[i] * lk})
      
      
      comp <- sapply(comp, cbind)
      compsum <- apply(comp, 1, sum)
      newobsloglik <- sum(log(compsum))
      # Q <-c(Q,newobsloglik)
      
      eps_iter <-abs(newobsloglik-obsloglik)
      obsloglik <- newobsloglik
    }
    
    if (sing > 0 || is.na(newobsloglik) || newobsloglik < 
        obsloglik || abs(newobsloglik) == Inf) {
      cat("Need new starting values due to singularity...", 
          "\n")
      restarts <- restarts + 1
      if (restarts > 15){
        cat("Too many tries!")
        return(NA)
      }
      z <- matrix(nrow = n, ncol = k)
      B <- list()
      Sigma <- list()
      eps_iter <- 100
      sing <- 0
      
      if(init_met == 'kmeans'){
        z_kmeans <- kmeans(y, centers = k, nstart = 20)$cluster
      }
      if(init_met == 'random'){
        z_kmeans <- sample(1:k, n, replace=T)
      }
      
      #PARAMETERS CALCULATION FROM Z
      
      for (kk in 1:k){
        z[,kk] <-as.numeric(z_kmeans == kk)
      }
      
      prop <- apply(z,2,mean)
      
      for (kk in 1:k){
        if (intercept){
          B[[kk]] <- lm(y ~ x[,-1], weights = z[,kk])$coef
        } else {
          B[[kk]] <- lm(y ~ x - 1, weights = z[,kk])$coef
        }
      }
      
      if(model_Sigma == 'EEE'){
        s <- 0
        for(kk in 1:k){
          yhat <- x%*%B[[kk]]
          # yhat <- crossprod(x , B[[kk]])
          s <- s + t(y-yhat)%*%((y-yhat)*z[,kk])
          #s <- s + crossprod(y-yhat)*z[,kk]
        }
        
        s <- s/n
        
        if(is.na(rcond(s))){
          sing <- 1
          s <- matrix(nrow = p, ncol = p)
          cat('\nrcond(Sigma is less than 3e-17!\n')
        }else if(rcond(s) < 3e-17){
          s <- matrix(nrow = p, ncol = p)
          cat('\nrcond(Sigma is less than 3e-17!\n')
          sing <- 1
        }
        
        for(kk in 1:k){
          Sigma[[kk]] <- s
        }
        
      }else if (model_Sigma == 'VVV'){
        
        for (kk in 1:k){
          yhat  <- x%*%B[[kk]]
          # yhat <- crossprod(x , B[[kk]])
          
          Sigma[[kk]] <- (t(y-yhat)%*%((y-yhat)* z[,kk]))/sum(z[,kk])
          # Sigma[[kk]] <- (crossprod(y-yhat) * z[,kk])/sum(z[,kk])
          
          # Sigma[[kk]][which(abs(Sigma[[kk]])< 10^-30 , arr.ind = T)] <- 10^-30  
          if(is.na(rcond(Sigma[[kk]]))){
            sing <- 1
            Sigma[[kk]] <- matrix(nrow = p, ncol = p)
            cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
          }else if(rcond(Sigma[[kk]]) < 3e-17){
            Sigma[[kk]] <- matrix(nrow = p, ncol = p)
            cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
            sing <- 1
          }
        }
      }else if (model_Sigma == 'VII'){
        for(kk in 1:k){
          
          yhat <- x%*%B[[kk]]
          # yhat <- crossprod(x , B[[kk]])
          Sigma[[kk]] <- (psych::tr((t(y-yhat)%*%((y-yhat)*z[,kk])))/(sum(z[,kk])*p))*diag(p)
          #  Sigma[[kk]] <- ((psych::tr((crossprod(y-yhat))*z[,kk]))/(sum(z[,kk])*p)))*diag(p)
          
          if(is.na(rcond(Sigma[[kk]]))){
            sing <- 1
            Sigma[[kk]] <- matrix(nrow = p, ncol = p)
            cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
          }else if(rcond(Sigma[[kk]]) < 3e-17){
            Sigma[[kk]] <- matrix(nrow = p, ncol = p)
            cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
            sing <- 1
          }
        }
      }else if(model_Sigma == 'EII'){
        s <- 0
        for(kk in 1:k){
          yhat <- x%*%B[[kk]]
          # yhat <- crossprod(x , B[[kk]])
          s <- s + t(y-yhat)%*%((y-yhat)*z[,kk])
          # s <- s + crossprod(y-yhat)*z[,kk]
          
        }
        s <- (psych::tr(s)/(n*p))*diag(p)
        
        if(is.na(rcond(s))){
          sing <- 1
          s <- matrix(nrow = p, ncol = p)
          cat('\nrcond(Sigma is less than 3e-17!\n')
        }else if(rcond(s) < 3e-17){
          s <- matrix(nrow = p, ncol = p)
          cat('\nrcond(Sigma is less than 3e-17!\n')
          sing <- 1
        }
        
        for(kk in 1:k){
          Sigma[[kk]] <- s
        }
      }
      
      comp <- lapply(1:k, function(i){
        yhat <- x%*%B[[i]]
        lk <- sapply(1:nrow(y) , function(j) {mvnfast::dmvn(X = y[j,] , mu = yhat[j,] , sigma = Sigma[[i]])})
        prop[i] * lk})
      
      
      comp <- sapply(comp, cbind)
      compsum <- apply(comp, 1, sum)
      obsloglik <- sum(log(compsum))
      
      iter <- 0
    }
  }
  
  group_member <- apply(z,FUN = which.max,MARGIN = 1)
  
  if(model_Sigma=='VVV'){
    if(q == 1){
      BIC <- -2*obsloglik + log(n)*(k*p + k*(p*(p+1)/2) + k - 1)
    }else{
      BIC <- -2*obsloglik + log(n)*(k*p +k*p*q + k*(p*(p+1)/2) + k - 1)
    }
  }else if (model_Sigma== 'EEE'){
    if(q == 1){
      BIC <- -2*obsloglik + log(n)*(k*p + (p*(p+1)/2) + k - 1)
    }else{
      BIC <- -2*obsloglik + log(n)*(k*p +k*p*q + (p*(p+1)/2) + k - 1)
    }
  }else if (model_Sigma == 'VII'){
    if(q == 1){
      BIC <- -2*obsloglik + log(n)*(k*p + k + k - 1)
    }else{
      BIC <- -2*obsloglik + log(n)*(k*p +k*p*q + k + k - 1)
    }
  }else if (model_Sigma == 'EII'){
    if(q == 1){
      BIC <- -2*obsloglik + log(n)*(k*p + 1 + k - 1)
    }else{
      BIC <- -2*obsloglik + log(n)*(k*p +k*p*q + 1 + k - 1)
    }
  }
  
  if (iter == max_iter){
    cat('Failed to converge in ',max_iter,' iterations')
  }else{
    cat('\nNumber of iterations = ',iter)
  }
  
  return (list(B = B, Sigma = Sigma, prop = prop, group_member = group_member, logLik = obsloglik, BIC = BIC, z = z))
}



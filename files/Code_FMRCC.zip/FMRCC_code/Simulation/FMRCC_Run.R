library(fda)
library(Rfast)
library(fdapace)
library(mvtnorm)
library(tidyverse)
library(funcharts)
library(ggpubr)
library(parallel)
library(ggplot2)
library(dplyr)
library(tidyr)
library(ggtext)
library(readr)
library(stringr)
library(ggpubr)
library(viridis)
library(mvnfast)

source("FMRCC_functions.R")

nsim <- 100
severity <- c(0,0.375,0.75,1.125,1.5)
n_obs_training  <- 1200
n_obs_tuning <- 3000
n_obs_testing <- 3000
shift_type <- c('constant','linear','quadratic')
delta2_vector <- c(0,0.5,1)
delta_vector <- c(0,0.33,0.66,1)
FVEy <- FVEx <- FVEz <-  0.95
alpha <- 0.01
SNR <- 10
SPE <- T

# linear shift type
shift_type_idx <- 2

# Delta1 = 1
delta_idx <- 3

# Delta2 = 1
delta2_idx <- 3

# Severity level (SL) = 2
severity_idx <- 3


shift_type_chosen <- shift_type[shift_type_idx]
delta2 <-delta2_vector[delta2_idx]
shift_coef <- shift_vector_choice(shift_case = 'intercept' , type = shift_type_chosen)
delta <- delta_vector[delta_idx]
severity_chosen <- severity[severity_idx]

func <- function(iii){

  set.seed(iii)
  
  cat('\n','Simulation',iii)
  ## DATA SIMULATION PHASE ## /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  ## Training set simulation ##
  sim <- simulate_data(n_obs = n_obs_training, len_grid = 500, SNR = SNR , ncompx = 50 ,delta = delta , delta_int = delta2)
  X_training <- sim$X
  Y_training <- sim$Y
  
  ## Tuning set simulation ##
  sim <- simulate_data(n_obs = n_obs_tuning, len_grid = 500, SNR = SNR, ncompx = 50 , delta = delta, delta_int = delta2)
  X_tuning <- sim$X
  Y_tuning <- sim$Y
  
  ## Testing set simulation ##
  sim_testing <- simulate_shift_data(n_obs = n_obs_testing , len_grid = 500 , SNR = SNR , severity = severity_chosen, ncompx = 50 , delta = delta,delta_int = delta2, shift_coef = shift_coef)
  X_testing <- sim_testing$X
  Y_testing <- sim_testing$Y
  
  ## SMOOTHING PHASE ## ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  ## Data Smoothing ## 
  dat <- smooth_data(X = X_training, Y = Y_training, domain = c(0,1), length_grid = 500 , norder = 4 , n_basis_x = 80 , n_basis_y = 80)
  X_training_fd <- dat$X_fd
  Y_training_fd <- dat$Y_fd
  colnames(X_training_fd$coefs) <- X_training_fd$fdnames[[2]]
  colnames(Y_training_fd$coefs) <- Y_training_fd$fdnames[[2]]
  X_training_mfd <- get_mfd_fd(X_training_fd)
  Y_training_mfd <- get_mfd_fd(Y_training_fd)
  
  dat <- smooth_data(X = X_tuning, Y = Y_tuning, domain = c(0,1), length_grid = 500 , norder = 4 , n_basis_x = 80 , n_basis_y = 80)
  X_tuning_fd <- dat$X_fd
  Y_tuning_fd <- dat$Y_fd
  colnames(X_tuning_fd$coefs) <- X_tuning_fd$fdnames[[2]]
  colnames(Y_tuning_fd$coefs) <- Y_tuning_fd$fdnames[[2]]
  X_tuning_mfd <- get_mfd_fd(X_tuning_fd)
  Y_tuning_mfd <- get_mfd_fd(Y_tuning_fd)
  
  dat <- smooth_data(X = X_testing, Y = Y_testing, domain = c(0,1), length_grid = 500 , norder = 4 , n_basis_x = 80 , n_basis_y = 80)
  X_testing_fd <- dat$X_fd
  Y_testing_fd <- dat$Y_fd
  colnames(X_testing_fd$coefs) <- X_testing_fd$fdnames[[2]]
  colnames(Y_testing_fd$coefs) <- Y_testing_fd$fdnames[[2]]
  X_testing_mfd <- get_mfd_fd(X_testing_fd)
  Y_testing_mfd <- get_mfd_fd(Y_testing_fd)
  
  ## FMRCC ## /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  cat("\n",'FMRCC')
  
  ## Studentized ##
  # FMRCC_stud_phaseI <- FMRCC_phaseI(Y_training_mfd = Y_training_mfd, X_training_mfd = X_training_mfd , Y_tuning_mfd = Y_tuning_mfd , X_tuning_mfd = X_tuning_mfd ,
  #                                   FVEy = FVEy , FVEx = FVEx , studentized = T , alpha = alpha , intercept = T , SPE = F , init_met = 'kmeans',
  #                                   num_iterations = 1 , max_group = 5)
  # FMRCC_stud_phaseII <- FMRCC_phaseII(Y_testing_mfd = Y_testing_mfd , X_testing_mfd = X_testing_mfd , phaseI = FMRCC_stud_phaseI, studentized = T , intercept = T ,SPE = F)
  # ARL_FMRCC_stud <- FMRCC_stud_phaseII$ARL 
  
  # Normal Residuals ##
  FMRCC_res_phaseI <- FMRCC_phaseI(Y_training_mfd = Y_training_mfd, X_training_mfd = X_training_mfd , Y_tuning_mfd = Y_tuning_mfd , X_tuning_mfd = X_tuning_mfd ,
                                   FVEy = FVEy , FVEx = FVEx , studentized = T ,
                                   alpha = alpha , intercept = T , SPE = F, init_met = 'kmeans',
                                   num_iterations = 1 , max_group =5)
  FMRCC_res_phaseII <- FMRCC_phaseII(Y_testing_mfd = Y_testing_mfd , X_testing_mfd = X_testing_mfd , phaseI = FMRCC_res_phaseI ,
                                     studentized = T , intercept = T , SPE = F)
  ARL_FMRCC_res <- FMRCC_res_phaseII$ARL
  
  ## FRCC ## //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

  cat("\n",'FRCC')
  
  ## Studentized ##

  FRCC_res <- FRCC(Y_training_mfd = Y_training_mfd, X_training_mfd = X_training_mfd , Y_tuning_mfd = Y_tuning_mfd , X_tuning_mfd = X_tuning_mfd ,
                   Y_testing_mfd = Y_testing_mfd, X_testing_mfd = X_testing_mfd, FVEy = FVEy , FVEx = FVEx , FVEz = FVEz, studentized = F , alpha = alpha,SPE =SPE)
  ARL_FRCC_res <- FRCC_res$ARL
  
  ## FCC ## ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  cat("\n",'FCC')
  
  FCC_result <- FCC(Y_training_mfd = Y_training_mfd , Y_tuning_mfd = Y_tuning_mfd , Y_testing_mfd = Y_testing_mfd , FVEy = FVEy , alpha = alpha,SPE = SPE)
  ARL_FCC <- FCC_result$ARL
  
  ## CLUST ## /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  cat("\n",'CLUST')
  
  Clust_result <-  Clust(Y_training_mfd = Y_training_mfd,Y_tuning_mfd = Y_tuning_mfd,Y_testing_mfd = Y_testing_mfd, FVEy = FVEy,alpha = alpha,SPE=SPE,
                         init_met = 'kmeans',num_iterations = 1,max_group = 5)
  ARL_CLUST <- Clust_result$ARL
  
  # frac_vec<-c(1/ARL_FMRCC_stud , 1/ARL_FMRCC_res , 1/ARL_FRCC_stud , 1/ARL_FRCC_res , 1/ARL_FCC , 1/ARL_CLUST)
  frac_vec<-c(1/ARL_FMRCC_res , 1/ARL_FRCC_res , 1/ARL_FCC , 1/ARL_CLUST)
  
  return(frac_vec)
}

ncores <- 7 # Select the number of cores to be used for parallel computation
if(.Platform$OS.type == "unix"){
  ncores <- min(ncores, parallel::detectCores())
} else if(.Platform$OS.type == "windows"){
  ncores <- 1 # Parallelization not implemented for windows systems
}
out <- mclapply(1:nsim,function(x) func(x), mc.cores = ncores)
frac_vec <- do.call(rbind , out)
colnames(frac_vec)<-c("FMRCC_R","FRCC_R","FCC","Clust")

plt <- plot_results(frac_vec , severity_idx = severity_idx)
plt
# ggsave("fig.pdf", width = 6, height = 5)


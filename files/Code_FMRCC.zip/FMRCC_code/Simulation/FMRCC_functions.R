#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

## FMRCC Functions ##

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

mixregfit_multivariate <- function(y,x,k,init_met = 'random',intercept = FALSE,eps = 1e-6,max_iter = 50 , model_Sigma){
  
  #INITIALIZATION
  y<- as.matrix(y)
  x <- as.matrix(x)
  if (intercept) {
    x = cbind(1, x)
  }
  n <- nrow(y)
  p <- ncol(y)
  q <- ncol(x)
  z <- matrix(nrow = n, ncol = k)
  B <- list()
  sing <- 0
  Sigma <- list()
  eps_iter <- 100
  restarts <- 0
  
  if(init_met == 'kmeans'){
    z_kmeans <- kmeans(y, centers = k, nstart = 20)$cluster
  }
  if(init_met == 'random'){
    z_kmeans <- sample(1:k, n, replace=T)
  }
  
  #PARAMETERS CALCULATION FROM Z
  for (kk in 1:k){
    z[,kk] <-as.numeric(z_kmeans == kk)
  }
  
  prop <- apply(z,2,mean)
  
  
  if(intercept){
    for(kk in 1:k){
      B[[kk]] <- lm(y ~ x[,-1], weights = z[,kk])$coef
    }
  }else{
    for(kk in 1:k){
      B[[kk]] <- lm(y ~ x - 1, weights = z[,kk])$coef  
    }
  }
  
  
  if(model_Sigma == 'EEE'){
    s <- 0
    for(kk in 1:k){
      yhat <- x%*%B[[kk]]
      # yhat <- crossprod(x , B[[kk]])
      s <- s + t(y-yhat)%*%((y-yhat)*z[,kk])
      #s <- s + crossprod(y-yhat)*z[,kk]
    }
    
    s <- s/n
    
    if(is.na(rcond(s))){
      sing <- 1
      s <- matrix(nrow = p, ncol = p)
      cat('\nrcond(Sigma is less than 3e-17!\n')
    }else if(rcond(s) < 3e-17){
      s <- matrix(nrow = p, ncol = p)
      cat('\nrcond(Sigma is less than 3e-17!\n')
      sing <- 1
    }
    
    for(kk in 1:k){
      Sigma[[kk]] <- s
    }
    
  }else if (model_Sigma == 'VVV'){
    
    for (kk in 1:k){
      yhat  <- x%*%B[[kk]]
      # yhat <- crossprod(x , B[[kk]])
      
      Sigma[[kk]] <- (t(y-yhat)%*%((y-yhat)* z[,kk]))/sum(z[,kk])
      # Sigma[[kk]] <- (crossprod(y-yhat) * z[,kk])/sum(z[,kk])
      
      # Sigma[[kk]][which(abs(Sigma[[kk]])< 10^-30 , arr.ind = T)] <- 10^-30  
      if(is.na(rcond(Sigma[[kk]]))){
        sing <- 1
        Sigma[[kk]] <- matrix(nrow = p, ncol = p)
        cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
      }else if(rcond(Sigma[[kk]]) < 3e-17){
        Sigma[[kk]] <- matrix(nrow = p, ncol = p)
        cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
        sing <- 1
      }
    }
  }else if (model_Sigma == 'VII'){
    for(kk in 1:k){
      
      yhat <- x%*%B[[kk]]
      # yhat <- crossprod(x , B[[kk]])
      Sigma[[kk]] <- (psych::tr((t(y-yhat)%*%((y-yhat)*z[,kk])))/(sum(z[,kk])*p))*diag(p)
      #  Sigma[[kk]] <- ((psych::tr((crossprod(y-yhat))*z[,kk]))/(sum(z[,kk])*p)))*diag(p)
      
      if(is.na(rcond(Sigma[[kk]]))){
        sing <- 1
        Sigma[[kk]] <- matrix(nrow = p, ncol = p)
        cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
      }else if(rcond(Sigma[[kk]]) < 3e-17){
        Sigma[[kk]] <- matrix(nrow = p, ncol = p)
        cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
        sing <- 1
      }
    }
  }else if(model_Sigma == 'EII'){
    s <- 0
    for(kk in 1:k){
      yhat <- x%*%B[[kk]]
      # yhat <- crossprod(x , B[[kk]])
      s <- s + t(y-yhat)%*%((y-yhat)*z[,kk])
      # s <- s + crossprod(y-yhat)*z[,kk]
      
    }
    s <- (psych::tr(s)/(n*p))*diag(p)
    
    if(is.na(rcond(s))){
      sing <- 1
      s <- matrix(nrow = p, ncol = p)
      cat('\nrcond(Sigma is less than 3e-17!\n')
    }else if(rcond(s) < 3e-17){
      s <- matrix(nrow = p, ncol = p)
      cat('\nrcond(Sigma is less than 3e-17!\n')
      sing <- 1
    }
    
    for(kk in 1:k){
      Sigma[[kk]] <- s
    }
  }
  
  
  # comp <- lapply(1:k, function(i){
  #   yhat <- x%*%B[[i]]
  #   lk <- diag((1/((2*pi)^(p/2)*det(Sigma[[i]])^0.5))*exp(-0.5*(y-yhat)%*%solve(Sigma[[i]],toll = NULL)%*%t(y-yhat)))
  # prop[i] * lk})
  # 
  comp <- lapply(1:k, function(i){
    yhat <- x%*%B[[i]]
    lk <- sapply(1:nrow(y) , function(j) {mvnfast::dmvn(X = y[j,] , mu = yhat[j,] , sigma = Sigma[[i]])})
    prop[i] * lk})
  
  
  
  comp <- sapply(comp, cbind)
  compsum <- apply(comp, 1, sum)
  obsloglik <- sum(log(compsum))
  # Q <-obsloglik
  
  #-----------------------------------------------------------------------------------------------------
  
  iter <- 0
  
  while(eps_iter >= eps & iter < max_iter ){
    
    iter <- iter + 1
    
    for(kk in 1:k){
      z[,kk] <- comp[,kk]/compsum
    }
    
    prop <- apply(z,2,mean)
    
    if (sum(prop < 1e-20) > 0 || is.na(sum(prop))) {
      sing <- 1
    }else{
      for (kk in 1:k){
        if (intercept){
          B[[kk]] <- lm(y ~ x[,-1], weights = z[,kk])$coef
        } else {
          B[[kk]] <- lm(y ~ x - 1, weights = z[,kk])$coef
        }
      }
      
      if(model_Sigma == 'EEE'){
        s <- 0
        for(kk in 1:k){
          yhat <- x%*%B[[kk]]
          # yhat <- crossprod(x , B[[kk]])
          s <- s + t(y-yhat)%*%((y-yhat)*z[,kk])
          #s <- s + crossprod(y-yhat)*z[,kk]
        }
        s <- s/n
        
        if(is.na(rcond(s))){
          sing <- 1
          s <- matrix(nrow = p, ncol = p)
          cat('\nrcond(Sigma is less than 3e-17!\n')
        }else if(rcond(s) < 3e-17){
          s <- matrix(nrow = p, ncol = p)
          cat('\nrcond(Sigma is less than 3e-17!\n')
          sing <- 1
        }
        
        for(kk in 1:k){
          Sigma[[kk]] <- s
        }
      }else if (model_Sigma == 'VVV'){
        
        for (kk in 1:k){
          yhat  <- x%*%B[[kk]]
          # yhat <- crossprod(x , B[[kk]])
          
          Sigma[[kk]] <- (t(y-yhat)%*%((y-yhat)* z[,kk]))/sum(z[,kk])
          # Sigma[[kk]] <- (crossprod(y-yhat) * z[,kk])/sum(z[,kk])
          
          # Sigma[[kk]][which(abs(Sigma[[kk]])< 10^-30 , arr.ind = T)] <- 10^-30  
          if(is.na(rcond(Sigma[[kk]]))){
            sing <- 1
            Sigma[[kk]] <- matrix(nrow = p, ncol = p)
            cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
          }else if(rcond(Sigma[[kk]]) < 3e-17){
            Sigma[[kk]] <- matrix(nrow = p, ncol = p)
            cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
            sing <- 1
          }
        }
      }else if (model_Sigma == 'VII'){
        for(kk in 1:k){
          
          yhat <- x%*%B[[kk]]
          # yhat <- crossprod(x , B[[kk]])
          Sigma[[kk]] <- (psych::tr((t(y-yhat)%*%((y-yhat)*z[,kk])))/(sum(z[,kk])*p))*diag(p)
          if(is.na(rcond(Sigma[[kk]]))){
            sing <- 1
            Sigma[[kk]] <- matrix(nrow = p, ncol = p)
            cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
          }else if(rcond(Sigma[[kk]]) < 3e-17){
            Sigma[[kk]] <- matrix(nrow = p, ncol = p)
            cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
            sing <- 1
          }
        }
      }else if(model_Sigma == 'EII'){
        s <- 0
        for(kk in 1:k){
          yhat <- x%*%B[[kk]]
          # yhat <- crossprod(x , B[[kk]])
          s <- s + t(y-yhat)%*%((y-yhat)*z[,kk])
          # s <- s + crossprod(y-yhat)*z[,kk]
        }
        s <- (psych::tr(s)/(n*p))*diag(p)
        
        if(is.na(rcond(s))){
          sing <- 1
          s <- matrix(nrow = p, ncol = p)
          cat('\nrcond(Sigma is less than 3e-17!\n')
        }else if(rcond(s) < 3e-17){
          s <- matrix(nrow = p, ncol = p)
          cat('\nrcond(Sigma is less than 3e-17!\n')
          sing <- 1
        }
        
        for(kk in 1:k){
          Sigma[[kk]] <- s
        }
      }
      
      
      comp <- lapply(1:k, function(i){
        yhat <- x%*%B[[i]]
        lk <- sapply(1:nrow(y) , function(j) {mvnfast::dmvn(X = y[j,] , mu = yhat[j,] , sigma = Sigma[[i]])})
        prop[i] * lk})
      
      
      comp <- sapply(comp, cbind)
      compsum <- apply(comp, 1, sum)
      newobsloglik <- sum(log(compsum))
      # Q <-c(Q,newobsloglik)
      
      eps_iter <-abs(newobsloglik-obsloglik)
      obsloglik <- newobsloglik
    }
    
    if (sing > 0 || is.na(newobsloglik) || newobsloglik < 
        obsloglik || abs(newobsloglik) == Inf) {
      cat("Need new starting values due to singularity...", 
          "\n")
      restarts <- restarts + 1
      if (restarts > 15){
        cat("Too many tries!")
        return(NA)
      }
      z <- matrix(nrow = n, ncol = k)
      B <- list()
      Sigma <- list()
      eps_iter <- 100
      sing <- 0
      
      if(init_met == 'kmeans'){
        z_kmeans <- kmeans(y, centers = k, nstart = 20)$cluster
      }
      if(init_met == 'random'){
        z_kmeans <- sample(1:k, n, replace=T)
      }
      
      #PARAMETERS CALCULATION FROM Z
      
      for (kk in 1:k){
        z[,kk] <-as.numeric(z_kmeans == kk)
      }
      
      prop <- apply(z,2,mean)
      
      for (kk in 1:k){
        if (intercept){
          B[[kk]] <- lm(y ~ x[,-1], weights = z[,kk])$coef
        } else {
          B[[kk]] <- lm(y ~ x - 1, weights = z[,kk])$coef
        }
      }
      
      if(model_Sigma == 'EEE'){
        s <- 0
        for(kk in 1:k){
          yhat <- x%*%B[[kk]]
          # yhat <- crossprod(x , B[[kk]])
          s <- s + t(y-yhat)%*%((y-yhat)*z[,kk])
          #s <- s + crossprod(y-yhat)*z[,kk]
        }
        
        s <- s/n
        
        if(is.na(rcond(s))){
          sing <- 1
          s <- matrix(nrow = p, ncol = p)
          cat('\nrcond(Sigma is less than 3e-17!\n')
        }else if(rcond(s) < 3e-17){
          s <- matrix(nrow = p, ncol = p)
          cat('\nrcond(Sigma is less than 3e-17!\n')
          sing <- 1
        }
        
        for(kk in 1:k){
          Sigma[[kk]] <- s
        }
        
      }else if (model_Sigma == 'VVV'){
        
        for (kk in 1:k){
          yhat  <- x%*%B[[kk]]
          # yhat <- crossprod(x , B[[kk]])
          
          Sigma[[kk]] <- (t(y-yhat)%*%((y-yhat)* z[,kk]))/sum(z[,kk])
          # Sigma[[kk]] <- (crossprod(y-yhat) * z[,kk])/sum(z[,kk])
          
          # Sigma[[kk]][which(abs(Sigma[[kk]])< 10^-30 , arr.ind = T)] <- 10^-30  
          if(is.na(rcond(Sigma[[kk]]))){
            sing <- 1
            Sigma[[kk]] <- matrix(nrow = p, ncol = p)
            cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
          }else if(rcond(Sigma[[kk]]) < 3e-17){
            Sigma[[kk]] <- matrix(nrow = p, ncol = p)
            cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
            sing <- 1
          }
        }
      }else if (model_Sigma == 'VII'){
        for(kk in 1:k){
          
          yhat <- x%*%B[[kk]]
          # yhat <- crossprod(x , B[[kk]])
          Sigma[[kk]] <- (psych::tr((t(y-yhat)%*%((y-yhat)*z[,kk])))/(sum(z[,kk])*p))*diag(p)
          #  Sigma[[kk]] <- ((psych::tr((crossprod(y-yhat))*z[,kk]))/(sum(z[,kk])*p)))*diag(p)
          
          if(is.na(rcond(Sigma[[kk]]))){
            sing <- 1
            Sigma[[kk]] <- matrix(nrow = p, ncol = p)
            cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
          }else if(rcond(Sigma[[kk]]) < 3e-17){
            Sigma[[kk]] <- matrix(nrow = p, ncol = p)
            cat('\nrcond(Sigma(',kk,') is less than 3e-17!\n')
            sing <- 1
          }
        }
      }else if(model_Sigma == 'EII'){
        s <- 0
        for(kk in 1:k){
          yhat <- x%*%B[[kk]]
          # yhat <- crossprod(x , B[[kk]])
          s <- s + t(y-yhat)%*%((y-yhat)*z[,kk])
          # s <- s + crossprod(y-yhat)*z[,kk]
          
        }
        s <- (psych::tr(s)/(n*p))*diag(p)
        
        if(is.na(rcond(s))){
          sing <- 1
          s <- matrix(nrow = p, ncol = p)
          cat('\nrcond(Sigma is less than 3e-17!\n')
        }else if(rcond(s) < 3e-17){
          s <- matrix(nrow = p, ncol = p)
          cat('\nrcond(Sigma is less than 3e-17!\n')
          sing <- 1
        }
        
        for(kk in 1:k){
          Sigma[[kk]] <- s
        }
      }
      
      comp <- lapply(1:k, function(i){
        yhat <- x%*%B[[i]]
        lk <- sapply(1:nrow(y) , function(j) {mvnfast::dmvn(X = y[j,] , mu = yhat[j,] , sigma = Sigma[[i]])})
        prop[i] * lk})
      
      
      comp <- sapply(comp, cbind)
      compsum <- apply(comp, 1, sum)
      obsloglik <- sum(log(compsum))
      
      iter <- 0
    }
  }
  
  group_member <- apply(z,FUN = which.max,MARGIN = 1)
  
  if(model_Sigma=='VVV'){
    if(q == 1){
      BIC <- -2*obsloglik + log(n)*(k*p + k*(p*(p+1)/2) + k - 1)
    }else{
      BIC <- -2*obsloglik + log(n)*(k*p +k*p*q + k*(p*(p+1)/2) + k - 1)
    }
  }else if (model_Sigma== 'EEE'){
    if(q == 1){
      BIC <- -2*obsloglik + log(n)*(k*p + (p*(p+1)/2) + k - 1)
    }else{
      BIC <- -2*obsloglik + log(n)*(k*p +k*p*q + (p*(p+1)/2) + k - 1)
    }
  }else if (model_Sigma == 'VII'){
    if(q == 1){
      BIC <- -2*obsloglik + log(n)*(k*p + k + k - 1)
    }else{
      BIC <- -2*obsloglik + log(n)*(k*p +k*p*q + k + k - 1)
    }
  }else if (model_Sigma == 'EII'){
    if(q == 1){
      BIC <- -2*obsloglik + log(n)*(k*p + 1 + k - 1)
    }else{
      BIC <- -2*obsloglik + log(n)*(k*p +k*p*q + 1 + k - 1)
    }
  }
  
  if (iter == max_iter){
    cat('Failed to converge in ',max_iter,' iterations')
  }else{
    cat('\nNumber of iterations = ',iter)
  }
  
  return (list(B = B, Sigma = Sigma, prop = prop, group_member = group_member, logLik = obsloglik, BIC = BIC, z = z))
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

## Simulate x ##
simulate_x <- function(nobs , n_comp = 50 , gamma = 1){
  P <- 200
  x_seq <- seq(0, 1, l = P)
  get_mat <- function(cov) {
    P <- length(cov)
    covmat <- matrix(0, nrow = P, ncol = P)
    for (ii in seq_len(P)) {
      covmat[ii, ii:P] <- cov[seq_len(P - ii + 1)]
      covmat[P - ii + 1, seq_len(P - ii + 1)] <- rev(cov[seq_len(P - ii + 1)])
    }
    covmat
  }
  w <- 1/P
  cov_fun <- function(x) exp(- gamma * sqrt(x))
  cov_mat <- get_mat(cov_fun(x_seq))
  eig <- RSpectra::eigs_sym(cov_mat, n_comp + 10)
  eig$values <- eig$values * w
  eig$vectors <- eig$vectors / sqrt(w)
  eig$values <- eig$values[seq_len(n_comp)]
  eig$vectors <- eig$vectors[, seq_len(n_comp)]
  e <- eig
  csi_X <- rnorm(n = length(e$values) * nobs, mean = 0, sd = sqrt(rep(e$values, each = nobs)))
  csi_X <- matrix(csi_X, nrow = nobs)
  X <- csi_X %*% t(e$vectors)
  # matplot(t(X), type = "l")
  x <- get_mfd_list(list(X1 = X))
  return(x)
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

## Data smoothing ##

smooth_data <- function(X = NULL, Y = NULL , domain = c(0,1), length_grid = 500 , norder = 4 , n_basis_x = 80 , n_basis_y = 80){
  
  grid<-seq(domain[1],domain[2],length.out = length_grid)
  
  if(!is.null(X)){
    n_basis_x<-min(n_basis_x,length_grid)
    breaks_x<-seq(domain[1],domain[2],length.out = (n_basis_x-2))
    basis_x <- create.bspline.basis(domain,breaks=breaks_x)
    X_fd <- smooth.basis(grid,X,basis_x)$fd
  }
  
  n_basis_y<-min(n_basis_y,length_grid)
  breaks_y<-seq(domain[1],domain[2],length.out = (n_basis_y-2))
  basis_y <- create.bspline.basis(domain,breaks=breaks_y)
  Y_fd <- smooth.basis(grid,Y,basis_y)$fd
  
  if(!is.null(X)){
    return(list(X_fd = X_fd,
                Y_fd = Y_fd))
  }else{
    return(list(Y_fd = Y_fd))
  }
  
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

## Data generation ##

simulate_data<-function(n_obs=3000,mixing_prop = c(1/3,1/3,1/3), len_grid = 500,SNR = 4 , sigma_equal = T , ncompx = 3 ,delta, delta_int) {
  
  k <- length(mixing_prop)
  
  length_tot<-len_grid
  grid_s<-grid_t<-seq(0,1,length.out = length_tot)
  mixing_prop <- matrix(mixing_prop,nrow = 1)
  domain<-c(0,1)
  
  # generate X --------------------------------------------------------------
  
  X_fd <- simulate_x(nobs = n_obs , n_comp = ncompx , gamma = 1)
  X_eval <- (1/5)*eval.fd(grid_s , X_fd)[,,1]
  
  # Generate ERROR ----------------------------------------------------------
  
  n_basis_eps<- 20 
  eps_basis<-create.bspline.basis(domain,norder = 4,nbasis = n_basis_eps)
  eps_coef <- vector(mode = "list", length = k)
  eps_fd <- vector(mode = "list", length = k)
  Eps <- vector(mode = "list", length = k)
  
  if(sigma_equal){
    for( kk in 1:k){
      eps_coef[[kk]] <- matrix(rnorm(round(n_obs*mixing_prop[kk])*n_basis_eps,mean = 0),nrow = n_basis_eps,ncol = round(n_obs*mixing_prop[kk]))
      eps_fd[[kk]] <- fd(eps_coef[[kk]],eps_basis)
      Eps[[kk]] <- eval.fd(grid_t,eps_fd[[kk]])
    }  
  }else{
    for(kk in 1:k){
      eps_coef[[kk]] <- matrix(rnorm(round(n_obs*mixing_prop[kk])*n_basis_eps,mean = 0,sd = 3*kk),nrow = n_basis_eps,ncol = round(n_obs*mixing_prop[kk]))
      eps_fd[[kk]] <- fd(eps_coef[[kk]],eps_basis)
      Eps[[kk]] <- eval.fd(grid_t,eps_fd[[kk]])
    }
  }
  
  # Define beta -----------------------------------------------------------
  
  beta_1<-function(s,t){
    a=0.3
    b=0.3
    c=0.3
    d=0.3
    f_1<-function(s,t){(((t-0.5)/c)^3+((s-0.5)/d)^3 + ((t-0.5)/b)^2 - ((s-0.5)/a)^2+5)}
    z<- outer(s,t,f_1)
    z}
  
  beta_2<-function(s,t){
    a=0.2  #0.2
    b=0.15 #0.15
    c=0.9  #0.9
    d=0.9  #0.9
    f_1<-function(s,t){(((t-0.5)/c)^3+((s-0.5)/d)^3+((t-0.5)/b)^2 - ((s-0.5)/a)^2-5)}
    z<- outer(s,t,f_1)
    z}
  
  beta_3<-function(s,t){
    a=0.3  #0.9
    b=0.3  #0.9
    c=0.3 #-0.3
    d=0.3  #-0.3
    f_1<-function(s,t){-(((t-0.5)/c)^3+((s-0.5)/d)^3+((t-0.5)/b)^2 - ((s-0.5)/a)^2+5)}
    z<- outer(s,t,f_1)
    z}
  
  b2 <- (1-delta)*beta_1(grid_s,grid_t) + (delta)*beta_2(grid_s,grid_t)
  b3 <- (1-delta)*beta_1(grid_s,grid_t) + (delta)*beta_3(grid_s,grid_t)
  
  x <- (grid_t-min(grid_t))/(max(grid_t)-min(grid_t))*(0.15-0.0045)+0.0045
  int_1 <- 100*(0.2074 + 0.3117*exp((-(371.4))*x) +0.5284*(1 - exp((-(-0.8217))*x)) -423.3*(1 + tanh(-26.15*(x-(-0.1715)))))
  
  x <- (grid_t-min(grid_t))/(max(grid_t)-min(grid_t))*(0.4-0.0045)+0.0045
  int_2 <- 100*(0.187 + 0.3117*exp((-(371.4))*x) +0.5284*(1 - exp((-(-0.2))*x)) -423.3*(1 + tanh(-27*(x-(-0.1715)))))
  
  x <- (grid_t-min(grid_t))/(max(grid_t)-min(grid_t))*(0.08-0.0045)+0.0045
  int_3 <- 100*(0.3 + 0.3117*exp((-(371.4))*x) +0.5284*(1 - exp((-(-4))*x)) -423.3*(1 + tanh(-24*(x-(-0.1715)))))
  
  int_2 <- (1-delta)*int_1 + (delta)*int_2
  int_3 <- (1-delta)*int_1 + (delta)*int_3
  
  b1 <- (delta_int)*beta_1(grid_s,grid_t)
  b2 <- (delta_int)*b2
  b3 <- (delta_int)*b3
  
  int_1 <- (1 - delta_int)*int_1
  int_2 <- (1 - delta_int)*int_2
  int_3 <- (1 - delta_int)*int_3
  
  Y_parz1<-(1/length(grid_s))*t(t(X_eval[,1:round(n_obs/3)])%*%b1) + int_1
  Y_parz2<-(1/length(grid_s))*t(t(X_eval[,(round(n_obs/3)+1):(2*round(n_obs/3))])%*%b2) + int_2
  Y_parz3<-(1/length(grid_s))*t(t(X_eval[,((2*round(n_obs/3))+1):n_obs])%*%b3) + int_3
  
  signal_to_noise_ratio<-SNR
  
  # num <- (mixing_prop%*%(rbind(rowVars(Y_parz1)+rowVars(Eps[[1]]),rowVars(Y_parz2)+rowVars(Eps[[2]]),rowVars(Y_parz3)+rowVars(Eps[[3]]))))
  # den <- (signal_to_noise_ratio - 1)*(mixing_prop%*%rbind(rowVars(Eps[[1]]),rowVars(Eps[[2]]),rowVars(Eps[[3]])))
  # h<- as.numeric(sqrt(num/den))
  # Y1 = Y_parz1 + diag(h)%*%Eps[[1]]
  # Y2 = Y_parz2 + diag(h)%*%Eps[[2]]
  # Y3 = Y_parz3 + diag(h)%*%Eps[[3]]
  
  num <-rowVars(Y_parz1) + rowVars(Eps[[1]])
  den <- signal_to_noise_ratio*(rowVars(Eps[[1]]))
  h <- as.numeric(sqrt(num/den))
  Y1 = Y_parz1 + diag(h)%*%Eps[[1]]
  
  num <-rowVars(Y_parz2) + rowVars(Eps[[2]])
  den <- signal_to_noise_ratio*(rowVars(Eps[[2]]))
  h <- as.numeric(sqrt(num/den))
  Y2 = Y_parz2 + diag(h)%*%Eps[[2]]
  
  num <-rowVars(Y_parz3) + rowVars(Eps[[3]])
  den <- signal_to_noise_ratio*(rowVars(Eps[[3]]))
  h <- as.numeric(sqrt(num/den))
  Y3 = Y_parz3 + diag(h)%*%Eps[[3]]
  
  
  Y <- cbind(Y1,Y2,Y3)
  colnames(Y) <- NULL
  out<-list(X=X_eval,
            Y=Y,
            Eps_1=Eps[[1]],
            Eps_2=Eps[[2]],
            Eps_3=Eps[[3]],
            beta_matrix_1=b1,
            beta_matrix_2=b2,
            beta_matrix_3=b3)
  
  return(out)
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

## Conditional prediction in mixture regression ##

predict_mixture <- function(y = NULL , x = NULL , hard = F , model = NULL){
  
  #Conditions--------------------------------------------------------------
  if(is.null(y)){
    cat('y is missing')
  }
  
  if(is.null(x)){
    cat('x is missing')
  }
  
  if(is.null(model)){
    cat('model is missing')
  }
  
  #Initialization ---------------------------------------------------------
  y <- as.matrix(y)
  x <- as.matrix(x)
  p <- ncol(y)
  n <- nrow(y)
  Sigma <- model$Sigma
  B <- model$B
  prop <- model$prop
  k <- length(prop)
  z <- matrix(nrow = n , ncol = k)
  resp <- vector(mode = "list", length = k)
  y_cond <- matrix(rep(0,n*p) , nrow = n , ncol = p)
  y_hard <- matrix(rep(0,n*p) , nrow = n , ncol = p)
  
  #Compute the posterior probabilities-------------------------------------
  comp <- lapply(1:k, function(i){ lk <-
    diag((1/((2*pi)^(p/2)*det(Sigma[[i]])^0.5))*exp(-0.5*(y-x%*%B[[i]])%*%solve(Sigma[[i]])%*%t(y-x%*%B[[i]])))
  prop[i] * lk})
  
  comp <- sapply(comp, cbind)
  if (!is.matrix(comp)){
    comp <- t(as.matrix(comp))
  }
  
  comp[which(comp == 0)] <- 1e-100
  comp
  
  compsum <- apply(comp, 1, sum)
  
  for(kk in 1:k){
    z[,kk] <- comp[,kk]/compsum
  }
  
  # Compute the responses per group----------------------------------------
  for( kk in 1:k){
    resp[[kk]] <- x%*%B[[kk]]
  }
  
  #Conditional prediction--------------------------------------------------
  if (hard == F){
    
    # Compute the conditional responses---------------------------------------
    for ( i in 1:n){
      for( kk in 1:k){
        y_cond[i,] <- y_cond[i,] + z[i,kk]*resp[[kk]][i,]
      }
    }
    pred <- y_cond
  }else{
    hard_membership <- apply(z,FUN = which.max,MARGIN = 1)
    for (kk in 1:k){
      z[,kk] <-as.numeric(hard_membership == kk)
    }
    
    # Compute the conditional responses---------------------------------------
    for ( i in 1:n){
      for( kk in 1:k){
        y_hard[i,] <- y_hard[i,] + z[i,kk]*resp[[kk]][i,]
      }
    }
    pred <- y_hard
  }
  
  return(list(
    prediction = pred,
    membership = z
  ))
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

# Simulate Shift Data

simulate_shift_data <- function(n_obs=3000 , mixing_prop = c(1/3,1/3,1/3), len_grid = 500 , SNR = 4 , shift_coef = c(0,0,0,0),severity,sigma_equal=T,
                                ncompx = 3 , delta, delta_int ){
  
  delta_shift <- 0
  
  k <- length(mixing_prop)
  
  length_tot<-len_grid
  domain <- c(0,1)
  grid_s<-grid_t<-seq(0,1,length.out = length_tot)
  mixing_prop <- matrix(mixing_prop,nrow = 1)
  
  # generate X --------------------------------------------------------------
  
  X_fd <- simulate_x(nobs = n_obs , n_comp = ncompx, gamma = 1)
  X_eval <- (1/5)*eval.fd(grid_s , X_fd)[,,1]
  
  # Generate ERROR ----------------------------------------------------------
  
  n_basis_eps<-20 #random chosen between 10 and 50
  eps_basis<-create.bspline.basis(domain,norder = 4,nbasis = n_basis_eps)
  eps_coef <- vector(mode = "list", length = k)
  eps_fd <- vector(mode = "list", length = k)
  Eps <- vector(mode = "list", length = k)
  
  if(sigma_equal){
    for( kk in 1:k){
      eps_coef[[kk]] <- matrix(rnorm(round(n_obs*mixing_prop[kk])*n_basis_eps,mean = 0),nrow = n_basis_eps,ncol = round(n_obs*mixing_prop[kk]))
      eps_fd[[kk]] <- fd(eps_coef[[kk]],eps_basis)
      Eps[[kk]] <- eval.fd(grid_t,eps_fd[[kk]])
    }  
  }else{
    for(kk in 1:k){
      eps_coef[[kk]] <- matrix(rnorm(round(n_obs*mixing_prop[kk])*n_basis_eps,mean = 0,sd = 3*kk),nrow = n_basis_eps,ncol = round(n_obs*mixing_prop[kk]))
      eps_fd[[kk]] <- fd(eps_coef[[kk]],eps_basis)
      Eps[[kk]] <- eval.fd(grid_t,eps_fd[[kk]])
    }
  }
  
  # Define beta -----------------------------------------------------------
  
  beta_1<-function(s,t){
    a=0.3
    b=0.3
    c=0.3
    d=0.3
    f_1<-function(s,t){(((t-0.5)/c)^3+((s-0.5)/d)^3 + ((t-0.5)/b)^2 - ((s-0.5)/a)^2+5)}
    z<- outer(s,t,f_1)
    z}
  
  beta_2<-function(s,t){
    a=0.2  #0.2
    b=0.15 #0.15
    c=0.9  #0.9
    d=0.9  #0.9
    f_1<-function(s,t){(((t-0.5)/c)^3+((s-0.5)/d)^3+((t-0.5)/b)^2 - ((s-0.5)/a)^2+5)}
    z<- outer(s,t,f_1)
    z}
  
  beta_3<-function(s,t){
    a=0.3  #0.9
    b=0.3  #0.9
    c=0.3 #-0.3
    d=0.3  #-0.3
    f_1<-function(s,t){-(((t-0.5)/c)^3+((s-0.5)/d)^3+((t-0.5)/b)^2 - ((s-0.5)/a)^2+5)}
    z<- outer(s,t,f_1)
    z}
  
  b2 <- (1-delta)*beta_1(grid_s,grid_t) + (delta)*beta_2(grid_s,grid_t)
  b3 <- (1-delta)*beta_1(grid_s,grid_t) + (delta)*beta_3(grid_s,grid_t)
  
  x <- (grid_t-min(grid_t))/(max(grid_t)-min(grid_t))*(0.15-0.0045)+0.0045
  int_1 <- 100*(0.2074 + 0.3117*exp((-(371.4))*x) +0.5284*(1 - exp((-(-0.8217))*x)) -423.3*(1 + tanh(-26.15*(x-(-0.1715)))))
  
  x <- (grid_t-min(grid_t))/(max(grid_t)-min(grid_t))*(0.4-0.0045)+0.0045
  int_2 <- 100*(0.187 + 0.3117*exp((-(371.4))*x) +0.5284*(1 - exp((-(-0.2))*x)) -423.3*(1 + tanh(-27*(x-(-0.1715)))))
  
  x <- (grid_t-min(grid_t))/(max(grid_t)-min(grid_t))*(0.08-0.0045)+0.0045
  int_3 <- 100*(0.3 + 0.3117*exp((-(371.4))*x) +0.5284*(1 - exp((-(-4))*x)) -423.3*(1 + tanh(-24*(x-(-0.1715)))))
  
  int_2 <- (1-delta)*int_1 + (delta)*int_2
  int_3 <- (1-delta)*int_1 + (delta)*int_3
  
  b1 <- (delta_int)*beta_1(grid_s,grid_t)
  b2 <- (delta_int)*b2
  b3 <- (delta_int)*b3
  
  int_1 <- (1 - delta_int)*int_1
  int_2 <- (1 - delta_int)*int_2
  int_3 <- (1 - delta_int)*int_3
  
  Y_parz1<-(1/length(grid_s))*t(t(X_eval[,1:round(n_obs/3)])%*%b1) + int_1
  Y_parz2<-(1/length(grid_s))*t(t(X_eval[,(round(n_obs/3)+1):(2*round(n_obs/3))])%*%b2) + int_2
  Y_parz3<-(1/length(grid_s))*t(t(X_eval[,((2*round(n_obs/3))+1):n_obs])%*%b3) + int_3
  
  signal_to_noise_ratio<-SNR
  # 
  # num <- (mixing_prop%*%(rbind(rowVars(Y_parz1)+rowVars(Eps[[1]]),rowVars(Y_parz2)+rowVars(Eps[[2]]),rowVars(Y_parz3)+rowVars(Eps[[3]]))))
  # den <- (signal_to_noise_ratio - 1)*(mixing_prop%*%rbind(rowVars(Eps[[1]]),rowVars(Eps[[2]]),rowVars(Eps[[3]])))
  # h<- as.numeric(sqrt(num/den))
  # 
  
  num <-rowVars(Y_parz1) + rowVars(Eps[[1]])
  den <- signal_to_noise_ratio*(rowVars(Eps[[1]]))
  h1 <- as.numeric(sqrt(num/den))
  
  num <-rowVars(Y_parz2) + rowVars(Eps[[2]])
  den <- signal_to_noise_ratio*(rowVars(Eps[[2]]))
  h2 <- as.numeric(sqrt(num/den))
  
  num <-rowVars(Y_parz3) + rowVars(Eps[[3]])
  den <- signal_to_noise_ratio*(rowVars(Eps[[3]]))
  h3 <- as.numeric(sqrt(num/den))
  
  
  
  Shift <- severity*shift_coef[1]*(grid_t)^3 + severity*shift_coef[2]*(grid_t)^2 + severity*shift_coef[3]*(grid_t) + severity*shift_coef[4]
  
  
  int_2 <- (1-delta_shift)*int_1 + (delta_shift)*int_2
  int_3 <- (1-delta_shift)*int_1 + (delta_shift)*int_3
  
  b2 <- b1
  b3 <- b1
  
  Y_parz1<-(1/length(grid_s))*t(t(X_eval[,1:round(n_obs/3)])%*%b1) + int_1
  Y_parz2<-(1/length(grid_s))*t(t(X_eval[,(round(n_obs/3)+1):(2*round(n_obs/3))])%*%b2) + int_2
  Y_parz3<-(1/length(grid_s))*t(t(X_eval[,((2*round(n_obs/3))+1):n_obs])%*%b3) + int_3
  
  Y1 = Y_parz1 + diag(h1)%*%Eps[[1]]
  Y2 = Y_parz2 + diag(h1)%*%Eps[[2]]
  Y3 = Y_parz3 + diag(h1)%*%Eps[[3]]
  
  Y1_shift <- Y1 + Shift
  Y2_shift <- Y2 + Shift
  Y3_shift <- Y3 + Shift
  
  Y <- cbind(Y1_shift,Y2_shift,Y3_shift)
  colnames(Y) <- NULL
  out<-list(X=X_eval,
            Y=Y,
            Eps_1=Eps[[1]],
            Eps_2=Eps[[2]],
            Eps_3=Eps[[3]],
            beta_matrix_1=b1,
            beta_matrix_2=b2,
            beta_matrix_3=b3,
            Shift = Shift)
  
  return(out)
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

## Phase II

phase_II <- function(loglikelihood = NULL , limits = NULL){
  
  status <- (loglikelihood > limits)
  status[which(status == T)] <- 'OC'
  status[which(status == F)] <- 'IC'
  df <- data.frame(id = 1:length(status),loglikelihood = loglikelihood,status = status)
  
  alpha <- sum(status == 'OC')/length(status)
  
  ARL <- 1 / (1 - ( 1 - alpha ))
  
  return(list(df = df,
              ARL = ARL))
  
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

# Plot Control Charts -------------------------------------------------------------

plot_cc <- function(df = NULL, limits = NULL , df_phaseI = NULL){
  
  if (!is.data.frame(df)) {
    stop(paste0("df must be a data frame ", "containing data to produce control charts."))
  }
  
  if(is.data.frame(df_phaseI)){
    df <- rbind(df_phaseI,df)
    df$id <- 1:nrow(df)
    v_line <- nrow(df_phaseI)
  }
  
  df_stat <- NULL
  if (!is.null(df$loglikelihood)) {
    df_stat <- data.frame(statistic = df$loglikelihood, lcl =min(df$loglikelihood), 
                          ucl = limits) %>% dplyr::mutate(id = seq_len(n()), 
                                                          ooc = .data$statistic > .data$ucl, type = "FMRCC~CONTROL~CHART")
    
    stat_range <- df_stat %>% dplyr::select(.data$statistic, .data$ucl, 
                                            .data$lcl) %>% range() %>% diff()
    df_stat <- df_stat %>% dplyr::mutate(ytext = case_when(statistic < 
                                                             lcl ~ statistic - stat_range * 0.2, statistic > ucl ~ 
                                                             statistic + stat_range * 0.2, TRUE ~ statistic, ))
  }
  
  
  plot_list <- list()
  if (!is.null(df$loglikelihood)) {
    plot_list$p_lik <- ggplot(df_stat, aes(x = .data$id, 
                                           y = .data$statistic)) + geom_line() + geom_point(aes(colour = .data$ooc)) + 
      # geom_blank(aes(y = min(df$loglikelihood))) +
      geom_point(aes(y = .data$ucl), 
                 pch = "-", size = 5) + theme_bw() + theme(axis.text.x = element_text(angle = 90, 
                                                                                      vjust = 0.5)) + theme(legend.position = "none", 
                                                                                                            plot.title = element_text(hjust = 0.5)) + 
      # geom_text(aes(y = .data$ytext, label = .data$id), data = filter(df_stat, .data$ooc), 
      #                                      size = 3) +
      xlab("Observation") + ylab(expression(FMRCC ~ 
                                              statistic)) + ggtitle(expression(FMRCC ~ 
                                                                                 CONTROL ~ CHART))+
      geom_vline(xintercept = v_line , col = 1 , size = 1)
  }
  
  
  p <- patchwork::wrap_plots(plot_list, ncol = 1) & scale_color_manual(values = c(`TRUE` = "red", 
                                                                                  `FALSE` = "black", phase1 = "grey")) & scale_x_continuous(limits = c(0, 
                                                                                                                                                       nrow(df) + 1), breaks = seq(1, nrow(df), by = round(nrow(df)/50) + 
                                                                                                                                                                                     1), expand = c(0.015, 0.015))
  
  
  return(p)
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

## EM estimate ## ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
estimate_mixture <- function(y = NULL , x = NULL , num_iterations = 10 , max_group = 5, selectK = NULL , mode = 'regression',intercept = T,init_met='kmeans'){
  
  num_iterations <- num_iterations
  if(is.null(selectK)){
    
    num_groups <- 1:max_group
    
  }else{
    num_groups <- selectK
  }
  methods_sigma <- c('VVV','EEE','VII','EII')
  minBIC <- 1000000
  minBIC_clust <- 100000
  BIC <- matrix(nrow = length(methods_sigma), ncol = max(num_groups))
  models <- vector(mode = 'list', length = length(num_groups))
  
  if(mode == 'regression'){
    for(k in num_groups){
      #cat('\n-----------------------------','\nGroups = ',k)
      # BIC_met_sigma <- numeric(length(methods_sigma))
      h <- 0
      for(hh in methods_sigma){
        h <- h+ 1
        BIC_group <- numeric(num_iterations)
        for (i in 1:num_iterations){
          #cat('\nIteration n ',i,'\tk = ',k,'\tSigma ',hh,'\n')
          est <- mixregfit_multivariate(y,x,k = k, init_met = init_met,intercept = intercept,eps = 1e-03, max_iter = 500,model_Sigma = hh)
          if(is.na(est[1])) {
            #cat('\n NA generated, passing to the next iteration \n')
            BIC_group[i] <- 1000000
            next}
          #cat('\nLogLikelihood = ',est$logLik,'\n')
          #cat('BIC = ',est$BIC,'\n')
          BIC_group[i] <- est$BIC
          if(BIC_group[i] < minBIC_clust){
            minBIC_clust <- BIC_group[i]
            if(minBIC_clust < minBIC){
              model <- est
              minBIC <- minBIC_clust  
            }
          }
        }
        BIC[h,k] <- min(BIC_group)
        # names(models)[k] <- paste('Model',k)
        minBIC_clust <- 100000
      }
      
    }
    
    BIC <- as.data.frame(BIC)
    rownames(BIC) <- methods_sigma
    
    # Choice of k
    if(!is.null(selectK)){
      best_model <- model
      num_groups <- selectK
    }else{
      best_model <- model
      num_groups <- length(best_model$prop)
    }
    
    # Matrix for Residuals variance 
    x <- as.matrix(x)
    if(intercept){
      if(sum(x[,1]!=1)!=0){
        x <- cbind(1,x)
      }
    }
    
    H <- list(num_groups)
    
    for(kk in 1:num_groups){
      H[[kk]] <- solve(t(x)%*%diag(best_model$z[,kk])%*%x)%*%t(x)%*%diag(best_model$z[,kk])
      H[[kk]] <- H[[kk]]%*%t(H[[kk]])  
    }
    
    return(list(best_model = best_model,
                H = H,
                BIC = BIC))  
  }
  
  if(mode == 'clustering'){
    y <- as.matrix(y)
    x <- matrix(1, ncol = 1 , nrow = nrow(y))
    for(k in num_groups){
      #cat('\n-----------------------------','\nGroups = ',k)
      # BIC_met_sigma <- numeric(length(methods_sigma))
      h <- 0
      for(hh in methods_sigma){
        h <- h+ 1
        BIC_group <- numeric(num_iterations)
        for (i in 1:num_iterations){
          #cat('\nIteration n ',i,'\tk = ',k,'\tSigma ',hh,'\n')
          est <- mixregfit_multivariate(y,x,k = k, init_met = init_met,intercept = F,eps = 1e-03, max_iter = 500,model_Sigma = hh)
          if(is.na(est[1])) {
            #cat('\n NA generated, passing to the next iteration \n')
            BIC_group[i] <- 1000000
            next}
          #cat('\nLogLikelihood = ',est$logLik,'\n')
          #cat('BIC = ',est$BIC,'\n')
          BIC_group[i] <- est$BIC
          if(BIC_group[i] < minBIC_clust){
            minBIC_clust <- BIC_group[i]
            if(minBIC_clust < minBIC){
              model <- est
              minBIC <- minBIC_clust  
            }
          }
        }
        BIC[h,k] <- min(BIC_group)
        # names(models)[k] <- paste('Model',k)
        minBIC_clust <- 100000
      }
      
    }
    
    BIC <- as.data.frame(BIC)
    rownames(BIC) <- methods_sigma
    
    # Choice of k
    if(!is.null(selectK)){
      best_model <- model
      num_groups <- selectK
    }else{
      best_model <- model
      num_groups <- length(best_model$prop)
    }
    
    return(list(best_model = best_model,
                BIC = BIC)) 
  }
  
}


#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

phaseI_residuals <- function(Y_tuning_mfd = NULL , X_tuning_mfd = NULL , fpca_results = NULL , model = NULL , alpha = NULL , intercept = T , SPE = F){
  
  # Standardization and score calculation
  y_tuning_std_mfd <- scale_mfd(mfdobj = Y_tuning_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  y_score_new <- get_scores(pca = fpca_results$pcay , components = 1:fpca_results$ncomponents_y , newdata_scaled = y_tuning_std_mfd)
  
  if(SPE){
    y_hat_z <- get_fun_from_scores(y_score_new, fpca_results$pcay$harmonics[1:fpca_results$ncomponents_y])
    y_hat <- descale_mfd(y_hat_z, center = fpca_results$pcay$center_fd, 
                         scale = fpca_results$pcay$scale_fd)
    res_fd <- minus.fd(Y_tuning_mfd, y_hat)
    res_mfd <- mfd(res_fd$coefs, res_fd$basis, res_fd$fdnames, 
                   B = res_fd$basis$B)
    cont_spe <- inprod_mfd_diag(res_mfd)
    colnames(cont_spe) <- rownames(cont_spe) <- NULL
    spe <- rowSums(cont_spe)
    
    y_score_new <- cbind(y_score_new,log(spe))
  }
  
  if(is.mfd(X_tuning_mfd)){
    
    x_tuning_std_mfd <- scale_mfd(mfdobj = X_tuning_mfd , center = fpca_results$pcax$center_fd , scale = fpca_results$pcax$scale_fd)
    x_score_new <- get_scores(pca = fpca_results$pcax , components = 1:fpca_results$ncomponents_x , newdata_scaled = x_tuning_std_mfd)
    
  }else{
    
    x_score_new <- as.matrix(X_tuning_mfd)
    
  }
  
  if(intercept){
    x_score_new <- cbind(rep(1,nrow(x_score_new)),x_score_new)
  }
  p <- ncol(y_score_new)
  num_groups <- length(model$prop)
  
  comp <- lapply(1:num_groups, function(i){ lk <-
    diag((det(model$Sigma[[i]])^0.5)*exp(-0.5*(y_score_new-x_score_new%*%model$B[[i]])%*%solve(model$Sigma[[i]])%*%t(y_score_new-x_score_new%*%model$B[[i]])))
  model$prop[i] * lk})
  comp <- sapply(comp, cbind)
  compsum <- log(apply(comp, 1, sum))
  
  lim <- quantile(-compsum,  1 -  alpha )
  
  status <- numeric(nrow(y_score_new))
  status[which(-compsum>lim)] <- 'OC'
  status[which(-compsum<=lim)] <- 'IC'
  
  df <- data.frame(id = 1:nrow(y_score_new),loglikelihood = -compsum , status = status)
  return(list(lim_residuals = lim,
              df = df))
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

phaseI_stud <- function(Y_tuning_mfd = NULL , X_tuning_mfd = NULL , fpca_results = NULL , model_estimate = NULL , alpha = NULL , intercept = T ,SPE = F){
  
  # Standardization and score calculation
  y_tuning_std_mfd <- scale_mfd(mfdobj = Y_tuning_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  y_score_new <- get_scores(pca = fpca_results$pcay , components = 1:fpca_results$ncomponents_y , newdata_scaled = y_tuning_std_mfd)
  
  if(SPE){
    y_hat_z <- get_fun_from_scores(y_score_new, fpca_results$pcay$harmonics[1:fpca_results$ncomponents_y])
    y_hat <- descale_mfd(y_hat_z, center = fpca_results$pcay$center_fd, 
                         scale = fpca_results$pcay$scale_fd)
    res_fd <- minus.fd(Y_tuning_mfd, y_hat)
    res_mfd <- mfd(res_fd$coefs, res_fd$basis, res_fd$fdnames, 
                   B = res_fd$basis$B)
    cont_spe <- inprod_mfd_diag(res_mfd)
    colnames(cont_spe) <- rownames(cont_spe) <- NULL
    spe <- rowSums(cont_spe)
    
    y_score_new <- cbind(y_score_new,log(spe))
  }
  
  if(is.mfd(X_tuning_mfd)){
    
    x_tuning_std_mfd <- scale_mfd(mfdobj = X_tuning_mfd , center = fpca_results$pcax$center_fd , scale = fpca_results$pcax$scale_fd)
    x_score_new <- get_scores(pca = fpca_results$pcax , components = 1:fpca_results$ncomponents_x , newdata_scaled = x_tuning_std_mfd)
    
  }else{
    x_score_new <- as.matrix(X_tuning_mfd)
  }
  
  if(intercept){
    x_score_new <- cbind(rep(1,nrow(x_score_new)),x_score_new)
  }
  
  best_model <- model_estimate$best_model
  p <- ncol(y_score_new)
  num_groups <- length(best_model$prop)
  
  # Tuning Residuals variance
  I_tun <- diag(1, nrow = nrow(y_score_new))
  c_tuning <- list(num_groups)
  
  for(kk in 1:num_groups){
    c_tuning[[kk]] <- as.numeric(diag(I_tun + x_score_new%*%model_estimate$H[[kk]]%*%t(x_score_new)))
  }
  
  c_tuning <- sapply(c_tuning , cbind)
  compsum_stud <- matrix(nrow = nrow(y_score_new) , ncol = num_groups)
  
  for(ii in 1:nrow(y_score_new)){
    comp <- lapply(1:num_groups, function(i){ lk <-
      diag((det(c_tuning[ii,i]*best_model$Sigma[[i]])^0.5)*exp(-0.5*(y_score_new[ii,]-x_score_new[ii,]%*%best_model$B[[i]])%*%solve(c_tuning[ii,i]*best_model$Sigma[[i]])%*%t(y_score_new[ii,]-x_score_new[ii,]%*%best_model$B[[i]])))
    best_model$prop[i] * lk})
    compsum_stud[ii,] <- sapply(comp,cbind)
  }
  
  compsum_stud <- log(apply(compsum_stud,1,sum))
  
  lim_stud <- quantile(-compsum_stud, 1 - alpha)
  
  status <- numeric(nrow(y_score_new))
  status[which(-compsum_stud>lim_stud)] <- 'OC'
  status[which(-compsum_stud<=lim_stud)] <- 'IC'
  
  df <- data.frame(id = 1:nrow(y_score_new),loglikelihood = -compsum_stud , status = status)
  return(list(lim_stud = lim_stud,
              df = df))
}


#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

# plot_cc_cluster <- function(phase = NULL , clust = NULL , lim = NULL){
#   
#   fig <- list()
#   df_T2 <- phase$df[[clust]] %>% 
#     select(id,T2 ,status_T2)
#   
#   df_T2 <- df_T2 %>% rename(loglikelihood = T2 , status = status_T2)
#   
#   df_SPE <- phase$df[[clust]] %>% 
#     select(id,SPE,status_SPE)
#   
#   df_SPE <- df_SPE %>% rename(loglikelihood = SPE  , status = status_SPE)
#   
#   fig[[1]] <- plot_cc(df = df_T2 , limits = lim$lim_T2[clust] ,title = paste('T2 Control Chart Cluster',clust),ylabel = 'T2 Statistic')
#   fig[[2]] <- plot_cc(df = df_SPE , limits = lim$lim_SPE[clust] ,title = paste('SPE Control Chart Cluster',clust),ylabel = 'SPE Statistic')
#   
#   ggarrange(plotlist = fig , ncol = 1 , nrow = 2)
# 
# }

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

phaseII_residuals <- function(Y_testing_mfd = NULL , X_testing_mfd = NULL , fpca_results = NULL , model = NULL , limits = NULL , intercept = T , SPE = F){
  
  # Standardization and score calculation
  y_testing_std_mfd <- scale_mfd(mfdobj = Y_testing_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  y_score_new <- get_scores(pca = fpca_results$pcay , components = 1:fpca_results$ncomponents_y , newdata_scaled = y_testing_std_mfd)
  
  if(SPE){
    y_hat_z <- get_fun_from_scores(y_score_new, fpca_results$pcay$harmonics[1:fpca_results$ncomponents_y])
    y_hat <- descale_mfd(y_hat_z, center = fpca_results$pcay$center_fd, 
                         scale = fpca_results$pcay$scale_fd)
    res_fd <- minus.fd(Y_testing_mfd, y_hat)
    res_mfd <- mfd(res_fd$coefs, res_fd$basis, res_fd$fdnames, 
                   B = res_fd$basis$B)
    cont_spe <- inprod_mfd_diag(res_mfd)
    colnames(cont_spe) <- rownames(cont_spe) <- NULL
    spe <- rowSums(cont_spe)
    
    y_score_new <- cbind(y_score_new,log(spe))
  }
  
  if(is.mfd(X_testing_mfd)){
    
    x_testing_std_mfd <- scale_mfd(mfdobj = X_testing_mfd , center = fpca_results$pcax$center_fd , scale = fpca_results$pcax$scale_fd)
    x_score_new <- get_scores(pca = fpca_results$pcax , components = 1:fpca_results$ncomponents_x , newdata_scaled = x_testing_std_mfd)
    
  }else{
    x_score_new <- as.matrix(X_testing_mfd)
  }
  
  if(intercept){
    x_score_new <- cbind(rep(1,nrow(x_score_new)),x_score_new)
  }
  
  best_model <- model
  p <- ncol(y_score_new)
  num_groups <- length(best_model$prop)
  
  ## Phase II on Residuals ## /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  comp <- lapply(1:num_groups, function(i){ lk <-
    diag((det(best_model$Sigma[[i]])^0.5)*exp(-0.5*(y_score_new-x_score_new%*%best_model$B[[i]])%*%solve(best_model$Sigma[[i]])%*%t(y_score_new-x_score_new%*%best_model$B[[i]])))
  best_model$prop[i] * lk})
  comp <- sapply(comp, cbind)
  compsum <- log(apply(comp, 1, sum))
  
  phaseII_list <- phase_II(loglikelihood = -compsum , limits = limits)
  return(phaseII_list)
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

phaseII_stud <- function(Y_testing_mfd = NULL , X_testing_mfd = NULL , fpca_results = NULL , model_estimate = NULL , limits = NULL , intercept = T , SPE = F){
  
  # Standardization and score calculation
  y_testing_std_mfd <- scale_mfd(mfdobj = Y_testing_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  y_score_new <- get_scores(pca = fpca_results$pcay , components = 1:fpca_results$ncomponents_y , newdata_scaled = y_testing_std_mfd)
  
  if(SPE){
    y_hat_z <- get_fun_from_scores(y_score_new, fpca_results$pcay$harmonics[1:fpca_results$ncomponents_y])
    y_hat <- descale_mfd(y_hat_z, center = fpca_results$pcay$center_fd, 
                         scale = fpca_results$pcay$scale_fd)
    res_fd <- minus.fd(Y_testing_mfd, y_hat)
    res_mfd <- mfd(res_fd$coefs, res_fd$basis, res_fd$fdnames, 
                   B = res_fd$basis$B)
    cont_spe <- inprod_mfd_diag(res_mfd)
    colnames(cont_spe) <- rownames(cont_spe) <- NULL
    spe <- rowSums(cont_spe)
    
    y_score_new <- cbind(y_score_new,log(spe))
  }
  
  if(is.mfd(X_testing_mfd)){
    
    x_testing_std_mfd <- scale_mfd(mfdobj = X_testing_mfd , center = fpca_results$pcax$center_fd , scale = fpca_results$pcax$scale_fd)
    x_score_new <- get_scores(pca = fpca_results$pcax , components = 1:fpca_results$ncomponents_x , newdata_scaled = x_testing_std_mfd)
    
  }else{
    x_score_new <- as.matrix(X_testing_mfd)
  }
  
  if(intercept){
    x_score_new <- cbind(rep(1,nrow(x_score_new)),x_score_new)
  }
  
  best_model <- model_estimate$best_model
  p <- ncol(y_score_new)
  num_groups <- length(best_model$prop)
  
  # testing Residuals variance
  I_tun <- diag(1, nrow = nrow(y_score_new))
  c_testing <- list(num_groups)
  
  for(kk in 1:num_groups){
    c_testing[[kk]] <- as.numeric(diag(I_tun + x_score_new%*%model_estimate$H[[kk]]%*%t(x_score_new)))
  }
  
  c_testing <- sapply(c_testing , cbind)
  compsum_stud <- matrix(nrow = nrow(y_score_new) , ncol = num_groups)
  
  for(ii in 1:nrow(y_score_new)){
    comp <- lapply(1:num_groups, function(i){ lk <-
      diag((det(c_testing[ii,i]*best_model$Sigma[[i]])^0.5)*exp(-0.5*(y_score_new[ii,]-x_score_new[ii,]%*%best_model$B[[i]])%*%solve(c_testing[ii,i]*best_model$Sigma[[i]])%*%t(y_score_new[ii,]-x_score_new[ii,]%*%best_model$B[[i]])))
    best_model$prop[i] * lk})
    compsum_stud[ii,] <- sapply(comp,cbind)
  }
  
  compsum_stud <- log(apply(compsum_stud,1,sum))
  
  phaseII_list <- phase_II(loglikelihood = -compsum_stud , limits = limits)
  return(phaseII_list)
  
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################


shift_vector_choice <- function(shift_case = NULL , type = NULL){
  
  if(shift_case == 'intercept'){
    if(type == 'constant'){
      shift_coef <- c(0,0,0,0.6)
    }
    
    if(type == 'linear'){
      shift_coef <- c(0,0,1.2,0)
    }
    
    if(type == 'quadratic'){
      shift_coef <- c(0,1.6,0,0)
    }
  }
  
  if(shift_case == 'beta'){
    if(type == 'constant'){
      shift_coef <- c(0,0,0,0.5)
    }
    
    if(type == 'linear'){
      shift_coef <- c(0,0,1,0)
    }
    
    if(type == 'quadratic'){
      shift_coef <- c(0,1.4,0,0)
    }
  }
  
  
  return(shift_coef)
}



#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

get_scores <- function (pca, components, newdata_scaled = NULL) 
{
  inprods <- get_pre_scores(pca, components, newdata_scaled)
  apply(inprods, 1:2, sum)
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

get_pre_scores <- function (pca, components, newdata_scaled = NULL) 
{
  if (missing(components)) {
    stop("components argument must be provided")
  }
  if (is.null(newdata_scaled)) {
    inprods <- pca$scores[, components, , drop = FALSE]
  }
  else {
    inprods <- inprod_mfd(newdata_scaled, pca$harmonics[components])
  }
  inprods
}
#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

my_FPCA <- function(Y_mfd , X_mfd=NULL , FVEy=NULL , FVEx = NULL , comp_y = NULL , comp_x = NULL,length_grid = 500,single_min_variance_explained = 0,scale = T){
  
  grid <- seq(0,1,length.out = length_grid)
  pca_y <- pca_mfd(mfdobj = Y_mfd ,scale = scale)
  
  if (is.null(comp_y)) {
    components_enough_var <- cumsum(pca_y$varprop) > FVEy
    if (sum(components_enough_var) == 0) 
      ncomponents <- length(pca_y$varprop)
    else ncomponents <- which(cumsum(pca_y$varprop) > FVEy)[1]
    components <- 1:ncomponents
    components <- which(pca_y$varprop[1:ncomponents] > single_min_variance_explained)
    comp_y <- ncomponents
    fpca_results <- list(pcay = pca_y,
                         ncomponents_y = ncomponents)
  }else{
    fpca_results <- list(pcay = pca_y,
                         ncomponents_y = comp_y)
  }
  
  if(!is.null(X_mfd)){
    pca_x <- pca_mfd(mfdobj = X_mfd ,scale = scale)
    if (is.null(comp_x)) {
      components_enough_var <- cumsum(pca_x$varprop) > FVEx
      if (sum(components_enough_var) == 0) 
        ncomponents_x <- length(pca_x$varprop)
      else ncomponents_x <- which(cumsum(pca_x$varprop) > FVEx)[1]
      components_x <- 1:ncomponents_x
      components_x <- which(pca_x$varprop[1:ncomponents_x] > single_min_variance_explained)
      
      fpca_results <- list(pcay = pca_y,
                           ncomponents_y = ncomponents,
                           pcax = pca_x,
                           ncomponents_x = ncomponents_x)
    }else{
      fpca_results <- list(pcay = pca_y,
                           ncomponents_y = comp_y,
                           pcax = pca_x,
                           ncomponents_x = comp_x)
    }
    
  }
  
  return(fpca_results)
  
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

get_fun_from_scores <- function (scores, harmonics) 
{
  basis <- harmonics$basis
  nbasis <- basis$nbasis
  basisnames <- basis$names
  variables <- harmonics$fdnames[[3]]
  nvar <- length(variables)
  obs <- rownames(scores)
  nobs <- nrow(scores)
  fit_coefs <- array(NA, dim = c(nbasis, nobs, nvar))
  dimnames(fit_coefs) <- list(basisnames, obs, variables)
  fit_coefs[] <- apply(harmonics$coefs, 3, function(x) x %*% 
                         t(scores))
  fdnames <- list(harmonics$fdnames[[1]], obs, variables)
  mfd(fit_coefs, basis, fdnames, B = basis$B)
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

descale_mfd <- function (scaled_mfd, center = FALSE, scale = FALSE) 
{
  if (!is.mfd(scaled_mfd)) 
    stop("scaled_mfd must be from class mfd")
  basis <- scaled_mfd$basis
  nbasis <- basis$nbasis
  nobs <- length(scaled_mfd$fdnames[[2]])
  nvar <- length(scaled_mfd$fdnames[[3]])
  if (is.fd(scale)) {
    coef_sd_list <- lapply(1:nvar, function(jj) {
      matrix(scale$coefs[, jj], nrow = nbasis, ncol = nobs)
    })
    coef_sd <- simplify2array(coef_sd_list)
    sd_fd <- fd(coef_sd, scaled_mfd$basis)
    centered <- times.fd(scaled_mfd, sd_fd, basisobj = basis)
  }
  else {
    if (is.logical(scale) & !scale & length(scale) == 1) {
      centered <- scaled_mfd
    }
    else {
      stop("scale must be either an mfd object or FALSE")
    }
  }
  if (is.fd(center)) {
    descaled_mean_list <- lapply(1:nvar, function(jj) {
      centered$coefs[, , jj] + center$coefs[, 1, jj]
    })
    descaled_coef <- simplify2array(descaled_mean_list)
  }
  else {
    if (is.logical(center) & !center & length(center) == 
        1) {
      descaled_coef <- centered$coef
    }
    else {
      stop("center must be either an mfd object or FALSE")
    }
  }
  mfd(descaled_coef, scaled_mfd$basis, scaled_mfd$fdnames, 
      B = scaled_mfd$basis$B)
}


#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

inprod_mfd_diag <- function (mfdobj1, mfdobj2 = NULL) 
{
  if (!is.mfd(mfdobj1)) {
    stop("Only mfd class allowed for mfdobj1 input")
  }
  if (!(is.fd(mfdobj2) | is.null(mfdobj2))) {
    stop("mfdobj2 input must be of class mfd, or NULL")
  }
  nvar1 <- dim(mfdobj1$coefs)[3]
  nobs1 <- dim(mfdobj1$coefs)[2]
  if (is.fd(mfdobj2)) {
    nvar2 <- dim(mfdobj2$coefs)[3]
    if (nvar1 != nvar2) {
      stop("mfdobj1 and mfdobj2 must have the same number of variables")
    }
    nobs2 <- dim(mfdobj2$coefs)[2]
    if (nobs1 != nobs2) {
      stop("mfdobj1 and mfdobj2 must have the same number of observations")
    }
  }
  if (is.null(mfdobj2)) 
    mfdobj2 <- mfdobj1
  if (identical(mfdobj1$basis, mfdobj2$basis)) {
    inprods <- sapply(1:nvar1, function(jj) {
      C1jj <- mfdobj1$coefs[, , jj]
      C2jj <- mfdobj2$coefs[, , jj]
      rowSums(as.matrix(t(C1jj) %*% mfdobj1$basis$B * 
                          t(C2jj)))
    })
  }
  else {
    inprods <- sapply(1:nvar1, function(jj) {
      fdobj1_jj <- fd(matrix(mfdobj1$coefs[, , jj], nrow = dim(mfdobj1$coefs)[1], 
                             ncol = dim(mfdobj1$coefs)[2]), mfdobj1$basis)
      if (is.null(mfdobj2)) {
        out <- inprod_fd_diag_single(fdobj1_jj)
      }
      else {
        fdobj2_jj <- fd(matrix(mfdobj2$coefs[, , jj], 
                               nrow = dim(mfdobj2$coefs)[1], ncol = dim(mfdobj2$coefs)[2]), 
                        mfdobj2$basis)
        out <- inprod_fd_diag_single(fdobj1_jj, fdobj2_jj)
      }
    })
  }
  if (nobs1 == 1) 
    inprods <- matrix(inprods, nrow = 1)
  inprods
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

# # Prediction interval by bootstrap ------------------------------------------------------------------
# 
# pred_int_bootstrap <- function(n_gen = NULL , Y_obs_fd = NULL , X_obs_fd = NULL , fpca_results = NULL , boot_models_model = NULL){
#   
#   samples_numb <- length(boot_models_model)
#   pred_list <- vector(mode = 'list' , length = samples_numb)
#   
#   for(bb in 1:samples_numb){
#     
#     # Functional observations generation
#     Y_obs_std_fd <- scale_fd(Y_obs_fd , center = fpca_results[[bb]]$mean_y_fd , scale = fpca_results[[bb]]$std_y_fd)
#     X_obs_std_fd <- scale_fd(X_obs_fd , center = fpca_results[[bb]]$mean_x_fd , scale = fpca_results[[bb]]$std_x_fd)
#     
#     y_std_eval <- eval.fd(grid , Y_obs_std_fd)
#     y_score_bb <- t(y_std_eval)%*%fpca_results[[bb]]$eigfun_y/length(grid)
#     x_std_eval <- eval.fd(grid , X_obs_std_fd)
#     x_score_bb <- t(x_std_eval)%*%fpca_results[[bb]]$eigfun_x/length(grid)
#     x_score_bb <- cbind(rep(1,nrow(x_score_bb)),x_score_bb)
#     
#     posterior <- predict_mixture(y = y_score_bb , x = x_score_bb , hard = F , model = boot_models_model[[bb]])$membership
#   
#     obs_gen_bb_std_fd <- from_post_gen(x_new_score = x_score_bb , posterior = posterior , model = boot_models_model[[bb]] , fpca_results = fpca_results[[bb]] , n_gen = n_gen)
#     obs_gen_bb_fd <- rescale_fd(obs_gen_bb_std_fd , center = fpca_results[[bb]]$mean_y_fd , scale = fpca_results[[bb]]$std_y_fd)
#     obs_gen_bb_eval <- eval.fd(grid , obs_gen_bb_fd)
#     pred_list[[bb]] <- obs_gen_bb_eval
# 
#   }
#   
#   pred_matrix <- do.call(cbind, pred_list)
#   
#   return(pred_matrix)
# }
# 
# #####################################################################################################################################################
# #///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
# #####################################################################################################################################################
# 
# # Confidence interval by bootstrap ------------------------------------------------------------------
# 
# conf_int_bootstrap <- function(n_gen = NULL , Y_obs_fd = NULL , X_obs_fd = NULL , fpca_results = NULL , boot_models_model = NULL){
#   
#   samples_numb <- length(boot_models_model)
#   pred_list <- vector(mode = 'list' , length = samples_numb)
#   
#   for(bb in 1:samples_numb){
#     
#     # Functional observations generation
#     Y_obs_std_fd <- scale_fd(Y_obs_fd , center = fpca_results[[bb]]$mean_y_fd , scale = fpca_results[[bb]]$std_y_fd)
#     X_obs_std_fd <- scale_fd(X_obs_fd , center = fpca_results[[bb]]$mean_x_fd , scale = fpca_results[[bb]]$std_x_fd)
#     
#     y_std_eval <- eval.fd(grid , Y_obs_std_fd)
#     y_score_bb <- t(y_std_eval)%*%fpca_results[[bb]]$eigfun_y/length(grid)
#     x_std_eval <- eval.fd(grid , X_obs_std_fd)
#     x_score_bb <- t(x_std_eval)%*%fpca_results[[bb]]$eigfun_x/length(grid)
#     x_score_bb <- cbind(rep(1,nrow(x_score_bb)),x_score_bb)
#     
#     prediction <- predict_mixture(y = y_score_bb , x = x_score_bb , hard = F , model = boot_models_model[[bb]])$prediction
#     prediction_eval <- fpca_results[[bb]]$eigfun_y%*%t(prediction)
#     prediction_std_fd <- smooth.basis(grid , prediction_eval , basis_y)$fd
#     prediction_fd <- rescale_fd(prediction_std_fd , center = fpca_results[[bb]]$mean_y_fd , scale = fpca_results[[bb]]$std_y_fd)
#     prediction_eval <- eval.fd(grid , prediction_fd)
#     pred_list[[bb]] <- prediction_eval
#     
#   }
#   
#   pred_matrix <- do.call(cbind, pred_list)
#   
#   return(pred_matrix)
# }


#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

# ## Bootstrap models ##

bootstrap_models <- function(Y_mfd, X_mfd , k = NULL , samples_numb = 20 , FVEthreshold_y = 0.90 , starts = 1 , ncomp_y = NULL){
  
  models <- vector(mode = "list", length = samples_numb)
  fpca_results <- vector(mode = "list" , length = samples_numb)
  n <- ncol(Y_mfd$coefs)
  
  for ( hh in 1:samples_numb){
    
    sample_idx <- sample(1:n , size = n , replace = T)
    Y_mfd_sampled <- Y_mfd[sample_idx]
    
    if(is.mfd(X_mfd)){
      X_mfd_sampled <- X_mfd[sample_idx]
      reduction <- my_FPCA(Y_mfd = Y_mfd_sampled ,X_mfd = X_mfd_sampled , FVEy = FVEthreshold_y, length_grid = 500)
      x <-reduction$pcax$pcscores[,1:reduction$ncomponents_x]
    }else{
      X_mfd_sampled <- X_mfd[sample_idx,]
      reduction <- my_FPCA(Y_mfd = Y_mfd_sampled ,FVEy = FVEthreshold_y, length_grid = 500)
      x <- X_mfd_sampled
    }
    
    y <- reduction$pcay$pcscores[,1:reduction$ncomponents_y]
    
    cat('\nModel',hh,'estimation...\n')
    
    models[[hh]] <- estimate_mixture(y = y , x = x , num_iterations = 1 , selectK = k , mode = 'regression' , intercept = T)
    
    cat('\n##########################\n#   Model',hh,'estimated!   #\n##########################\n')
    fpca_results[[hh]] <- reduction
    names(models)[hh] <- paste0('Model ',hh)
  }
  return(list(models = models , fpca_results = fpca_results))
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

# # Adjust Label Switching

adjust_label <- function(boot_models, best_model, fpca_res_best){
  
  num_groups <- length(best_model$prop)
  beta <- list()
  sigma <- list()
  a <- matrix(nrow = num_groups , ncol = num_groups)
  grid <- seq(0,1,length.out=500)
  harm_best_mod <- eval.fd(grid,fpca_res_best$pcay$harmonics[1:fpca_res_best$ncomponents_y])[,,1]
  
  for( kk in 1:length(boot_models$models)){
    
    harm <- eval.fd(evalarg = grid,boot_models$fpca_results[[kk]]$pcay$harmonics[1:boot_models$fpca_results[[kk]]$ncomponents_y])[,,1]
    
    for(hh in 1:num_groups){
      for( jj in 1:num_groups){
        beta[[jj]] <- as.matrix(boot_models$models[[kk]]$best_model$B[[jj]])%*%t(harm)
        # sigma[[jj]] <- harm%*%as.matrix(boot_models$models[[kk]]$best_model$Sigma[[jj]]%*%t(harm))
        m <-  best_model$B[[hh]]%*%t(harm_best_mod)
        a[jj,hh] <- sum((beta[[jj]] - best_model$B[[hh]]%*%t(harm_best_mod))^2)/500 
        # + 
        #   (sum((sigma[[jj]] - harm_best_mod%*%best_model$Sigma[[hh]]%*%t(harm_best_mod) )^2)/(500*500))
        # 
      }
    }
    # print(a)
    
    for(hh in 1 :num_groups){
      if(which.min(a[,hh]) != hh){
        print('diverso')
        aux <- boot_models$models[[kk]]$best_model$B[[which.min(a[,hh])]]
        boot_models$models[[kk]]$best_model$B[[which.min(a[,hh])]] <- boot_models$models[[kk]]$best_model$B[[hh]]
        boot_models$models[[kk]]$best_model$B[[hh]] <- aux
        
        aux <- boot_models$models[[kk]]$best_model$Sigma[[which.min(a[,hh])]]
        boot_models$models[[kk]]$best_model$Sigma[[which.min(a[,hh])]] <- boot_models$models[[kk]]$best_model$Sigma[[hh]]
        boot_models$models[[kk]]$best_model$Sigma[[hh]] <- aux
        
        aux <- boot_models$models[[kk]]$best_model$prop[which.min(a[,hh])]
        boot_models$models[[kk]]$best_model$prop[which.min(a[,hh])] <- boot_models$models[[kk]]$best_model$prop[hh]
        boot_models$models[[kk]]$best_model$prop[hh] <- aux
        
        aux <- boot_models$models[[kk]]$best_model$z[,which.min(a[,hh])]
        boot_models$models[[kk]]$best_model$z[,which.min(a[,hh])] <- boot_models$models[[kk]]$best_model$z[,hh]
        boot_models$models[[kk]]$best_model$z[,hh] <- aux
        
        boot_models$models[[kk]]$best_model$group_member <- apply(boot_models$models[[kk]]$best_model$z,FUN = which.max,MARGIN = 1)
        
        for(qq in 1:num_groups){
          for( uu in 1:num_groups){
            beta[[uu]] <- as.matrix(boot_models$models[[kk]]$best_model$B[[uu]])%*%t(harm)
            a[uu,qq] <- sum((beta[[uu]] - best_model$B[[qq]]%*%t(harm_best_mod))^2)/500
            
          }
        }
        
      }
      
    }
  }
  return(boot_models)
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

## Beta functions confidence interval ##

conf_int <- function(boot_models){
  
  grid <- seq(0,1 , length.out = 500)
  k <- length(boot_models$models$`Model 1`$best_model$prop)
  ncoef <- nrow(boot_models$models$`Model 1`$best_model$B[[1]])
  n_mod <- length(boot_models$models)
  conf_int <- vector(mode = 'list' , length = k)
  coef <- vector(mode = 'list' , length = ncoef)
  b <- matrix(nrow = n_mod , ncol = length(grid))
  
  for(kk in 1:k){
    for(n in 1:ncoef){
      for(ii in 1:n_mod){
        harm <- eval.fd(grid,boot_models$fpca_results[[ii]]$pcay$harmonics[1:boot_models$fpca_results[[ii]]$ncomponents_y])[,,1]
        b[ii,] <- as.matrix(boot_models$models[[ii]]$best_model$B[[kk]])[n,]%*%t(harm)
        
      }
      coef[[n]] <- b
      if(n==1) names(coef)[n] <- paste0('Intercept')else names(coef)[n] <- paste0('Coef ',n) 
    }
    conf_int[[kk]] <- coef
    names(conf_int)[kk] <- paste0('Cluster ',kk)
  }
  
  
  for(kk in 1:k){
    for(n in 1:ncoef){
      conf_int[[kk]][[n]] <- apply(X = conf_int[[kk]][[n]] , MARGIN = 2 , FUN = quantile , c(0.025,0.975))
    }
  }
  
  
  
  return(conf_int)
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

## Get_outliers_case_study

get_out_mfd <- function (mfdobj ,fvalue ) 
{
  xseq <- seq(0, 1, l = 200)
  nvar <- dim(mfdobj$coefs)[3]
  nobs <- dim(mfdobj$coefs)[2]
  if (nvar == 1) {
    fd_obj <- fd(mfdobj$coefs[, , 1], mfdobj$basis)
    fd_eval <- eval.fd(xseq, fd_obj)
    fData_obj <- roahd::fData(xseq, t(fd_eval))
  }
  else {
    fd_obj <- fd(mfdobj$coefs, mfdobj$basis)
    fd_eval <- eval.fd(xseq, fd_obj)
    fd_eval_list <- lapply(seq_len(nvar), function(ii) t(fd_eval[, 
                                                                 , ii]))
    fData_obj <- roahd::mfData(xseq, fd_eval_list)
  }
  is_outlier <- rep(FALSE, nobs)
  new_outliers <- 100
  while (length(new_outliers) > 0) {
    fbplot_obj <- roahd::fbplot(fData_obj[!is_outlier], 
                                display = FALSE , Fvalue = fvalue)
    new_outliers <- fbplot_obj$ID_outliers
    is_outlier[!is_outlier][new_outliers] <- TRUE
  }
  outliers <- which(is_outlier)
  names(outliers) <- mfdobj$fdnames[[2]][outliers]
  return(outliers)
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

## Parametric Bootstrap ##

parametric_bootstrap <- function(X_mfd  , samples_numb = 20 , FVEthreshold_y = 0.95 , starts = 1 , ncomp_y = NULL , mod , fpca){
  
  k <- length(mod$prop)
  models <- vector(mode = "list", length = samples_numb)
  fpca_results <- vector(mode = "list" , length = samples_numb)
  n <- nrow(mod$z)
  p <- nrow(mod$Sigma[[1]])
  
  for ( hh in 1:samples_numb){
    
    sample_idx <- sample(1:n , size = n , replace = T)
    
    if(is.mfd(X_mfd)){
      X_mfd_sampled <- X_mfd[sample_idx]
      reduction <- my_FPCA(Y_mfd = X_mfd_sampled , FVEy = FVEthreshold_y, length_grid = 500)
      x <-reduction$pcay$pcscores[,1:reduction$ncomponents_y]
      
    }else{
      X_mfd_sampled <- X_mfd[sample_idx,]
      x <- X_mfd_sampled
    }
    
    prop <- t(rmultinom(n = n , size = 1 , prob = mod$prop))
    pred <- vector(mode = 'list' , length = k)
    
    y_sim <- matrix(nrow = n, ncol = p)
    
    for ( ii in 1:n){
      x_new <- cbind(1,t(as.matrix(x[ii,])))
      if(p ==1){
        y_sim[ii,] <- rnorm(n = 1, mean = x_new%*%mod$B[[which(prop[ii,]==1)]] ,sd = sqrt(mod$Sigma[[which(prop[ii,]==1)]]))
      }else{
        y_sim[ii,] <- mvtnorm::rmvnorm(n = 1, mean =x_new%*%mod$B[[which(prop[ii,]==1)]] ,sigma =  mod$Sigma[[which(prop[ii,]==1)]])
        
      }
      
    }
    
    
    cat('\nModel',hh,'estimation...\n')
    
    models[[hh]] <- estimate_mixture(y = y_sim , x = x , num_iterations = 1 , selectK = k , mode = 'regression' , intercept = T)
    
    cat('\n##########################\n#   Model',hh,'estimated!   #\n##########################\n')
    names(models)[hh] <- paste0('Model ',hh)
    fpca_results[[hh]] <- fpca
    
  }
  return(list(models = models,fpca_results = fpca_results))
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

plot_results <- function(results, severity_idx){
  v <- c('A','B','C','D','E','F','G','H')
  palette1 <- vector(length = 10*length(v))
  k <- 0
  for(a in v){
    k <- k+1
    palette1[(10*(k-1)+1):(10*k)] <- viridis(n = 10,option = a , begin = 0 , end = 1)
  }
  
  palette <- palette1[c(41,7,38,49)]
  
  gg_color_hue <- function(n) {
    hues = seq(15, 375, length = n + 1)
    hcl(h = hues, l = 65, c = 100)[1:n]
  }
  palette <- gg_color_hue(6)
  # palette[1] <- "black"
  
  # ggplot()+
  #   geom_bar(aes(1:length(palette)),col = palette , fill = palette)
  
  palette[4]<- 'black'
  palette <- palette[c(4,5,3,1)]
  
  type <- c('constant' , 'linear' , 'quadratic')
  type_chosen <- 'quadratic'
  
  ARL <- colmeans(results)
  STD <- apply(FUN = sd , MARGIN = 2 , X = results)/sqrt(nrow(results))
  
  sev <- c(0,1,2,3,4)
  names=c('FMRCC','FRCC','FCC','CLUST')
  severity=rep(sev,4)
  method=as.factor(rep(names,each=5))
  levels(method) <- names
  
  pal_line <- 1:4
  
  df <- data.frame(SL = severity , mean = rep(NA,length(severity)) , method = method  ,sd = rep(NA,length(severity)) )
  df_res <- data.frame(SL = rep(severity_idx - 1 , 4) , mean = ARL , method = as.factor(names) , sd = STD)
  
  df <- left_join(df , df_res , by = c('SL','method'))
  df <- df[,c(1,3,5,6)]
  colnames(df) <- c('SL','method','mean','sd')
  
  plt <-  ggplot(df
                 ,aes(x=SL, y=mean, group=method, linetype=method, color=method, fill=method, shape=method))+
    geom_hline(yintercept =0.01,color="grey",size=0.8)+
    geom_hline(yintercept =0,color="black",size=0.8) +
    scale_shape_manual(values=c(16,15,17,18,25,4)) +
    scale_linetype_manual(values=c(1,2,3,4)) +
    geom_line()+
    geom_point(size = 3) +
    geom_errorbar(aes(ymin=mean-2*sd, ymax=mean+2*sd), width=.2,
                  position=position_dodge(0))+
    ylim(0,1)+
    scale_color_manual(values = palette)+
    ylab("FAR/TDR")+
    theme_bw()+
    theme(plot.title = element_text(size = 15),legend.title=element_blank(),legend.text = element_text(size = 15),legend.position = c(0.178,0.822),
          legend.background = element_rect(color = 'black'))
  return(plt)
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################


FMRCC_phaseI <- function(Y_training_mfd,X_training_mfd,Y_tuning_mfd,X_tuning_mfd,FVEy,FVEx,studentized = T,alpha = 0.01 , intercept = T , SPE = F ,
                         init_met = 'kmeans', num_iterations = 1 , max_group = 3){
  
  #/// FPCA PHASE ///#
  ## FPCA Training ##
  if(is.mfd(X_training_mfd)){
    
    fpca_results <- my_FPCA(X_mfd = X_training_mfd,Y_mfd = Y_training_mfd, FVEy = FVEy, length_grid = 500, FVEx = FVEx)
    score_x <- fpca_results$pcax$pcscores[,1:fpca_results$ncomponents_x]
    score_y <-  fpca_results$pcay$pcscores[,1:fpca_results$ncomponents_y]
    
  }else{
    fpca_results <- my_FPCA(Y_mfd = Y_training_mfd,FVEy = FVEy, length_grid = 500)
    score_x <- as.matrix(X_training_mfd)
    score_y <-  fpca_results$pcay$pcscores[,1:fpca_results$ncomponents_y]
  }
  
  
  if(SPE){
    y_hat_z <- get_fun_from_scores(score_y, fpca_results$pcay$harmonics[1:fpca_results$ncomponents_y])
    y_hat <- descale_mfd(y_hat_z, center = fpca_results$pcay$center_fd, 
                         scale = fpca_results$pcay$scale_fd)
    res_fd <- minus.fd(Y_training_mfd, y_hat)
    res_mfd <- mfd(res_fd$coefs, res_fd$basis, res_fd$fdnames, 
                   B = res_fd$basis$B)
    cont_spe <- inprod_mfd_diag(res_mfd)
    spe <- rowSums(cont_spe)
    
    score_y <- cbind(score_y,log(spe))
  }
  
  #/// MODELS ESTIMATION PHASE ///#
  if(init_met == 'kmeans') num_iterations <- 1
  ## FMR Model estimation ##
  estimate <- estimate_mixture(y = score_y , x = score_x , num_iterations = num_iterations , max_group = max_group ,mode = 'regression',intercept = intercept , init_met = init_met)
  best_model <- estimate$best_model
  num_groups <- length(best_model$prop)  
  
  #/// PHASE I ///#
  if(studentized){
    ## Phase I FMRCC on Studentized Residuals ##
    phaseI <- phaseI_stud(Y_tuning_mfd = Y_tuning_mfd , X_tuning_mfd = X_tuning_mfd , fpca_results = fpca_results , model_estimate = estimate , alpha = alpha , intercept = intercept , SPE = SPE)
    # plot_cc(df = stud_phaseI$df , limits = stud_phaseI$lim_stud)  
  }else{
    ## Phase I FMRCC on Residuals ##
    phaseI <- phaseI_residuals(Y_tuning_mfd = Y_tuning_mfd , X_tuning_mfd = X_tuning_mfd , fpca_results = fpca_results , model = best_model , alpha = alpha, intercept = intercept, SPE = SPE)
    # plot_cc(df = res_phaseI$df , limits = res_phaseI$lim_residuals)
  }
  
  plt <- NULL
  mod <- estimate
  a <- c(as.matrix(mod$BIC))
  a[which(a == 1000000)] <- NA
  b <- rep(c('VVV','EEE','VII','EII'),max_group)
  c <- rep(1:max_group,each = 4)
  BIC <- data.frame(BIC = a , method = b , n_clust = c)
  
  plt <- ggplot(BIC , aes(x = n_clust, y = BIC ,col = method, shape = method))+
    geom_point(size = 3)+
    scale_shape_manual(values=c(16,15,17,18))+
    geom_line(size = 1)+
    theme_bw()
  
  
  
  
  return(list(model = best_model,
              phaseI = phaseI,
              fpca = fpca_results,
              estimate = estimate,
              BIC_plt = plt))
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

FMRCC_phaseII <- function(Y_testing_mfd,X_testing_mfd,phaseI,studentized , intercept = T , SPE = F){
  #/// PHASE II  ///#
  if(studentized){
    ## Phase II FMRCC on Stundentized Residuals ##
    phaseII <- phaseII_stud(Y_testing_mfd = Y_testing_mfd , X_testing_mfd = X_testing_mfd , fpca_results = phaseI$fpca , model_estimate = phaseI$estimate ,limits = phaseI$phaseI$lim_stud , intercept = intercept , SPE = SPE)
    # plot_cc(df = stud_phaseII$df , limits = stud_phaseI$lim_stud)
    ARL <- phaseII$ARL
  }else{
    ## Phase II FMRCC on Residuals ##
    phaseII <- phaseII_residuals(Y_testing_mfd = Y_testing_mfd , X_testing_mfd = X_testing_mfd , fpca_results = phaseI$fpca , model = phaseI$model ,limits = phaseI$phaseI$lim_residuals, intercept = intercept , SPE = SPE)
    # plot_cc(df = res_phaseII$df , limits = res_phaseI$lim_residuals)
    ARL <- phaseII$ARL
  }
  return(list(ARL=ARL,
              phaseII = phaseII))
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

FRCC <- function(Y_training_mfd,X_training_mfd,Y_tuning_mfd,X_tuning_mfd,Y_testing_mfd,X_testing_mfd,FVEy,FVEx,FVEz,studentized = T,alpha = 0.01,SPE=T){
  
  mfdobj_y <- Y_training_mfd
  mfdobj_x <- X_training_mfd
  mfdobj_y_tuning <- Y_tuning_mfd
  mfdobj_x_tuning <- X_tuning_mfd
  mfdobj_y_new <- Y_testing_mfd
  mfdobj_x_new <- X_testing_mfd
  
  alpha_corr <- 1 - ( 1 - alpha )^0.5
  
  if(studentized){
    
    ## Studentized Residuals
    model_fof <- fof_pc(mfdobj_y = mfdobj_y , mfdobj_x = mfdobj_x, tot_variance_explained_x = FVEx , tot_variance_explained_y = FVEy , tot_variance_explained_res = FVEz, type_residuals = 'studentized')
    
    if(SPE){
      frcc_df <- regr_cc_fof(object = model_fof , mfdobj_y_tuning = mfdobj_y_tuning , mfdobj_x_tuning = mfdobj_x_tuning , mfdobj_y_new = mfdobj_y_new , mfdobj_x_new = mfdobj_x_new , alpha = list(T2 = alpha_corr,spe = alpha_corr))
      alpha <- sum(frcc_df$T2 > frcc_df$T2_lim | frcc_df$spe > frcc_df$spe_lim)/length(frcc_df$id)
      ARL_FRCC_stud <- 1 / (1 - ( 1 - alpha ))  
    }else{
      frcc_df <- regr_cc_fof(object = model_fof , mfdobj_y_tuning = mfdobj_y_tuning , mfdobj_x_tuning = mfdobj_x_tuning , mfdobj_y_new = mfdobj_y_new , mfdobj_x_new = mfdobj_x_new , alpha = list(T2 = alpha,spe = alpha_corr))
      alpha_tsq <- sum(frcc_df$T2 > frcc_df$T2_lim)/length(frcc_df$id)
      ARL_FRCC_stud <- 1 /alpha_tsq   
    }
    
    return(list(frcc_df=frcc_df,
                ARL = ARL_FRCC_stud,
                model_fof = model_fof))
  }else{
    ## Residuals
    model_fof <- fof_pc(mfdobj_y = mfdobj_y , mfdobj_x = mfdobj_x, tot_variance_explained_x = FVEx , tot_variance_explained_y = FVEy , tot_variance_explained_res = FVEz, type_residuals = 'standard')
    
    if(SPE){
      frcc_df <- regr_cc_fof(object = model_fof , mfdobj_y_tuning = mfdobj_y_tuning , mfdobj_x_tuning = mfdobj_x_tuning , mfdobj_y_new = mfdobj_y_new , mfdobj_x_new = mfdobj_x_new , alpha = list(T2 = alpha_corr,spe = alpha_corr))
      alpha <- sum(frcc_df$T2 > frcc_df$T2_lim | frcc_df$spe > frcc_df$spe_lim)/length(frcc_df$id)
      ARL_FRCC_res <- 1 / (1 - ( 1 - alpha ))  
    }else{
      frcc_df <- regr_cc_fof(object = model_fof , mfdobj_y_tuning = mfdobj_y_tuning , mfdobj_x_tuning = mfdobj_x_tuning , mfdobj_y_new = mfdobj_y_new , mfdobj_x_new = mfdobj_x_new , alpha = list(T2 = alpha,spe = alpha_corr))
      alpha_tsq <- sum(frcc_df$T2 > frcc_df$T2_lim)/length(frcc_df$id)
      ARL_FRCC_res <- 1 /alpha_tsq   
    }
    
    return(list(frcc_df=frcc_df,
                ARL = ARL_FRCC_res,
                model_fof = model_fof)) 
  }
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

FCC <- function(Y_training_mfd,Y_tuning_mfd,Y_testing_mfd,FVEy,alpha = 0.01,SPE=T , scale = T){
  
  mfdobj_y <- Y_training_mfd
  mfdobj_y_tuning <- Y_tuning_mfd
  mfdobj_y_new <- Y_testing_mfd
  
  alpha_corr <- 1 - ( 1 - alpha )^0.5
  
  ## FCC ##
  pca <- pca_mfd(mfdobj = mfdobj_y ,scale = scale)
  if(SPE){
    fcc_df <- control_charts_pca(pca = pca , tuning_data =mfdobj_y_tuning , newdata = mfdobj_y_new , tot_variance_explained = FVEy , alpha = list(T2 = alpha_corr,spe = alpha_corr))
    alpha <- sum(fcc_df$T2 > fcc_df$T2_lim | fcc_df$spe > fcc_df$spe_lim)/length(fcc_df$id)
    ARL_FCC <- 1 / (1 - ( 1 - alpha))
    
  }else{
    fcc_df <- control_charts_pca(pca = pca , tuning_data =mfdobj_y_tuning , newdata = mfdobj_y_new , tot_variance_explained = FVEy , alpha = list(T2 = alpha,spe = alpha_corr))
    alpha_tsq <- sum(fcc_df$T2 > fcc_df$T2_lim)/length(fcc_df$id)
    ARL_FCC <- 1 / alpha_tsq
  }
  
  return(list(fcc_df=fcc_df,
              ARL = ARL_FCC,
              pca = pca)) 
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

Clust <- function(Y_training_mfd,Y_tuning_mfd,FVEy,alpha = 0.01 , Y_testing_mfd , SPE =T , init_met = 'kmeans',num_iterations = 1 , max_group = 3){
  
  #/// FPCA PHASE ///#
  ## FPCA Training ##
  fpca_results <- my_FPCA(Y_mfd = Y_training_mfd,FVEy = FVEy, length_grid = 500)
  score_y <-  fpca_results$pcay$pcscores[,1:fpca_results$ncomponents_y]
  score_y <- as.matrix(score_y)
  #/// MODEL ESTIMATION PHASE ///#
  ## Model estimation ##
  if(init_met == 'kmeans') num_iterations <- 1
  
  estimate <- estimate_mixture(y = score_y , num_iterations =num_iterations  , max_group = max_group ,mode = 'clustering',init_met = init_met)
  best_model_clust <- estimate$best_model
  num_groups_clust <- length(best_model_clust$prop)  
  
  plt <- NULL
  mod <- estimate
  a <- c(as.matrix(mod$BIC))
  a[which(a == 1000000)] <- NA
  b <- rep(c('VVV','EEE','VII','EII'),max_group)
  c <- rep(1:max_group,each = 4)
  BIC <- data.frame(BIC = a , method = b , n_clust = c)
  
  plt <- ggplot(BIC , aes(x = n_clust, y = BIC ,col = method, shape = method))+
    geom_point(size = 3)+
    scale_shape_manual(values=c(16,15,17,18))+
    geom_line(size = 1)+
    theme_bw()
  
  
  # Standardization and score calculation tuning
  y_tuning_std_mfd <- scale_mfd(mfdobj = Y_tuning_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  y_score_new <- get_scores(pca = fpca_results$pcay , components = 1:fpca_results$ncomponents_y , newdata_scaled = y_tuning_std_mfd)
  
  
  # Standardization and score calculation testing
  y_testing_std_mfd <- scale_mfd(mfdobj = Y_testing_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  y_score_test <- get_scores(pca = fpca_results$pcay , components = 1:fpca_results$ncomponents_y , newdata_scaled = y_testing_std_mfd)
  
  
  membership_training <- predict_mixture(y = score_y, x = matrix(1 , nrow = nrow(score_y)) ,hard = T , model = best_model_clust)$membership
  membership_tuning <- predict_mixture(y = y_score_new, x = matrix(1 , nrow = nrow(y_score_new)) ,hard = T , model = best_model_clust)$membership
  membership_testing <- predict_mixture(y = y_score_test, x = matrix(1 , nrow = nrow(y_score_test)) ,hard = T , model = best_model_clust)$membership
  
  results <- vector(mode = 'list' , length = num_groups_clust)
  
  n_obs_training <- colsums(membership_training)
  n_obs_tuning <- colsums(membership_tuning)
  n_obs_testing <- colsums(membership_testing)
  
  for(kk in 1:num_groups_clust){
    
    if(sum(membership_testing[,kk]!=0)==0) next
    results[[kk]] <- FCC(Y_training_mfd = Y_training_mfd[which(membership_training[,kk]==1)],
                         Y_tuning_mfd = Y_tuning_mfd[which(membership_tuning[,kk]==1)],
                         Y_testing_mfd = Y_testing_mfd[which(membership_testing[,kk]==1)],
                         FVEy = FVEy,alpha = alpha,SPE = SPE)
    
  }
  
  # ARL
  OC <- 0
  
  if(SPE){
    for(kk in 1:num_groups_clust){
      OC <- OC + sum(results[[kk]]$fcc_df$T2 > results[[kk]]$fcc_df$T2_lim | results[[kk]]$fcc_df$spe > results[[kk]]$fcc_df$spe_lim )
    }
  }else{
    for(kk in 1:num_groups_clust){
      OC <- OC + sum(results[[kk]]$fcc_df$T2 > results[[kk]]$fcc_df$T2_lim)
    }
  }
  
  alpha <- OC/nrow(y_score_test)
  
  
  ARL <- 1 / (1 - ( 1 - alpha))
  
  return(list(ARL = ARL,
              Charts = results,
              model = best_model_clust,
              nobs = list(n_obs_testing = n_obs_testing,
                          n_obs_tuning = n_obs_tuning,
                          n_obs_training = n_obs_training),
              BIC_plt = plt))
}


#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

FRCC_fos <- function(Y_training_mfd , X_training , Y_tuning_mfd , X_tuning , Y_testing_mfd , X_testing , FVEy=0.90 , FVE_res = 0.90 , type_residuals = 'standard' , SPE = T , alpha = 0.01){
  
  ## FPCA Training ##
  fpca_results <- my_FPCA(Y_mfd = Y_training_mfd,FVEy = FVEy, length_grid = 500)
  score_y <-  fpca_results$pcay$pcscores[,1:fpca_results$ncomponents_y]
  y_training_mfd_scaled <- scale_mfd(mfdobj = Y_training_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  
  y_tuning_scaled_mfd <- scale_mfd(mfdobj = Y_tuning_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  y_tuning <- get_scores(pca = fpca_results$pcay , components = 1:fpca_results$ncomponents_y, newdata_scaled = y_tuning_scaled_mfd)
  y_testing_scaled_mfd <- scale_mfd(mfdobj = Y_testing_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  y_testing <- get_scores(pca = fpca_results$pcay , components = 1:fpca_results$ncomponents_y, newdata_scaled = y_testing_scaled_mfd)
  
  mod <- lm(score_y ~ as.matrix(X_training))
  y_pred_train <- mod$fitted.values
  y_pred_scaled_mfd <- get_fun_from_scores(scores = y_pred_train , harmonics = fpca_results$pcay$harmonics[1:fpca_results$ncomponents_y])
  y_pred_mfd <- descale_mfd(scaled_mfd = y_pred_scaled_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  res_mfd <- scale_mfd(mfdobj = y_training_mfd_scaled,center = y_pred_scaled_mfd , scale = F)
  res_original_mfd <- scale_mfd(mfdobj = Y_training_mfd,center = y_pred_mfd , scale = F)
  
  
  y_pred_tuning <- as.matrix(cbind(1,X_tuning))%*%mod$coefficients
  y_pred_scaled_tuning_mfd <- get_fun_from_scores(scores = y_pred_tuning , harmonics = fpca_results$pcay$harmonics[1:fpca_results$ncomponents_y])
  y_pred_scaled_tuning_mfd$fdnames[[2]] <- as.character(c(1:nrow(X_tuning)))
  y_pred_tuning_mfd <- descale_mfd(scaled_mfd = y_pred_scaled_tuning_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  attr(y_pred_tuning_mfd$coefs,"dimnames")[[1]] <- attr(y_pred_scaled_tuning_mfd$coefs,"dimnames")[[1]]
  attr(y_pred_tuning_mfd$coefs,"dimnames")[[3]] <- attr(y_pred_scaled_tuning_mfd$coefs,"dimnames")[[3]]
  attr(y_pred_scaled_tuning_mfd$coefs,"dimnames")[[2]] <- attr(y_pred_tuning_mfd$coefs,"dimnames")[[2]]
  res_tuning_mfd <- scale_mfd(mfdobj = y_tuning_scaled_mfd ,center =  y_pred_scaled_tuning_mfd , scale = F)
  res_tuning_original_mfd <- scale_mfd(mfdobj = Y_tuning_mfd ,center =  y_pred_tuning_mfd , scale = F)
  
  
  y_pred_test <- as.matrix(cbind(1,X_testing))%*%mod$coefficients
  y_pred_scaled_test_mfd <- get_fun_from_scores(scores = y_pred_test , harmonics = fpca_results$pcay$harmonics[1:fpca_results$ncomponents_y])
  y_pred_scaled_test_mfd$fdnames[[2]] <- as.character(c(1:nrow(X_testing)))
  y_pred_test_mfd <- descale_mfd(scaled_mfd = y_pred_scaled_test_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  attr(y_pred_test_mfd$coefs,"dimnames")[[1]] <- attr(y_pred_scaled_test_mfd$coefs,"dimnames")[[1]]
  attr(y_pred_test_mfd$coefs,"dimnames")[[3]] <- attr(y_pred_scaled_test_mfd$coefs,"dimnames")[[3]]
  attr(y_pred_scaled_test_mfd$coefs,"dimnames")[[2]] <- attr(y_pred_test_mfd$coefs,"dimnames")[[2]]
  res_test_mfd <- scale_mfd(mfdobj = y_testing_scaled_mfd ,center =  y_pred_scaled_test_mfd , scale = F)
  res_testing_original_mfd <- scale_mfd(mfdobj = Y_testing_mfd ,center =  y_pred_test_mfd , scale = F)
  
  
  
  if(type_residuals=='standard'){
    FRCC_res <- FCC(Y_training_mfd = res_mfd , Y_tuning_mfd = res_tuning_mfd , Y_testing_mfd = res_test_mfd , FVEy = FVE_res , alpha = alpha , SPE = SPE , scale = F)
    ARL_FRCC <- FRCC_res$ARL
    frcc_df <- FRCC_res$fcc_df
    res_pca <- FRCC_res$pca
  }
  
  if(type_residuals=='studentized'){
    basis_y <- Y_training_mfd$basis
    nbasis_y <- basis_y$nbasis
    y_pca <- fpca_results$pcay
    ncomponents_y <- fpca_results$ncomponents_y
    get_studentized_residuals <- NULL
    res_original <- res_original_mfd
    domain <- res_original$basis$rangeval
    bs <- create.bspline.basis(domain, 100)
    bs$B <- inprod.bspline(fd(diag(1, bs$nbasis), bs))
    sd_res <- sd.fd(res_original)
    var_res <- times.fd(sd_res, sd_res, bs)
    sigma_M <- crossprod(mod$residuals)/nrow(X)
    gain <- hatvalues(mod)
    xseq <- seq(bs$rangeval[1], bs$rangeval[2], length.out = 1000)
    y_pca_eval <- eval.fd(xseq, y_pca$harmonics)
    y_pca_coef <- project.basis(y_pca_eval, xseq, bs)
    G <- as.numeric(y_pca_coef[, seq_len(ncomponents_y), 
                               1])
    G <- matrix(G, ncol = ncomponents_y)
    psp_coef <- G %*% sigma_M %*% t(G)
    bifd_obj <- bifd(psp_coef, sbasisobj = bs, tbasisobj = bs)
    psp_eval <- fda::evaldiag.bifd(xseq, bifd_obj)
    psp_coef <- as.numeric(project.basis(psp_eval, xseq, 
                                         bs))
    get_studentized_residuals <- function(gain, pred_error) {
      omega_coef <- outer(psp_coef, gain)
      cov_hat_coef <- omega_coef + var_res$coefs[, 1]
      cov_hat_sqrt_inv <- fd(cov_hat_coef, bs)^(-0.5)
      studentized <- times.fd(fd(pred_error$coefs[, , 
                                                  1], basis_y), fd(cov_hat_sqrt_inv$coefs, bs), 
                              basisobj = bs)
      mfd(array(studentized$coefs, dim = c(dim(studentized$coefs), 
                                           1)), bs, pred_error$fdnames, B = bs$B)
    }
    res <- get_studentized_residuals(gain, res_original)
    res_pca <- my_FPCA(Y_mfd = res , FVEy = FVE_res , scale = F)
    
    gain_new_tuning <- rowSums(t(t(X_tuning)^2/colSums(X_training^2)))
    pred_error_tuning <- get_studentized_residuals(gain = gain_new_tuning, 
                                                   pred_error = res_tuning_original_mfd)
    
    gain_new_testing <- rowSums(t(t(X_testing)^2/colSums(X_training^2)))
    pred_error_testing <- get_studentized_residuals(gain = gain_new_testing, 
                                                    pred_error = res_testing_original_mfd)
    
    frcc_df <- control_charts_pca(pca = res_pca$pcay , components = 1:res_pca$ncomponents_y , tuning_data = pred_error_tuning  , newdata =pred_error_testing  , alpha = alpha)
    alpha <- sum(frcc_df$T2 > frcc_df$T2_lim | frcc_df$spe > frcc_df$spe_lim)/length(frcc_df$id)
    ARL_FRCC <- 1 / (1 - ( 1 - alpha ))
  }
  return(list(ARL = ARL_FRCC,
              frcc_df = frcc_df,
              model = mod,
              pca_res = res_pca))
}


#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

## FCC param ##

# FCC_param <- function(Y_training_mfd,Y_tuning_mfd,Y_testing_mfd,FVEy,alpha = 0.01,SPE=T , scale = T){
#   
#   alpha_corr <- 1 - ( 1 - alpha )^0.5
#   
#   pca <- my_FPCA(Y_mfd = Y_training_mfd , FVEy = FVEy , scale = T)
#   
#   y_tun_scaled <- scale_mfd(mfdobj = Y_tuning_mfd , center = pca$pcay$center_fd , scale = pca$pcay$scale_fd)
#   df <- funcharts:::get_T2_spe(pca = pca$pcay , components = 1:pca$ncomponents_y ,newdata_scaled = y_tun_scaled , absolute_error = F )
#   p <- pca$ncomponents_y
#   n <- ncol(Y_tuning_mfd$coefs)
#   c <- (p*(n+1)*(n-1))/(n*(n-p))
#   lim_t2 <- c*qf(p = 1 - alpha_corr , df1 = p , df2 = n - p) 
#   lim_spe <- 
#   
# }
#   

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

Clust_model <- function(Y_training_mfd,FVEy , init_met = 'kmeans',num_iterations = 1 , max_group = 3){
  
  #/// FPCA PHASE ///#
  ## FPCA Training ##
  fpca_results <- my_FPCA(Y_mfd = Y_training_mfd,FVEy = FVEy, length_grid = 500)
  score_y <-  fpca_results$pcay$pcscores[,1:fpca_results$ncomponents_y]
  score_y <- as.matrix(score_y)
  #/// MODEL ESTIMATION PHASE ///#
  ## Model estimation ##
  if(init_met == 'kmeans') num_iterations <- 1
  
  estimate <- estimate_mixture(y = score_y , num_iterations =num_iterations  , max_group = max_group ,mode = 'clustering',init_met = init_met)
  best_model_clust <- estimate
  num_groups_clust <- length(best_model_clust$prop)  
  
  
  return(list(model = best_model_clust,
              fpca_results = fpca_results))
}

#####################################################################################################################################################
#///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////#
#####################################################################################################################################################

Clust_control_chart <- function(Y_training_mfd,Y_tuning_mfd,alpha = 0.01 , Y_testing_mfd , SPE =T, model){ 
  
  best_model_clust <- model$model
  fpca_results <- model$fpca_results
  num_groups_clust <- length(best_model_clust$prop)  
  
  score_y <-  fpca_results$pcay$pcscores[,1:fpca_results$ncomponents_y]
  score_y <- as.matrix(score_y)
  
  # Standardization and score calculation tuning
  y_tuning_std_mfd <- scale_mfd(mfdobj = Y_tuning_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  y_score_new <- get_scores(pca = fpca_results$pcay , components = 1:fpca_results$ncomponents_y , newdata_scaled = y_tuning_std_mfd)
  
  
  # Standardization and score calculation testing
  y_testing_std_mfd <- scale_mfd(mfdobj = Y_testing_mfd , center = fpca_results$pcay$center_fd , scale = fpca_results$pcay$scale_fd)
  y_score_test <- get_scores(pca = fpca_results$pcay , components = 1:fpca_results$ncomponents_y , newdata_scaled = y_testing_std_mfd)
  
  
  membership_training <- predict_mixture(y = score_y, x = matrix(1 , nrow = nrow(score_y)) ,hard = T , model = best_model_clust)$membership
  membership_tuning <- predict_mixture(y = y_score_new, x = matrix(1 , nrow = nrow(y_score_new)) ,hard = T , model = best_model_clust)$membership
  membership_testing <- predict_mixture(y = y_score_test, x = matrix(1 , nrow = nrow(y_score_test)) ,hard = T , model = best_model_clust)$membership
  
  results <- vector(mode = 'list' , length = num_groups_clust)
  
  n_obs_training <- colsums(membership_training)
  n_obs_tuning <- colsums(membership_tuning)
  n_obs_testing <- colsums(membership_testing)
  
  for(kk in 1:num_groups_clust){
    
    if(sum(membership_testing[,kk]!=0)==0) next
    results[[kk]] <- FCC(Y_training_mfd = Y_training_mfd[which(membership_training[,kk]==1)],
                         Y_tuning_mfd = Y_tuning_mfd[which(membership_tuning[,kk]==1)],
                         Y_testing_mfd = Y_testing_mfd[which(membership_testing[,kk]==1)],
                         FVEy = FVEy,alpha = alpha,SPE = SPE)
    
  }
  
  # ARL
  OC <- 0
  
  if(SPE){
    for(kk in 1:num_groups_clust){
      OC <- OC + sum(results[[kk]]$fcc_df$T2 > results[[kk]]$fcc_df$T2_lim | results[[kk]]$fcc_df$spe > results[[kk]]$fcc_df$spe_lim )
    }
  }else{
    for(kk in 1:num_groups_clust){
      OC <- OC + sum(results[[kk]]$fcc_df$T2 > results[[kk]]$fcc_df$T2_lim)
    }
  }
  
  alpha <- OC/nrow(y_score_test)
  
  
  ARL <- 1 / (1 - ( 1 - alpha))
  
  return(list(ARL = ARL,
              Charts = results,
              model = best_model_clust,
              nobs = list(n_obs_testing = n_obs_testing,
                          n_obs_tuning = n_obs_tuning,
                          n_obs_training = n_obs_training)))
  
}


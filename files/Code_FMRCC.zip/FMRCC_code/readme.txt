The folders contains the R files for replicating the simulation study and the case study.

In Simulation folder, the FMRCC_Run.R script could be used to obtain all the figures in the Simulation Study of the manuscript by appropriately setting the simulation parameters.
By default, it provides the bottom-right panel of Figure 4 of the main text of the manuscript for:
      - Linear shift
      - Delta_1 = 1
      - Delta_2 = 1
      - SL = 3
       
The files Functions.R , FMRCC_functions.R , mixregfit.R and models_functions.R contain
the functions to simulate data and implement the proposed and competing methods used in FMRCC_Run.R.

In Case Study folder, the FMRCC_case_study.R script contains the code to replicate the results and plots of the case study presented in Section 4.
The file plot_regr_coef.R is used to obtain the Figure 7 of the main text of the manuscript.

The Data folder contains the RSW dataset used for the case study in .RData format.
RSW_datset.RData contains 4 objects:
      - RSW_IC contains the 1802 in-control observations sampled on a grid of length 699
      - RSW_OC contains the 37 out-of-control observations sampled on a grid of length 699
      - X_IC contains the 1802 in-control values of wear and dressing for the IC data
      - X_OC contains the 37 out-of-control values of wear and dressing for the OC data

dat <-data.frame(id = unique(Y_training_mfd$fdnames$reps) ,group = factor(FMRCC_stud_phaseI$model$group_member),
                 wear = X_train[,2] , tip = X_train[,1])
pl <- list()
for(i in 1:length(FMRCC_stud_phaseI$model$prop)){
  
  pl[[i]] <- plot_mfd(mapping = aes(col= wear),
                      mfdobj = Y_training_mfd[which(dat$group==i)] ,
                      data = dat[which(dat$group==i),],
                      alpha = 0.5)+
    ylab(expression('Resistance ['~m*Omega~']'))+
    # scale_color_gradient(low="gray20",high="gray73")
    # ylim(0.5,0.20)
    scale_color_gradient(high="gray40",low="gray40")
  
  
}

pl[[1]] <- plot_mfd(mapping = aes(col= wear),
                    mfdobj = Y_training_mfd[which(dat$group==1)] ,
                    data = dat[which(dat$group==1),],
                    alpha = 0.5,show.legend = F)+
  ylab(expression('Resistance ['~m*Omega~']'))+
  scale_color_gradient(high="gray40",low="gray40")+
  theme(axis.title = element_text(size = 15))

pl[[2]] <- pl[[2]]+theme(legend.title = element_text(size = 15),legend.text = element_text(size = 15),axis.title = element_text(size = 15))+
  ylab('')



## Plot coefficient functions ##

b1 <- get_fun_from_scores(rbind(t(FMRCC_stud_phaseI$model$B[[1]][1,]),
                                t(FMRCC_stud_phaseI$model$B[[1]][2,]),
                                t(FMRCC_stud_phaseI$model$B[[1]][3,])),FMRCC_stud_phaseI$fpca$pcay$harmonics[1:FMRCC_stud_phaseI$fpca$ncomponents_y])
b1$fdnames[[2]] <- c('Intercept','Dressing','Wear')
names(b1$fdnames) <- c('time','reps','values')

dat_B <- data.frame(id = unique(b1$fdnames$reps) , Coefficients = unique(b1$fdnames$reps)  )
p1 <-plot_mfd(mfdobj = b1 , mapping = aes(col = Coefficients, lty = Coefficients ) , lwd = 1 ,data = dat_B,show.legend = F)+
  # ylab(bquote(beta["0k"] ~ "(t) / " ~ beta[k]~"(t)"))+
  ylab('')+
  xlab("t")+
  ylim(-1,1)+
  # scale_color_discrete(labels = c(bquote(beta),bquote(alpha),bquote(gamma)))+
  theme(legend.title = element_blank(), legend.text = element_text(size=20),axis.title = (element_text(size = 15)))

grid <- seq(0,1,length.out = 500)
int_clust_1 <- get_mfd_list(list(interc = confid_interv$`Cluster 1`$Intercept,
                                 tip = confid_interv$`Cluster 1`$`Coef 2`,
                                 wear = confid_interv$`Cluster 1`$`Coef 3`),n_basis = 80,lambda = 0)

plt_1 <- lines_mfd(plot_mfd_obj = p1,mfdobj_new = int_clust_1[,1],color = '#00BA38',lwd=0.7,lty = 3)+
  geom_ribbon(data = data.frame(x = grid , ymin = confid_interv$`Cluster 1`$Intercept[1,],
                                ymax = confid_interv$`Cluster 1`$Intercept[2,]),
              aes(x = x,
                  ymin = ymin,
                  ymax = ymax), alpha = 0.02 , fill = '#00BA38')

plt_1 <- lines_mfd(plot_mfd_obj = plt_1,mfdobj_new = int_clust_1[,2],color = '#F8766D',lwd=0.5,lty = 1)+
  geom_ribbon(data = data.frame(x = grid , ymin = confid_interv$`Cluster 1`$`Coef 2`[1,],
                                ymax = confid_interv$`Cluster 1`$`Coef 2`[2,]),
              aes(x = x,
                  ymin = ymin,
                  ymax = ymax), alpha = 0.02 , fill = '#F8766D')
plt_1 <- lines_mfd(plot_mfd_obj = plt_1,mfdobj_new = int_clust_1[,3],color = '#619CFF',lwd=0.55,lty =2)+
  geom_ribbon(data = data.frame(x = grid , ymin = confid_interv$`Cluster 1`$`Coef 3`[1,],
                                ymax = confid_interv$`Cluster 1`$`Coef 3`[2,]),
              aes(x = x,
                  ymin = ymin,
                  ymax = ymax), alpha = 0.02 , fill = '#619CFF')
plt_1 <-plt_1+geom_hline(yintercept = 0,col = 'black',lwd = 1 , linetype="dashed")
b2 <- get_fun_from_scores(rbind(t(FMRCC_stud_phaseI$model$B[[2]][1,]),
                                t(FMRCC_stud_phaseI$model$B[[2]][2,]),
                                t(FMRCC_stud_phaseI$model$B[[2]][3,])),FMRCC_stud_phaseI$fpca$pcay$harmonics[1:FMRCC_stud_phaseI$fpca$ncomponents_y])
b2$fdnames[[2]] <-as.character(c('Intercept','Dressing','Wear'))
names(b2$fdnames) <- c('time','reps','values')

dat_B <- data.frame(id = unique(b2$fdnames$reps) , Coefficients = unique(b2$fdnames$reps)  )
p2 <-plot_mfd(mfdobj = b2 , mapping = aes(col = Coefficients,lty = Coefficients) , lwd = 1 ,data = dat_B , show.legend = T)+
  # ylab(bquote(beta["0k"] ~ "(t) / " ~ beta[k]~"(t)"))+
  xlab("t")+
  scale_color_discrete(labels = c( bquote(Dressing ~ beta["2k"] ~ "(t)"),
                                   bquote(Intercept ~ beta["0k"] ~ "(t)"),
                                   bquote(Wear ~ beta["1k"] ~ "(t)")))+
  scale_linetype_discrete(labels = c( bquote(Dressing ~ beta["2k"] ~ "(t)"),
                                      bquote(Intercept ~ beta["0k"] ~ "(t)"),
                                      bquote(Wear ~ beta["1k"] ~ "(t)")))+
  theme(legend.title = element_blank(), legend.text = element_text(size=15),axis.title = (element_text(size = 15)))+
  ylim(-1,1)
# theme(legend.title = element_text(size = 15), legend.text = ggtext::element_markdown(size=15))+
# ylim(-1,1)

int_clust_2 <- get_mfd_list(list(interc = confid_interv$`Cluster 2`$Intercept,
                                 tip = confid_interv$`Cluster 2`$`Coef 2`,
                                 wear = confid_interv$`Cluster 2`$`Coef 3`),n_basis = 80,lambda = 0)

plt_2 <- lines_mfd(plot_mfd_obj = p2,mfdobj_new = int_clust_2[,1],color = '#00BA38',lwd=0.7,lty = 3 , show.legend = F)+
  geom_ribbon(data = data.frame(x = grid , ymin = confid_interv$`Cluster 2`$Intercept[1,],
                                ymax = confid_interv$`Cluster 2`$Intercept[2,]),
              aes(x = x,
                  ymin = ymin,
                  ymax = ymax), alpha = 0.02 , fill = '#00BA38',show.legend = F)+
  scale_color_discrete(labels = c( bquote(Dressing ~ beta["2k"] ~ "(t)"),
                                   bquote(Intercept ~ beta["0k"] ~ "(t)"),
                                   bquote(Wear ~ beta["1k"] ~ "(t)")))+
  scale_linetype_discrete(labels = c( bquote(Dressing ~ beta["2k"] ~ "(t)"),
                                      bquote(Intercept ~ beta["0k"] ~ "(t)"),
                                      bquote(Wear ~ beta["1k"] ~ "(t)")))


plt_2 <- lines_mfd(plot_mfd_obj = plt_2,mfdobj_new = int_clust_2[,2],color = '#F8766D',lwd=0.5,lty = 1)+
  geom_ribbon(data = data.frame(x = grid , ymin = confid_interv$`Cluster 2`$`Coef 2`[1,],
                                ymax = confid_interv$`Cluster 2`$`Coef 2`[2,]),
              aes(x = x,
                  ymin = ymin,
                  ymax = ymax), alpha = 0.02 , fill = '#F8766D')+
  scale_color_discrete(labels = c( bquote(Dressing ~ beta["2k"] ~ "(t)"),
                                   bquote(Intercept ~ beta["0k"] ~ "(t)"),
                                   bquote(Wear ~ beta["1k"] ~ "(t)")))+
  scale_linetype_discrete(labels = c( bquote(Dressing ~ beta["2k"] ~ "(t)"),
                                      bquote(Intercept ~ beta["0k"] ~ "(t)"),
                                      bquote(Wear ~ beta["1k"] ~ "(t)")))

plt_2 <- lines_mfd(plot_mfd_obj = plt_2,mfdobj_new = int_clust_2[,3],color = '#619CFF',lwd=0.55,lty = 2)+
  geom_ribbon(data = data.frame(x = grid , ymin = confid_interv$`Cluster 2`$`Coef 3`[1,],
                                ymax = confid_interv$`Cluster 2`$`Coef 3`[2,]),
              aes(x = x,
                  ymin = ymin,
                  ymax = ymax), alpha = 0.02 , fill = '#619CFF')+
  scale_color_discrete(labels = c( bquote(Dressing ~ beta["2k"] ~ "(t)"),
                                   bquote(Intercept ~ beta["0k"] ~ "(t)"),
                                   bquote(Wear ~ beta["1k"] ~ "(t)")))+
  scale_linetype_discrete(labels = c( bquote(Dressing ~ beta["2k"] ~ "(t)"),
                                      bquote(Intercept ~ beta["0k"] ~ "(t)"),
                                      bquote(Wear ~ beta["1k"] ~ "(t)")))

plt_2 <-plt_2 + geom_hline(yintercept = 0,col = 'black',lwd = 1 , linetype="dashed")+ylab('')
plt_1 <- plt_1 + ylim(-1.1,1.1)
plt_2 <- plt_2 + ylim(-1.1,1.1)

pl[[1]] <- pl[[1]] + ylim(0.125,0.232) + xlab('t')
pl[[2]] <- pl[[2]] + ylim(0.125,0.232)+ xlab('t')
pl[[2]] <- pl[[2]]+theme(legend.margin = margin(r=100))

fig<-ggarrange(plotlist = list(plt_1,plt_2) , ncol = 2 ,nrow=1, common.legend = T ,legend = 'right')
# fig2 <- ggarrange(plotlist = pl, ncol = 2 ,nrow=1, common.legend = F ,legend = "none")

pl[[2]] <- pl[[2]]+theme(legend.margin = margin(r=88))

fig2 <- ggarrange(plotlist = pl, ncol = 2 ,nrow=1, common.legend = T ,legend = 'right')

fig_final <- ggarrange(fig,fig2,ncol = 1,common.legend = F,align = "hv")+
  theme(plot.margin = margin(1,1,0,0, "cm"))+
  annotate("text", x=0.23, y=1.01, label=deparse(bquote(Group ~ 1)),size=7,fontface =1,parse = T)+
  annotate("text", x=0.65, y=1.01, label=deparse(bquote(Group ~ 2)),size=7,fontface =1,parse = T)


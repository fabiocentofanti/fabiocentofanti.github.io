
##########################################################
# Functional Mixture Regression Control Chart Case Study #
##########################################################

# Load the necessary files and libraries ----------------------------------

library(fda)
library(Rfast)
library(fdapace)
library(mvtnorm)
library(tidyverse)
library(funcharts)
library(ggpubr)
library(parallel)
library(doParallel)

source("../Simulation/Functions.R")
source("../Simulation/mixregfit.R")
source("../Simulation/models_functions.R")
load("Data/RSW_dataset.RData")

# Parameters setting ----------------------------------------------------------

FVEy <- 0.95    
alpha <- 0.01
SPE <- T
nsim <- 100

# Data smoothing ---------------------------------------------------------------

# IC data
dat <- smooth_data(Y = RSW_IC, domain = c(0,1), length_grid = nrow(RSW_IC) , norder = 4 , n_basis_x = 80 , n_basis_y = 80)
Y_training_fd <- dat$Y_fd
colnames(Y_training_fd$coefs) <-as.character(1:ncol(RSW_IC))
Y_training_fd$fdnames[[2]] <- as.character(1:ncol(RSW_IC))
Y_mfd <- get_mfd_fd(Y_training_fd)

# OC data ----------------------------------------------------------------------
dat <- smooth_data(Y = RSW_OC, domain = c(0,1), length_grid = nrow(RSW_OC) , norder = 4 , n_basis_x = 80 , n_basis_y = 80)
Y_testing_fd <- dat$Y_fd
colnames(Y_testing_fd$coefs) <-as.character(1:ncol(RSW_OC))
Y_testing_fd$fdnames[[2]] <- as.character(1:ncol(RSW_OC))
Y_test_mfd <- get_mfd_fd(Y_testing_fd)

dat1 <- data.frame(id = unique(Y_mfd$fdnames$reps),leg = 'IC')
p <- plot_mfd(Y_mfd ,  alpha = 0.7,data = dat1 , show.legend = F , mapping = aes(col = leg))+
  color_palette(c('grey40','grey40'))+
  theme(legend.title = element_blank(),legend.text = element_text(size = 40))+
  # ylim(0.12,0.287)+
  ylim(0.125,0.232)+
  ylab(expression('Resistance ['~m*Omega~']'))+
  theme(plot.title = element_text(size = 40),axis.title.x = element_text(size=20),axis.title.y = element_text(size=20))
# theme_void()
dat2 <- data.frame(id = unique(Y_test_mfd$fdnames[[2]]),leg = 'OC')
lines_mfd(p ,Y_test_mfd, alpha = 0.7,lwd = 1 , data = dat2,show.legend = T,aes(color = leg))+
  color_palette(c('grey','black'))+
  theme(legend.title = element_blank(),legend.text = element_text(size = 20))+
  # ggtitle(element_text('Phase II profiles'))+
  ylim(0.125,0.29)+
  ylab(expression('Resistance ['~m*Omega~']'))+
  xlab('t')+
  theme(plot.title = element_text(size = 40),axis.title.x = element_text(size=20),axis.title.y = element_text(size=20))

# ggsave(paste0("C:/Users/Davide/Desktop/RSW_sample_OC2.pdf"),width =9, height = 8.27)

# Training - Tuning splitting --------------------------------------------------
set.seed(12345)
idx <- sample(1:ncol(Y_mfd$coefs) , size =  901 , replace = F)

Y_tuning_mfd <- Y_mfd[idx]
Y_training_mfd <- Y_mfd[-idx]

X_tun <- as.matrix(X_IC[idx,])
X_train <- as.matrix(X_IC[-idx,])
x_mean <- colMeans(X_train)
x_sd <- apply(X_train, 2, sd)
X_train <- scale(as.matrix(X_train))
X_tun <- t(apply(X_tun , 1 , function(x)( x - x_mean)/x_sd))
X_test <- t(apply(X_OC , 1 , function(x)( x - x_mean)/x_sd))

# FMRCC ----------------------------------------------------------------
FMRCC_stud_phaseI <- FMRCC_phaseI(Y_training_mfd = Y_training_mfd, X_training_mfd = X_train , Y_tuning_mfd = Y_tuning_mfd ,
                                  X_tuning_mfd = X_tun ,
                                  FVEy = FVEy , FVEx = FVEy , studentized = T , alpha = alpha ,
                                  intercept = T , SPE = F,max_group = 3,init_met = 'kmeans')

FMRCC_stud_phaseII <- FMRCC_phaseII(Y_testing_mfd = Y_test_mfd , X_testing_mfd = X_test , phaseI = FMRCC_stud_phaseI, studentized = T , intercept = T ,SPE = F)
ARL_FMRCC_stud <- FMRCC_stud_phaseII$ARL 

plot_cc(df = FMRCC_stud_phaseII$phaseII$df , limits = FMRCC_stud_phaseI$phaseI$lim_stud , df_phaseI = FMRCC_stud_phaseI$phaseI$df)
# ggsave(paste0("C:/Users/Davide/Desktop/FMRCC_cc.pdf"),width =12, height = 3)

## FRCC ---------------------------------------------------------------
## Standard ##
FRCC_res <- FRCC_fos(Y_training_mfd = Y_training_mfd , X_training = X_train , Y_tuning_mfd = Y_tuning_mfd ,
                     X_tuning = X_tun , Y_testing_mfd = Y_test_mfd,
                     X_testing = X_test , FVEy = FVEy , FVE_res = FVEy , type_residuals = 'standard' ,
                     alpha = alpha , SPE = T)

ARL_FRCC_res <- FRCC_res$ARL

## FCC ## ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
FCC_result <- FCC(Y_training_mfd = Y_training_mfd , Y_tuning_mfd = Y_tuning_mfd ,
                  Y_testing_mfd = Y_test_mfd , FVEy = FVEy , alpha = alpha,SPE = SPE)
ARL_FCC <- FCC_result$ARL

## CLUST ## /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
model_clust <- Clust(Y_training_mfd = Y_training_mfd , Y_tuning_mfd = Y_tuning_mfd ,
                     FVEy = FVEy , alpha = alpha , Y_testing_mfd = Y_test_mfd ,SPE = SPE,
                     init_met = 'kmeans' , num_iterations = 1 , max_group = 3)
ARL_CLUST <- model_clust$ARL

frac_vec <- c(1/ARL_FMRCC_stud, 1/ARL_FRCC_res , 1/ARL_FCC , 1/ARL_CLUST)
names(frac_vec) <- c('FMRCC','FRCC','FCC','CLUST')
frac_vec

# Confidence intervals for coefficient functions -----------------------

boot_models <- bootstrap_models(Y_mfd = Y_training_mfd, X_mfd = X_train , k = length(FMRCC_stud_phaseI$model$prop) ,
                                samples_numb = 100 , FVEthreshold_y = FVEy , starts = 1)
boot_adj <- adjust_label(boot_models = boot_models , best_model = FMRCC_stud_phaseI$model ,fpca_res_best = FMRCC_stud_phaseI$fpca)
boot_adj <- adjust_label(boot_models = boot_adj , best_model = FMRCC_stud_phaseI$model , fpca_res_best = FMRCC_stud_phaseI$fpca)
confid_interv <- conf_int(boot_models = boot_adj)

# source('plot_regr_coef.R')
# fig_final
# ggsave(paste0("C:/Users/Davide/Desktop/coef_clust2.pdf"),width =12, height = 8.27)


# TDR Bootstrap confidence intervals --------------------------------------

nsim <- 100

cores <- detectCores()-1
cl <- makeCluster(cores)
registerDoParallel(cl)

result <- foreach(ii = 1:nsim, .packages=c("fda","funcharts","Rfast","fdapace","tidyverse")) %dopar% {
  source("../Simulation/Functions.R")
  source("../Simulation/mixregfit.R")
  source("../Simulation/models_functions.R")
  
  set.seed(ii)
  
  boot_OC <- sample(1:ncol(Y_test_mfd$coefs) , size =  ncol(Y_test_mfd$coefs) , replace = T)
  Y_II_boot <- Y_test_mfd[boot_OC]
  X_II_boot <- X_test[boot_OC,]
  
  ## FMRCC ## ------------------------------
  ## Studentized ##

  FMRCC_stud_phaseII_boot <- FMRCC_phaseII(Y_testing_mfd = Y_II_boot , X_testing_mfd = X_II_boot ,
                                           phaseI = FMRCC_stud_phaseI, studentized = T , intercept = T ,SPE = F)
  ARL_FMRCC_stud_boot <- FMRCC_stud_phaseII_boot$ARL 
  
  ## FRCC ## ------------------------------
  
  FRCC_res_boot <- FRCC_fos(Y_training_mfd = Y_training_mfd , X_training = X_train , Y_tuning_mfd = Y_tuning_mfd , X_tuning = X_tun ,
                            Y_testing_mfd = Y_II_boot, X_testing = X_II_boot,
                            FVEy = FVEy , FVE_res = FVEy , type_residuals = 'standard' , alpha = alpha , SPE = T)
  
  ARL_FRCC_res_boot <- FRCC_res_boot$ARL
  
  ## FCC ## ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  FCC_result_boot <- FCC(Y_training_mfd = Y_training_mfd , Y_tuning_mfd = Y_tuning_mfd ,
                         Y_testing_mfd = Y_II_boot , FVEy = FVEy , alpha = alpha,SPE = SPE)
  ARL_FCC_boot <- FCC_result_boot$ARL
  
  ## CLUST ## /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  model_clust_boot <- Clust(Y_training_mfd = Y_training_mfd , Y_tuning_mfd = Y_tuning_mfd ,
                            FVEy = FVEy , alpha = alpha , Y_testing_mfd = Y_II_boot ,SPE = SPE,
                            init_met = 'kmeans' , num_iterations = 1 , select_k = length(model_clust$model$prop))
  ARL_CLUST_boot <- model_clust_boot$ARL
  
  frac_vec_boot <- c(1/ARL_FMRCC_stud_boot , 1/ARL_FRCC_res_boot , 1/ARL_FCC_boot , 1/ARL_CLUST_boot)
  
  return(frac_vec_boot)
}
stopCluster(cl)
frac_vec_boot <- do.call(rbind , result)

gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
}
palette <- gg_color_hue(6)

palette[4]<- 'black'
palette <- palette[c(4,5,3,1)]

colnames(frac_vec_boot)<-c("FMRCC","FRCC","FCC","CLUST")

# power <- colmeans(frac_vec_boot)
power <- frac_vec
int <- apply(X = frac_vec_boot , MARGIN = 2 , FUN = quantile , c(0.025 , 0.975))
df <- data.frame(power = power , method = colnames(frac_vec_boot)  , q1 = int[1,] , q2 = int[2,])

df$method <- factor(df$method , levels = c('FMRCC','FRCC','FCC','CLUST'))

ggplot(df , aes(x = method , y = power ,  group=method, color=method, fill=method, shape=method))+
  geom_point()+
  theme_bw()+
  scale_shape_manual(values=c(16,15,17,18,25,4)) +
  scale_fill_manual(values = palette)+
  scale_color_manual(values = palette)+
  geom_line(size=0.8)+
  geom_point(size = 5) +
  geom_errorbar(aes(y = power,ymin=q1, ymax=q2), width=.1,
                position=position_dodge(0))+
  xlab(NULL)+
  ylab('TDR')+
  theme(legend.title = element_blank() ,legend.background = element_rect(colour = NULL), legend.text = element_text(size = 15) , axis.title = element_text(size = 20) , axis.text = element_text(size = 15))+
  theme(plot.title = element_text(size =25))+
  ylim(0,1)+
  geom_hline(yintercept = 0,col = 1,size = 1)+
  geom_hline(yintercept = 0.01,col = 'grey',size = 1)

# ggsave(paste0("C:/Users/Davide/Desktop/RSW_power.pdf"),width =16, height = 4)


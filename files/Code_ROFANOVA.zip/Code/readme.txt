The folder contains the Main.R file that is used to perform the Scenario 1 of the simulation study.
The variable mean and contamination indicate respectively mean functions (i.e., M1, M2, and M3) and contamination models (i.e., C0-6) in the simulation study (see the help page of the function rofanova::simulate_data for further information).
Information about the rofanova package may be found at https://github.com/unina-sfere/rofanova.

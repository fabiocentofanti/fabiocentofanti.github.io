
library(rofanova)#devtools::install_github("unina-sfere/rofanova")
library(fdANOVA)


mean<-"M1"
contamination<-'C0'
ll_cont<-1
ll_m<-1
ll_sd<-2
n_i=20

alpha=0.05
N=500
B=1000
k=3
n=n_i*k
length_grid<-25
grid=seq(0,1,length.out = length_grid)
eff<-0.95
tol=1e-20
p_cont_vec<-c(0.05,0.1)
M_vec<-c(1,5,10)
sd_vec<-c(0.2,1,1.8,2.6,3.4,4.2,5)/length_grid
cores=parallel::detectCores()

p_cont<-p_cont_vec[ll_cont]
M_given<-M_vec[ll_m]
sd_given<-sd_vec[ll_sd]

par_fun<-function(iii){
  data_out<-rofanova::simulate_data(k_1=k,mean = mean,con=contamination,p = p_cont,n_i = n_i,M = M_given,sd = sd_given,grid =grid)
  label=data_out$label_1
  data=X_fdata$data
  X_fdata<-data_out$X_fdata
  # RoFanova ----------------------------------------------------------------
  mu0=func.trim.FM(X_fdata,trim=0.2)
  per_list_median<-rofanova(X_fdata,label,B = B,eff=eff,family="median",mu0_g=mu0,cores=cores  )
  pvalue_median<-per_list_median$pval_vec
  per_list_huber<-rofanova(X_fdata,label,B = B,eff=eff,family="huber",mu0_g=mu0,cores=cores)
  pvalue_huber<-per_list_huber$pval_vec
  per_list_bisquare<-rofanova(X_fdata,label,B = B,eff=eff,family="bisquare",mu0_g=mu0,cores=cores)
  pvalue_bisquare<-per_list_bisquare$pval_vec
  per_list_hampel<-rofanova(X_fdata,label,B = B,eff=eff,family="hampel",mu0_g=mu0,cores=cores)
  pvalue_hampel<-per_list_hampel$pval_vec
  per_list_optimal<-rofanova(X_fdata,label,B = B,eff=eff,family="optimal",mu0_g=mu0,cores=cores)
  pvalue_optimal<-per_list_optimal$pval_vec


  # FANOVA ------------------------------------------------------------------

  test<-fanova.tests(x = t(data), group.label = label,test = c("FP","GPF","L2B","FB"))
  fac1<-as.factor(label)
  m03<-data.frame(fac1)
  mod_rpm<-fanova.RPm(X_fdata,~fac1,m03,RP=c(30))
  pvalue_FP<-test$FP$pvalueFP
  pvalue_GPF<-test$GPF$pvalueGPF
  pvalue_L2B<-test$L2B$pvalueL2B
  pvalue_FB<-test$FB$pvalueFB
  pvalue_TRP<-mod_rpm$p.FDR
  pvalue_TRPbon<-mod_rpm$p.Bonf
  out<-list(pvalue_FP,
            pvalue_GPF,
            pvalue_L2B,
            pvalue_FB,
            pvalue_TRP,
            pvalue_TRPbon,
            pvalue_median,
            pvalue_huber,
            pvalue_bisquare,
            pvalue_hampel,
            pvalue_optimal
  )

  return(out)
}


out<-lapply(1,par_fun)#,mc.cores = 8)
pvalue_FP_vec<-sapply(out,"[[",1)
pvalue_GPF_vec<-sapply(out,"[[",2)
pvalue_L2B_vec<-sapply(out,"[[",3)
pvalue_FB_vec<-sapply(out,"[[",4)
pvalue_TRP_vec<-sapply(out,"[[",5)
pvalue_TRPbon_vec<-sapply(out,"[[",6)
pvalue_median_vec<-sapply(out,"[[",7)
pvalue_huber_vec<-sapply(out,"[[",8)
pvalue_bisquare_vec<-sapply(out,"[[",9)
pvalue_hampel_vec<-sapply(out,"[[",10)
pvalue_optimal_vec<-sapply(out,"[[",11)

level_FP<-length(which(pvalue_FP_vec<=alpha))/N
level_GPF<-length(which(pvalue_GPF_vec<=alpha))/N
level_L2B<-length(which(pvalue_L2B_vec<=alpha))/N
level_FB<-length(which(pvalue_FB_vec<=alpha))/N
level_TRP<-length(which(pvalue_TRP_vec<=alpha))/N
level_TRPbon<-length(which(pvalue_TRPbon_vec<=alpha))/N

level_median<-length(which(pvalue_median_vec<=alpha))/N
level_huber<-length(which(pvalue_huber_vec<=alpha))/N
level_bisquare<-length(which(pvalue_bisquare_vec<=alpha))/N
level_hampel<-length(which(pvalue_hampel_vec<=alpha))/N
level_optimal<-length(which(pvalue_optimal_vec<=alpha))/N


levels<-c(level_FP,level_GPF,level_L2B,level_FB,level_TRP,level_TRPbon,level_median,level_huber,level_bisquare,level_hampel,level_optimal)
names(levels)<-c("FP","GPF","L2B","FB","TRP","TRPbon","MED","HUB","BIS","HAM","OPT")
levels=t(levels)
print(levels)

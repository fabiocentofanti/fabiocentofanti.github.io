library(funcharts); library(ggplot2)
set.seed(0); dat <- sim_funcharts()

mfdI <- get_mfd_list(dat$datI[1:4])
mfdI_tun <- get_mfd_list(dat$datI_tun[1:4])
mfdII <- get_mfd_list(dat$datII[1:4])
plot_mfd(mfdI[1:20, c("X1", "Y")])

pca <- pca_mfd(mfdI[, c("X1", "X2", "X3")])
plot_pca_mfd(pca, harm = 1:2)


cclist_pca <- control_charts_pca(pca = pca,
                                 tuning_data = mfdI_tun[, c("X1","X2","X3")],
                                 newdata = mfdII[, c("X1","X2","X3")])
plot_control_charts(cclist_pca) &
  geom_vline(aes(xintercept = x), data = data.frame(x = c(20.5, 40.5)), lty = 2)


cont_plot(cclist = cclist_pca, which_plot = "spe", id_num = 33)
cont_plot(cclist = cclist_pca, which_plot = "spe", id_num = 59)


plot_mon(cclist = cclist_pca,
         fd_train = mfdI[, c("X1", "X2", "X3")],
         fd_test = mfdII[59, c("X1", "X2", "X3")])

mod_sof <- sof_pc(y = dat$datI$y_scalar, mfdobj_x = mfdI[, c("X1", "X2", "X3")])

plot_bootstrap_sof_pc(mod_sof, nboot = 100)

cclist_sof_pc <- regr_cc_sof(
  object = mod_sof,
  y_new = dat$datII$y_scalar,
  mfdobj_x_new = mfdII[, c("X1", "X2", "X3")]
)
plot_control_charts(cclist_sof_pc) &
  geom_vline(aes(xintercept = c(20.5)), lty = 2) &
  geom_vline(aes(xintercept = c(40.5)), lty = 2)

mod_fof <- fof_pc(mfdobj_y = mfdI[, "Y"],
                  mfdobj_x = mfdI[, c("X1", "X2", "X3")])

plot_bifd(mod_fof$beta_fd)

cclist_fof_pc <- regr_cc_fof(
  object = mod_fof,
  mfdobj_y_tuning = mfdI_tun[, "Y"],
  mfdobj_x_tuning = mfdI_tun[, c("X1", "X2", "X3")],
  mfdobj_y_new = mfdII[, "Y"],
  mfdobj_x_new = mfdII[, c("X1", "X2", "X3")])
plot_control_charts(cclist_fof_pc) &
  geom_vline(aes(xintercept = c(20.5)), lty = 2) &
  geom_vline(aes(xintercept = c(40.5)), lty = 2)


xI <- get_mfd_list_real_time(dat$datI[c("X1", "X2", "X3")],
                             ncores = 1)
yI <- get_mfd_list_real_time(dat$datI["Y"],
                             ncores = 1)
xI_tun <- get_mfd_list_real_time(dat$datI_tun[c("X1", "X2", "X3")],
                                 ncores = 1)
yI_tun <- get_mfd_list_real_time(dat$datI_tun["Y"],
                                 ncores = 1)
xII <- get_mfd_list_real_time(dat$datII[c("X1", "X2", "X3")],
                              ncores = 1)
yII <- get_mfd_list_real_time(dat$datII["Y"],
                              ncores = 1)


mod_realtime <- fof_pc_real_time(yI, xI,
                                 ncores = 1)


cc_realtime <- regr_cc_fof_real_time(
  mod_list = mod_realtime,
  mfdobj_y_new_list = yII,
  mfdobj_x_new_list = xII,
  mfdobj_y_tuning_list = yI_tun,
  mfdobj_x_tuning_list = xI_tun,
  ncores = 1
)


plot_control_charts_real_time(cc_realtime, id_num = 30)



# real-case study ---------------------------------------------------------
library(funcharts); library(dplyr)
load("data/ShipNavigation.RData")
dft <- ShipNavigation %>%
  group_by(VN) %>%
  mutate(CO2pm = CO2_emissions / nautic_miles) %>%
  ungroup() %>%
  filter(position == "PORT3 -> PORT1") %>%
  na.omit()

yvar <- "CO2pm"
xvar <- c("sog", "w_long", "w_trasv", "trim")

x <- get_mfd_df(dt = dft,
                arg = "fraction of distance travelled",
                domain = c(0, 1),
                id = "VN",
                variables = c(xvar, yvar),
                n_basis = 100)
obs <- unique(dft$VN)
obs_numeric <- as.numeric(substr(obs, 3, 7))
obs1 <- obs[obs_numeric >= 517 & obs_numeric <= 1248]
obs2 <- obs[obs_numeric > 1248 & obs_numeric <= 2054]

x1 <- x[obs1, xvar]
y1 <- x[obs1, yvar]

mod <- fof_pc(y1, x1, type_residuals = "studentized")
outliers <- get_outliers_mfd(mod$residuals)
obs1_ok <- obs1[-outliers]
obs1_train <- obs1_ok[1:110]
obs1_tun <- setdiff(obs1_ok, obs1_train)
x1train <- x1[obs1_train]
y1train <- y1[obs1_train]
x1tun <- x1[obs1_tun]
y1tun <- y1[obs1_tun]
x2 <- x[c(obs1_tun, obs2), xvar]
y2 <- x[c(obs1_tun, obs2), yvar]

mod <- fof_pc(y1train, x1train, type_residuals = "studentized")
plot_bifd(mod$beta_fd)

cc <- regr_cc_fof(mod,
                  mfdobj_y_new = y2,
                  mfdobj_x_new = x2,
                  mfdobj_y_tuning = y1tun,
                  mfdobj_x_tuning = x1tun,
                  alpha = 0.01)
plot_control_charts(cc, nobsI = length(obs1_tun))

yhat <- predict_fof_pc(object = mod,
                       mfdobj_y_new = y2,
                       mfdobj_x_new = x2)

plot_mon(cc, mod$residuals, yhat$pred_error[88], plot_title = TRUE)
plot_mon(cc, mod$residuals, yhat$pred_error[221], plot_title = TRUE)

xl <- get_mfd_df_real_time(dt = dft,
                           domain = c(0, 1),
                           arg = "predicted fraction of distance travelled",
                           id = "VN",
                           variables = c(xvar, yvar),
                           n_basis = 100
)
y1l <- lapply(xl, function(x) x[obs1_train, yvar])
x1l <- lapply(xl, function(x) x[obs1_train, xvar])
y1ltun <- lapply(xl, function(x) x[obs1_tun, yvar])
x1ltun <- lapply(xl, function(x) x[obs1_tun, xvar])
y2l <- lapply(xl, function(x) x[c(obs1_tun, obs2), yvar])
x2l <- lapply(xl, function(x) x[c(obs1_tun, obs2), xvar])

modl <- fof_pc_real_time(mfdobj_y_list = y1l,
                         mfdobj_x_list = x1l,
                         type_residuals = "studentized")

ccl <- regr_cc_fof_real_time(mod_list = modl,
                             mfdobj_y_new_list = y2l,
                             mfdobj_x_new_list = x2l,
                             mfdobj_y_tuning_list = y1ltun,
                             mfdobj_x_tuning_list = x1ltun,
                             alpha = 0.01)


plot_control_charts_real_time(ccl, 221)



The folder contains the R files for a single run of the simulation study in Scenario I, Shift A, M2, d=0.5, and OC conditions that start at 30% of the total duration.

The main file is Run.R that provides the ARLs for the FRTM and competing methods.
The file functions_competitors.R contains the functions to implement the competing methods used in Run.R.
The file FRTM_1.0.0.tar.gz contains the R package FRTM.

The files fastdist2_0.1.0.tar.gz and dtwfunctions.R contain functions used to implement the DTWPCA approach.


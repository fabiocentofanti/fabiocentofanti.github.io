
##Single run of the simulation study in Scenario 1, Shift A, M2, d=0.5, and OC conditions that start at the 30% of the total duration.
# In this form, this implementation takes around 1 hour to complete on a server with unix operating system where each node has two 24 cores Intel(R) Xeon(R) Platinum 8160 with clock frequency of 2.10GHz.


##Load libraries and functions
library(fda)
library(parallel)
library(mgcv)
library(funcharts)
library(spatstat.univar)

# install.packages("fastdist_0.1.0.tar.gz", repos = NULL, type="source")
# install.packages("fastdist2_0.1.0.tar.gz", repos = NULL, type="source")
library(fastdist) 
library(fastdist2)
require(plyr)
require(dtw)
source('functions_competitors.R')
source('dtwfunctions.R')


n_obs_tra <- 250
n_obs_tun <- 250
n_obs_oc <- 500

alpha <- 0.05
cores <- detectCores()
data <- simulate_data_FRTM(n_obs = n_obs_tra, alignemnt_level = "M2")
data_tuning <- simulate_data_FRTM(n_obs = n_obs_tun, alignemnt_level = "M2")
data_oc <-
  simulate_data_FRTM(
    n_obs = n_obs_oc,
    scenario = "1",
    shift = "OC_h",
    alignemnt_level = "M2",
    t_out_type = "0.3",
    severity = 0.5
  )


max_x <- max(unlist(data$grid_i))
seq_t_tot <- seq(0, 1, length.out = 100)
seq_x <- seq(0.1, max_x, length.out = 60)
lambda <- c(0, 10 ^ seq(-7, -1, by = 0.25), 10 ^ 5)

# FRTM --------------------------------------------------------------------

mod_phaseI_FRTM <-
  FRTM_PhaseI(
    data_tra =  data,
    data_tun = data_tuning,
    control.FDTW = list(lambda = lambda, seq_t =
                          seq_t_tot[-1]),
    control.rtr = list(seq_x = seq_x),
    
    ncores = cores,
    alpha = alpha
  )
mod_phaseII_FRTM <-
  FRTM_PhaseII(data_oc = data_oc , mod_phaseI = mod_phaseI_FRTM)

ARL_FRTM <-
  funcharts:::get_ARL(mod_phaseII = mod_phaseII_FRTM,
                 data_oc$out_control_t,
                 min_t = c(0, 1))
indeces_FRTM <- c(FA = ARL_FRTM$m_FA, TD = ARL_FRTM$m_TD)

# Pointwise ---------------------------------------------------------------


data_pw <- data
data_pw$x_err <- c(data$x_err, data_tuning$x_err)
data_pw$grid_i <- c(data$grid_i, data_tuning$grid_i)
mod_phaseI_PW <- PhaseI_pw(data_pw,
                           seq_x = seq_x,
                           alpha = alpha,
                           PLOT = F)
mod_phaseII_PW <- PhaseII_pw(data_oc , mod_phaseI_PW, PLOT = F)
ARL_PW <-
  get_ARLPW(
    mod_phaseII = mod_phaseII_PW,
    t_out = data_oc$out_control_t,
    min_t = c(0, 1)
  )
indeces_PW <- c(FA = ARL_PW$m_FA, TD = ARL_PW$m_TD)

# NOAL --------------------------------------------------------------------

mod_phaseI_NOAL <-
  PhaseI_noal(
    data,
    data_tuning = data_tuning,
    seq_x = seq_x,
    alpha = alpha,
    cores = cores,
    PLOT = F
  )
mod_phaseII_NOAL <-
  PhaseII_noal(data_oc, mod_phaseI_NOAL, cores = cores, PLOT = F)
ARL_NOAL <-
  funcharts:::get_ARL(mod_phaseII_NOAL, data_oc$out_control_t, min_t = c(0, 1))
indeces_NOAL <- c(FA = ARL_NOAL$m_FA, TD = ARL_NOAL$m_TD)

# DTWPCA ----------------------------------------------------------------
mod_MPCADTW <-
  MPCADTW(
    data,
    data_tun = data_tuning,
    data_oc = data_oc,
    seq_x = seq_x,
    alpha = alpha,
    cores = cores
  )
ARL_MPCADTW <-
  get_ARLMPCADTW(mod_MPCADTW, data_oc$out_control_t, min_t = c(0, 1))
indeces_MPCADTW <- c(FA = ARL_MPCADTW$m_FA, TD = ARL_MPCADTW$m_TD)




results <-
  t(cbind(indeces_FRTM, indeces_NOAL, indeces_PW, indeces_MPCADTW))
rownames(results) <- c("FRTM", "NOAL", "PW", "DTWPCA")

print(results)

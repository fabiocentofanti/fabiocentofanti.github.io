
# Pointwise ---------------------------------------------------------------
PhaseI_pw<-function(data,alpha=0.01,seq_x,PLOT=FALSE,lag=0){

  x_list<-data$x_err
  grid_list<-data$grid_i

  n_obs<-length(x_list)

  max_grid<-sapply(1:length(grid_list),function(ii)max(grid_list[[ii]]))

  domain_list<-lapply(1:n_obs, function(ii)c(min(grid_list[[ii]]),max(grid_list[[ii]])))
  basis_list<-lapply(1:n_obs, function(ii)create.bspline.basis(domain_list[[ii]],norder = 2,breaks = grid_list[[ii]]))
  fd_list<-lapply(1:n_obs, function(ii)fd(x_list[[ii]],basis_list[[ii]]))
  grid_tot<-seq(0.1,max(max_grid),length.out = 100)
  width<-1*(seq_x[2]-seq_x[1])
  eval_mat<-matrix(NA,length(seq_x),n_obs)
  for(ii in 1:length(seq_x)){
    for (kk in 1:n_obs) {
      grid_i<-grid_list[[kk]]
      eval_i<-x_list[[kk]]
      ind_k=unique(which(abs(grid_i-seq_x[ii])<=width&grid_i<=seq_x[ii]))
      if(length(ind_k)!=0){
        ind_k=max(ind_k):max(1,(max(ind_k)-lag))
        eval_mat[ii,kk]<-mean(eval_i[ind_k])
      }

    }
  }






  CL_mat<-matrix(NA,length(seq_x),2)
  for (ii in 1:length(seq_x)) {
    mat_i<-eval_mat[ii,]
    mat_i<-mat_i[!is.na(mat_i)]
    if(length(mat_i)>1){
      den<-try(density(mat_i,na.rm = TRUE,bw = "SJ",adjust = 0.25),outFile = "err");
      if(class(den)=="try-error")den<-density(mat_i,na.rm = TRUE)
      CL_mat[ii,]<-spatstat.univar::quantile.density(den,c(alpha/2,1-alpha/2))#quantile(mat_i,c(alpha/2,1-alpha/2),type = 1)#

      # CL_mat[ii,]<-c(mean(mat_i)+qnorm(c(alpha/2))*sd(mat_i),mean(mat_i)+qnorm(c(1-alpha/2))*sd(mat_i))

    }#spatstat::quantile.density(den,1-alpha)}
    else if(length(mat_i)==1){
      CL_mat[ii,]<-mat_i
    }
    else{
      CL_mat[ii,]=NA
    }
  }
  ind_el<-which(!is.na(CL_mat[,1]))
  CL_mat<-CL_mat[ind_el,]
  seq_x_n<-seq_x[ind_el]
  basis<-create.bspline.basis(range(seq_x_n),breaks =seq_x_n ,norder = 2)
  CL_fd<-fd(CL_mat,basis)
  if(PLOT){
    plot.lfd(fd_list,type="l",ylim=c(15,30),xlim=c(0,15))
    lines(CL_fd,lwd=3,col=2)
  }

  out<-list(CL=CL_fd,
            grid_tot=grid_tot,
            seq_x=seq_x)

}


PhaseII_pw<-function(data,mod_phaseI,t_out=NA,PLOT=FALSE,lag=0){

  x_list_o<-data$x_err
  grid_x_o<-data$grid_i
  n_obs_II<-length(x_list_o)
  grid_tot=mod_phaseI$grid_tot
  seq_x=mod_phaseI$seq_x
  domain_list<-lapply(1:n_obs_II, function(ii)c(min(grid_x_o[[ii]]),max(grid_x_o[[ii]])))
  basis_list<-lapply(1:n_obs_II, function(ii)create.bspline.basis(domain_list[[ii]],norder = 2,breaks = grid_x_o[[ii]]))
  fd_list<-lapply(1:n_obs_II, function(ii)fd(x_list_o[[ii]],basis_list[[ii]]))
  CL<-mod_phaseI$CL
  dom_limit<-CL$basis$rangeval
  grid_eval<-seq(min(dom_limit),max(dom_limit),length.out = 500)

  width<-1*(seq_x[2]-seq_x[1])
  ind_grid_tot<-eval_new<-grid_new<-matrix(NA,length(seq_x),n_obs_II)
  for(ii in 1:n_obs_II){
      grid_i<-grid_x_o[[ii]]
      eval_i<-x_list_o[[ii]]
    for (kk in 1:length(seq_x)) {
      ind_grid_i<-if(kk==1)which(grid_i<=seq_x[kk]) else which(grid_i<=seq_x[kk]&grid_i>seq_x[kk-1])
      if(length(ind_grid_i)>0){
      ind_sx<-max(ind_grid_i):max(1,(max(ind_grid_i)-lag))
        eval_new[kk,ii]<-mean(eval_i[ind_sx])
        grid_new[kk,ii]<-grid_i[max(ind_grid_i)]
      }
    }}


  if(PLOT){

    plot.lfd(fd_list,type="l",ylim=range(unlist(x_list_o)))
    lines(CL,lwd=3,col=1)
    matplot(grid_new,eval_new,type="l")
    lines(CL,lwd=3,col=1)
  }
  #

  range_cl<-CL$basis$rangeval
  ind_na<-which(seq_x<=range_cl[2]&seq_x>=range_cl[1])
  new_seq<-seq_x[ind_na]
  eval<-matrix(NA,length(seq_x),2)
  eval[ind_na,]<-eval.fd( seq_x[ind_na],CL)
  # CL_eval<-eval.fd( new_seq,CL)
  data_out<-matrix(NA,n_obs_II,length(seq_x))
  for(kk in 1:n_obs_II){
    for (ll in ind_na) {
      if(!is.na( eval_new[ll,kk])){
          CL_i<-eval[ll,]
          data_out[kk,ll]<-as.numeric(eval_new[ll,kk]<CL_i[1]|eval_new[ll,kk]>CL_i[2])

    }
    }
  }

  #
  out<-list(grid_new=grid_new,
            eval=eval,
            data_out=data_out,
            seq_x=seq_x)
  return(out)

}
get_ARLPW<-function(mod_phaseII,t_out,min_t=0){
  grid_new=mod_phaseII$grid_new
  data_out=mod_phaseII$data_out
  seq_x=mod_phaseII$seq_x
  n_obs<-dim(data_out)[1]
  TD<-FA<-numeric()
  TTS=matrix(0,n_obs,length(min_t))
  for (ii in 1:n_obs) {
    grid_eval_i<-grid_new[,ii]
    ind_out<-data_out[ii,]
    ind_na<-which(is.na(ind_out))
    if(length(ind_na)>0){
      ind_out=ind_out[-ind_na]
      grid_eval_i=grid_eval_i[-ind_na]

    }
    ind_out_l=which(ind_out==1)
    if(is.null(t_out[ii])){
      ind_ic<-1:length(grid_eval_i)
      seq_x_n<-grid_eval_i[ind_ic]
      delta_x=diff(c(seq_x[1],seq_x_n))
      if(length(ind_ic)>0)
        FA[ii]<-sum(as.numeric(ind_ic%in%ind_out_l)*delta_x)/sum(delta_x)
      else
        FA[ii]<-NA

      TD[ii]=NA
      TTS[ii]<-NA

    }
    else{

      ind_ic<-which(grid_eval_i<t_out[ii])
      seq_x_n<-grid_eval_i[ind_ic]

      seq_x_n=c(seq_x[1],seq_x_n)
      delta_x=diff(seq_x_n)
      if(length(ind_ic)>0)
        FA[ii]<- sum(as.numeric(ind_ic%in%ind_out_l)*delta_x)/sum(delta_x)
      else
        FA[ii]<-NA

      ind_oc<-which(grid_eval_i>=t_out[ii])
      seq_x_n<-grid_eval_i[ind_oc]

      delta_x=diff(c(t_out[ii],seq_x_n))
      if(length(ind_oc)>0)
        TD[ii]<- sum(as.numeric(ind_oc%in%ind_out_l)*delta_x)/sum(delta_x)
      else
        TD[ii]<-NA


      for(ll in 1:length(min_t)){
        if(sum(ind_out)==0)
        {
          TTS[ii,ll]<-1
        }
        else{
          t_out_ii<-grid_eval_i[ind_out_l]

          diff_out<-t_out_ii-t_out[ii]
          ind<-which(diff_out>0|min(diff_out)<0)
          if(length(ind)==0){
            TTS[ii,ll]<-1
          }
          else{

            t_out_ii=t_out_ii[ind]
            kkkk=0
          for (mm in 1:length(t_out_ii)) {

            est_max<-t_out_ii[mm]+min_t[ll]
            seq_red<-seq_x_n[seq_x_n<=est_max&seq_x_n>=t_out_ii[mm]]
            seq_obs<-t_out_ii[t_out_ii<=est_max&t_out_ii>=t_out_ii[mm]]

            if(length(seq_red)==length(seq_obs)){
              TTS[ii,ll]<-(est_max-t_out[ii])/(max(grid_eval_i)-t_out[ii])
              kkkk=1
              break

            }
          }
            if(kkkk==0) TTS[ii,ll]=1

          #
          # min_diff<-min(diff_out)
          # ind_min<-which.min(diff_out)
          # # if(min_diff<0){
          # #   TTS[ii,ll]<-NA
          # # }
          # # else{
          #   if(min_diff<min_t[ll]){
          #     ind_new<-which(t_out_ii>t_out[ii]+min_t[ll])
          #     if(length(ind_new)==0)
          #       min_diff<-1
          #     else
          #       min_diff<-min(t_out_ii[ind_new]-t_out[ii])
          #   }
          #
          #   TTS[ii,ll]<-min_diff/(max(grid_eval_i)-t_out[ii])
          #  }
        }
      }


    }
    }
  }
  TTS_r<-list()
  m_TTS=numeric()
  for (ll in 1:length(min_t)) {
    TTS_r[[ll]]<-TTS[,ll][TTS[,ll]!=Inf&!is.na(TTS[,ll])]
    m_TTS[ll]<-base::mean(TTS_r[[ll]],na.rm=TRUE)
  }

  m_TD<-base::mean(TD,na.rm=TRUE)
  m_FA<-base::mean(FA,na.rm=TRUE)
  m_pFA<-base::mean(apply(data_out,2,sum,na.rm=TRUE)/apply(!is.na(data_out),2,sum),na.rm=TRUE)


  out<-list(FA=FA,
            TD=TD,
            TTS=TTS,
            m_FA=m_FA,
            m_TD=m_TD,
            m_TTS=m_TTS,
            data_out=data_out,
            m_pFA=m_pFA)
  return(out)
}


# NOAL ------------------------------------------------------------

PhaseI_noal<-function(data,data_tuning = NULL,seq_x,alpha=0.01,cores=1,PLOT=FALSE,perc_pca=0.9,perc_basis_x = 0.3,n_basis_x_tot = 30,min_grid_tot=0.1){
  # n_basis_x_tot=30
  # perc_basis_x=0.1
  x_list<-data$x_err
  grid_list<-data$grid_i
  n_obs<-length(x_list)
  max_grid<-sapply(1:length(grid_list),function(ii)max(grid_list[[ii]]))
  domain_list<-lapply(1:n_obs, function(ii)c(min(grid_list[[ii]]),max(grid_list[[ii]])))
  basis_list<-lapply(1:n_obs, function(ii)create.bspline.basis(domain_list[[ii]],norder = 2,breaks = grid_list[[ii]]))
  fd_list<-lapply(1:n_obs, function(ii)fd(x_list[[ii]],basis_list[[ii]]))

  grid_tot<-seq(min_grid_tot,max(max_grid),length.out = 100)
  data_mat<-matrix(NA,length(grid_tot),n_obs)
  delta_grid_x<-grid_tot[2]-grid_tot[1]

  parr_fun<-function(ii) {
     # print(ii)
    grid_x_t=grid_list[[ii]]
    x_fd_list<-list()
    for (kk in 1:length(grid_tot)) {
      #print(kk)
      t_x=grid_tot[kk]
      grid_x<-grid_x_t[which(grid_x_t<=t_x)]
      dom_x=range(grid_x)
      x_value_i=x_list[[ii]][which(grid_x_t<=t_x)]
      npoints<-length(x_value_i)
      if(npoints<12){
        basis_x<-create.bspline.basis(c(dom_x[1],t_x),nbasis =min(npoints,max(2,round(perc_basis_x*npoints))),norder = min(npoints,2))
        x_fd_r<-smooth.basis(grid_x,x_value_i,basis_x)$fd
      }
      else{
        x_fd_r<- funcharts:::get_fd_smooth(x_value_i,grid_x,min(n_basis_x_tot,max(6,round(perc_basis_x*npoints))),plot=FALSE)
      }
      x_fd_list[[kk]]<-x_fd_r
    }
    return(x_fd_list)
  }
  if(.Platform$OS.type=="unix")
    x_fd_list<-mclapply(1:n_obs,function(ii)parr_fun(ii),mc.cores = cores)
  else
    x_fd_list<-lapply(1:n_obs,function(ii)parr_fun(ii))


  end_i<-matrix(0,n_obs,length(grid_tot))
  for (ii in 1:n_obs) {
    for (kk in 1:length(grid_tot)) {
      end_i[ii,kk]<- x_fd_list[[ii]][[kk]]$basis$rangeval[2]
    }
  }

  for (ii in 1:n_obs) {
    indzz<- which(end_i[ii,]==end_i[ii,length(grid_tot)])
    if(length(indzz)>=1)
      end_i[ii,indzz[-1]]=NA
  }

  ind_end=0
  x_list_x<-list()
  for (ii in 1:length(grid_tot)) {
    x_list_x[[ii]]<-list()
    mm=1
    for (kk in 1:n_obs) {
      ind_ke=unique(which(abs(end_i[kk,]-grid_tot[ii])<10^-6))
      ind_k=unique(which(end_i[kk,]>=grid_tot[ii]))
      indeces=1
      if(length(ind_k)!=0){
        for (ll in 1:length(ind_k[indeces])) {
          x_list_x[[ii]][[mm]]<-x_fd_list[[kk]][[ind_k[indeces][ll]]]
          mm=mm+1
        }
      }
      else{
        x_list_x[[ii]][[mm]]<-NA
        mm=mm+1
      }
    }
     # print(length(x_list_x[[ii]]))
  }



  range_x=range(unlist(grid_list))
  parr_pca<-function(ii){
    # print(ii)
    t_x<-grid_tot[ii]
    eval_seq<-seq(range_x[1],t_x,length.out = 100)
    ind_na<-which(!is.na(x_list_x[[ii]]))
    if(length(ind_na)>10){
      eval_x<-matrix(0,length(eval_seq),length(ind_na))

      nbasisx<-numeric()
      for (jj in 1:length(ind_na)) {
        x_fd_i=x_list_x[[ii]][[ind_na[jj]]]
        ev<-eval.fd(eval_seq,x_fd_i)
        eval_x[,jj]<-ev
        nbasisx[jj]<-x_fd_i$basis$nbasis
      }
      npoints<-length(eval_x[,1])
      basis_x_r<-create.bspline.basis(c(range_x[1],t_x),nbasis = max(2,round(base::max(nbasisx))),norder=min(round(base::mean(nbasisx)),4))
      x_fd_r<-smooth.basis(eval_seq,eval_x,basis_x_r)$fd
      mod_pca<-mFPCA(x_fd_r,ncom="ptv",par_ncom=perc_pca)

    }
    else{
      mod_pca<-"no variability"
    }
    out<-mod_pca
    return(out)
  }
  if(.Platform$OS.type=="unix")
    pca_list<-mclapply(1:length(grid_tot),function(ii)parr_pca(ii),mc.cores = cores)
  else
    pca_list<-lapply(1:length(grid_tot),function(ii)parr_pca(ii))


  if(!is.null(data_tuning)){
    print("Tuning")
    x_list_tun<-data_tuning$x_err
    grid_list_tun<-data_tuning$grid_i
  }
  else{
    x_list_tun<- x_list
    grid_list_tun<-grid_list
  }

  get_T2SPE_noal<-function(x_list,grid_list,seq_x,pca_list,grid_tot){
    delta_x<-seq_x[2]-seq_x[1]
    n_obs=length(x_list)

    parr_fun<-function(ii){
      # print(ii)
      T_vec<-SPE_vec<- numeric()
      for (kk in 1:n_obs) {
        # print(kk)
        grid_x_t=grid_list[[kk]]
        t_x=seq_x[ii]
        grid_x<-grid_x_t[which(grid_x_t<=t_x)]
        t_x2<-max(grid_x)
        ind_pos<-which(grid_tot-t_x2<=0)
        ind_k<-ind_pos[which.max((grid_tot-t_x2)[ind_pos])]
        t_x_new<-grid_tot[ind_k]
        if(length(t_x_new)==1){
          if(abs(t_x2-t_x)<=delta_x){
            dom_x=range(grid_x)
            x_value_i=x_list[[kk]][which(grid_x_t<=t_x)]
            npoints<-length(x_value_i)
            if(npoints<12){
              basis_x<-create.bspline.basis(c(dom_x[1],t_x),nbasis =min(npoints,max(2,round(perc_basis_x*npoints))),norder = min(npoints,2))
              x_fd_r<-smooth.basis(grid_x,x_value_i,basis_x)$fd
            }
            else{
              x_fd_r<- funcharts:::get_fd_smooth(x_value_i,grid_x,min(n_basis_x_tot,max(6,round(perc_basis_x*npoints))),plot=FALSE)
            }
            mod_pca<-pca_list[[ind_k]]
            if((mod_pca!="no variability")[1]){
              grid_new<-seq(x_fd_r$basis$rangeval[1],t_x_new,length.out = 300)
              eval<-eval.fd(grid_new,x_fd_r)
              basis<-create.bspline.basis(c(x_fd_r$basis$rangeval[1],t_x_new),nbasis = mod_pca$x_fd$basis$nbasis,norder=min(mod_pca$x_fd$basis$nbasis,4))
              new_fd<- smooth.basis(grid_new,eval,basis)$fd
              out_rt<-funcharts:::get_T2SPE(new_fd,mod_pca = mod_pca)
              T_vec[kk]<- out_rt$T_2
              SPE_vec[kk]<-out_rt$SPE
            }
            else{
              T_vec[kk]<-NA
              SPE_vec[kk]<-NA
            }
          }
          else{
            T_vec[kk]<-NA
            SPE_vec[kk]<-NA
          }
        }
        else{
          T_vec[kk]<-NA
          SPE_vec[kk]<-NA
        }
      }
      out<-list(T_vec=T_vec,
                SPE_vec=SPE_vec)
      return(out)
    }
    if(.Platform$OS.type=="unix")
      out_list<-mclapply(1:length(seq_x),function(ii)parr_fun(ii),mc.cores = cores)
    else
      out_list<-lapply(1:length(seq_x),function(ii)parr_fun(ii))

    T_2_mat<-sapply(out_list, "[[", 1)
    SPE_2_mat<-sapply(out_list, "[[", 2)

    out<-list(T_2_mat=T_2_mat,
              SPE_2_mat=SPE_2_mat)
    return(out)
  }
  mod<-get_T2SPE_noal(x_list_tun,grid_list_tun,seq_x,pca_list,grid_tot)
  T_2_mat=mod$T_2_mat
  SPE_2_mat=mod$SPE_2_mat

  T2SPE_fd<-funcharts:::get_T2SPE_fd(T_2_mat,SPE_2_mat,seq_x)
  T2_fd=T2SPE_fd$T2_fd
  SPE_fd=T2SPE_fd$SPE_fd
  alpha_sid<-1-sqrt(1-alpha)
  CL_T2<-funcharts:::CL_T2SPE_fd(T2_fd,alpha=alpha_sid,seq_x = seq_x)
  CL_SPE<-funcharts:::CL_T2SPE_fd(SPE_fd,alpha=alpha_sid,seq_x = seq_x)
  if(PLOT){
    par(mfrow=c(1,2))
    plot.lfd(T2_fd,type="l",ylim=c(0,100),xlim=c(0,max(seq_x)))
    lines(CL_T2,lwd=2,col=2)
    plot.lfd(SPE_fd,type="l",ylim=c(0,10),xlim=c(0,max(seq_x)))
    lines(CL_SPE,lwd=2,col=2)
  }

  out<-list(T_2_mat=T_2_mat,
            SPE_mat=SPE_2_mat,
            T2_fd=T2_fd,
            SPE_fd=SPE_fd,
            CL_SPE=CL_SPE,
            CL_T2=CL_T2,
            seq_x=seq_x,
            grid_tot=grid_tot,
            pca_list=pca_list,
            n_basis_x_tot= n_basis_x_tot,
            perc_basis_x= perc_basis_x)

  return(out)

}
PhaseII_noal<-function(data_ocin,mod_phaseI,cores = 1,PLOT=FALSE){


  x_list_o = data_ocin$x_err
  grid_x_o = data_ocin$grid_i
  pca_list=mod_phaseI$pca_list
  CL_T2=mod_phaseI$CL_T2
  CL_SPE=mod_phaseI$CL_SPE
  seq_t=mod_phaseI$seq_t
  seq_x=mod_phaseI$seq_x
  grid_tot=mod_phaseI$grid_tot
  perc_basis_x=mod_phaseI$perc_basis_x
  n_basis_x_tot= mod_phaseI$n_basis_x_tot
  n_obs_II<-length(x_list_o)
  # print(n_obs_II)


  delta_x<-seq_x[2]-seq_x[1]
  par_funII<-function(kk){

    T_vec<-SPE_vec<-numeric()

    for (ii in 1:length(seq_x)) {
      # print(kk)
      grid_x_t=grid_x_o[[kk]]
      t_x=seq_x[ii]
      grid_x<-grid_x_t[which(grid_x_t<=t_x)]
      t_x2<-max(grid_x)
      ind_pos<-which(grid_tot-t_x2<=0)
      ind_k<-ind_pos[which.max((grid_tot-t_x2)[ind_pos])]
      t_x_new<-grid_tot[ind_k]
      if(length(t_x_new)==1){
        if(abs(t_x2-t_x)<=delta_x){
          dom_x=range(grid_x)
          x_value_i=x_list_o[[kk]][which(grid_x_t<=t_x)]
          npoints<-length(x_value_i)
          if(npoints<12){
            basis_x<-create.bspline.basis(c(dom_x[1],t_x),nbasis =min(npoints,max(2,round(perc_basis_x*npoints))),norder = min(npoints,2))
            x_fd_r<-smooth.basis(grid_x,x_value_i,basis_x)$fd
          }
          else{
            x_fd_r<- funcharts:::get_fd_smooth(x_value_i,grid_x,min(n_basis_x_tot,max(6,round(perc_basis_x*npoints))),plot=FALSE)
          }

          mod_pca<-pca_list[[ind_k]]
          if((mod_pca!="no variability")[1]){
            grid_new<-seq(x_fd_r$basis$rangeval[1],t_x_new,length.out = 300)
            eval<-eval.fd(grid_new,x_fd_r)
            basis<-create.bspline.basis(c(x_fd_r$basis$rangeval[1],t_x_new),nbasis = mod_pca$x_fd$basis$nbasis,norder=min(mod_pca$x_fd$basis$nbasis,4))
            new_fd<- smooth.basis(grid_new,eval,basis)$fd
            out_rt<-funcharts:::get_T2SPE(new_fd,mod_pca = mod_pca)
            T_vec[ii]<- out_rt$T_2
            SPE_vec[ii]<-out_rt$SPE
          }
          else{
            T_vec[ii]<-NA
            SPE_vec[ii]<-NA
          }
        }
        else{
          T_vec[ii]<-NA
          SPE_vec[ii]<-NA
        }
      }
      else{
        T_vec[ii]<-NA
        SPE_vec[ii]<-NA
      }

    }

    out<-list(T_vec=T_vec,
              SPE_vec=SPE_vec,
              seq_x=seq_x)

    return(out)

  }
  if(.Platform$OS.type=="unix")
    out_list<-mclapply(1:n_obs_II,function(ii)par_funII(ii),mc.cores = cores)
  else
    out_list<-lapply(1:n_obs_II,function(ii)par_funII(ii))
 

  T_2_mat<-t(sapply(out_list, "[[", 1))
  SPE_2_mat<-t(sapply(out_list, "[[", 2))

  T2SPE_fd<-funcharts:::get_T2SPE_fd(T_2_mat,SPE_2_mat,seq_x)
  T2_fd=T2SPE_fd$T2_fd
  SPE_fd=T2SPE_fd$SPE_fd
  alpha=0.05
  alpha_sid<-1-sqrt(1-alpha)
  CL_T22<-funcharts:::CL_T2SPE_fd(T2_fd,alpha=alpha_sid,seq_x = seq_x)
  CL_SPE2<-funcharts:::CL_T2SPE_fd(SPE_fd,alpha=alpha_sid,seq_x = seq_x)
  if(PLOT){
    # par(mfrow=c(1,2))
    plot.lfd(T2_fd,type="l",ylim=c(0,100),xlim=range(seq_x))
    lines(CL_T2,lwd=3,col=2)
    # lines(CL_T22,lwd=3,col=3)
    plot.lfd(SPE_fd,type="l",ylim=c(0,3),xlim=range(seq_x))
    lines(CL_SPE,lwd=3,col=2)
    # lines(CL_SPE2,lwd=3,col=3)



  }

  out<-list(T_2_mat=T_2_mat,
            SPE_mat=SPE_2_mat,
            T2_fd=T2_fd,
            SPE_fd=SPE_fd,
            CL_SPE=CL_SPE,
            CL_T2=CL_T2,
            seq_x=seq_x,
            pca_list=pca_list )

  return(out)

}


# DTWPCA -----------------------------------------------
MPCADTW<-function(data_tra,data_tun,data_oc,seq_x,alpha=0.05,cores=1){
  n_obs_tra=length(data_tra$x_err)
  n_obs_tun=length(data_tun$x_err)
  n_obs_oc=length(data_oc$x_err)
  
  data_tra<-lapply(1:n_obs_tra,function(ii)data.frame(Time=data_tra$grid_i[[ii]],V1=data_tra$x_err[[ii]]))
  data_tun<-lapply(1:n_obs_tun,function(ii)data.frame(Time=data_tun$grid_i[[ii]],V1=data_tun$x_err[[ii]]))
  data_oc<-lapply(1:n_obs_oc,function(ii)data.frame(Time=data_oc$grid_i[[ii]],V1=data_oc$x_err[[ii]]))
  vmeas=c("V1")
  
  datsc=c(data_tra,data_tun,data_oc)
  duration<-sapply(1:n_obs_tra, function(ii)abs(diff(range(data_tra[[ii]][,1]))))
  x<-abs(duration-stats::median(duration))
  idx = idx_ref=which(x == min(x))[1]
  idx=10
  
  wts = rep(1,length(vmeas))
  
  K.ref = nrow(data_tra[[idx_ref]])
  ref=data_tra[[idx_ref]]$V1
  grid_ref=data_tra[[idx_ref]][,1]
  dat_al = mydtw(data_tra, refid=idx_ref, alvars = vmeas,
                 sp = symmetricP1, varwts = wts, timename = "Time",varname = "V1",
                 window.type ="sakoechiba", window.size = 10)
  
  dat_al = dat_al[[1]]
  lenght_grid=length(seq_x)
  X3 = simplify2array(lapply(dat_al, as.matrix), higher=T)
  dim(X3)
  
  X = t(apply(X3, 3, function(x) as.vector(x)))
  colnames(X) = paste0(rep(c("h",vmeas), each = K.ref), 1:K.ref)
  sds = apply(X,2,sd, na.rm = T)
  sds[sds == 0] = 1
  mns = apply(X,2,mean, na.rm=T)
  
  Xsc = scale(X, center = mns, scale = sds)
  
  mod = prcomp(Xsc[!is.na(Xsc[,1]),], center = F, scale. = F)
  summary(mod)
  varprop=mod$sdev^2/sum(mod$sdev^2)
  ncomp <- which(cumsum(varprop) >= 0.8)[1]
  inputs = list(Pmat = mod$rotation[,1:ncomp],
                wts = wts,
                idx_ref = idx_ref,
                vmeas=vmeas,
                mns = mns,
                sds = sds)
  
  tempfun = function(datsc, idx_qry, inputs,ref){
    list2env(inputs, .GlobalEnv)
    
    nm = matrix(1:1000, nrow = 1000, ncol = 1000, byrow = F) +
      matrix(1:1000, nrow = 1000, ncol = 1000, byrow = T)
    qry = as.matrix(datsc[[idx_qry]][,vmeas],ncol=1)
    grid_i=datsc[[idx_qry]]$Time
    width<-1*(seq_x[2]-seq_x[1])
    new_time<-numeric()
    for (ii in 1:length(seq_x)) {
      tt<-unique(which(abs(grid_i-seq_x[ii])<=width&grid_i<=seq_x[ii]))
      if(length(tt)!=0)
        new_time[ii]<- max(tt)
    }
    qry=as.matrix(qry)
    K.ref = nrow(ref)
    qry2 = t(apply(qry,1,function(x) x*sqrt(wts)))
    ref2 = t(apply(ref,1,function(x) x*sqrt(wts)))
    ncomp = ncol(Pmat)
    d = fastdist(t(qry2),t(ref2))
    lineup = dtw(t(qry2),t(ref2), step.pattern=symmetricP1, open.end = T, keep.internals = T,
                 window.type ="sakoechiba", window.size = 10)
    
    scrs = matrix(NA,nrow = nrow(qry), ncol = ncomp)
    Q2 = rep(NA, nrow(qry))
    
    for(k.bt in 1:nrow(qry)){
      
      k.rt = which.min(lineup$costMatrix[k.bt,]/nm[k.bt,1:K.ref])
      k.rt
      
      lineup2 = lineup
      lineup2$costMatrix = lineup2$costMatrix[1:k.bt, 1:k.rt, drop=F]
      lineup2$directionMatrix = lineup2$directionMatrix[1:k.bt, 1:k.rt, drop=F]
      lineup2$jmin = k.rt
      
      test = mybacktrack(lineup2)
      
      if (length(test$index1) > 1) {
        qryal = aggregate(qry[test$index1, ], by = list(test$index2), mean)[, -1]
      } else{
        qryal = qry[test$index1, ]
      }
      idx = data.frame(qryidx = test$index1, refidx = test$index2)
      tw = rep(NA, max(idx$refidx))
      
      for(j in 1:max(idx$refidx)){
        matchid = idx$qryidx[idx$refidx == j]
        tw[j] = max(matchid)
      }
      tw = tw
      startindex = K.ref*(0:(2-1))+1
      idx = cbind(startindex, startindex + k.rt - 1)
      idx = apply(idx, 1, function(x) x[1]:x[2])
      idx = (as.vector(idx))
      xnew_red1 = t(as.matrix(unlist(qryal)))
      xnew_red1=c(grid_i[tw],xnew_red1)
      xnew_red = (xnew_red1 - mns[idx])/sds[idx]
      
      p_red = Pmat[idx,]
      scrs[k.bt,] = t(MASS::ginv(t(p_red) %*% p_red) %*% t(p_red) %*% xnew_red)
      xhat = c(scrs[k.bt,] %*% t(mod$rotation[,1:ncomp]))
      Q2[k.bt] = sum((c(xnew_red) - c(xhat[idx]))^2)
    }
    scrs=scrs[new_time,]
    Q2=Q2[new_time]
    scrs = cbind(scrs, Q2, idx_qry)
    na_mat<-matrix(NA,length(seq_x)-dim(scrs)[1],dim(scrs)[2])
    scrs = rbind(scrs,na_mat)
    return(scrs)
  }
  
  
  scores_online = array(dim = c(lenght_grid, ncomp+1, length(data_tun)+length(data_oc)), data = NA)
  scores_tra = array(dim = c(lenght_grid, ncomp+1, length(data_tra)), data = NA)
  
  inputs.all = inputs
  
  if(.Platform$OS.type=="unix")
    scores_list<-parallel::mclapply(1:length(data_tra),function(ii)tempfun(datsc = data_tra, idx_qry = ii, inputs=inputs.all,ref=as.matrix(ref)),mc.cores = cores)
  else
    scores_list<-lapply(1:length(data_tra),function(ii)tempfun(datsc = data_tra, idx_qry = ii, inputs=inputs.all,ref=as.matrix(ref)))
  for(i in (1:length(data_tra))){
    scores_tra[,,i] = scores_list[[i]][,1:(ncomp+1)]
  }
  
  if(.Platform$OS.type=="unix")
  scores_list<-parallel::mclapply(1:length(data_tun),function(ii)tempfun(datsc = data_tun, idx_qry = ii, inputs.all,ref=as.matrix(ref)),mc.cores = cores)
  else
    scores_list<-lapply(1:length(data_tun),function(ii)tempfun(datsc = data_tun, idx_qry = ii, inputs.all,ref=as.matrix(ref)))
  for(i in (1:length(data_tun))){
    scores_online[,,i] = scores_list[[i]][,1:(ncomp+1)]
  }
  
  library(foreach)
  library(doParallel)
  if(.Platform$OS.type=="unix")
    zlist<-parallel::mclapply(1:length(data_oc),function(ii){tempfun(datsc = data_oc, ii, inputs.all,ref=as.matrix(ref))},mc.cores = cores)
  else
    zlist<-lapply(1:length(data_oc),function(ii){tempfun(datsc = data_oc, ii, inputs.all,ref=as.matrix(ref))})
  for(i in (1:length(data_oc))){
    scores_online[,,length(data_tun)+i] = zlist[[i]][,1:(ncomp+1)]
  }
  K.maxbt=lenght_grid
  N_ref=length(data_tun)
  dim(scores_online)
  
  q2mat = t(scores_online[,ncomp+1,])
  
  q2info = data.frame(mn = apply(q2mat[1:length(data_tun),],2,mean,na.rm=T),
                      vr = apply(q2mat[1:length(data_tun),],2,var, na.rm=T))
  
  
  alpha_sid<-1-sqrt(1-alpha)
  q2info$CL<-apply(q2mat[1:N_ref,],2,function(x)quantile(x,1-alpha_sid,na.rm = T))
  scores_SigmaInv = array(NA, dim = c(ncomp,ncomp,K.maxbt))
  scores_Means = matrix(NA, nrow = K.maxbt, ncol = ncomp)
  for(k in 1:K.maxbt){
    scores_SigmaInv[,,k] = MASS::ginv(cov(t(scores_tra[k,1:ncomp,1:length(data_tra)]), use = "complete"))
    scores_Means[k,] = colMeans(t(scores_tra[k,1:ncomp,1:length(data_tra)]), na.rm = T)
  }
  
  t2mat = matrix(NA,nrow = N_ref+length(data_oc), ncol = K.maxbt)
  for(k in 1:K.maxbt){
    scrs = t(scores_online[k,1:ncomp,])
    Sinv = scores_SigmaInv[,,k]
    mn = scores_Means[k,]
    t2 = apply(scrs,
               1,
               function(x) t(as.matrix(x-mn))%*% Sinv  %*% as.matrix(x-mn))
    t2mat[,k] = t2
  }
  alpha_sid<-1-sqrt(1-alpha)
  T2CL =apply(t2mat[1:N_ref,],2,function(x)quantile(x,1-alpha_sid,na.rm = T))
  data_out<-matrix(0,length(data_oc),K.maxbt)
  for (ii in 1:length(data_oc)) {
    for (kk in 1:K.maxbt) {
      data_out[ii,kk]<-as.numeric(t2mat[(length(data_tun))+ii,kk]>T2CL[kk]|q2mat[(length(data_tun))+ii,kk]>q2info$CL[kk])
    }
  }
  new_time_list<-list()
  for (jj in 1:length(data_oc)) {
    grid_i=data_oc[[jj]]$Time
    width<-1*(seq_x[2]-seq_x[1])
    new_time<-numeric()
    for (ii in 1:length(seq_x)) {
      tt<-unique(which(abs(grid_i-seq_x[ii])<=width&grid_i<=seq_x[ii]))
      if(length(tt)!=0)
        new_time[ii]<-grid_i[ max(tt)]
    }
    new_time_list[[jj]]=c(new_time,rep(NA,length(seq_x)-length(new_time)))
  }
  grid_new<-do.call("rbind",new_time_list)
  out<-list(grid_new=grid_new,
            data_out=data_out,
            seq_x=seq_x)
  return(out)
}
get_ARLMPCADTW<-function(mod_MPCADTW,t_out,min_t = c(0,1)){
  
  
  
  grid_new=mod_MPCADTW$grid_new
  data_out=mod_MPCADTW$data_out
  seq_x=mod_MPCADTW$seq_x
  n_obs<-dim(data_out)[1]
  TD<-FA<-numeric()
  TTS=matrix(0,n_obs,length(min_t))
  for (ii in 1:n_obs) {
    grid_eval_i<-grid_new[ii,]
    ind_out<-data_out[ii,]
    ind_out_l=which(ind_out==1)
    if(is.null(t_out[ii])){
      ind_ic<-1:length(grid_eval_i)
      seq_x_n<-grid_eval_i[ind_ic]
      delta_x=diff(c(seq_x[1],seq_x_n))
      if(length(ind_ic)>0)
        FA[ii]<-sum(as.numeric(ind_ic%in%ind_out_l)*delta_x)/sum(delta_x)
      else
        FA[ii]<-NA
      
      TD[ii]=NA
      TTS[ii]<-NA
      
    }
    else{
      
      ind_ic<-which(grid_eval_i<t_out[ii])
      seq_x_n<-grid_eval_i[ind_ic]
      
      seq_x_n=c(seq_x[1],seq_x_n)
      delta_x=diff(seq_x_n)
      if(length(ind_ic)>0)
        FA[ii]<- sum(as.numeric(ind_ic%in%ind_out_l)*delta_x)/sum(delta_x)
      else
        FA[ii]<-NA
      
      ind_oc<-which(grid_eval_i>=t_out[ii])
      seq_x_n<-grid_eval_i[ind_oc]
      
      delta_x=diff(c(t_out[ii],seq_x_n))
      if(length(ind_oc)>0)
        TD[ii]<- sum(as.numeric(ind_oc%in%ind_out_l)*delta_x)/sum(delta_x)
      else
        TD[ii]<-NA
      
      
      for(ll in 1:length(min_t)){
        if(sum(ind_out,na.rm = T)==0)
        {
          TTS[ii,ll]<-1
        }
        else{
          t_out_ii<-grid_eval_i[ind_out_l]
          
          diff_out<-t_out_ii-t_out[ii]
          ind<-which(diff_out>0|min(diff_out)<0)
          if(length(ind)==0){
            TTS[ii,ll]<-1
          }
          else{
            
            t_out_ii=t_out_ii[ind]
            kkkk=0
            for (mm in 1:length(t_out_ii)) {
              
              est_max<-t_out_ii[mm]+min_t[ll]
              seq_red<-seq_x_n[seq_x_n<=est_max&seq_x_n>=t_out_ii[mm]]
              seq_obs<-t_out_ii[t_out_ii<=est_max&t_out_ii>=t_out_ii[mm]]
              
              if(length(seq_red)==length(seq_obs)){
                TTS[ii,ll]<-(est_max-t_out[ii])/(max(grid_eval_i,na.rm = T)-t_out[ii])
                kkkk=1
                break
                
              }
            }
            if(kkkk==0) TTS[ii,ll]=1
          }
        }
        
        
      }
    }
  }
  TTS_r<-list()
  m_TTS=numeric()
  for (ll in 1:length(min_t)) {
    TTS_r[[ll]]<-TTS[,ll][TTS[,ll]!=Inf&!is.na(TTS[,ll])]
    m_TTS[ll]<-base::mean(TTS_r[[ll]],na.rm=TRUE)
  }
  
  m_TD<-base::mean(TD,na.rm=TRUE)
  m_FA<-base::mean(FA,na.rm=TRUE)
  m_pFA<-base::mean(apply(data_out,2,sum,na.rm=TRUE)/apply(!is.na(data_out),2,sum),na.rm=TRUE)
  
  out<-list(FA=FA,
            TD=TD,
            TTS=TTS,
            m_FA=m_FA,
            m_TD=m_TD,
            m_TTS=m_TTS,
            data_out=data_out,
            m_pFA=m_pFA)
  return(out)
}
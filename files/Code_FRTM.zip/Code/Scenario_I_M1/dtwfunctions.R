





diagdtw = function(d){
  nx =nrow(d)
  ny = ncol(d)
  if(nx>ny){
    beta = (ny-1)/(nx-1)
    alpha = 1-beta
    
    x = 1:nx
    y = round(alpha + beta*x,digits = 0)
    stepwts = rep(2, nx)
    stepwts[which(diff(y)==0)+1] = 1
  }
  if(ny>nx){
    beta = (nx-1)/(ny-1)
    alpha = 1-beta
    
    y = 1:ny
    x = round(alpha + beta*y,digits = 0)
    stepwts = rep(2, ny)
    stepwts[which(diff(x)==0)+1] = 1
  }
  if(nx==ny){
    x = 1:nx
    y = 1:ny
    stepwts = rep(2,nx)
  }
  
  #dtw distance
  donpath = d[cbind(x,y)]
  dtwdist = sum(stepwts*donpath)
  timediff = sqrt(mean((x-y)^2))
  return(list(index1 = x, index2 = y, distance = dtwdist, normalizedDistance = dtwdist/(nx+ny)))
  
}




mydtw = function(datall, refid, alvars, varwts, sp, timename,varname,...){
  
  
  n = length(datall)
  ref = datall[[refid]]
  dat_alligned = list(NA)
  dtwresults = list(NA)
  measfreq = 1
  grid_ref=ref[,1]
  varwts = as.numeric(varwts)
  
  for(i in (1:n)[-refid]){
    qry = datall[[i]]
    d = mydist(data.frame(qry[,alvars]),data.frame(ref[, alvars]), varwts = varwts)
    
    
    if((sp == "PInf")[1]){
      lineup = diagdtw(d)
    }else{
      lineup = dtw(d, step.pattern = sp,...)
    }
    
    #varmspe[i] = lineup$normalizedDistance
    #timemspe[i] = sqrt(sum((lineup$index1 - lineup$index2)^2)/length(lineup$index1))
 
    tid = which(colnames(qry)==timename)
    qry = matrix(qry[,-tid],ncol =length(alvars))  #remove time column #++++++++
    
    
    qry2 <- data.frame(matrix(ncol = ncol(qry), nrow = max(lineup$index2)))
    colnames(qry2) = colnames(qry)
    
    
    idx = data.frame(qryidx = lineup$index1, refidx = lineup$index2)
    tw = rep(NA, max(idx$refidx))
    
    for(j in 1:max(idx$refidx)){
      matchid = idx$qryidx[idx$refidx == j]
      qry2[j,] = colMeans(matrix(qry[matchid,],ncol=1))#++++++++
      tw[j] = max(matchid)
    }
    tw = measfreq*tw
    
    grid_i=datall[[i]][,1]
    qry2 = cbind(grid_i[tw], qry2)
    colnames(qry2)[1] = timename
    colnames(qry2)[2] = varname
    
    #for(i in 1:7){plot(qry2[,i], main = colnames(qry2)[i], type = "o")}
    
    
    dat_alligned[[i]] = qry2
    dtwresults[[i]] = lineup
    
    
    
  }
  
  
  dat_alligned[[refid]] = datall[[refid]][,1:2]
  #dat_alligned[[refid]][,1] = 1:nrow(dat_alligned[[refid]])
  
  
  return(list(batches = dat_alligned, dtwoutput = dtwresults))
  
}


findwts = function(datall, refid, alvars, varwts, sp, method, timename){

  
  n = length(datall)
  ref = datall[[refid]]
  wts = varwts
  wts=(wts*length(wts))/sum(wts)
  wtsall = as.data.frame(t(wts))
  colnames(wtsall)=alvars
  measfreq = diff(datall[[1]][,timename][1:2]) #NB. Sensitive to naming of time column!
  
  if(method == "ramaker"){    
    for(iter in 1:20){
      
      wtsperbatch = matrix(nrow=n, ncol=length(alvars))
      
      dat_alligned = datall
      for(i in (1:n)[-refid]){
        qry = datall[[i]]
        
        d = mydist(qry[,alvars],ref[, alvars], varwts = wts)
        
        lineup = dtw(d, step.pattern=sp)
        pathidx = cbind(lineup$index1, lineup$index2)
        n_onpath = nrow(pathidx)
        n_offpath = length(d) - n_onpath
        
        
        for(vidx in 1:length(alvars)){
          dv = as.matrix(mydist(qry[,alvars[vidx]],ref[, alvars[vidx]]))
          sum_onpath = sum(dv[pathidx])
          sum_offpath = sum(dv) - sum_onpath
          wtsperbatch[i, vidx] = (sum_offpath*n_onpath)/(sum_onpath*n_offpath)
        }
        
      
        
        if(iter==20){
          timeid = which(colnames(qry)==timename)
          qry = qry[,-timeid] #remove time column
          qry2 <- data.frame(matrix(ncol = ncol(qry), nrow = max(lineup$index2)))
          colnames(qry2) = colnames(qry)
          
          idx = data.frame(qryidx = lineup$index1, refidx = lineup$index2)
          tw = rep(NA, max(idx$refidx))
          
          for(j in 1:max(idx$refidx)){
            matchid = idx$qryidx[idx$refidx == j]
            qry2[j,] = colMeans(qry[matchid,])
            tw[j] = max(matchid)
          }
          tw = measfreq*tw
          qry2 = cbind(tw, qry2)
          colnames(qry2)[1] = timename
          
          dat_alligned[[i]] = qry2
        }
      }
      if(iter==20){dat_alligned[[refid]] = datall[[refid]][,colnames(dat_alligned[[1]])]}
      
      wts = colMeans(wtsperbatch[-refid,])
      wts = wts*length(alvars)/sum(wts)  # Change here !!!!!!!!!!!!!!!!
      
      wtsall = rbind(wtsall, wts)
    }# end of iteration
  } #end of ramaker method
  
  
  
  if(method == "kassidas"){
    for(iter in 1:20){
      
      if(iter>3){ref = B_bar}
      dat_alligned = datall
      for(i in (1:n)[-refid]){
        qry = datall[[i]]
        
        d = mydist(qry[,alvars],ref[, alvars], varwts = wts)
        
        lineup = dtw(d, step.pattern=sp)
        
        timeid = which(colnames(qry)==timename)
        qry = qry[,-timeid] #remove time column
        
        
        qry2 <- data.frame(matrix(ncol = ncol(qry), nrow = max(lineup$index2)))
        colnames(qry2) = colnames(qry)
        
        
        idx = data.frame(qryidx = lineup$index1, refidx = lineup$index2)
        tw = rep(NA, max(idx$refidx))
        
        for(j in 1:max(idx$refidx)){
          matchid = idx$qryidx[idx$refidx == j]
          qry2[j,] = colMeans(qry[matchid,])
          tw[j] = max(matchid)
        }
        
        tw = measfreq*tw
        qry2 = cbind(tw, qry2)
        colnames(qry2)[1] = timename
        dat_alligned[[i]] = qry2
      }
      
      dat_alligned[[refid]] = datall[[refid]][,colnames(dat_alligned[[1]])]
      
      B_bar = aaply(laply(dat_alligned, as.matrix), c(2, 3), mean)
      
      sse=rep(NA, length(alvars))
      for(i_dev in 1:length(alvars)){
        vn=alvars[i_dev]
        sse[i_dev] = sum(unlist( lapply(dat_alligned, function(x) sum((x[,vn]-B_bar[,vn])^2)) ))
      }
      
      wts = 1/sse
      wts = (wts/sum(wts))*length(alvars)
      wtsall = rbind(wtsall, wts)
      
    }
  } #end of kassidas method
  
  eps = rep(NA, iter+1)
  for(i in 2:(iter+1)){
    eps[i] = sqrt(sum( (wtsall[i,]-wtsall[i-1,])^2 ))
  }
  
  wtsall$epsilon = eps
  
  return(list(batches = dat_alligned, weights = wtsall))  
}
  

findwts2 = function(datall, refid, alvars, varwts, sp, timename){
  n = length(datall)
  ref = datall[[refid]]
  wts = varwts
  wts=(wts*length(wts))/sum(wts)
  wtsall = as.data.frame(t(wts))
  colnames(wtsall)=alvars
  measfreq = diff(datall[[1]][,timename][1:2]) #NB. Sensitive to naming of time column!
  epsall = rep(NA,21)
    iter=0
    eps = 1
    while(eps>1e-4 & iter<20){
      iter=iter+1
      wtsperbatch = matrix(nrow=n, ncol=length(alvars))
      
      dat_alligned = datall
      for(i in (1:n)[-refid]){
        qry = datall[[i]]
        
        a = as.matrix(qry[,alvars])
        a = t(apply(a,1,function(x) x*sqrt(wts)))
        b = as.matrix(ref[,alvars])
        b = t(apply(b,1,function(x) x*sqrt(wts)))
        
        d = fastdist(a,b)
        
        lineup = dtw(d, step.pattern=sp)
        pathidx = cbind(lineup$index1, lineup$index2)
        n_onpath = nrow(pathidx)
        n_offpath = length(d) - n_onpath
        
        
        for(vidx in 1:length(alvars)){
          dv = as.matrix(mydist(qry[,alvars[vidx]],ref[, alvars[vidx]]))
          sum_onpath = sum(dv[pathidx])
          sum_offpath = sum(dv) - sum_onpath
          wtsperbatch[i, vidx] = (sum_offpath*n_onpath)/(sum_onpath*n_offpath)
        }
      }
      
      wts = colMeans(wtsperbatch[-refid,])
      wts = wts*length(alvars)/sum(wts)  # Change here !!!!!!!!!!!!!!!!
      
      wtsall = rbind(wtsall, wts)
      eps = sqrt(sum( (wts-wtsall[iter,])^2 ))
      epsall[iter+1] = eps
    }# end of iteration
  
  wtsall$epsilon = epsall[1:nrow(wtsall)]
  
  return(wtsall)
}




myscale = function(datall, noscale, minvals, mnrn){
  # Scales list of dataframes by the subtracting the minimum and dividing by the mean range
  # Scales all variables except those given by nocscale.
  I =length(datall)
  J = ncol(datall[[1]])
  
  if(missing(minvals)){
    minvals=rep(NA,J)
    mnrn = rep(NA,J)
    for(i in 1:J){
      mnrn[i]=mean(unlist(lapply(datall, function(x) diff(range(x[,i])) )))
      minvals[i]=min(unlist(lapply(datall, function(x) min(x[,i])) ))
    }
    names(mnrn)=colnames(datall[[1]])
    names(minvals)=names(mnrn)
    mnrn=data.frame(t(mnrn))
    minvals=data.frame(t(minvals))
  }
  
  if(!missing(noscale)){minvals[noscale]=0; mnrn[noscale]=1}
  
  datscale=list(rep(NA, I))
  for(i in 1:I){
    dat=datall[[i]]
    sc = mnrn[rep(1, nrow(dat)),]
    minim=minvals[rep(1, nrow(dat)),]
    dat=dat-minim
    dat=dat/sc
    datscale[[i]]=dat
  }
  
  return(list(datscale, scaleinfo = list(minvals, mnrn)))
}

# Use command: convert *.png -delay 3 -loop 0 binom.gif
# Delay is time between frames and loop i number of repeats (0 means forever)


# Online Alignment function


onlinedtw = function(qry, ref, alvars, varwts, sp, gc){
  # Returns warpings. Column number corresponds to current batch time
  # Column gives the reference batch time corresponding to each qry time up until current time
  
  online = data.frame(batchtime = 1:nrow(qry), reftime = NA, dist = NA)
  Kref = max(ref[,1])
  Kqry = nrow(qry)
  #varwts= wts
  tstart = 1
  distances = rep(NA, Kqry)
  
  
  for(tnow in tstart:Kqry){
    d = mydist(qry[1:tnow,alvars, drop = F],ref[, alvars, drop = F], varwts = varwts)
    if(!missing(gc)){
      d = d+gc[1:nrow(d), 1:ncol(d)]
    }
    lineup = dtw(d, step.pattern = sp, open.end = T)
    distances[tnow] = lineup$normalizedDistance
    
    # Current warping function (Reference time against batch time)
    w = rep(NA, Kqry)
    for(j in 1:tnow){
      matchidx = lineup$index2[lineup$index1 == j]
      w[j] = max(matchidx)
    }
    
    if(tnow == tstart){warpings = w}else{warpings = cbind(warpings,w)}
    
  }
  
  colnames(warpings) = paste0("Qt", tstart:Kqry)

  return(list(warpings, distances))
  
  
}


mycbind = function(mat, vec){
  if(length(vec)<nrow(mat)){
    length(vec) = nrow(mat)
  }
  if(nrow(mat)<length(vec)){
    mat = rbind(mat,
               matrix(NA, nrow = length(vec) - nrow(mat), ncol = ncol(mat))
               )
  }
  
  mat = cbind(mat, vec)
  return(mat)
}

mat = matrix(1:9, nrow = 3)
mycbind(mat, 1:2)
mycbind(mat, 1:10)


onlinedtw2 = function(qry, ref, alvars, varwts, sp,gc){
  # Returns warpings. Column number corresponds to current batch time
  # Column gives the reference batch time corresponding to each qry time up until current time
  
  online = data.frame(batchtime = 1:nrow(qry), reftime = NA, dist = NA)
  Kref = max(ref$time)
  Kqry = nrow(qry)
  varwts= wts
  tstart = 1
  distances = rep(NA, Kqry)
  
  rtime = matrix(NA, nrow = 1, ncol = tstart - 1)
  qtime = rtime
  
  for(tnow in tstart:Kqry){
    d = mydist(qry[1:tnow,alvars],ref[, alvars], varwts = varwts)
    if(!missing(gc)){
      d = d+gc[1:nrow(d), 1:ncol(d)]
    }
    lineup = dtw(d, step.pattern = sp, open.end = T)
    distances[tnow] = lineup$normalizedDistance
    
    qtime = mycbind(qtime, lineup$index1)
    rtime = mycbind(rtime, lineup$index2)
    
    

    
  }
  
  #colnames(warpings) = paste0("Qt", tstart:Kqry)
  
  return(list(qtime,rtime, distances))
  
  
}

onlinedtw3 = function(qry, ref, alvars, varwts, sp,gc){
  # Returns warpings. Column number corresponds to current batch time
  # Number of rows = length of reference. Row is reference time.
  
  online = data.frame(batchtime = 1:nrow(qry), reftime = NA, dist = NA)
  Kref = nrow(ref)
  Kqry = nrow(qry)
  #varwts= wts
  tstart = 1
  distances = rep(NA, Kqry)
  
  
  for(tnow in tstart:Kqry){
    d = mydist(qry[1:tnow,alvars, drop = F],ref[, alvars, drop = F], varwts = varwts)
    if(!missing(gc)){
      d = d+gc[1:nrow(d), 1:ncol(d)]
    }
    lineup = dtw(d, step.pattern = sp, open.end = T)
    distances[tnow] = lineup$normalizedDistance
    
    # Current warping function (batch time against reference time)
    w = aggregate(lineup$index1, by = list(lineup$index2), max)$x
    length(w) = Kref
    
    
    if(tnow == tstart){warpings = w}else{warpings = cbind(warpings,w)}
    
  }
  
  colnames(warpings) = paste0("Qt", tstart:Kqry)
  
  return(list(warpings, distances))
  
  
}

onlinedtw4= function(qry, ref, alvars, sp, varwts,gc){
  # Returns single data frame of online warpings for each batch
  # OuterBT, OuterRT, InnerBT, InnerRT, DTWdist
  
  if(missing(varwts)){varwts = rep(1, length(alvars))}
  Kref = nrow(ref)
  Kqry = nrow(qry)

  for(tnow in 1:Kqry){
    d = mydist(qry[1:tnow,alvars, drop = F],ref[, alvars, drop = F], varwts = varwts)
    if(!missing(gc)){
      d = d+gc[1:nrow(d), 1:ncol(d)]
    }
    lineup = dtw(d, step.pattern = sp, open.end = T)
    w = data.frame(OuterBT = tnow,
                   OuterRT = max(lineup$index2),
                   InnerBT = lineup$index1,
                   InnerRT = lineup$index2,
                   Dist = lineup$normalizedDistance)
    if(tnow == 1){df = w}else{df = rbind(df,w)}
  }
  return(df)
}







warpedline = function(qtime,rtime, qry){
  rtime = rtime[!is.na(rtime)]
  qtime = qtime[!is.na(qtime)]
  qry = qry[qtime]
  qry = aggregate(qry, by = list(rtime), mean)$x
  return(qry)
}



mylines = function(mat, title, col){
  if(missing(col)){col = 1}
  col = rep(col, length.out = nrow(mat))
  plot(1,1,xlim = c(0,ncol(mat)), ylim = range(mat, na.rm = T), main = title, type = "n")
  jnk = apply(cbind(col, mat),1, function(x) lines(x[-1], col = x[1]))
}




mysteppattern = function(p){
  if(p>=1 & p<1000){
    c1 = c(rep(1, p+2), rep(2,2), rep(3,p+2))
    c2 = c(p:0, 0,  1, 0, (p+1):0)
    c3 = c((p+1):0, 1, 0, p:0, 0)
    c4 = c(-1, rep(2, p), 1, -1, 2, -1, rep(2, p), 1)
    mat = cbind(c1,c2,c3,c4)
    out = dtw:::stepPattern(mat, "N+M")
  }else{
    if(p==0){out = symmetricP0}
    if(p == 0.5){out = symmetricP05}
    if(p == Inf){out = "PInf"}
  }
  return(out)
}


# C:\Users\mpsp\Documents\dtw_1.18-1.tar\dtw_1.18-1\dtw\R
plotp = function(p){
  if(p==0.5){
    mat = matrix(c(
      1  ,  1, 3 , -1,
      1  ,  0, 2 ,  2,
      1  ,  0, 1 ,  1,
      1  ,  0, 0 ,  1,
      2  ,  1, 2 , -1,
      2  ,  0, 1 ,  2,
      2  ,  0, 0 ,  1,
      3  ,  1, 1 , -1,
      3  ,  0, 0 ,  2,
      4  ,  2, 1 , -1,
      4  ,  1, 0 ,  2,
      4  ,  0, 0 ,  1,
      5  ,  3, 1 , -1,
      5  ,  2, 0 ,  2,
      5  ,  1, 0 ,  1,
      5  ,  0, 0 ,  1), ncol = 4, byrow = T)
  }else{
    mat = matrix(c(rep(1, p+2), rep(2,2), rep(3,p+2),
                   p:0, 0,  1, 0, (p+1):0,
                   (p+1):0, 1, 0, p:0, 0,
                   -1, rep(2, p), 1, -1, 2, -1, rep(2, p), 1), ncol = 4, byrow = F)
  }
  
  maxi = max(mat[,2])
  plot(0,0, xlim = c(-maxi, 0), ylim = c(-maxi, 0), type = "n", axes = F,#xaxt = "n", yaxt = "n",
       xlab = "", ylab = "", main = paste("P =", p))
  labsi = paste0("i - ",(maxi):0); labsi[maxi+1] = "i"
  labsj = paste0("j - ",(maxi):0); labsj[maxi+1] = "j"
  
  if(maxi<10){
  axis(side = 1,at = (-maxi):0, labsi, las = 2)
  axis(side = 2,at = (-maxi):0, labsj, las = 2)
  }else{
    idx = seq(length(labsi),1,by = -2)
    axis(side = 1,at = ((-maxi):0)[idx], labsi[idx], las = 2)
    axis(side = 2,at = ((-maxi):0)[idx], labsj[idx], las = 2)
  }
  for(i in 1:(max(mat[,1]))){
    m = mat[mat[,1]==i,]
    lines(-m[,2], -m[,3], type = "o", pch = 20, cex = 1)
  }

  
}

myresults = function(mydtwobj, refid){
  countsteps = function(idx1, idx2){
    ndiag = sum(diff(idx1)==1 & diff(idx2) == 1)+1
    ntot = length(idx1)
    nhv = ntot-ndiag
    return(nhv)
  }
  
  alp0 = mydtwobj
  
  dtwdist = lapply(alp0[[2]], function(obj) obj$normalizedDistance)
  dtwmn = mean(unlist(dtwdist[-refid]))
  dtwsd = sd(unlist(dtwdist[-refid]))
  
  Nhv = sapply(alp0[[2]], function(obj) countsteps(obj$index1, obj$index2))
  
  #Nhv = sapply(alp0[[2]], function(obj) sqrt(mean((obj$index1-obj$index2)^2)))
  
  Nhv = mean(Nhv[-refid])
  return(c(dtwmn, Nhv, dtwsd))
}



calcperformance = function(statval, cl, onsettimes){
  # Statval: n_times x n_batches matrix of monitoring statistic
  # cl: control limit
  # onsettimes: n-batches length vector of fault onset times (0 for NOC batches)
  
  K = nrow(statval)
  I = ncol(statval)
  
  idxnoc = which(onsettimes == 0)
  
  performance = data.frame(FPR = rep(NA, I), TPR = rep(NA,I), TTS = rep(NA, I), TTS3 = rep(NA,I))
  
  for(i in 1:I){
    x = statval[,i]
    # if batch ends before K, last stavals will be NA
    if(any(is.na(x))){n = min(which(is.na(x)))-1}else{n = K}
    
    x = x[1:n]
    
    if(length(cl)>1){cl_i = cl[1:n]}else{cl_i = cl}
    
    alarms = x > cl_i
    alarms3 = c(F,F,
                alarms[1:(n-2)] & alarms[2:(n-1)] & alarms[3:n])
    
    if(i %in% idxnoc){
      fpr = sum(alarms)/length(alarms)
      dr = NA
      tts = NA
      tts3 = NA
    }else{
      faultytimes = (1:n)>onsettimes[i]
      dr = sum(faultytimes & alarms)/sum(faultytimes)
      fpr = sum((!faultytimes) & alarms)/sum(!faultytimes)
      tts = NA
      tts3 = NA
      if(any(faultytimes & alarms3)){
        tts3 = min(which(faultytimes & alarms3))-min(which(faultytimes))
      }
      if(any(faultytimes & alarms)){
        tts = min(which(faultytimes & alarms))-min(which(faultytimes))
      }
    }
    performance$FPR[i] = fpr
    performance$TPR[i] = dr
    performance$TTS[i] = tts
    performance$TTS3[i] = tts3
  }
  
  return(performance)
}



nnwts = function(datsc, refidx, k, wtsinit, vmeas){
  wtsall = matrix(nr=length(refidx),nc=length(vmeas),NA)
  wts = wtsinit
  for(j in 1:length(refidx)){
    print(j)
    ri = refidx[j]
    ri = j
    temp = datsc
    temp = lapply(temp, function(x) as.matrix(t(apply(x[,vmeas], 1, function(y) y*sqrt(wts)))))
    dvec = rep(NA, length(temp))
    for(i in (1:length(temp))[-ri]){
      cm = fastdist(temp[[i]], temp[[ri]])
      dvec[i] = dtw(cm, step.pattern = symmetricP1,distance.only = T)$normalizedDistance
    }
    nn = order(dvec)[1:k]
    
    temp = datsc[c(ri,nn)]
    ram = findwts2(temp, refid = 1, alvars = vmeas, varwts = wts,
                   sp = symmetricP1, timename = "Time")
    wts = as.numeric(ram[nrow(ram),1:12])
    wtsall[j,] = wts
    
    # for next nn search
    wts = apply(wtsall,2,mean,na.rm = T)
    wts = 12*(wts/sum(wts))
  }
  return(wtsall)
}


# Following adapted from code for backtrack function in dtw package
mybacktrack= function (gcm)
{
  .extractpattern = function (sp, sn) 
  {
    sbs <- sp[, 1] == sn
    spl <- sp[sbs, -1, drop = FALSE]
    nr <- nrow(spl)
    spl <- spl[nr:1, , drop = FALSE]
    return(spl)
  }
  
  
  dir <- gcm$stepPattern
  npat <- attr(dir, "npat")
  n <- nrow(gcm$costMatrix)
  m <- ncol(gcm$costMatrix)
  i <- n
  j <- gcm$jmin
  nullrows <- dir[, 2] == 0 & dir[, 3] == 0
  tmp <- dir[!nullrows, , drop = FALSE]
  stepsCache <- list()
  for (k in 1:npat) {
    stepsCache[[k]] <- .extractpattern(tmp, k)
  }
  iis <- ii <- c(i)
  jjs <- jj <- c(j)
  ss <- NULL
  repeat {
    if (i == 1 && j == 1) {
      break
    }
    s <- gcm$directionMatrix[i, j]
    if (is.na(s)) {
      break
    }
    ss <- c(s, ss)
    steps <- stepsCache[[s]]
    ns <- nrow(steps)
    for (k in 1:ns) {
      ii <- c(i - steps[k, 1], ii)
      jj <- c(j - steps[k, 2], jj)
    }
    i <- i - steps[ns, 1]
    j <- j - steps[ns, 2]
    iis <- c(i, iis)
    jjs <- c(j, jjs)
  }
  out <- list(index1 = ii, index2 = jj, index1s = iis, index2s = jjs, 
              stepsTaken = ss)
  return(out)
}
mydist = function(X,Y, varwts, tmwts){
  # X is query
  # Y is reference
  if(!missing(varwts)){
    varwts = sqrt(varwts)
    for(i in 1:length(varwts)){
      X[,i] = varwts[i]*X[,i]
      Y[,i] = varwts[i]*Y[,i]
    }
  }
  
  d = dist(X,Y, method = "euclidean")
  d = d^2
  if(!missing(tmwts)){d = t(t(d) * tmwts)}
  return(d)  
}
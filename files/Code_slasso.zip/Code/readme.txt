This folder contains the R files for a single run of the simulation study in Scenario II with sample size n=500.
The main file is Run.R that provides the ISE and PMSE values corresponding to the considered run.
The file functions_fd.R contains some functions used in Run.R.

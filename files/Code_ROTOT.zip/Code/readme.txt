The script functions.R contains all the functions 
required by the script below.

The script LFW_analysis.R reproduces some plots
of section 5 of the paper.


# LFW analysis
# Manage libraries --------------------------------------------------------
rm(list = ls()); 
setwd(dirname(rstudioapi::getSourceEditorContext()$path))

# List of required CRAN packages
required_packages <- c("argparse", "rTensor", "Rcpp", "cellWise", "parallel",
                       "ggplot2", "RcppArmadillo", "devtools", "OmicsPLS",
                       "combinat", "fastmatrix","Matrix", "abind", "rrcov",
                       "robustbase", "scales", "reshape2", "RSpectra", 
                       "MultiwayRegression", "RobStatTM")

# Function to check and install missing CRAN packages
install_if_missing <- function(packages) {
  missing_packages <- packages[!(packages %in% installed.packages()[,"Package"])]
  if(length(missing_packages) > 0) {
    cat("\n Installing missing packages:", paste(missing_packages, collapse = ", "), "\n")
    install.packages(missing_packages, dependencies = TRUE)
  } else {
    cat("\n All required CRAN packages are already installed.\n")
  }
}

# Install required CRAN packages
install_if_missing(required_packages)

# Ensure "devtools" is loaded before installing from GitHub
library(devtools)

# Check & Install `rfunctions` from GitHub if missing
if (!"rfunctions" %in% installed.packages()[,"Package"]) {
  cat("\n Installing `rfunctions` from GitHub...\n")
  devtools::install_github("jaredhuling/rfunctions")
}

# Load all packages
all_packages <- c(required_packages, "rfunctions")
lapply(all_packages, library, character.only = TRUE)


seed.set <- 1998
set.seed(seed.set)
source("functions.R")

# Import data -------------------------------------------------------------
lfw_data <- readRDS("LFW_data.rds")

# Get data
Xfull <- lfw_data$Xfull
Yfull <- lfw_data$Yfull

# paramters
set.seed(seed.set)
dimensionY <- dim(Yfull)
dimensionX <- dim(Xfull)
dimeY <- c(dimensionY[-1], 10000)
dimeX <- c(dimensionX[-1], 10000)
set.seed(seed.set)
par <- c(0.7189176, 0.8096263, 3.8975767, 2.0570039) #get_tuning_const_tanh(dimeY, 1.5, 1)
par.mpca <- c(0.6984245, 0.7247385, 7.2362134, 3.6793787) #get_tuning_const_tanh(dimeX, 1.5, 1)
b <- 1.5 # parameters for ROTOT
delta <- 1e-05 # parameters for L1 and Huber
N <- dimensionY[1]
Q <- dim(Yfull)[2:((length(dim(Yfull)) - 1) + 1)]

# Initialize ranks and lambda ---------------------------------------------
# Chose ranks for ROMPCA
# ROTOT(
#   X = Xfull,
#   Y = Yfull,
#   R = current_rank_rotot,
#   lambda = lam_rotot,
#   b = b
# )

# Get lambda and ranks for TOT
# set.seed(seed.set)
# K.folds <- 5
# folds <- sample(rep(1:K.folds, length.out = N))
# grid_ranks <- 7:10
# grid_lambda <- c(1e04, 1e05, 1e06, 1e07)
# res_par <- cv_parallel(
#   Yfull = Yfull,
#   Xfull = Xfull,
#   Ximp = ROTOT.out$Ximp,
#   outl.X = ROTOT.out$outl.X,
#   folds = folds,
#   K.folds = K.folds,
#   b = b,
#   tpar = par,
#   grid.lambda = grid_lambda,
#   grid.ranks = grid_ranks,
#   convThresh = 1e-05,
#   seed.set = seed.set,
#   ncores_par = detectCores() - 6
# )
# argmin_tot = which.min(sapply(1:length(res_par), \(x) res_par[[x]]$scale.tot.ave))
# argmin_rotot = which.min(sapply(1:length(res_par), \(x) res_par[[x]]$scale.rotot.ave))
# current_rank_tot <- res_par[[argmin_tot]]$rank
# lam_tot <- res_par[[argmin_tot]]$lambda
# current_rank_rotot <- res_par[[argmin_rotot]]$rank
# lam_rotot <- res_par[[argmin_rotot]]$lambda

# ROTOT -------------------------------------------------------------------
current_rank_rotot <- 10
lam_rotot <- 1e+05

ranks_X = c(7,7)
ROTOT.out <- ROTOT(
  X = Xfull,
  Y = Yfull,
  R = current_rank_rotot,
  lambda = lam_rotot,
  b = b,
  tpar = par,
  tpar.mpca = par.mpca,
  ranks_X = ranks_X,
  OFS = FALSE,
  seed = seed.set,
  convThresh = 1e-05
)

# Save results ------------------------------------------------------------
# saveRDS(ROTOT.out, file = "LFW_ROTOT.RDS")
# saveRDS(res_par, file = "LFW_CV.RDS")

# ROTOT.out <- readRDS("LFW_ROTOT.RDS")
# res_par <- readRDS("LFW_CV.RDS")

# Residual Map ------------------------------------------------------------
Ximp <- ROTOT.out$Ximp
Y.pred.rotot <- ctprod(Ximp, ROTOT.out$B, 2) + ROTOT.out$B0
Res.rotot <- Yfull - Y.pred.rotot
scale.cell.re.new <- apply(Yfull - Y.pred.rotot, 2, scale_tanh)
Res.std <- Res.rotot/matrix(scale.cell.re.new, N, Q, byrow = T)

label.idx <- c(1:5, 8, 10, 20, 304, 336)
ResidualMap(
  R = Res.std[label.idx,],
  mTitle = " Residual cellmap",
  sizemain = 0.8,
  sizerowlabels = 0.4,
  sizetitles = 0.8,
  sizecolumnlabels = 0,
  rowtitle = "Cases",
  columntitle = "Attributes",
  rowlabels = paste0(label.idx),
  autolabel = FALSE,
  drawCircles = FALSE
)

ggsave(
  filename = "LFW_Outl_UnfResidualMap_ROTOT_new.pdf",
  device = "pdf",
  width = 4,
  height = 1.5,
  dpi = 400
)

# Outlier Map -------------------------------------------------------------
tens.obj <- list(Y = Yfull, Y.pred = Y.pred.rotot, X.cont = aperm(Xfull, c(2, 3, 1)))
lfw_outmap <- OutlierMap_TR(
  tens.obj = tens.obj,
  X.model = ROTOT.out$ROMPCA,
  score_distance = ROTOT.out$ROMPCA$score.distance,
  ranks.mp = ranks_X,
  par.mpca = par.mpca,
  idx_to_label = c(3, 5, 20)
)
lfw_outmap$outmap

ggsave(
  filename = "LFW_Outl_OutlierMap_ROTOT_new.pdf",
  device = "pdf",
  width = 6,
  height = 5,
  dpi = 400
)

# Boxplot of the variable blury -------------------------------------------
df_y <- stack(as.data.frame(Yfull[, c("Blurry", "Flash")]))
ggplot(df_y, aes(x = ind, y = values)) +
  stat_boxplot(geom = "errorbar", width = 0.25, linewidth = 0.8) +
  geom_boxplot(linewidth = 1) +
  geom_point(x = "Blurry", y = Yfull[8, "Blurry"], color = "red", size = 3) +
  geom_point(x = "Flash", y = Yfull[8, "Flash"], color = "red", size = 3) +
  theme_minimal(base_size = 14) +
  theme(
    axis.title.x = element_text(size = 11),
    axis.title.y = element_text(size = 11),
    panel.background = element_rect(fill = "gray90", color = NA),
    panel.grid.major = element_line(color = "white"),
    panel.grid.minor = element_line(color = "white"),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1.2),
    legend.position = "none"
  ) + labs(x = NULL) + labs(y = NULL) + coord_cartesian(ylim = c(-5, 5))

ggsave(
  filename = "LFW_boxplots_variables.pdf",
  device = "pdf",
  width = 3.5,
  height = 3,
  dpi = 400
)

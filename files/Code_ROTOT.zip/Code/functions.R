################################################################################
##                                                                             #
##                    Functions to perform ROTOT.                              #
##                                                                             #
################################################################################
# TOT functions -----------------------------------------------------------
DDC_TOT <- function(X, Y, R, lambda = 0, w.fix = NULL, 
                    h = 0.75, convThresh = 10^(-5), seed = 1998){
  # Initialisation starting with DDC.
  #
  # Arguments:
  # X: an P1x...xPL tensor.
  # Y: an Q1x...xQM tensor.
  # R: the number of ranks for every mode.
  # lambda: regularization parameter.
  # w.fix: outliers set from the predictors
  # h: parameter for the number of observation retained after DDC.
  #    Depending on the value, there is tradeoff between robustness
  #    and efficiency. Typically set to 0.75.
  # convThresh: tolerance of the IRLS algorithm (for stopping rule)
  # seed: seed.
  # silent: whether the progress bar is outputted.
  
  #### Apply DDC ####
  dimension <- dim(Y)
  Y.unf <- n_unfold(Y, 1)
  ddc.out <- cellWise::DDC(Y.unf, DDCpars = list(silent = TRUE)) 
  
  #### construct weight tensor ####
  ind.case.X <- w.fix
  
  ind.case.ddc <- unique(c(ddc.out$indrows, w.fix))
  indcell.out <- array(0, dim(Y.unf))
  indcell.out[ddc.out$indcells] <- NA
  indcell.out <- n_fold(indcell.out, Y, dim(Y)[1], n = 1)
  indcell.out <- which(is.na(indcell.out)) # for cellwise weight
  W.fixed <- array(1, dim(Y))
  
  W.fixed[indcell.out] <- 0
  if(length(which(is.na(Y))) != 0) W.fixed[which(is.na(Y))] <- 0 # for NA
  if(length(ind.case.ddc) != 0) W.fixed[ind.case.ddc,] <- 0 # for casewise weight
  
  #### TOT on the h observation with fewest cellwise ####
  outl.obs <- array(rep(1, prod(dimension)), dimension)
  outl.obs <- n_unfold(outl.obs, 1) # n-mode unfolding
  outl.obs[ddc.out$indcells] <- 0
  
  sorted_indices <- order(rowSums(outl.obs), decreasing = FALSE)
  sorted_indices <- setdiff(sorted_indices, ind.case.ddc) # to remove the observation considered as casewise by DDC
  reduced_indices <- sorted_indices[1:floor(h * length(sorted_indices))]
  
  Y_sorted <- Y[reduced_indices,]
  Y_sorted_ddc <- n_fold(ddc.out$Ximp, Y, dim(Y)[1], n = 1)
  Y_sorted_ddc <- Y_sorted_ddc[reduced_indices,]
  X_sorted_ddc <- X[reduced_indices,,]
  
  # Center X and Y
  X_sorted_ddc.mean <- array(0, dim(X_sorted_ddc)[-1])
  Y_sorted_ddc.mean <- array(0, dim(Y_sorted_ddc)[-1])
  for (i in 1:length(reduced_indices)) {
    X_sorted_ddc.mean <- X_sorted_ddc[i,,] + X_sorted_ddc.mean
    Y_sorted_ddc.mean <- Y_sorted_ddc[i,] + Y_sorted_ddc.mean
  }
  X_sorted_ddc.mean <- X_sorted_ddc.mean/length(reduced_indices)
  X_sorted_ddc.mean <- array(rep(X_sorted_ddc.mean, times = length(reduced_indices)), dim = c(dim(X)[-1], length(reduced_indices)))
  X_sorted_ddc.mean <- aperm(X_sorted_ddc.mean, c(3, 1, 2))
  
  Y_sorted_ddc.mean <- Y_sorted_ddc.mean/length(reduced_indices)
  Y_sorted_ddc.mean <- array(rep(Y_sorted_ddc.mean, times = length(reduced_indices)), dim = c(dim(Y)[-1], length(reduced_indices)))
  Y_sorted_ddc.mean <- t(Y_sorted_ddc.mean)
  
  X_sorted_ddc_cent <- X_sorted_ddc - X_sorted_ddc.mean
  Y_sorted_ddc_cent <- Y_sorted_ddc - Y_sorted_ddc.mean
  
  # Classical TOT
  TOT.reduced <- rrr(X = X_sorted_ddc_cent, Y = Y_sorted_ddc_cent, R = R, convThresh = convThresh, seed = seed, lambda = lambda)
  U_reduced <- TOT.reduced$U
  V_reduced <- TOT.reduced$V
  B_reduced <- TOT.reduced$B
  Y_pred_reduced <- ctprod(X_sorted_ddc, B_reduced, 2)
  
  # Compute Intercept
  Nu <- array(0, dimension[-1])
  De <- array(0, dimension[-1])
  for(i in 1:length(reduced_indices)){
    Nu <- Nu + ((Y_sorted_ddc[i,] - Y_pred_reduced[i,]))
  }
  B0 <- Nu/(length(reduced_indices))
  B0 <- array(rep(B0, times = dimension[1]), dim = c(dimension[-1], dimension[1]))
  B0 <- t(B0)
  
  TOT.ddc.init <- list(B = B_reduced, B0 = B0, U = U_reduced, V = V_reduced)
  
  #### Result ####
  res <- list()
  res$U <- U_reduced
  res$V <- V_reduced
  res$B <- B_reduced
  res$B0 <- B0
  res$init <- TOT.ddc.init
  return(res)
}

Huber_TOT <- function (X, Y, R, lambda = 0, delta = 1e-05, init, w.fix = NULL, 
                       max_iter = 100, convThresh = 10^(-5), seed = 0, scale.cell = NULL, 
                       silent = FALSE){
  # Huber-TOT.
  #
  # Arguments:
  # X: an P1x...xPL tensor.
  # Y: an Q1x...xQm tensor.
  # R: the number of ranks for the coefficient tensor. Obtained from CV.
  # lambda: the number of ranks for the coefficient tensor. Obtained from CV.
  # delta: parameter for L1 weights.
  # init: a list containing initial estimators for V, U and C.
  # w.fix: outliers set from the predictors
  # max_itr: maximum number of iterations.
  # convThresh: tolerance of the IRLS algorithm (for stopping rule).
  # seed: seed.
  # scale.cell.reshape: cellwise residual scales.
  #             Typically NULL and computed internally.
  # silent: whether the progress bar is outputted.
  
  #### Auxiliary functions ####
  rho_huber <- function(x, delta = 1e-05) {
    rhos <- numeric(length(x))
    abs_x <- abs(x)
    
    # abs(x) <= delta
    idx1 <- abs_x <= delta
    rhos[idx1] <- 0.5 * x[idx1]^2
    
    # abs(x) > delta
    idx2 <- abs_x > delta
    rhos[idx2] <- delta * (abs_x[idx2] - 0.5 * delta)
    
    dim(rhos) <- dim(x)
    return(rhos)
  }
  weight_huber <- function(Y, Y.pred, scale.cell, delta = 1e-05){
    psihuber <- function(xx, delta) {
      psi <- xx
      abs_xx <- abs(xx)
      psi[abs_xx > delta] <- delta * sign(xx[abs_xx > delta])
      
      return(psi)
    }
    
    D <- (Y - Y.pred) / scale.cell
    psi_vals <- psihuber(D, delta)
    weights <- ifelse(is.na(D), NA, ifelse(D == 0, 1, psi_vals / D))
    
    # Preserve array shape
    weights <- array(weights, dim = dim(D))
    return(weights)
  }
  weighted_loss_huber <- function(Y, Y.pred, scale.cell, w.fix = NULL, delta = 1e-05){
    W.fix <- rep(1, dim(Y)[1])
    if(!is.null(w.fix)){
      W.fix[w.fix] <-  0
    }
    D <- (Y - Y.pred) / scale.cell
    rho_vals <- scale.cell^2 * rho_huber(D, delta = delta)
    loss <- sum(W.fix * rho_vals, na.rm = TRUE)
    return(loss)
  }
  get_scell_L1 <- function(Y, Y.pred){
    Y.reshape <- t(Y)
    Ypred.reshape <- t(Y.pred)
    # Y.reshape <- aperm(Y, c(2, 3, 1))
    # Ypred.reshape <- aperm(Y.pred, c(2, 3, 1))
    D <- Y.reshape - Ypred.reshape
    I <- dim(D)
    num_mode <- length(I)
    N <- dim(Y)[1]
    
    scale.cell.reshape <- apply(D, 1:(num_mode - 1), RobStatTM::scaleM) #change with another scale?
    scale.cell.reshape <- array(rep(scale.cell.reshape, times = N), I)
    
    scale.cell <- t(scale.cell.reshape) # permute back
    return(scale.cell)
  }
  
  #### Algo setup ####
  if (seed > 0) 
    set.seed(seed)
  lambdaFin = lambda
  L = length(dim(X)) - 1
  N = dim(X)[1]
  P = dim(X)[2:(L + 1)]
  M = length(dim(Y)) - 1
  Q = dim(Y)[2:(M + 1)]
  Xmat = array(X, dim = c(N, prod(P)))
  Ymat = array(Y, dim = c(N, prod(Q)))
  Yvec = as.vector(Y)
  Y.unc <- Y
  
  #### Initialize U and V ####
  U = init$U
  V = init$V
  B0 = init$B0
  Y <- Y.unc - B0
  
  Vmat = matrix(nrow = prod(Q), ncol = R)
  for (r in 1:R) {
    Vr = lapply(V, function(x) x[, r])
    Vmat[, r] = as.vector(array(apply(expand.grid(Vr), 1, prod), dim = Q))
  }
  
  Bmat = matrix(nrow = R, ncol = prod(P))
  for (r in 1:R) {
    Ur = lapply(U, function(x) x[, r])
    Br = array(apply(expand.grid(Ur), 1, prod), dim = P)
    Bmat[r, ] = array(Br, dim = c(1, prod(P)))
  }
  Y_pred = as.vector(Xmat %*% t(Bmat) %*% t(Vmat))
  Xarrays = list()
  for (l in 1:L) {
    Xarrays[[l]] <- array(dim = c(N, P[l], prod(P[-l])))
    perm = c(l, c(1:L)[-l])
    for (i in 1:N) {
      X_slice = array(Xmat[i, ], dim = c(P))
      X_slice_perm = aperm(X_slice, perm)
      Xarrays[[l]][i, , ] = array(X_slice_perm, dim = c(P[l], 
                                                        prod(P[-l])))
    }
  }
  Ymats = list()
  for (m in 1:M) {
    perm = c(m + 1, c(1:(M + 1))[-(m + 1)])
    Y_perm = aperm(Y, perm)
    Ymats[[m]] = array(Y_perm, dim = c(Q[m], N * prod(Q[-m])))
  }
  
  # get scale cell
  B.tens = array(t(Bmat) %*% t(Vmat), dim = c(P, Q))
  Y_pred.tens <- ctprod(X, B.tens, 2) # change the 2 by any dimension
  if(is.null(scale.cell)){scale.cell <- get_scell_L1(Y, Y_pred.tens)}
  
  # get the huber weights
  W <- weight_huber(Y, Y_pred.tens, scale.cell, delta = delta)
  W.fix <- array(1, dim(W))
  if(!is.null(W.fix)){
    W.fix[w.fix,] <- 0
  }
  W <- W * W.fix
  
  Wmats = list() # matricize W
  for (m in 1:M) {
    perm = c(m + 1, c(1:(M + 1))[-(m + 1)])
    W_perm = aperm(W, perm)
    Wmats[[m]] = array(W_perm, dim = c(Q[m], N * prod(Q[-m])))
  }
  Wvec <- as.vector(W) # vectorize W
  
  #### Main part ####
  loss.val = c()
  loss.val[1] <- weighted_loss_huber(Y, Y_pred.tens, scale.cell, w.fix = w.fix, delta = delta) + lambda * sum((t(Bmat) %*% t(Vmat))^2)
  j = 0
  conv = convThresh + 1
  
  if(silent == FALSE) {pb <- txtProgressBar(min = 0, max = max_iter, style = 3)}
  
  while (conv > convThresh && j < max_iter) {
    j = j + 1
    
    if(silent == FALSE) {setTxtProgressBar(pb, j)}
    
    # if (j <= annealIter) {
    #   lambda = 100 * (annealIter - j)/annealIter + lambdaFin
    # }
    
    #### Update Ul ####
    for (l in 1:L) {
      B_red = matrix(nrow = prod(P[-l]), ncol = R)
      for (r in 1:R) {
        Ured_r <- lapply(U[-l], function(x) x[, r])
        B_red[, r] = as.vector(array(apply(expand.grid(Ured_r), 
                                           1, prod), dim = P[-l]))
      }
      X_red = matrix(nrow = N, ncol = P[l] * r)
      perm = c(l, c(1:L)[-l])
      for (i in 1:N) {
        X_red[i, ] = as.vector(Xarrays[[l]][i, , ] %*% 
                                 B_red)
      }
      C = matrix(nrow = dim(X_red)[1] * prod(Q), ncol = dim(X_red)[2])
      for (r in 1:R) {
        index = ((r - 1) * P[l] + 1):(r * P[l])
        C[, index] = kronecker(Vmat[, r], X_red[, index])
      }
      lambdaMat = kronecker(t(Vmat) %*% Vmat * t(B_red) %*% B_red, 2*lambda * diag(P[l]))
      
      CP <- t(C) %*% (C * Wvec)
      # regMat = MASS::ginv(CP + lambdaMat)
      regMat = safe_ginv(CP + lambdaMat)
      Ulvec <- regMat %*% (t(C) %*% (Yvec * Wvec))
      
      U[[l]] = matrix(Ulvec, nrow = P[l])
      Bmat = matrix(nrow = R, ncol = prod(P))
      for (r in 1:R) {
        Ur = lapply(U, function(x) x[, r])
        Br = array(apply(expand.grid(Ur), 1, prod), dim = P)
        Bmat[r, ] = array(Br, dim = c(1, prod(P)))
      }
      Y_pred = as.vector(Xmat %*% t(Bmat) %*% t(Vmat))
    }
    
    #### Update Vm ####
    for (m in 1:M) {
      BRmat = matrix(nrow = prod(c(P, Q[-m])), ncol = R)
      D = matrix(nrow = N * prod(Q[-m]), ncol = R)
      for (r in 1:R) {
        Vecs <- lapply(c(U, V[-m]), function(x) x[, r])
        Br = array(apply(expand.grid(Vecs), 1, prod),
                   dim = c(prod(P), prod(Q[-m])))
        BRmat[, r] = as.vector(Br)
        D[, r] = as.vector(Xmat %*% Br)
      }
      
      Vmvec1 <- kronecker(t(D), diag(dim(Ymats[[m]])[1])) %*% (kronecker(D, diag(dim(Ymats[[m]])[1])) * as.vector(Wmats[[m]]))
      lamvec <- kronecker((2*lambda * t(BRmat) %*% BRmat), diag(dim(Ymats[[m]])[1]))
      Vmvec <- safe_ginv(Vmvec1 + lamvec) %*% as.vector((Ymats[[m]] * Wmats[[m]])%*% D)
      V[[m]] = matrix(Vmvec, nrow = Q[m])
      
      Vmat = matrix(nrow = prod(Q), ncol = R)
      for (r in 1:R) {
        Vr = lapply(V, function(x) x[, r])
        Vmat[, r] = as.vector(array(apply(expand.grid(Vr),
                                          1, prod), dim = Q))
      }
      Y_pred = as.vector(Xmat %*% t(Bmat) %*% t(Vmat))
    }
    
    #### Update Center ####
    B.tens = array(t(Bmat) %*% t(Vmat), dim = c(P, Q))
    Y_pred.tens <- ctprod(X, B.tens, 2)
    Nu <- array(0, Q)
    De <- array(0, Q)
    
    for(i in 1:N){
      Nu <- Nu + ((Y.unc[i,] - Y_pred.tens[i,]) * W[i,])
      De <- De + W[i,]
    }
    
    B0 <- Nu/(De)
    B0 <- array(rep(B0, times = N), dim = c(Q, N))
    B0 <- t(B0)
    
    # Recompute Y matrix and vector
    Y <- Y.unc - B0
    Yvec = as.vector(Y)
    Ymats = list()
    for (m in 1:M) {
      perm = c(m + 1, c(1:(M + 1))[-(m + 1)])
      Y_perm = aperm(Y, perm)
      Ymats[[m]] = array(Y_perm, dim = c(Q[m], N * prod(Q[-m])))
    }
    
    #### Get the huber weights ####
    B.tens = array(t(Bmat) %*% t(Vmat), dim = c(P, Q))
    Y_pred.tens <- ctprod(X, B.tens, 2)
    W <- weight_huber(Y, Y_pred.tens, scale.cell, delta = delta)
    W <- W * W.fix
    Wmats = list() # matricize W
    for (m in 1:M) {
      perm = c(m + 1, c(1:(M + 1))[-(m + 1)])
      W_perm = aperm(W, perm)
      Wmats[[m]] = array(W_perm, dim = c(Q[m], N * prod(Q[-m])))
    }
    Wvec <- as.vector(W) # vectorize W
    
    #### Check convergence ####
    if (j > 1){
      loss.val[j] <- weighted_loss_huber(Y, Y_pred.tens, scale.cell, w.fix = w.fix, delta = delta) + lambda * sum((t(Bmat) %*% t(Vmat))^2)
      conv = abs(loss.val[j] - loss.val[j-1])/loss.val[j-1]
    }
  }
  B = array(t(Bmat) %*% t(Vmat), dim = c(P, Q))
  
  if(silent == FALSE) {close(pb)}
  
  #### Results ####
  return(list(
    U = U,
    V = V,
    B0 = B0,
    B = B,
    loss = loss.val,
    scale.cell = scale.cell,
    itr = j,
    W = W
  ))
}

ROTOT <- function(X, Y, R, lambda = 0, init = NULL, b = 1.5, tpar = NULL, W.init = NULL, W.fixed = NULL, 
                  delta = 1e-05, scale.cell.reshape = NULL, scale.row.reshape = NULL, 
                  max_iter = 100, convThresh = 10^(-5), seed = 0, init_X = NULL, ranks_X = NULL, X.git = NULL, 
                  tpar.mpca = NULL, delta_X = 1e-05, max_iter_X = 100, tpar.mpca.cell = NULL, OFS = TRUE, Xtest = NULL,
                  gl.alpha = 0.75, cut_out = FALSE, silent = FALSE){
  # Cellwise and casewise robust TOT.
  #
  # Arguments:
  # X: an P1x...xPL tensor.
  # Y: an Q1x...xQm tensor.
  # R: the number of ranks for the coefficient tensor. Obtained from CV.
  # lambda: the number of ranks for the coefficient tensor. Obtained from CV.
  # init: a list containing initial estimators for V, U and C.
  #       Typically NULL and computed internally.
  # b: the tuning constant for rho_1.
  # tpar: tuning parameter vector including b, c, q1, and q2 to tune rho_2.
  # W.init: weights from the predictor tensors.
  #             If NULL, its computed using ROMPCA.
  # delta: parameter for L1 weights.
  # scale.row.reshape: casewise residual scales.
  #             Typically NULL and computed internally.
  # scale.cell.reshape: cellwise residual scales.
  #             Typically NULL and computed internally.
  # max_iter: maximum number of iterations.
  #       Can be NULL and computed internally.
  # convThresh: tolerance of the IRLS algorithm (for stopping rule).
  # seed: seed.
  # init_X: initialization from the predictor.
  #        Typically NULL and computed using ROMPCA.
  # ranks_X: the number of ranks for every mode for MPCA.
  #        If NULL then the algorithm stops by showing the eigenvalue
  #        cumulative plot. The user needs to chose the rank from this.
  # X.git: an P1x...xPL tensor with gittering for DDC.
  # tpar.mpca: tuning parameter vector for MPCA.
  #       Can be NULL and computed internally.
  # delta_X: parameter for L1 weights for L1-MPCA.
  # max_iter_X: maximum number of iterations for ROMPCA.
  #       Can be NULL and computed internally.
  # tpar.mpca.cell: tuning parameter vector for MPCA to tune rho_2.
  #       Can be NULL and computed internally.
  # OFS: whether the out of sample prediction should be computed.
  # Xtest: an P1x...xPL tensor for the test set used in ROMPCA.
  # gl.alpha: parameter for the cutoff to detect good leverage points.
  # cut_out: whether the cutoff is outputted for ROMPCA.
  #          Typically FALSE.
  # silent: whether the progress bar is outputted.
  
  #### Outputs for outliers in predictors #### 
  X.orig <- X
  
  if(is.null(init_X)){
    if(silent == FALSE) {
      # comments for the user
      cat("\n===============================================\n")
      cat("                 Apply ROMPCA                    \n")
      cat("===============================================\n\n")
    }
    
    # If we don't have result from the predictors
    if(is.null(ranks_X)){
      # output the eigen distribution to choose rank
      ROMPCA(X = aperm(X, c(2,3,1)), X.git = X.git, cent = T)
    }
    
    if(OFS == TRUE){
      ROMPCA.out <- ROMPCA(
        X = aperm(X, c(2,3,1)),
        ranks = ranks_X,
        X.git = X.git,
        b = b,
        tpar = tpar.mpca,
        tpar.cell = tpar.mpca.cell,
        max_itr = max_iter_X,
        cut_out = cut_out,
        OFS = OFS,
        gl.alpha = gl.alpha,
        delta = delta_X,
        Xtest = aperm(Xtest, c(2, 3, 1))
      )
      
      outl.X <- ROMPCA.out$outl.X
      Ximp <- ROMPCA.out$Ximp
      X <- ROMPCA.out$Ximp
      Ximp_test <- ROMPCA.out$Ximp_test
      
    }else{
      ROMPCA.out <- ROMPCA(
        X = aperm(X, c(2,3,1)),
        ranks = ranks_X,
        X.git = X.git,
        b = b,
        tpar = tpar.mpca,
        max_itr = max_iter_X,
        cut_out = cut_out,
        OFS = OFS,
        gl.alpha = gl.alpha,
        delta = delta_X,
      )
      
      outl.X <- ROMPCA.out$outl.X
      Ximp <- ROMPCA.out$Ximp
      X <- ROMPCA.out$Ximp
    }
    
  }else{
    # If we already have result from the predictors
    if(OFS == TRUE){
      outl.X <- init_X$outl.X
      Ximp <- init_X$Ximp
      X <- init_X$Ximp
      Ximp_test <- init_X$Ximp_test
    }else{
      outl.X <- init_X$outl.X
      Ximp <- init_X$Ximp
      X <- init_X$Ximp
    }
  }
  
  #### Get dimensions ####
  if (seed > 0) {
    set.seed(seed)
  }
  
  # lambdaFin = lambda
  L = length(dim(X)) - 1
  N = dim(X)[1]
  P = dim(X)[2:(L + 1)]
  M = length(dim(Y)) - 1
  Q = dim(Y)[2:(M + 1)]
  Xmat = array(X, dim = c(N, prod(P)))
  Ymat = array(Y, dim = c(N, prod(Q)))
  Yvec = as.vector(Y)
  Y.unc <- Y
  
  #### Extract initial estimates ####
  if (is.null(init)){
    # TOT on reduced set and reweighting step
    if(silent == FALSE) {
      # cat("\n===============================================\n")
      # cat("             DDC initialization                  \n")
      # cat("===============================================\n\n")
      
      cat("\nDDC initialization:\n\n")
    }
    
    DDC.TOT.out <- DDC_TOT(
      X = X,
      Y = Y,
      R = R,
      lambda = lambda,
      w.fix = outl.X,
      convThresh = convThresh,
      seed = seed
    )
    DDC.TOT.init <- DDC.TOT.out$init
    
    # Huber TOT
    if(silent == FALSE) {
      # cat("\n===============================================\n")
      # cat("             Huber initialization                \n")
      # cat("===============================================\n\n")
      cat("\nHuber initialization:\n\n")
    }
    
    Huber.out <- Huber_TOT(
      X = X,
      Y = Y,
      R = R,
      lambda = lambda,
      w.fix = outl.X,
      init = DDC.TOT.init,
      delta = delta,
      max_iter = max_iter,
      convThresh = convThresh,
      seed = seed
    )
    Huber.TOT.init <- list(
      B = Huber.out$B,
      B0 = Huber.out$B0,
      V = Huber.out$V,
      U = Huber.out$U
    )
    
    # choose initialization according to casewise scale
    init.comp.ddc <- init.scale.comp_cent(X = X, Y = Y, b = b, init = DDC.TOT.init, m.name = "DDC-Init")
    init.comp.L1 <- init.scale.comp_cent(X = X, Y = Y, b = b, init = Huber.TOT.init, m.name = "L1-Init")
    
    init.comp <- cbind(init.comp.ddc, init.comp.L1)
    init.name <- colnames(init.comp[, which.min(init.comp), drop = FALSE])
    
    list.init <- list("DDC-Init" = DDC.TOT.init, "L1-Init" = Huber.TOT.init)
    init <- list.init[[init.name]]
  }
  
  U = init$U
  V = init$V
  B0 = init$B0
  Y <- Y - B0
  
  W.init <- array(1, dim(Y))
  W.init[outl.X,] <- 0
  
  #### Reshape U and V ####
  Vmat = matrix(nrow = prod(Q), ncol = R)
  for (r in 1:R) {
    Vr = lapply(V, function(x) x[, r])
    Vmat[, r] = as.vector(array(apply(expand.grid(Vr), 1, prod), dim = Q))
  }
  
  Bmat = matrix(nrow = R, ncol = prod(P))
  for (r in 1:R) {
    Ur = lapply(U, function(x) x[, r])
    Br = array(apply(expand.grid(Ur), 1, prod), dim = P)
    Bmat[r, ] = array(Br, dim = c(1, prod(P)))
  }
  Y_pred = as.vector(Xmat %*% t(Bmat) %*% t(Vmat))
  Xarrays = list()
  for (l in 1:L) {
    Xarrays[[l]] <- array(dim = c(N, P[l], prod(P[-l])))
    perm = c(l, c(1:L)[-l])
    for (i in 1:N) {
      X_slice = array(Xmat[i, ], dim = c(P))
      X_slice_perm = aperm(X_slice, perm)
      Xarrays[[l]][i, , ] = array(X_slice_perm, dim = c(P[l], 
                                                        prod(P[-l])))
    }
  }
  Ymats = list()
  for (m in 1:M) {
    perm = c(m + 1, c(1:(M + 1))[-(m + 1)])
    Y_perm = aperm(Y, perm)
    Ymats[[m]] = array(Y_perm, dim = c(Q[m], N * prod(Q[-m])))
  }
  
  #### Initialize scale and weights ####
  B.tens = array(t(Bmat) %*% t(Vmat), dim = c(P, Q))
  Y_pred.tens <- ctprod(X, B.tens, 2) # change the 2 by any dimension
  
  # reshape to use ROMPCA function
  Y.reshape <- array(NA, dim = c(Q, N))
  Ypred.reshape <- array(NA, dim = c(Q, N))
  
  for (i in 1:N) {
    Y.reshape[,i] <- Y[i,]
    Ypred.reshape[,i] <- Y_pred.tens[i,]
  }
  
  # Get scale
  scale.out <- get_scale_tanh(Y.reshape, Ypred.reshape, b)
  
  if(is.null(scale.row.reshape)){
    scale.row.reshape <- scale.out$scale.row
  }
  if(is.null(scale.cell.reshape)){
    scale.cell.reshape <- scale.out$scale.cell
  }
  
  scale.cell <- array(NA, dim(Y))
  for (i in 1:N) {
    scale.cell[i,] <- scale.cell.reshape[,i]
  }
  
  # Get tuning constant
  if(is.null(tpar)){
    dime <- c(Q, 10000)
    # dime <- c(10000, Q)
    par <- get_tuning_const_tanh(dime, b, 1) 
  }else{
    par <- tpar
  }
  
  # Get weights
  Weight.est.reshape <- weight_tanh_tanh(Y.reshape, Ypred.reshape, b_1 = b,
                                         scale.cell = scale.cell.reshape, scale.row = scale.row.reshape, 
                                         bb = par[1], cc = par[2], q1 = par[3], q2 = par[4])
  W.reshape <- Weight.est.reshape$W
  
  if(!is.null(W.fixed)) W.reshape <- W.fixed
  
  W <- array(NA, dim(Y))
  Wc <- array(NA, dim(Y))
  for (i in 1:N) {
    W[i,] <- W.reshape[,i]
    Wc[i,] <- Weight.est.reshape$w1[,i]
  }
  
  if(!is.null(W.init)) W <- W.init * W
  W_vec_init <- n_unfold(W.init, 1)[,1]
  
  loss.val = c()
  loss.val.step <- get_loss_tanh.full(Y.reshape, Ypred.reshape, b_1 = b,
                                      scale.cell = scale.cell.reshape, scale.row = scale.row.reshape,
                                      bb = par[1], cc = par[2], q1 = par[3], q2 = par[4], w_vec = W_vec_init)
  loss.val[1] <- loss.val.step + lambda * sum((t(Bmat) %*% t(Vmat))^2)
  Wmats = list() # matricize W
  for (m in 1:M) {
    perm = c(m + 1, c(1:(M + 1))[-(m + 1)])
    W_perm = aperm(W, perm)
    Wmats[[m]] = array(W_perm, dim = c(Q[m], N * prod(Q[-m])))
  }
  Wvec <- as.vector(W) # vectorize W
  
  #### Main part ####
  sse = c()
  sseSig = c()
  sseR = c()
  sseW = c()
  sseLam = c()
  U.fix <- U
  V.fix <- V
  j = 0
  count <- 1
  conv = convThresh + 1
  
  if(silent == FALSE) {
    # cat("\n===============================================\n")
    # cat("                    ROTOT                        \n")
    # cat("===============================================\n\n")
    cat("\nROTOT:\n\n")
    
    pb <- txtProgressBar(min = 0, max = max_iter, style = 3)
  }
  
  while (conv > convThresh && j < max_iter) {
    j = j + 1
    
    if(silent == FALSE) {setTxtProgressBar(pb, j)}
    
    # if (j <= annealIter) {
    #   lambda = 100 * (annealIter - j)/annealIter + lambdaFin
    # }
    
    #### Update Ul ####
    for (l in 1:L) {
      B_red = matrix(nrow = prod(P[-l]), ncol = R)
      for (r in 1:R) {
        Ured_r <- lapply(U[-l], function(x) x[, r])
        B_red[, r] = as.vector(array(apply(expand.grid(Ured_r),
                                           1, prod), dim = P[-l]))
      }
      X_red = matrix(nrow = N, ncol = P[l] * r)
      perm = c(l, c(1:L)[-l])
      for (i in 1:N) {
        X_red[i, ] = as.vector(Xarrays[[l]][i, , ] %*%
                                 B_red)
      }
      C = matrix(nrow = dim(X_red)[1] * prod(Q), ncol = dim(X_red)[2])
      for (r in 1:R) {
        index = ((r - 1) * P[l] + 1):(r * P[l])
        C[, index] = kronecker(Vmat[, r], X_red[, index])
      }
      
      lambdaMat = kronecker((t(Vmat) %*% Vmat * t(B_red) %*% B_red), (4 * lambda) * diag(P[l]))
      
      CP <- t(C) %*% (C * Wvec)
      # regMat = MASS::ginv(CP + lambdaMat)
      regMat = safe_ginv(CP + lambdaMat)
      Ulvec <- regMat %*% (t(C) %*% (Yvec * Wvec))
      U[[l]] = matrix(Ulvec, nrow = P[l])
      
      Bmat = matrix(nrow = R, ncol = prod(P))
      for (r in 1:R) {
        Ur = lapply(U, function(x) x[, r])
        Br = array(apply(expand.grid(Ur), 1, prod), dim = P)
        Bmat[r, ] = array(Br, dim = c(1, prod(P)))
      }
      Y_pred = as.vector(Xmat %*% t(Bmat) %*% t(Vmat))
      Y_pred.tens <- ctprod(X, array(t(Bmat) %*% t(Vmat), dim = c(P, Q)), 2)
      
      Ypred.reshape <- array(NA, dim = c(Q, N))
      for (i in 1:N) {
        Ypred.reshape[,i] <- Y_pred.tens[i,]
      }
    }
    
    #### Update Vm ####
    for (m in 1:M) {
      BRmat = matrix(nrow = prod(c(P, Q[-m])), ncol = R)
      D = matrix(nrow = N * prod(Q[-m]), ncol = R)
      for (r in 1:R) {
        Vecs <- lapply(c(U, V[-m]), function(x) x[, r])
        Br = array(apply(expand.grid(Vecs), 1, prod),
                   dim = c(prod(P), prod(Q[-m])))
        BRmat[, r] = as.vector(Br)
        D[, r] = as.vector(Xmat %*% Br)
      }
      
      Vmvec1 <- kronecker(t(D), diag(dim(Ymats[[m]])[1])) %*% (kronecker(D, diag(dim(Ymats[[m]])[1])) * as.vector(Wmats[[m]]))
      lamvec <- kronecker((t(BRmat) %*% BRmat), (4*lambda) * diag(dim(Ymats[[m]])[1]))
      # Vmvec <- MASS::ginv(Vmvec1 + lamvec) %*% as.vector((Ymats[[m]] * Wmats[[m]])%*% D)
      Vmvec <- safe_ginv(Vmvec1 + lamvec) %*% as.vector((Ymats[[m]] * Wmats[[m]])%*% D)
      V[[m]] = matrix(Vmvec, nrow = Q[m])
      
      Vmat = matrix(nrow = prod(Q), ncol = R)
      for (r in 1:R) {
        Vr = lapply(V, function(x) x[, r])
        Vmat[, r] = as.vector(array(apply(expand.grid(Vr),
                                          1, prod), dim = Q))
      }
      Y_pred = as.vector(Xmat %*% t(Bmat) %*% t(Vmat))
      Y_pred.tens <- ctprod(X, array(t(Bmat) %*% t(Vmat), dim = c(P, Q)), 2)
      
      for (i in 1:N) {
        Ypred.reshape[,i] <- Y_pred.tens[i,]
      }
    }
    
    #### Update Center ####
    Nu <- array(0, Q)
    De <- array(0, Q)
    
    for(i in 1:N){
      Nu <- Nu + ((Y.unc[i,] - Y_pred.tens[i,]) * W[i,])
      De <- De + W[i,]
    }
    
    B0 <- Nu/(De)
    B0 <- array(rep(B0, times = N), dim = c(Q, N))
    B0 <- t(B0)
    
    # Recompute Y matrix and vector
    Y <- Y.unc - B0
    Yvec = as.vector(Y)
    Ymats = list()
    for (m in 1:M) {
      perm = c(m + 1, c(1:(M + 1))[-(m + 1)])
      Y_perm = aperm(Y, perm)
      Ymats[[m]] = array(Y_perm, dim = c(Q[m], N * prod(Q[-m])))
    }
    
    #### Update weights ####
    B.tens = array(t(Bmat) %*% t(Vmat), dim = c(P, Q))
    Y_pred.tens <- ctprod(X, B.tens, 2) # change the 2 by any dimension
    
    for (i in 1:N) {
      Ypred.reshape[,i] <- Y_pred.tens[i,]
      Y.reshape[,i] <- Y[i,]
    }
    
    Weight.est.reshape <- weight_tanh_tanh(Y.reshape, Ypred.reshape, b_1 = b,
                                           scale.cell = scale.cell.reshape, scale.row = scale.row.reshape,
                                           bb = par[1], cc = par[2], q1 = par[3], q2 = par[4])
    W.reshape <- Weight.est.reshape$W
    W.case.vec <- Weight.est.reshape$w2_vec
    if(!is.null(W.fixed)) W.reshape <- W.fixed
    
    W <- array(NA, dim(Y))
    W.cell <- array(NA, dim(Y))
    for (i in 1:N) {
      W[i,] <- W.reshape[,i]
      W.cell[i,] <- Weight.est.reshape$w1[,i]
    }
    
    if(!is.null(W.init)) W <- W.init * W
    W_vec_init <- n_unfold(W.init, 1)[,1]
    
    Wmats = list() # matricize W
    for (m in 1:M) {
      perm = c(m + 1, c(1:(M + 1))[-(m + 1)])
      W_perm = aperm(W, perm)
      Wmats[[m]] = array(W_perm, dim = c(Q[m], N * prod(Q[-m])))
    }
    Wvec <- as.vector(W) # vectorize W
    
    #### Check convergence ####
    if (j > 1){
      loss.val.step <- get_loss_tanh.full(Y.reshape, Ypred.reshape, b_1 = b,
                                          scale.cell = scale.cell.reshape, scale.row = scale.row.reshape,
                                          bb = par[1], cc = par[2], q1 = par[3], q2 = par[4], w_vec = W_vec_init)
      loss.val[j] <- loss.val.step + lambda * sum((t(Bmat) %*% t(Vmat))^2)
      conv = abs(loss.val[j] - loss.val[j-1])/loss.val[j-1]
    }
  }
  B = array(t(Bmat) %*% t(Vmat), dim = c(P, Q))
  
  if(silent == FALSE) {
    close(pb)
  }
  
  #### Results ####
  res <- list()
  
  # Output from TOT
  res$U <- U
  res$V <- V
  res$B <- B
  res$B0 <- B0
  res$loss <- loss.val
  res$itr <- j
  res$W <- W
  res$W.case <- W.case.vec
  res$scale.cell.reshape <- scale.cell.reshape
  res$scale.row.reshape <- scale.row.reshape
  
  # Output from MPCA
  res$X <- X.orig
  res$Ximp <- Ximp
  res$outl.X <- outl.X
  if(OFS == TRUE) res$Ximp_test <- Ximp_test
  if(is.null(init_X)){res$ROMPCA <- ROMPCA.out}
  
  return(res)
}

# Auxiliary function for TOT ----------------------------------------------
init.scale.comp_cent <- function(X, Y, b = 1.5, init, m.name = NULL){
  #### Compute scale ####
  Y <- Y - init$B0
  Y_pred.tens <- ctprod(X, init$B, 2)
  Y.reshape <- t(Y)
  Ypred.reshape <- t(Y_pred.tens)
  
  scale.out <- get_scale_tanh(Y.reshape, Ypred.reshape, b = b)
  scale.case <- scale.out$scale.row
  
  #### Results ####
  if(!is.null(m.name)){
    scale.case <- as.matrix(scale.case)
    colnames(scale.case) <- m.name
  }
  
  return(scale.case)
}

calculateq1q2 <- function(b, c, maxit = 500, precScale = 1e-10) {
  # This function calculates the necessary parameters to make 
  # the wrapping psi function continuous. It implements the approach 
  # suggest in Remark 4, page 163 of Robust Statistics: The approach based on 
  # influence functions (1981) by F. R. Hampel, E. M. Ronchetti, P. J. Rousseeuw
  # and W. A. Stahel
  
  # Input:
  # b: tipping point of the wrapping psi function
  # c: rejection point of the wrapping psi function
  
  A <- 2 * pnorm(c) - 1 - 2 * c * dnorm(c)
  B <- 2 * pnorm(c) - 1
  k <- max(1,c)
  
  Anew <- A
  Bnew <- B
  knew <- k
  converged <- FALSE
  iter <- 0
  while (!converged & iter < maxit) {
    A <- Anew
    B <- Bnew
    k <- knew
    
    knew <- optimize(f = function(y) 
      abs(b - (A * (y - 1)) ^ (0.5) *
            tanh(0.5 * ((y - 1) * B ^ 2 / A) ^ 0.5*(c - b))),
      interval = c(1 + precScale, 1000),tol = precScale)$minimum
    Anew <- integrate(f = function(y) psiWrap(y, b, c, A, B, k) ^ 2 *
                        dnorm(y), lower = -c, upper = c)$value
    Bnew <- integrate(f = function(y) abs(psiWrap(y, b, c, A, B, k)) *
                        abs(y) * dnorm(y), lower = -c, upper = c)$value
    iter <- iter + 1
    converged <- max(abs(Anew - A), abs(Bnew - B), abs(knew - k)) < precScale
  }
  q1 <- sqrt(Anew * (knew - 1))
  q2 <- Bnew / 2 * sqrt((knew - 1) / Anew)
  return(list(q1 = q1, q2 = q2))
}
rho_tanh <- function(x, dime, b=1.5, bb = NULL, cc = NULL, q1 = NULL, q2 = NULL) { 
  # the rho function of wrapping.
  # It is the function with corner at 1.5 and rejection at 4,
  # but here I scale so that b becomes the new corner, to be
  # consistent with huber, square, and cubic.
  
  if(is.null(bb) | is.null(cc)){
    xx = 1.5*x/b
    bb = 1.5
    cc = 4 
    q1 = 1.540793
    q2 = 0.8622731
    q12 = q1/q2 
    dd = 3.7622126668 
    rhos = array(NA, dime)
    
    indsmall = which(abs(xx) <= bb)
    rhos[indsmall] = (xx[indsmall]^2)/2
    
    indmid = which(abs(xx) > bb & abs(xx) < cc)
    rhos[indmid] =(dd - q12*log(cosh(q2*(cc-abs(xx[indmid])))))
    
    indbig = which(abs(xx) >= cc)
    rhos[indbig] = dd
    rhos <- rhos*(b/1.5)^2
  }else{
    if(bb > 100){
      rhos = array(NA, dime)
      rhos <- x^2
    }else{
      xx <- x
      if (is.null(q1)) {
        params <- calculateq1q2(bb, cc)
        q1 <- params$q1
        q2 <- params$q2
      }
      q12 <- q1 / q2
      dd <- (bb ^ 2 / 2) + (q1 / q2) * log(cosh(q2 * (cc - bb)))
      
      rhos = array(NA, dime)
      
      indsmall = which(abs(xx) <= bb)
      rhos[indsmall] = (xx[indsmall]^2)/2
      
      indmid = which(abs(xx) > bb & abs(xx) < cc)
      rhos[indmid] = (dd - q12*log(cosh(q2*(cc-abs(xx[indmid])))))
      
      indbig = which(abs(xx) >= cc)
      rhos[indbig] = dd
    }
  }
  
  return(rhos)
}
psiWrap <- function(x, b, c, A, B, k) {
  # Wrapping psi function
  indmid <- which(abs(x) >= b & abs(x) <= c)
  indup  <- which(abs(x) >= c)
  x[indmid] <- (A * (k - 1)) ^ (0.5) *
    tanh(0.5 * ((k - 1) * B ^ 2 / A) ^ 0.5 *
           (c - abs(x[indmid]))) * sign(x[indmid])
  x[indup] <- 0
  return(x)
}

get_tuning_const_tanh <- function(dime, b_1 = 1.5, b_2 = 1){
  D <- array(rnorm(prod(dime), mean = 0, sd = 1), dime)
  
  I <- dim(D)
  num_modes <- length(I)
  N <- (num_modes - 1)
  
  scale.cell <- apply(D, 1:N, scale_tanh)
  # scale.cell <- apply(D, 1:N, RobStatTM::scaleM)
  scale.cell <- array(rep(scale.cell, times = I[num_modes]), I)
  
  rho1 <- rho_tanh(D/scale.cell, dime = I, b = b_1)
  rho1_scaled <- scale.cell^2 * rho1
  rho1 <- sapply(1:tail(dim(D), 1), function(i) {
    sqrt(sum(tens_s(rho1_scaled, i)))
    # sqrt(sum(tens_s(rho1_scaled, i))/prod(I[1:N]))
  })
  
  # scale.row <- RobStatTM::scaleM(rho1)
  scale.row <- scale_tanh(rho1)
  
  rowres <- rho1/scale.row
  bb <- max(b_2 * quantile(rowres, 0.7), 0)
  cc <- max(b_2 * quantile(rowres, 0.99), 0.3)
  
  if(bb<100){
    params <- calculateq1q2(bb, cc)
    q1 <- params$q1
    q2 <- params$q2
  }
  else{
    q1 <- q2 <- NA
  }
  par <- c(bb, cc, q1, q2)
  return(par)
}
get_c_scaletanh <- function(delta = 1.8811){
  set.seed(123)
  x<-rnorm(5000)
  c_vec<-seq(0.1, 10, 0.0001)
  m_vec<-numeric()
  for (ii in 1:length(c_vec)){
    
    m_vec[ii]<-mean(rho_tanh(x/c_vec[ii]))
    
  }
  dist<-abs(m_vec-delta)
  
  c<-c_vec[which.min(dist)]
  return(c)
}
scale_tanh <- function (u, delta = 1.8811, max.it = 100, tol = 1e-06, tolerancezero = .Machine$double.eps){
  #### function ####
  rho_tanh_vec <- function(x, b = 1.5, bb = NULL, cc = NULL, q1 = NULL, q2 = NULL) {
    # The rho function of wrapping.
    if(is.null(bb) | is.null(cc)){
      xx <- 1.5 * x / b
      bb <- 1.5
      cc <- 4
      q1 <- 1.540793
      q2 <- 0.8622731
      q12 <- q1 / q2
      dd <- 3.7622126668
      rhos <- rep(NA, length(xx))
      indsmall <- which(abs(xx) <= bb)
      rhos[indsmall] <- (xx[indsmall] ^ 2) / 2
      indmid <- which(abs(xx) > bb & abs(xx) < cc)
      rhos[indmid] <- (dd - q12 * log(cosh(q2 * (cc - abs(xx[indmid])))))
      indbig <- which(abs(xx) >= cc)
      rhos[indbig] = dd
    }
    else{
      if(bb > 100) {
        rhos <- rep(NA, length(x))
        rhos <- (x ^ 2)
      }
      else{
        xx <- x
        if (is.null(q1)) {
          params <- calculateq1q2(bb, cc)
          q1 <- params$q1
          q2 <- params$q2
        }
        
        q12 <- q1 / q2
        dd <- (bb ^ 2 / 2) + (q1 / q2) * log(cosh(q2 * (cc - bb)))
        
        rhos <- rep(NA, length(xx))
        indsmall <- which(abs(xx) <= bb)
        rhos[indsmall] <-  (xx[indsmall] ^ 2) / 2
        indmid <- which(abs(xx) > bb & abs(xx) < cc)
        rhos[indmid] <-
          (dd - q12 * log(cosh(q2 * (cc - abs(
            xx[indmid]
          )))))
        indbig <- which(abs(xx) >= cc)
        rhos[indbig] <- dd
      }
    }
    return(rhos)
  }
  
  #### main ####
  if(delta == 1.8811){
    c<-0.34308##
  }
  else{
    c<-get_c_scaletanh(delta)
  }
  s0 <- median(abs(u))/0.6745
  if (s0 < tolerancezero)
    return(0)
  err <- tol + 1
  it <- 0
  while ((err > tol) && (it < max.it)) {
    it <- it + 1
    s1 <- sqrt(s0^2 * mean(rho_tanh_vec(u/(c*s0)))/delta)
    err <- abs(s1 - s0)/s0
    s0 <- s1
  }
  return(s0)
}
get_scale_tanh <- function(At, Ahat, b_1 = 1.5){
  res <- list()
  
  I <- dim(At)
  num_modes <- length(I)
  N <- (num_modes - 1)
  D <- (At - Ahat)
  
  # Cellwise scale
  # scale.cell <- apply(D, 1:N, RobStatTM::scaleM)
  scale.cell <- apply(D, 1:N, scale_tanh) # new scale using tanh
  scale.cell <- array(rep(scale.cell, times = I[num_modes]), I)
  res$scale.cell <- scale.cell
  rho1 <- rho_tanh(D/scale.cell, dime = I, b = b_1)
  rho1 <- rho1 * scale.cell^2
  
  # Rowwise scale
  res_M <- sapply(1:tail(dim(At), 1), function(i) {
    sqrt(sum(tens_s(rho1, i)))
    # sqrt(sum(tens_s(rho1, i))/prod(I[1:N]))
  })
  # res$scale.row <- RobStatTM::scaleM(res_M)
  res$scale.row <- scale_tanh(res_M) # new scale using tanh
  
  return(res)
}
get_scale_sd <- function(At, Ahat){
  res <- list()
  
  I <- dim(At)
  num_modes <- length(I)
  N <- (num_modes - 1)
  D <- (At - Ahat)
  
  # Cellwise scale
  scale.cell <- apply(D, 1:N, sd)
  scale.cell <- array(rep(scale.cell, times = I[num_modes]), I)
  res$scale.cell <- scale.cell
  rho1 <- D^2
  
  # Rowwise scale
  res_M <- sapply(1:tail(dim(At), 1), function(i) {
    sqrt(sum(tens_s(rho1, i)))
  })
  res$scale.row <- sd(res_M)
  return(res)
}

get_loss_tanh.full <- function(At, Ahat, scale.cell, scale.row, b_1 = 1.5, bb, cc, q1, q2, w_vec){
  I <- dim(At)
  num_modes <- length(I)
  N <- (num_modes - 1)
  D <- (At - Ahat)
  
  rho1 <- rho_tanh(D/scale.cell, dime = I, b = b_1)
  
  rho1_scaled <- scale.cell^2 * rho1
  
  rho1 <- sapply(1:tail(dim(At), 1), function(i) {
    # sqrt(sum(tens_s(rho1_scaled, i)))
    sqrt(sum(tens_s(rho1_scaled, i))/prod(I[1:N]))
  })
  
  rho2 <- rho_tanh(rho1/scale.row, dime = length(rho1), bb = bb, cc = cc, q1 = q1, q2 = q2)
  return(sum(w_vec*rho2))
}
weight_tanh <- function(x, dime, b = 1.5, bb = NULL, cc = NULL, q1 = NULL, q2 = NULL){
  psitanh <- function(xx, bb, cc, q1, q2){
    abs_xx <- abs(xx)
    psi <- xx
    
    # boolean indexing instead of which
    indb <- abs_xx <= bb
    indc <- abs_xx > bb & abs_xx <= cc
    indbig <- abs_xx > cc
    
    psi[indc] <- q1 * tanh(q2 * (cc - abs_xx[indc])) * sign(xx[indc])
    psi[indbig] <- 0
    
    psi
  }
  
  if(is.null(bb) | is.null(cc)){
    xx <- 1.5 * x / b
    bb <- 1.5
    cc <- 4
    q1 <- 1.540793
    q2 <- 0.8622731
    q12 <- q1 / q2
    dd <- 3.7622126668
    
    # tanh_w <- ifelse(is.na(xx), NA, ifelse(xx == 0, 0, psitanh(xx, bb, cc, q1, q2) / xx))
    tanh_w <- ifelse(is.na(xx), NA, ifelse(xx == 0, 1, psitanh(xx, bb, cc, q1, q2) / xx))
    tanh_w <- array(tanh_w, dime)
    
  }else{
    if(bb > 100){
      xx <- x
      tanh_w <- array(sapply(xx, function(t){ ifelse(is.na(t), NA,  1 )}), dime)
    }else{
      xx <- x
      if(is.null(q1)){
        params <- calculateq1q2(bb, cc)
        q1 <- params$q1
        q2 <- params$q2
      }
      q12 <- q1 / q2
      dd <- (bb ^ 2 / 2) + (q1 / q2) * log(cosh(q2 * (cc - bb)))
      
      # tanh_w <- ifelse(is.na(xx), NA, ifelse(xx == 0, 0, psitanh(xx, bb, cc, q1, q2) / xx))
      tanh_w <- ifelse(is.na(xx), NA, ifelse(xx == 0, 1, psitanh(xx, bb, cc, q1, q2) / xx))
      tanh_w <- array(tanh_w, dime)
    }
  }
  
  return(tanh_w)
}
weight_tanh_tanh <- function(At, Ahat, scale.cell, scale.row, b_1 = 1.5, b_2 = 1.5, bb, cc, q1, q2){
  I <- dim(At)
  num_modes <- length(I)
  N <- (num_modes - 1)
  D <- (At - Ahat)
  
  w1 <- weight_tanh(D/scale.cell, dime = I, b = b_1)
  
  rho1 <- rho_tanh(D/scale.cell, dime = I, b = b_1)
  rho1_scaled <- scale.cell^2 * rho1
  rho1 <- sapply(1:tail(dim(At), 1), function(i) {
    # sqrt(sum(tens_s(rho1_scaled, i)))
    sqrt(sum(tens_s(rho1_scaled, i))/prod(I[1:N]))
  })
  
  w2_vec <- weight_tanh(rho1/scale.row, length(rho1), bb = bb, cc = cc, q1 = q1, q2 = q2)
  w2 <- array(rep(w2_vec, each = prod(I[-num_modes])), dim = I)
  W <- w1 * w2
  
  res <- list(w1 = w1, w2 = w2, w2_vec = w2_vec, W = W)
  return(res)
}

SinglePar_cv <- function(Yfull, Xfull, Ximp, outl.X, folds, K.folds,
                         b = 1.5, tpar, curr_rank, curr_lambda, 
                         convThresh = 1e-05, seed.set = 1998){
  # Single run for cv parallelization
  #
  # Arguments:
  # Xfull: an Q1x...xQm tensor.
  # Yfull: an P1x...xPL tensor.
  # Ximp: an P1x...xPL tensor from ROMPCA.
  # outl.X: Set of outlier from the predictor from ROMPCA.
  # folds: The crossvalidation folds.
  # K.folds: The folds used for K-folds cross validation.
  # b: the tuning constant for rho_1.
  # tpar: tuning parameter vector including b, c, q1, and q2 to tune rho_2.
  # curr_rank: current rank.
  # curr_lambda: current lambda.
  # convThresh: tolerance of the IRLS algorithm (for stopping rule).
  # seed.set: seed.
  
  #### Initialization ####
  save.scale.rotot <- rep(NA, K.folds)
  save.scale.tot <- rep(NA, K.folds)
  
  #### Main loop ####
  for (k in 1:K.folds) {
    #### get train and test indices ####
    test_idx_cv <- which(folds == k)
    train_idx_cv <- which(folds != k)
    
    Y_cv <- Yfull[train_idx_cv,] #it should be adapted accordingly
    X_cv <- Xfull[train_idx_cv, ,]
    
    Ytest_cv  <- Yfull[test_idx_cv,]
    Xtest_cv  <- Xfull[test_idx_cv,,]
    
    # create list for ROTOT predictors
    Ximp_reduced <- Ximp[train_idx_cv, ,]
    Ximp_test_reduced  <- Ximp[test_idx_cv, , ]
    
    outl.X_reduced <- which(train_idx_cv %in% outl.X)
    outl.X_reduced_test <- which(test_idx_cv %in% outl.X)
    
    rompca_init <- list(outl.X = outl.X_reduced, Ximp = Ximp_reduced)
    
    #### Run ROTOT ####
    # run ROTOT
    rotot_cv <- ROTOT_paper(
      X = X_cv,
      Y = Y_cv,
      R = curr_rank,
      lambda = curr_lambda,
      b = b,
      tpar = tpar,
      init_X = rompca_init,
      OFS = FALSE,
      max_iter = 100, #change this to 100
      seed = seed.set,
      convThresh = convThresh,
      silent = TRUE
    )
    
    # compute casewise scale
    B0.test.rotot <- rotot_cv$B0[1,]
    B0.test.rotot <- array(rep(B0.test.rotot, times = dim(Ytest_cv)[1]), dim = c(dim(Ytest_cv)[-1], dim(Ytest_cv)[1]))
    B0.test.rotot <- t(B0.test.rotot)
    
    if(length(outl.X_reduced_test != 0)){
      # if there are outliers in the test set
      Y_pred.tens.rotot <- ctprod(Xtest_cv[-outl.X_reduced_test, , ], rotot_cv$B, 2) + B0.test.rotot[-outl.X_reduced_test, ]
      Y.reshape <- t(Ytest_cv[-outl.X_reduced_test, ])
      Ypred.reshape.rotot <- t(Y_pred.tens.rotot)
    }else{
      Y_pred.tens.rotot <- ctprod(Xtest_cv, rotot_cv$B, 2) + B0.test.rotot
      Y.reshape <- t(Ytest_cv)
      Ypred.reshape.rotot <- t(Y_pred.tens.rotot)
    }
    
    scale.out.rotot <- get_scale_tanh(Y.reshape, Ypred.reshape.rotot, b = b)
    scale.case.rotot <- scale.out.rotot$scale.row
    
    #### Run TOT ####
    # run TOT
    D = dim(X_cv)
    X_cv.cent <- X_cv
    MeansDim23 <- array(dim = D[2:3])
    for(i in 1:D[2]){
      for(j in 1:D[3]){
        MeansDim23[i, j] <- mean(X_cv.cent[, i, j])
        X_cv.cent[, i, j] <- X_cv.cent[, i, j] - MeansDim23[i, j]
      }
    }
    
    Y_cv.scaled <- scale(Y_cv)
    tot_cv.out <- rrr(
      X_cv.cent,
      Y_cv.scaled,
      R = curr_rank,
      lambda = curr_lambda,
      seed = seed.set,
      convThresh = convThresh
    )
    
    # compute casewise scale
    D.test <- dim(Xtest_cv)
    Xtest_cv.cent <- Xtest_cv
    MeansDim23_test <- array(dim = D.test[2:3])
    for(i in 1:D.test[2]){
      for(j in 1:D.test[3]){
        MeansDim23_test[i, j] <- mean(Xtest_cv.cent[, i, j])
        Xtest_cv.cent[, i, j] <- Xtest_cv.cent[, i, j] - MeansDim23_test[i, j]
      }
    }
    
    Ytest_cv.scaled <- scale(Ytest_cv)
    Y_pred.tens.tot <- ctprod(Xtest_cv.cent, tot_cv.out$B, 2)
    Y.reshape.scaled <- t(Ytest_cv.scaled)
    Ypred.reshape.tot <- t(Y_pred.tens.tot)
    
    scale.out.tot <- get_scale_sd(Y.reshape.scaled, Ypred.reshape.tot)
    scale.case.tot <- scale.out.tot$scale.row
    
    #### Save results ####
    save.scale.rotot[k] <- scale.case.rotot
    save.scale.tot[k] <- scale.case.tot
  }
  
  #### Results ####
  res <- list()
  res$rank <- curr_rank
  res$lambda <- curr_lambda
  res$scale.tot <- save.scale.tot
  res$scale.rotot <- save.scale.rotot
  res$scale.tot.ave <- mean(save.scale.tot)
  res$scale.rotot.ave <- mean(save.scale.rotot)
  
  return(res)
}

cv_parallel <- function(Yfull, Xfull, folds, K.folds, Ximp = NULL, outl.X = NULL,
                        ranks_X = NULL, X.git = NULL, tpar.mpca = NULL, max_iter_X = NULL,
                        delta_X = NULL, b = 1.5, tpar, grid.lambda, grid.ranks, convThresh = 1e-05, 
                        seed.set = 1998, ncores_par = 1){
  # cross validation parallelization
  #
  # Arguments:
  # Yfull: an P1x...xPL tensor.
  # Xfull: an Q1x...xQm tensor.
  # folds: The crossvalidation folds.
  # K.folds: The folds used for K-folds cross validation.
  # Ximp: an P1x...xPL tensor from ROMPCA. 
  #            If NULL, ROMPCA is applied.
  # outl.X: Set of outlier from the predictor from ROMPCA.
  # ranks_X: The number of ranks for every mode for MPCA.
  # X.git: an P1x...xPL tensor with gittering for DDC.
  # tpar.mpca: Tuning parameter vector for MPCA.
  # max_iter_X: maximum number of iterations for ROMPCA.
  # delta_X: parameter for L1 weights for L1-MPCA.
  # b: the tuning constant for rho_1.
  # tpar: tuning parameter vector including b, c, q1, and q2 to tune rho_2.
  # grid.lambda: grid of ranks.
  # grid.ranks: grid of lambda.
  # convThresh: tolerance of the IRLS algorithm (for stopping rule).
  # seed.set: seed.
  # ncores_par: cores used for parallelization.
  
  #### Initialization ####
  if(is.null(Ximp)){
    # Get ROMPCA outputs
    ROMPCA.out <- ROMPCA(
      X = aperm(Xfull, c(2,3,1)),
      b = b,
      ranks = ranks_X,
      X.git = X.git,
      tpar = tpar.mpca,
      max_itr = max_iter_X,
      OFS = FALSE,
      delta = delta_X
    )
    
    Ximp <- ROMPCA.out$Ximp
    outl.X <- ROMPCA.out$outl.X
  }
  
  combinations.cv <- expand.grid(lambda = grid.lambda, ranks = grid.ranks)
  
  #### Run parallelization ####
  results_par <- mclapply(1:nrow(combinations.cv), \(l){
    # initialization
    current_rank <- combinations.cv$ranks[l]
    current_lambda <- combinations.cv$lambda[l]
    
    # run k fold CV with parameters
    res_SinglePar <- SinglePar_cv(
      Yfull = Yfull,
      Xfull = Xfull,
      Ximp = Ximp,
      outl.X = outl.X,
      folds = folds,
      K.folds = K.folds,
      b = b,
      tpar = tpar,
      curr_rank = current_rank,
      curr_lambda = current_lambda,
      convThresh = convThresh,
      seed.set = seed.set 
    )
    
    # save results of the run
    return(res_SinglePar)
    
  } , mc.cores = ncores_par)
  
  #### Results ####
  return(results_par)
}

# Auxiliary function ------------------------------------------------------
perm_idx <- function(tnsr, n){
  # permutation index
  num_modes <- length(dim(tnsr))
  if(n == 1){
    perm.idx <- c(n, (num_modes:(n+1)))
  }else if(n == num_modes){
    perm.idx <- c((num_modes:(1)))
  }else{
    perm.idx <- c(n, (n -1):1,(num_modes:(n+1)))
  }
  return(perm.idx)
}
tnsr_tnsr <- function(tnsr, mat_list, ms){
  # tensor product
  num_modes <- length(dim(tnsr))
  tnsr_fold <- tnsr
  for(m in ms){
    tnsr_unf <- n_unfold(tnsr_fold, n = m)
    mat_list_m <- mat_list[[m]]
    tnsr_prod <- mat_list_m %*% tnsr_unf
    tnsr_fold <- n_fold(tnsr_prod, tnsr_fold, modes.out = dim(mat_list_m)[1], n = m)
  }
  return(tnsr_fold)
}
n_unfold <- function(tnsr, n){
  # unfold the tensor
  perm_idx <- perm_idx(tnsr, n) # get the permutarion index
  tnsr_perm <- aperm(tnsr, perm_idx)
  tnsr_unf <- matrix(tnsr_perm, nrow = dim(tnsr_perm)[1], ncol = prod(dim(tnsr_perm)[-1]))
  return(tnsr_unf)
}
n_fold <- function(unf_tnsr, tnsr, modes.out, n){
  # fold back the tensor
  perm.idx <- perm_idx(tnsr, n)
  dime <- dim(tnsr)
  tnsr_fold <- array(unf_tnsr, c(modes.out, dime[perm.idx][-1]))
  tnsr_fold <- aperm(tnsr_fold, order(perm.idx))
  return(tnsr_fold)
}
tens_s <- function(tnsr, i){
  # get one slice from the tensor
  num_modes <- length(dim(tnsr))
  tnsr.slice <- do.call("[", c(list(tnsr), c(rep(list(TRUE), num_modes - 1), i)))
  
  if (inherits(tnsr, "Tensor")) {
    tnsr.slice <- as.tensor(array(tnsr.slice@data, dim(tnsr)[-num_modes]))
    return(tnsr.slice)
  } else {
    tnsr.slice <- array(tnsr.slice, dim(tnsr)[-num_modes])
    return(tnsr.slice)
  }
}
tnsr_cent <- function(tnsr, mean_tens = NULL){
  # center the tensor according to the sample mode
  if(is.null(mean_tens)){
    mean_tens <- tnsr_mean(tnsr)
    tnsr.list <- lapply(1:tail(tnsr@modes, n =1), 
                        function(i) do.call("[", c(list(tnsr@data), c(rep(list(TRUE), tnsr@num_modes - 1), i))))
    
    tnsr.centered.list <- lapply(tnsr.list, function(x) x - mean_tens)
    tnsr.centered <- as.tensor(abind::abind(tnsr.centered.list, along = tnsr@num_modes))
  }else{
    tnsr.list <- lapply(1:tail(tnsr@modes, n =1), 
                        function(i) do.call("[", c(list(tnsr@data), c(rep(list(TRUE), tnsr@num_modes - 1), i))))
    
    tnsr.centered.list <- lapply(tnsr.list, function(x) x - mean_tens)
    tnsr.centered <- as.tensor(abind::abind(tnsr.centered.list, along = tnsr@num_modes))
  }
  return(tnsr.centered)
}
frobnorm <- function(x){
  # compute the frobenius norm
  x <- as.vector(x)
  sum(x^2)^(1/2)
}

RPE.mod <- function(Ytest, Xtest, Bhat, B0, h = 0.75, outl.case = NULL){
  if(!is.null(outl.case)){
    Ytest <- Ytest[-outl.case,]
    Xtest <- Xtest[-outl.case,,]
  }
  dimension <- dim(Ytest)
  Q <- dimension[-1]
  B0 <- array(rep(B0, times = dimension[1]), dim = c(dimension[-1], dimension[1]))
  B0 <- t(B0)
  Y.pred <- ctprod(Xtest, Bhat, 2) + B0
  
  size.reduced <- h * dimension[1]
  s_res <- (Ytest - Y.pred)^2
  s_res_reduced <- sapply(1:Q, function(q) {
    idx <- order(s_res[, q])[1:size.reduced]
    s_res[idx, q]
  })
  
  idx.mat <- array(NA, c(size.reduced, Q))
  for (q in 1:Q) {
    idx <- order(s_res[, q])[1:size.reduced]
    idx.mat[,q] <- idx
  }
  
  if(!is.null(outl.case)){
    s_res_reduced <- s_res_reduced[-outl.case,]
  }
  
  # Compute RPE
  RPE.out <- sqrt(sum(s_res_reduced))/(length(s_res_reduced))
  return(list(RPE.out = RPE.out, idx = idx.mat))
  # return(RPE.out = RPE.out)
}
RPE.mod.class <- function(Ytest, Xtest, Bhat, h = 0.75){
  dimension <- dim(Ytest)
  Q <- dimension[-1]
  
  D = dim(Xtest)
  Xtest.cent <- Xtest
  MeansDim23=array(dim=D[2:3])
  for(i in 1:D[2]){
    for(j in 1:D[3]){
      MeansDim23[i,j] <- mean(Xtest.cent[,i,j])
      Xtest.cent[,i,j] <- Xtest.cent[,i,j]-MeansDim23[i,j]
    }
  }
  
  Ytest.scaled <- scale(Ytest)
  Y.pred <- ctprod(Xtest.cent, Bhat, 2)
  
  size.reduced <- h * dimension[1]
  s_res <- (Ytest.scaled - Y.pred)^2
  s_res_reduced <- sapply(1:Q, function(q) {
    idx <- order(s_res[, q])[1:size.reduced]
    s_res[idx, q]
  })
  
  idx.mat <- array(NA, c(size.reduced, Q))
  for (q in 1:Q) {
    idx <- order(s_res[, q])[1:size.reduced]
    idx.mat[,q] <- idx
  }
  
  # Compute RPE
  RPE.out <- sqrt(sum(s_res_reduced))/(length(s_res_reduced))
  # return(RPE.out)
  return(list(RPE.out = RPE.out, idx = idx.mat))
}

# ROMPCA function ---------------------------------------------------------
DDC_MPCA <- function(X.cont, X.ddc = NULL, ranks, h = 0.75, tol = 1e-05, silent = FALSE, seed = 1998){
  # Initialisation starting with DDC.
  #
  # Arguments:
  # X.cont: an P1x...xPL tensor contaminated tensor.
  #         Current version takes up to L = 3.
  # X.ddc: an P1x...xPL tensor contaminated tensor used for DDC.
  # ranks: the number of ranks for every mode.
  # h: parameter for the number of observation retained after DDC.
  #    Depending on the value, there is tradeoff between robustness
  #    and efficiency. Typically set to 0.75.
  # tol: tolerance of the IRLS algorithm (for stopping rule)
  # init: a list containing initial estimators for V, U and C.
  #       Typically NULL and computed internally.
  # seed: seed.
  # silent: whether the progress bar is outputted.
  
  set.seed(seed)
  dimension <- dim(X.cont)
  N <- tail(dimension, 1)
  num_modes <- length(dimension); L <- (num_modes - 1)
  
  #### Apply DDC ####
  if(is.null(X.ddc)){
    X.unf <- n_unfold(X.cont, num_modes)
    ddc.out <- cellWise::DDC(X.unf, DDCpars = list(silent = silent))
  }else{
    # this for real data application to avoid constant scale
    X.unf <- n_unfold(X.ddc, num_modes)
    ddc.out <- cellWise::DDC(X.unf, DDCpars = list(silent = silent))
  }
  
  #### construct weight tensor ####
  ind.case.ddc <- ddc.out$indrows
  indcell.out <- array(0, dim(X.unf))
  indcell.out[ddc.out$indcells] <- NA
  indcell.out <- n_fold(indcell.out, X.cont, N, n = num_modes)
  indcell.out <- which(is.na(indcell.out)) # for cellwise weight
  W.fixed <- array(1, dim(X.cont))
  
  if(L == 3){
    W.fixed[indcell.out] <- 0
    if(length(which(is.na(X.cont))) != 0)  W.fixed[which(is.na(X.cont))] <- 0 # for NA
    if(length(ind.case.ddc) != 0) W.fixed[,,,ind.case.ddc] <- 0 # for casewise weight 
  }else{
    W.fixed[indcell.out] <- 0
    if(length(which(is.na(X.cont))) != 0)  W.fixed[which(is.na(X.cont))] <- 0
    if(length(ind.case.ddc) != 0) W.fixed[,,ind.case.ddc] <- 0
  }
  
  #### MPCA on the h observation with fewest cellwise ####
  outl.obs <- array(rep(1, prod(dimension)), dimension)
  outl.obs <- n_unfold(outl.obs, num_modes)
  outl.obs[ddc.out$indcells] <- 0
  
  sorted_indices <- order(rowSums(outl.obs), decreasing = FALSE)
  sorted_indices <- setdiff(sorted_indices, ind.case.ddc) # to remove the observation considered as casewise by DDC
  
  reduced_indices <- sorted_indices[1:floor(h * length(sorted_indices))]
  if((length(ind.case.ddc)/N) > 0.5){
    stop("Too many outlying cases are flagged by DDC")
  }else if((length(ind.case.ddc)/N) > 0.25){
    h <- floor((1 - (length(ind.case.ddc)/N)) * 100) / 100
    reduced_indices <- sorted_indices[1:floor(h * length(sorted_indices))]
  }
  
  if(L == 3){
    X_sorted_ddc <- n_fold(ddc.out$Ximp, X.cont, N, n = num_modes)
    X_sorted_ddc <- X_sorted_ddc[,,,reduced_indices] 
  }else{
    X_sorted_ddc <- n_fold(ddc.out$Ximp, X.cont, N, n = num_modes)
    X_sorted_ddc <- X_sorted_ddc[,,reduced_indices] 
  }
  
  MPCA.reduced <- MPCA(X_sorted_ddc, ranks, tol = tol, silent = silent)
  V_reduced <- MPCA.reduced$V
  Center_reduced <- MPCA.reduced$Center
  X.cont.cent <- tnsr_cent(as.tensor(X.cont), mean_tens = (Center_reduced))@data
  
  #### Reweighting step ####
  W.fixed.onlycell <- array(1, dim(X.cont))
  W.fixed.onlycell[indcell.out] <- 0
  if(length(which(is.na(X.cont))) != 0){W.fixed.onlycell[which(is.na(X.cont))] <- 0} # for NA
  
  if(any(is.na(X.cont))) {
    U_ddc_list <- lapply(1:N, function(i)
      U_samp_NA(
        tens_s(as.tensor(X.cont.cent), i)@data,
        V_reduced,
        tens_s(as.tensor(W.fixed.onlycell), i)@data,
        ranks
      ))
  } else{
    U_ddc_list <- lapply(1:N, function(i)
      U_samp(
        tens_s(as.tensor(X.cont.cent), i)@data,
        V_reduced,
        tens_s(as.tensor(W.fixed.onlycell), i)@data,
        ranks
      ))
  }
  
  U_ddc <- abind::abind(U_ddc_list, along = num_modes)
  Xhat.ddc <- ttl(as.tensor(U_ddc), V_reduced, ms = 1:L)
  Xhat.decenter.ddc <- tnsr_cent(Xhat.ddc, mean_tens = (-Center_reduced))
  
  #### Results ####
  res <- list(
    U.tilde = U_ddc,
    V = V_reduced,
    Center = Center_reduced,
    Xhat = Xhat.ddc@data,
    Xhat.decenter = Xhat.decenter.ddc,
    ddc.out = ddc.out
  )
  return(res)
}
MPCA <- function(X, ranks, max_itr = 100, tol = 1e-05, init = NULL, silent = FALSE){
  # classical MPCA.
  #
  # Arguments:
  # X: an P1x...xPL tensor.
  #    Current version takes up to L = 3.
  # ranks: the number of ranks for every mode.
  # max_itr: maximum number of iterations.
  # tol: tolerance of the IRLS algorithm (for stopping rule)
  # init: a list containing initial estimators for V, U and C.
  #       Typically NULL and computed internally.
  # silent: whether the progress bar is outputted.
  
  tnsr <- as.tensor(X)
  num_modes <- tnsr@num_modes
  L <- (num_modes - 1)
  modes <- tnsr@modes
  X <- tnsr@data
  P <- dim(X)
  
  #### Initialisation with classical MPCA ####
  # Get the mean tensor
  C <- array(0, P[-num_modes])
  
  for(i in 1:P[num_modes]){
    C <- C + tens_s(as.tensor(X), i)@data
  }
  
  C <- C / P[num_modes]
  Xt <- tnsr_cent(as.tensor(X), mean_tens = (C))@data
  
  if(is.null(init)){
    # MPCA
    V_list <- vector("list", L)
    
    for (i in 1:L) {
      Xn <- n_unfold(Xt, n = i)
      Xn.decomp <- eigen(tcrossprod(Xn, Xn))
      # V_list[[i]] <- Xn.decomp$vector[, 1:ranks[i]]
      V_list[[i]] <- as.matrix(Xn.decomp$vector[, 1:ranks[i]])
    }
  }else{
    Cent <- init$Center
    Xt <- tnsr_cent(as.tensor(X), mean_tens = (Cent))@data
    V_list <- init$V
  }
  
  itr <- 0
  U <- ttl(as.tensor(Xt), lapply(V_list, t), ms = 1:(num_modes - 1))
  Xhat <- ttl(U, V_list, ms = 1:(num_modes - 1))
  
  # Initialize the weights
  W <- array(1, dim(Xt))
  fnorm.U <- sapply(1:tail(dim(Xt), 1), function(i) {
    frobnorm(tens_s(U@data, i))
  })
  E <- sum(fnorm.U^2)
  
  EE <- matrix(c(0, E), nrow = 1)
  U <- U@data
  
  #### Main part ####
  converged <- FALSE
  if(silent == FALSE) {
    pb <- txtProgressBar(min = 0, max = max_itr, style = 3)
  }
  
  while((itr < max_itr)){
    
    if(silent == FALSE) {
      setTxtProgressBar(pb, itr)
    }
    itr <- itr + 1
    ## U update
    V_list <- Get_V(Xt, V_list, U, W)
    
    ## Core tensor update
    U <- ttl(as.tensor(Xt), lapply(V_list, t), ms = 1:(num_modes - 1))@data
    Xhat <- ttl(as.tensor(U), V_list, ms = 1:(num_modes - 1))
    
    ## Center update
    Nu <- array(0, P[-num_modes])
    De <- array(0, P[-num_modes])
    
    for(i in 1:P[num_modes]){
      Nu <- Nu + ((tens_s(as.tensor(X), i)@data - tens_s(Xhat, i)@data) * tens_s(as.tensor(W), i)@data)
      De <- De + tens_s(as.tensor(W), i)@data
    }
    
    C <- Nu / De
    Xt <- tnsr_cent(as.tensor(X), mean_tens = (C))@data
    
    ## Convergence
    fnorm.U <- sapply(1:tail(dim(Xt), 1), function(i) {
      frobnorm(tens_s(U, i))
    })
    
    ssDe <- sum(fnorm.U^2)
    EE <- rbind(EE, c(itr, ssDe))
    if(abs(ssDe - E)/E < tol){
      converged <- TRUE
      if(silent == FALSE) {
        setTxtProgressBar(pb, max_itr)
      }
      break
    }
    
    if(itr == max_itr && silent == FALSE){
      setTxtProgressBar(pb, max_itr)
    }
    
    E <- ssDe
  }
  
  if(silent == FALSE) {
    close(pb)
  }
  
  #### Result ####
  res <- list()
  res$X <- X
  res$X.tilde <- Xt
  res$U.tilde <- U
  res$V <- V_list
  res$Xhat.decenter <- tnsr_cent(Xhat, mean_tens = (-C))
  res$Xhat <- Xhat@data
  res$Center <- C
  res$W <- W
  res$loss <- EE
  res$itr <- itr
  res$converged <- converged
  
  return(res)
}
L1_MPCA <- function(X, ranks, init = NULL, max_itr = 600, scale, tol = 1e-05, delta = 1e-05, silent = FALSE){
  # L1-MPCA.
  #
  # Arguments:
  # X: an P1x...xPL tensor.
  #    Current version takes up to L = 3.
  # ranks: the number of ranks for every mode.
  # tol: tolerance of the IRLS algorithm (for stopping rule).
  # max_itr: maximum number of iterations.
  # init: a list containing initial estimators for V, U and C.
  # scale: scale computed on the initialisation.
  # delta: parameters for the weights.
  # silent: whether the progress bar is outputted.
  
  #### Auxiliary functions ####
  L1_weights <- function(X, Xhat, delta = 1e-5, scale){
    # function to compute the L1 weights
    P <- dim(X)
    num_modes <- length(P)
    L <- (num_modes - 1)
    D <- X - Xhat
    
    scale.cell <- array(rep(scale, times = P[num_modes]), P)
    D <- D/scale.cell
    
    L1_w <- 1 /pmax.int(delta, abs(D))
    L1_weight <- array(1, dim = dim(X)) * L1_w
    
    return(L1_weight)
  }
  
  #### Get tensor and dimensions ####
  tnsr <- as.tensor(X)
  num_modes <- tnsr@num_modes
  L <- (num_modes - 1)
  modes <- tnsr@modes
  X <- tnsr@data
  P <- dim(X)
  
  #### Extract initial estimates ####
  # You need to specify an initialization
  if (is.null(init)) {
    stop("Error: An initialization (init) must be specified.", call. = FALSE)
  }
  
  V_list <- init$V
  U <- as.tensor(init$U.tilde)
  Cent <- init$Center
  Xt <- tnsr_cent(as.tensor(X), mean_tens = (Cent))@data
  
  itr <- 0
  Xhat <- ttl(U, V_list, ms = 1:(num_modes - 1))
  
  #### Initialize weights and loss ####
  W <- L1_weights(Xt, Xhat@data, scale = scale, delta = delta)
  if(any(is.na(X))) {
    W[which(is.na(X))] <- 0
  }
  E <- sum(abs((Xt - Xhat@data)), na.rm = T)
  EE <- matrix(c(0, E), nrow = 1)
  U <- U@data
  
  #### Main part ####
  converged <- FALSE
  if(silent == FALSE) {
    pb <- txtProgressBar(min = 0, max = max_itr, style = 3)
  }
  while((itr < max_itr)){
    setTxtProgressBar(pb, itr)
    itr <- itr + 1
    
    ## U update
    if(any(is.na(X))){
      V_list <- Get_V_NA(Xt, V_list, U, W) 
    }else{
      V_list <- Get_V(Xt, V_list, U, W)
    }
    
    ## Core tensor update
    if(any(is.na(X))){
      U.list <-
        lapply(1:P[num_modes], function(i)
          U_samp_NA(
            tens_s(as.tensor(Xt), i)@data,
            V_list,
            tens_s(as.tensor(W), i)@data,
            ranks
          ))
    }else{
      U.list <-
        lapply(1:P[num_modes], function(i)
          U_samp(
            tens_s(as.tensor(Xt), i)@data,
            V_list,
            tens_s(as.tensor(W), i)@data,
            ranks
          ))
    }
    
    U <- abind::abind(U.list, along = num_modes)
    Xhat <- ttl(as.tensor(U), V_list, ms = 1:L)
    
    ## Center update
    Nu <- array(0, P[-num_modes])
    De <- array(0, P[-num_modes])
    
    if(any(is.na(X))) {
      for (i in 1:P[num_modes]) {
        D.miss <- (tens_s(as.tensor(X), i)@data - tens_s(Xhat, i)@data)
        D.miss[which(is.na(D.miss))] <- 0
        Nu <- Nu + (D.miss * tens_s(as.tensor(W), i)@data)
        De <- De + tens_s(as.tensor(W), i)@data
      }
      
    } else{
      for (i in 1:P[num_modes]) {
        Nu <-
          Nu + ((tens_s(as.tensor(X), i)@data - tens_s(Xhat, i)@data) * tens_s(as.tensor(W), i)@data)
        De <- De + tens_s(as.tensor(W), i)@data
      }
      
    }
    
    C <- Nu / De
    Xt <- tnsr_cent(as.tensor(X), mean_tens = (C))@data
    
    ## Weight update
    W <- L1_weights(Xt, Xhat@data, scale = scale, delta = delta)
    if(any(is.na(X))) {
      W[which(is.na(X))] <- 0
    }
    
    ## Convergence
    ssDe <- sum(abs((Xt - Xhat@data)), na.rm = T)
    EE <- rbind(EE, c(itr, ssDe))
    
    if(abs(ssDe - E)/E < tol) {
      converged <- TRUE
      if(silent == FALSE) {
        setTxtProgressBar(pb, max_itr)
      }
      break
    }
    
    if(itr == max_itr && silent == FALSE) {
      setTxtProgressBar(pb, max_itr)
    }
    
    E <- ssDe
  }
  
  if(silent == FALSE) {
    close(pb)
  }
  
  #### Result ####
  res <- list()
  res$X <- X
  res$X.tilde <- Xt
  res$U.tilde <- U
  res$V <- V_list
  res$Xhat.decenter <- tnsr_cent(Xhat, mean_tens = (-C))
  res$Xhat <- Xhat@data
  res$Center <- C
  res$W <- W
  res$loss <- EE
  res$itr <- itr
  res$converged <- converged
  return(res)
}
ROMPCA <- function(X, ranks = NULL, b = 1.5, max_itr = 600, X.git = NULL, tol = 1e-05, delta = 1e-05, gl.alpha = 0.75, 
                   scale.case = NULL, scale.cell = NULL, init = NULL, cent = FALSE, OFS = FALSE, Xtest = NULL,
                   tpar = NULL, tpar.cell = NULL, n.clean = 100, cut_out = FALSE, silent = FALSE){
  # Cellwise and casewise robust MPCA.
  #
  # Arguments:
  # X: an P1x...xPL tensor.
  #    Current version takes up to L = 3.
  # Xtest: an P1x...xPL test tensor.
  #    Current version takes up to L = 3.
  # ranks: the number of ranks for every mode.
  #        If NULL then the algorithm stops by showing the eigenvalue
  #        cumulative plot. The user needs to chose the rank from this.
  # cent:  whether to compute the eigenvalue cumulative plot on the centered
  #        data.
  # X.git: an P1x...xPL tensor with gittering for DDC.
  # b: the tuning constant for rho_1.
  # tol: tolerance of the IRLS algorithm (for stopping rule).
  # max_itr: maximum number of iterations.
  # tpar: tuning parameter vector including b, c, q1, and q2 to tune rho_2.
  #       Can be NULL and computed internally.
  # tpar.cell: tuning parameter used in the out of sample prediction.
  #       Can be NULL and computed internally inside ROMPCA_OFS.
  # init: a list containing initial estimators for V, U and C.
  #       Typically NULL and computed internally.
  # scale.case: casewise residual scales.
  #             Typically NULL and computed internally.
  # scale.cell: cellwise residual scales.
  #             Typically NULL and computed internally.
  # cut_out: whether the cutoff is outputted.
  #          Typically FALSE.
  # OFS: whether the out of sample prediction should be computed.
  # delta: parameter for L1 weights.
  # gl.alpha: parameter for the cutoff to detect good leverage points.
  # silent: whether the progress bar is outputted.
  
  #### Auxiliary functions ####
  init.scale.comp <- function(X, b = 1.5, init, m.name = NULL){
    #### parameters ####
    tnsr <- as.tensor(X)
    num_modes <- tnsr@num_modes
    L <- (num_modes - 1)
    modes <- tnsr@modes
    X <- tnsr@data
    P <- dim(X)
    
    #### Initialisation ####
    Cent <- init$Center
    Xt <- tnsr_cent(as.tensor(X), mean_tens = (Cent))@data
    U <- init$U.tilde
    V_list <- init$V
    Xhat <- init$Xhat
    
    #### Scale from initialization ####
    scale.out <- get_scale_tanh(Xt, Xhat, b)
    scale.case <- scale.out$scale.case
    scale.cell <- scale.out$scale.cell
    
    #### Results ####
    if(!is.null(m.name)){
      scale.case <- as.matrix(scale.case)
      colnames(scale.case) <- m.name
    }
    
    return(scale.case)
  }
  calculateq1q2 <- function(b, c, maxit = 500, precScale = 1e-10) {
    # This function calculates the necessary parameters to make 
    # the wrapping psi function continuous.
    #
    # Input:
    # b: corner point of the wrapping psi function
    # c: rejection point of the wrapping psi function
    
    A <- 2 * pnorm(c) - 1 - 2 * c * dnorm(c)
    B <- 2 * pnorm(c) - 1
    k <- max(1,c)
    
    Anew <- A
    Bnew <- B
    knew <- k
    converged <- FALSE
    iter <- 0
    while (!converged & iter < maxit) {
      A <- Anew
      B <- Bnew
      k <- knew
      
      knew <- optimize(f = function(y) 
        abs(b - (A * (y - 1)) ^ (0.5) *
              tanh(0.5 * ((y - 1) * B ^ 2 / A) ^ 0.5*(c - b))),
        interval = c(1 + precScale, 1000),tol = precScale)$minimum
      Anew <- integrate(f = function(y) psiWrap(y, b, c, A, B, k) ^ 2 *
                          dnorm(y), lower = -c, upper = c)$value
      Bnew <- integrate(f = function(y) abs(psiWrap(y, b, c, A, B, k)) *
                          abs(y) * dnorm(y), lower = -c, upper = c)$value
      iter <- iter + 1
      converged <- max(abs(Anew - A), abs(Bnew - B), abs(knew - k)) < precScale
    }
    q1 <- sqrt(Anew * (knew - 1))
    q2 <- Bnew / 2 * sqrt((knew - 1) / Anew)
    return(list(q1 = q1, q2 = q2))
  }
  rho_tanh <- function(x, dime, b=1.5, bb = NULL, cc = NULL, q1 = NULL, q2 = NULL) { 
    # The rho function of wrapping.
    if(is.null(bb) | is.null(cc)){
      xx = 1.5*x/b
      bb = 1.5
      cc = 4 
      q1 = 1.540793
      q2 = 0.8622731
      q12 = q1/q2 
      dd = 3.7622126668 
      rhos = array(NA, dime)
      
      indsmall = which(abs(xx) <= bb)
      rhos[indsmall] = (xx[indsmall]^2)/2
      
      indmid = which(abs(xx) > bb & abs(xx) < cc)
      rhos[indmid] =(dd - q12*log(cosh(q2*(cc-abs(xx[indmid])))))
      
      indbig = which(abs(xx) >= cc)
      rhos[indbig] = dd
      rho <- rhos*(b/1.5)^2
    }else{
      if(bb > 100){
        rhos = array(NA, dime)
        rhos <- x^2
      }else{
        xx <- x
        if (is.null(q1)) {
          params <- calculateq1q2(bb, cc)
          q1 <- params$q1
          q2 <- params$q2
        }
        q12 <- q1 / q2
        dd <- (bb ^ 2 / 2) + (q1 / q2) * log(cosh(q2 * (cc - bb)))
        
        rhos = array(NA, dime)
        
        indsmall = which(abs(xx) <= bb)
        rhos[indsmall] = (xx[indsmall]^2)/2
        
        indmid = which(abs(xx) > bb & abs(xx) < cc)
        rhos[indmid] =(dd - q12*log(cosh(q2*(cc-abs(xx[indmid])))))
        
        indbig = which(abs(xx) >= cc)
        rhos[indbig] = dd
      }
    }
    
    return(rhos)
  }
  get_tuning_const_tanh <- function(dime, b_1 = 1.5, b_2 = 1){
    # Function that calculates the tuning constants under tanh rho
    
    D <- array(rnorm(prod(dime), mean = 0, sd = 1), dime)
    
    I <- dim(D)
    num_modes <- length(I)
    N <- (num_modes - 1)
    
    scale.cell <- apply(D, 1:N, scale_tanh)
    scale.cell <- array(rep(scale.cell, times = I[num_modes]), I)
    
    rho1 <- rho_tanh(D/scale.cell, dime = I, b = b_1)
    rho1_scaled <- scale.cell^2 * rho1
    rho1 <- sapply(1:tail(dim(D), 1), function(i) {
      sqrt(sum(tens_s(rho1_scaled, i))/prod(I[1:N]))
    })
    
    scale.row <- scale_tanh(rho1)
    
    rowres <- rho1/scale.row
    bb <- max(b_2 * quantile(rowres, 0.7), 0)
    cc <- max(b_2 * quantile(rowres, 0.99), 0.3)
    
    if(bb<100){
      params <- calculateq1q2(bb, cc)
      q1 <- params$q1 
      q2 <- params$q2
    }
    else{
      q1 <- q2 <- NA
    }
    par <- c(bb, cc, q1, q2)
    return(par)
  }
  get_c_scaletanh <- function(delta = 1.8811){
    set.seed(123)
    x<-rnorm(5000)
    c_vec<-seq(0.1, 10, 0.0001)
    m_vec<-numeric()
    for (ii in 1:length(c_vec)){
      
      m_vec[ii]<-mean(rho_tanh(x/c_vec[ii]))
      
    }
    dist<-abs(m_vec-delta)
    
    c<-c_vec[which.min(dist)]
    return(c)
  }
  scale_tanh <- function (u, delta = 1.8811, max.it = 100, tol = 1e-06, tolerancezero = .Machine$double.eps){
    # get scale using tanh rho
    rho_tanh_vec <- function(x, b = 1.5, bb = NULL, cc = NULL, q1 = NULL, q2 = NULL) { 
      # The rho function of wrapping.
      if(is.null(bb) | is.null(cc)){
        xx <- 1.5 * x / b
        bb <- 1.5
        cc <- 4
        q1 <- 1.540793
        q2 <- 0.8622731
        q12 <- q1 / q2
        dd <- 3.7622126668
        rhos <- rep(NA, length(xx))
        indsmall <- which(abs(xx) <= bb)
        rhos[indsmall] <- (xx[indsmall] ^ 2) / 2
        indmid <- which(abs(xx) > bb & abs(xx) < cc)
        rhos[indmid] <- (dd - q12 * log(cosh(q2 * (cc - abs(xx[indmid])))))
        indbig <- which(abs(xx) >= cc)
        rhos[indbig] = dd
      }
      else{
        if(bb > 100) {
          rhos <- rep(NA, length(x))
          rhos <- (x ^ 2)
        }
        else{
          xx <- x
          if (is.null(q1)) {
            params <- calculateq1q2(bb, cc)
            q1 <- params$q1
            q2 <- params$q2
          }
          
          q12 <- q1 / q2
          dd <- (bb ^ 2 / 2) + (q1 / q2) * log(cosh(q2 * (cc - bb)))
          
          rhos <- rep(NA, length(xx))
          indsmall <- which(abs(xx) <= bb)
          rhos[indsmall] <-  (xx[indsmall] ^ 2) / 2
          indmid <- which(abs(xx) > bb & abs(xx) < cc)
          rhos[indmid] <-
            (dd - q12 * log(cosh(q2 * (cc - abs(
              xx[indmid]
            )))))
          indbig <- which(abs(xx) >= cc)
          rhos[indbig] <- dd
        }
      }
      return(rhos)
    }
    
    #### main ####
    if(delta == 1.8811){
      c<-0.34308##
    }
    else{
      c <- get_c_scaletanh(delta)
    }
    # s0 <- median(abs(u))/0.6745
    s0 <- median(abs(u), na.rm = T)/0.6745
    if (s0 < tolerancezero) 
      return(0)
    err <- tol + 1
    it <- 0
    while ((err > tol) && (it < max.it)) {
      it <- it + 1
      s1 <- sqrt(s0^2 * mean(rho_tanh_vec(u/(c*s0)), na.rm = T)/delta)
      err <- abs(s1 - s0)/s0
      s0 <- s1
    }
    return(s0)
  }
  psiWrap <- function(x, b, c, A, B, k) {
    # Wrapping psi function
    indmid <- which(abs(x) >= b & abs(x) <= c)
    indup  <- which(abs(x) >= c)
    x[indmid] <- (A * (k - 1)) ^ (0.5) *
      tanh(0.5 * ((k - 1) * B ^ 2 / A) ^ 0.5 *
             (c - abs(x[indmid]))) * sign(x[indmid])
    x[indup] <- 0
    return(x)
  }
  
  get_scale_tanh <- function(Xt, Xhat, b_1 = 1.5){
    res <- list()
    
    P <- dim(Xt)
    num_modes <- length(P)
    L <- (num_modes - 1)
    D <- (Xt - Xhat)
    
    # Cellwise scale
    scale.cell <- apply(D, 1:L, scale_tanh) # new scale using tanh
    scale.cell <- array(rep(scale.cell, times = P[num_modes]), P)
    res$scale.cell <- scale.cell
    rho1 <- rho_tanh(D/scale.cell, dime = P, b = b_1)
    rho1 <- rho1 * scale.cell^2
    
    # Rowwise scale
    if(any(is.na(Xt))){
      res_N <- sapply(1:tail(dim(Xt), 1), function(i) {
        numNA <- length(which(!is.na(n_unfold(rho1, num_modes)[i,])))
        sqrt(sum(tens_s(rho1, i), na.rm = T)/numNA)
      })
    }else{
      res_N <- sapply(1:tail(dim(Xt), 1), function(i) {
        sqrt(sum(tens_s(rho1, i))/prod(P[1:L]))
      }) 
    }
    
    res$scale.case <- scale_tanh(res_N) # new scale using tanh
    
    return(res)
  }
  weight_tanh <- function(x, dime, b = 1.5, bb = NULL, cc = NULL, q1 = NULL, q2 = NULL){
    # The weight function of wrapping.
    psitanh <- function(xx, bb, cc, q1, q2){
      abs_xx <- abs(xx)
      psi <- xx
      
      # boolean indexing instead of which
      indb <- abs_xx <= bb
      indc <- abs_xx > bb & abs_xx <= cc
      indbig <- abs_xx > cc
      
      if(any(is.na(indc))){
        indc[is.na(indc)] <- FALSE
      }
      
      if(any(is.na(indbig))){
        indbig[is.na(indbig)] <- FALSE 
      }
      
      psi[indc] <- q1 * tanh(q2 * (cc - abs_xx[indc])) * sign(xx[indc])
      psi[indbig] <- 0
      
      psi
    }
    
    if(is.null(bb) | is.null(cc)){
      xx <- 1.5 * x / b
      bb <- 1.5
      cc <- 4
      q1 <- 1.540793
      q2 <- 0.8622731
      q12 <- q1 / q2
      dd <- 3.7622126668
      
      tanh_w <- ifelse(is.na(xx), NA, ifelse(xx == 0, 1, psitanh(xx, bb, cc, q1, q2) / xx))
      tanh_w <- array(tanh_w, dime)
      
    }else{
      if(bb > 100){
        xx <- x
        tanh_w <- array(sapply(xx, function(t){ ifelse(is.na(t), NA,  1 )}), dime)
      }else{
        xx <- x
        if(is.null(q1)){
          params <- calculateq1q2(bb, cc)
          q1 <- params$q1
          q2 <- params$q2
        }
        q12 <- q1 / q2
        dd <- (bb ^ 2 / 2) + (q1 / q2) * log(cosh(q2 * (cc - bb)))
        
        tanh_w <- ifelse(is.na(xx), NA, ifelse(xx == 0, 1, psitanh(xx, bb, cc, q1, q2) / xx))
        tanh_w <- array(tanh_w, dime)
      }
    }
    
    return(tanh_w)
  }
  weight_tanh_tanh <- function(Xt, Xhat, scale.cell, scale.case, b_1 = 1.5, bb, cc, q1, q2){
    # The weight function of wrapping 
    # combined for both casewise and cellwise.
    P <- dim(Xt)
    num_modes <- length(P)
    L <- (num_modes - 1)
    D <- (Xt - Xhat)
    
    w1 <- weight_tanh(D/scale.cell, dime = P, b = b_1)
    
    rho1 <- rho_tanh(D/scale.cell, dime = P, b = b_1)
    rho1_scaled <- scale.cell^2 * rho1
    
    if(any(is.na(Xt))) {
      rho1 <- sapply(1:tail(dim(Xt), 1), function(i) {
        numNA <- length(which(!is.na(n_unfold(
          rho1_scaled, num_modes
        )[i, ])))
        sqrt(sum(tens_s(rho1_scaled, i), na.rm = T) / numNA)
      })
    } else{
      rho1 <- sapply(1:tail(dim(Xt), 1), function(i) {
        sqrt(sum(tens_s(rho1_scaled, i)) / prod(P[1:L]))
      })
    }
    
    w2_vec <- weight_tanh(rho1/scale.case, length(rho1), bb = bb, cc = cc, q1 = q1, q2 = q2)
    w2 <- array(rep(w2_vec, each = prod(P[-num_modes])), dim = P)
    W <- w1 * w2
    
    res <- list(w1 = w1, w2 = w2, w2_vec = w2_vec, W = W)
    return(res)
  }
  get_loss_tanh <- function(Xt, Xhat, scale.cell, scale.case, b_1 = 1.5, bb, cc, q1, q2){
    # Loss function using tanh rhos
    P <- dim(Xt)
    num_modes <- length(P)
    L <- (num_modes - 1)
    D <- (Xt - Xhat)
    
    rho1 <- rho_tanh(D/scale.cell, dime = P, b = b_1)
    rho1_scaled <- scale.cell^2 * rho1
    
    if(any(is.na(Xt))){
      rho1 <- sapply(1:tail(dim(Xt), 1), function(i) {
        numNA <- length(which(!is.na(n_unfold(rho1_scaled, num_modes)[i,])))
        sqrt(sum(tens_s(rho1_scaled, i), na.rm = T)/numNA)
      })
      
      numNA <- sapply(1:tail(dim(Xt), 1), function(i) length(which(!is.na(n_unfold(rho1_scaled, num_modes)[i,]))))
      rho2 <- rho_tanh(rho1/scale.case, dime = length(rho1), bb = bb, cc = cc, q1 = q1, q2 = q2)*numNA
      
    }else{
      rho1 <- sapply(1:tail(dim(Xt), 1), function(i) {
        sqrt(sum(tens_s(rho1_scaled, i))/prod(P[1:L]))
      })
      
      rho2 <- rho_tanh(rho1/scale.case, dime = length(rho1), bb = bb, cc = cc, q1 = q1, q2 = q2)
    }
    
    return(sum(rho2))
  }
  
  
  #### Get tensor and dimensions ####
  tnsr <- as.tensor(X)
  num_modes <- tnsr@num_modes
  L <- (num_modes - 1)
  modes <- tnsr@modes
  X <- tnsr@data
  P <- dim(X)
  cinit <- FALSE
  
  #### Ranks ####
  if(is.null(ranks)){
    
    # comments for the user
    cat("\n===============================================\n")
    cat("🔍 Compute cumulative eigenvalue distribution\n")
    cat("   to choose ranks accordingly based on the plot\n")
    cat("===============================================\n\n")
    
    # DDC on the unfolded
    if(is.null(X.git)){
      DDC.out <- cellWise::DDC(n_unfold(X, num_modes), DDCpars = list(silent = TRUE)) 
    }else{
      # this for real data application to avoid constant scale
      DDC.out <- cellWise::DDC(n_unfold(X.git, num_modes), DDCpars = list(silent = TRUE))
    }
    
    # DDC imputed 
    DDC.imp <- n_fold(DDC.out$Ximp, X, N, n = num_modes)
    
    X.na.imp <- X
    if(any(is.na(X))){
      X.na.imp[which(is.na(X))] <- DDC.imp[which(is.na(X))]
    }
    
    # get the cellwise outliers
    ind.case.ddc <- DDC.out$indrows
    indcell.out <- array(0, dim(DDC.out$Ximp))
    indcell.out[DDC.out$indcells] <- NA
    indcell.out <- n_fold(indcell.out, X, N, n = num_modes)
    indcell.out <- which(is.na(indcell.out))
    
    # impute also the cells with DDC and remove casewise outliers
    X.ccase.imp <- X.na.imp
    X.ccase.imp[indcell.out] <- DDC.imp[indcell.out]
    if(length(DDC.out$indrows) != 0) {
      X.ccase.imp <- X.ccase.imp[, , -DDC.out$indrows]
    }
    
    X.imp.cent <- X.ccase.imp
    if(cent == T) {
      dimes <- dim(X.ccase.imp)
      center.data.imp <- array(0, dimes[-num_modes])
      for (i in 1:dimes[num_modes]) {
        center.data.imp <- center.data.imp + tens_s(as.tensor(X.ccase.imp), i)@data
      }
      DDC.imp.cent <- center.data.imp / dimes[num_modes]
      
      X.imp.cent <- (tnsr_cent(as.tensor(X.ccase.imp), mean_tens = (DDC.imp.cent))@data)
      
      X.imp.sum <- array(0, dimes[-num_modes])
      for (i in 1:dimes[num_modes]) {
        X.imp.sum <- X.imp.sum + tens_s(as.tensor(X.imp.cent), i)@data
      }
      X.imp.cent <- X.imp.sum
    }
    
    mode1 <- n_unfold(X.imp.cent, n = 1)
    mode2 <- n_unfold(X.imp.cent, n = 2)
    eig1 <- eigen(mode1 %*% t(mode1))$values
    eig2 <- eigen(mode2 %*% t(mode2))$values
    cumulative_eig1 <- c(0, (cumsum(eig1) / sum(eig1)))
    cumulative_eig2 <- c(0, (cumsum(eig2) / sum(eig2)))
    
    if(L == 3){
      mode3 <- n_unfold(X.imp.cent, n = 3)
      eig3 <- eigen(mode3 %*% t(mode3))$values
      cumulative_eig3 <- c(0, (cumsum(eig3) / sum(eig3)))
    }
    
    # Plot cumulative eigenvalue distribution
    col.modes <- c("black", "red")
    legend.modes <- c("Mode 1", "Mode 2")
    
    plot(0:length(eig1), cumulative_eig1, type = "b", pch = 22, lty = 1, lwd = 3,
         xlab = "Ranks", ylab = "",
         ylim = c(0, 1), xlim = c(0, 25), col = "black")
    grid()
    points(0:length(eig2), cumulative_eig2, type = "b", pch = 23, lty = 2, col = "red", lwd = 3)
    if(L == 3){
      points(0:length(eig3), cumulative_eig3, type = "b", pch = 24, lty = 3, col = "blue", lwd = 3)
      col.modes <- c("black", "red", "blue")
      legend.modes <- c("Mode 1", "Mode 2", "Mode 3")
    }
    legend("bottomright", inset = c(0.015, 0.015), legend = legend.modes,
           pch = c(21 + 1:L), lty = (1:L), col = col.modes, cex = 0.6,
           box.lwd = 2, bg = "white", box.col = "black")
    
    cat("\n=================================================\n")
    cat("💡 Use the cumulative eigenvalue distribution plot\n")
    cat("   to decide on the ranks.\n")
    cat("=================================================\n\n")
    # Stop execution and indicate next steps
    stop("Rerun the ROMPCA with the chosen ranks")
  }
  
  #### Extract initial estimates ####
  if (is.null(init)) {
    # MPCA on reduced set and reweighting step
    cinit <- TRUE
    if(is.null(X.git)){
      if(silent == FALSE) {
        # cat("\n===============================================\n")
        # cat("             DDC initialization                  \n")
        # cat("===============================================\n\n")
        
        cat("\nDDC initialization:\n\n")
      }
      
      DDC.MPCA.init <- DDC_MPCA(
        X.cont = X,
        ranks = ranks,
        tol = tol,
        silent = silent
      )
    }else{
      if(silent == FALSE) {
        # cat("\n===============================================\n")
        # cat("             DDC initialization                  \n")
        # cat("===============================================\n\n")
        
        cat("\nDDC initialization:\n\n")
      }
      
      DDC.MPCA.init <- DDC_MPCA(
        X.cont = X,
        X.ddc = X.git,
        ranks = ranks,
        tol = tol,
        silent = silent
      )
    }
    
    # Compute scale for L1
    scale.L1 <- apply((X - DDC.MPCA.init$Xhat.decenter@data), 1:L, scale_tanh)
    
    # L1-MPCA
    if(silent == FALSE) {
      # cat("\n===============================================\n")
      # cat("               L1 initialization                 \n")
      # cat("===============================================\n\n")
      cat("\nL1 initialization:\n\n")
    }
    
    L1.out <- L1_MPCA(
      X,
      ranks,
      max_itr = max_itr,
      init = DDC.MPCA.init,
      tol = tol,
      scale = scale.L1,
      delta = delta,
      silent = silent
    )
    L1.init <- list(
      X.tilde = L1.out$X.tilde,
      U.tilde = L1.out$U.tilde,
      V = L1.out$V,
      Xhat = L1.out$Xhat,
      Center = L1.out$Center
    )
    
    # choose initialization according to casewise scale
    init.comp.ddc <- init.scale.comp(X, b = b, init = DDC.MPCA.init, m.name = "DDC-Init")
    init.comp.L1 <- init.scale.comp(X, b = b, init = L1.init, m.name = "L1-Init")
    
    init.comp <- cbind(init.comp.ddc, init.comp.L1)
    init.name <- colnames(init.comp[, which.min(init.comp), drop = FALSE])
    
    # choose the initialisation with lowest casewise scale
    list.init <- list("DDC-Init" = DDC.MPCA.init, "L1-Init" = L1.init)
    init <- list.init[[init.name]]
  }
  
  V_list <- init$V
  U <- init$U.tilde
  Cent <- init$Center
  Xt <- tnsr_cent(as.tensor(X), mean_tens = (Cent))@data
  Xhat <- init$Xhat
  
  #### Scale from initialization ####
  scale.out <- get_scale_tanh(Xt, Xhat, b)
  
  if(is.null(scale.case)) {
    scale.case <- scale.out$scale.case
  }
  
  if(is.null(scale.cell)) {
    scale.cell <- scale.out$scale.cell
  }
  
  # Get tuning constants
  if(is.null(tpar)){
    dime <- c(P[-num_modes], 10000)
    par <- get_tuning_const_tanh(dime, b, 1) 
  }else{
    par <- tpar
  }
  
  #### Initialize weights and loss ####
  Weight.est <- weight_tanh_tanh(Xt, Xhat, b_1 = b,
                                 scale.cell = scale.cell, 
                                 scale.case = scale.case, 
                                 bb = par[1], cc = par[2], 
                                 q1 = par[3], q2 = par[4])
  W <- Weight.est$W
  Wc <- Weight.est$w1
  
  if(any(is.na(X))) {
    miss.idx <- which(is.na(X))
    W[miss.idx] <- 0
    Wc[miss.idx] <- 0
  }
  
  E <- get_loss_tanh(Xt, Xhat, b_1 = b,
                     scale.cell = scale.cell, 
                     scale.case = scale.case,
                     bb = par[1], cc = par[2], 
                     q1 = par[3], q2 = par[4])
  EE <- matrix(c(0, E), nrow = 1)
  
  #### Main part ####
  converged <- FALSE
  itr <- 0
  if(silent == FALSE) {
    # cat("\n===============================================\n")
    # cat("                    ROMPCA                       \n")
    # cat("===============================================\n\n")
    cat("\nROMPCA:\n\n")
    
    pb <- txtProgressBar(min = 0, max = max_itr, style = 3)
  }
  
  while((itr < max_itr)){
    
    if(silent == FALSE) {
      setTxtProgressBar(pb, itr)
    }
    itr <- itr + 1
    
    ## U update
    if(any(is.na(X))) {
      V_list <- Get_V_NA(Xt, V_list, U, W)
    } else{
      V_list <- Get_V(Xt, V_list, U, W)
    }
    
    ## Core tensor update
    if(any(is.na(X))) {
      U.list <-
        lapply(1:P[num_modes], function(i)
          U_samp_NA(
            tens_s(as.tensor(Xt), i)@data,
            V_list,
            tens_s(as.tensor(Wc), i)@data,
            ranks
          ))
    } else{
      U.list <-
        lapply(1:P[num_modes], function(i)
          U_samp(
            tens_s(as.tensor(Xt), i)@data,
            V_list,
            tens_s(as.tensor(Wc), i)@data,
            ranks
          ))
    }
    
    U <- abind::abind(U.list, along = num_modes)
    Xhat <- ttl(as.tensor(U), V_list, ms = 1:L)
    
    ## Center update
    Nu <- array(0, P[-num_modes])
    De <- array(0, P[-num_modes])
    
    if(any(is.na(X))) {
      for (i in 1:P[num_modes]) {
        D.miss <- (tens_s(as.tensor(X), i)@data - tens_s(Xhat, i)@data)
        D.miss[which(is.na(D.miss))] <- 0
        Nu <- Nu + (D.miss * tens_s(as.tensor(W), i)@data)
        De <- De + tens_s(as.tensor(W), i)@data
      }
      
    } else{
      for (i in 1:P[num_modes]) {
        Nu <-
          Nu + ((tens_s(as.tensor(X), i)@data - tens_s(Xhat, i)@data) * tens_s(as.tensor(W), i)@data)
        De <- De + tens_s(as.tensor(W), i)@data
      }
      
    }
    
    C <- Nu/(De+1e-10)
    Xt <- tnsr_cent(as.tensor(X), mean_tens = (C))@data
    
    ## Weight update
    Weight.est <- weight_tanh_tanh(Xt, Xhat@data, b_1 = b,
                                   scale.cell = scale.cell, 
                                   scale.case = scale.case,
                                   bb = par[1], cc = par[2], 
                                   q1 = par[3], q2 = par[4])
    W <- Weight.est$W
    Wc <- Weight.est$w1
    Wr <- Weight.est$w2
    
    if(any(is.na(X))) {
      W[miss.idx] <- 0
      Wc[miss.idx] <- 0
    }
    
    ## Convergence
    ssDe <- get_loss_tanh(Xt, Xhat@data, b_1 = b,
                          scale.cell = scale.cell, 
                          scale.case = scale.case,
                          bb = par[1], cc = par[2], 
                          q1 = par[3], q2 = par[4])
    
    EE <- rbind(EE, c(itr, ssDe))
    if(abs(ssDe - E)/E < tol){
      converged <- TRUE
      if(silent == FALSE) {
        setTxtProgressBar(pb, max_itr)
      }
      break
    }
    
    if(itr == max_itr && silent == FALSE){
      setTxtProgressBar(pb, max_itr)
    }
    
    E <- ssDe
  }
  
  if(silent == FALSE) {
    close(pb)
  }
  
  #### Compute standardized residuals ####
  R.rompca <- X - tnsr_cent(Xhat, mean_tens = (-C))@data
  scale.cell.re <- get_scale_tanh(X, tnsr_cent(Xhat, mean_tens = (-C))@data, b)
  R.std <- R.rompca / scale.cell.re$scale.cell
  
  # compute RD
  RD <- sapply(1:N, function(i) {
    x <- as.vector(tens_s(R.std, i))
    sum(x^2, na.rm = T)^(1/2)
  })
  
  if(L == 3){
    scale.cell1 <- scale.cell.re$scale.cell[, , , 1]
  }else{
    scale.cell1 <- scale.cell.re$scale.cell[, , 1]
  }
  
  if(cut_out == TRUE) {
    X.idx <- sample(seq_len(N), size = n.clean, replace=T)
    dime <- c((dimension[-num_modes]), length(X.idx))
    X.clean <- array(rnorm(prod(dime)), dime)
    
    scale.cell.clean <- apply(X.clean, 1:L, scale_tanh)
    scale.cell.clean <- array(rep(scale.cell.clean, times = n.clean), dime)
    Res.final <- X.clean/scale.cell.clean
    
    RD.simu <- sapply(1:n.clean, function(i) {
      frobnorm(tens_s(Res.final, i))
    })
    RD.cut <- quantile(RD.simu, 0.99)
  }
  
  #### Correct the center ####
  # Update the mean to cope with the translational ambiguity
  Nu <- array(0, P[-num_modes])
  De <- array(0, P[-num_modes])
  
  for(i in 1:P[num_modes]){
    Nu <- Nu + ((tens_s(as.tensor(X), i)@data) * tens_s(as.tensor(W), i)@data)
    De <- De + tens_s(as.tensor(W), i)@data
  }
  
  C.new <- Nu/(De)
  C.old <- C
  
  Center.prime <- C.new - C.old
  U.mean.diff <- ttl(as.tensor(Center.prime), lapply(V_list, t), ms = 1:(num_modes - 1))@data
  Center.new <- C.old + ttl(as.tensor(U.mean.diff), V_list, ms = 1:(num_modes - 1))@data
  
  Center.proj <- ttl(as.tensor(Center.prime), lapply(V_list, t), ms = 1:(num_modes - 1))@data
  U.new <- tnsr_cent(as.tensor(U), mean_tens = (Center.proj))@data
  
  #### Get Imputed value ####
  Xhat.decenter <- tnsr_cent(Xhat, mean_tens = (-C))@data
  Ximp <- aperm((Xhat.decenter + Wc * (X - Xhat.decenter)), c(3, 1, 2))
  
  #### Get outlying set (BL + GL) ####
  scores <- U # change to the corrected?
  scores.unf <- n_unfold(scores, num_modes)
  score.cov <- robustbase::covMcd(scores.unf, alpha = gl.alpha)
  score.distance <- score.cov$mah
  cut.sd <- qchisq(0.99, dim(scores.unf)[2])
  outl.X <- which(score.distance > cut.sd)
  outl.X <- unique(c(outl.X, which(n_unfold(Wr, num_modes)[,1] != 1)))
  
  #### Results ####
  res <- list()
  res$X <- X
  res$X.tilde <- Xt
  res$U.tilde <- U
  res$U.tilde.corr <- U.new
  res$V <- V_list
  res$Xhat.decenter <- tnsr_cent(Xhat, mean_tens = (-C))
  res$Xhat <- Xhat@data
  res$Center <- C
  res$Center.corr <- Center.new
  res$W <- W
  res$W.cell <- Wc
  res$W.case <- Wr
  res$loss <- EE
  res$itr <- itr
  res$converged <- converged
  res$scale.cell <- scale.cell
  res$scale.cell.re <- scale.cell.re$scale.cell
  res$scale.case <- scale.case
  res$R.std <- R.std
  
  # For the outliers an imputed tensor
  res$Ximp <- Ximp
  res$scores <- scores
  res$score.distance <- score.distance
  res$outl.X <- outl.X
  
  if(cut_out == TRUE) {
    res$RD <- RD
    res$RD.cut <- RD.cut
  }
  
  if (cinit == TRUE){
    res$DDC.MPCA.init <- DDC.MPCA.init
    res$L1.init <- L1.init
  }
  
  if(OFS == TRUE){
    Ntest <- tail(dim(Xtest),1)
    scale.ofs <- get_scale_tanh(X, Xhat.decenter, b)
    scale.ofs$scale.cell <- scale.ofs$scale.cell[,,1:Ntest]
    
    # from DDC construct a weight tensor
    Xtest_std <- n_unfold(Xtest, num_modes)
    Xtest_std <- sweep(Xtest_std, 2, DDC.MPCA.init$ddc.out$locX,  FUN = "-")
    Xtest_std <- sweep(Xtest_std, 2, DDC.MPCA.init$ddc.out$scaleX, FUN = "/")
    outl.ofs <- which(abs(Xtest_std) > sqrt(qchisq(0.99, 1))) #qchisq 0.99 with p = 1
    
    cell.idx <- array(0, dim(Xtest_std))
    cell.idx[outl.ofs] <- NA
    cell.idx <- n_fold(cell.idx, Xtest, Ntest, n = num_modes)
    cell.idx <- which(is.na(cell.idx)) #for cellwise weight
    
    W.cell.ofs <- array(1, dim(Xtest))
    W.cell.ofs[cell.idx] <- 0
    
    # get out of sample prediction
    rompca_ofs.out <- ROMPCA_OFS(
      Xtest,
      ranks = ranks,
      scale.init = scale.ofs,
      tpar = tpar.cell,
      init = res,
      w.init = W.cell.ofs,
      max_itr = 100
    )
    
    res$Ximp_test <- rompca_ofs.out$Ximp
  }
  
  return(res)
}

# Auxiliary function for ROMPCA -------------------------------------------
Get_V <-  function(Xt, V_list, U, W){
  # Get V without missing values
  tnsr <- as.tensor(Xt)
  mode_seq <- 1:(length(dim(tnsr)) - 1)
  V_list.update <- vector("list", (length(dim(tnsr))  - 1))
  
  for (n in mode_seq) {
    ms <- mode_seq[-n]
    Rn <- dim(V_list[[n]])[2]
    mat1 <- matrix(0, dim(tnsr)[n]*Rn, dim(tnsr)[n]*Rn)
    mat2 <- matrix(0, dim(tnsr)[n]*Rn, 1)
    
    # Iterate over all sample
    for (i in 1:tail(tnsr@modes, 1)) {
      U_red <- (tnsr_tnsr(tens_s(U, i), V_list, ms = mode_seq[-n]))
      U_red_unf <- n_unfold(U_red, n)
      W_unf <- n_unfold(tens_s(as.tensor(W), i)@data, n)
      Xt_unf <- n_unfold(tens_s(tnsr, i)@data, n)
      
      kr.first.1 <- Matrix::Matrix(fastmatrix::kronecker.prod(U_red_unf, diag(dim(tnsr)[n])))
      kr.sec.1 <- Matrix::Matrix(t(kr.first.1))
      mat1 <- mat1 + (kr.first.1 %*% (kr.sec.1 * c(W_unf)))
      mat2 <- mat2 + (kr.first.1 %*% (matrix(c(Xt_unf)) * c(W_unf)))
    }
    
    mat1 <- as.matrix(mat1)
    mat2 <- as.matrix(mat2)
    Vn.vec <- rfunctions::geninv(mat1 + .Machine$double.eps) %*% mat2
    Vn <- matrix(c(Vn.vec), dim(Xt)[n], Rn)
    Vn <- OmicsPLS::orth(Vn)
    V_list.update[[n]] <- Vn
  }
  
  return(V_list.update)
}
Get_V_NA <-  function(Xt, V_list, U, W){
  # Get V with missing values
  miss.idx <- which(is.na(Xt))
  Xt[miss.idx] <- 0
  
  tnsr <- as.tensor(Xt)
  mode_seq <- 1:(length(dim(tnsr)) - 1)
  V_list.update <- vector("list", length(mode_seq))
  
  for (n in mode_seq) {
    ms <- mode_seq[-n]
    Rn <- dim(V_list[[n]])[2]
    mat1 <- matrix(0, dim(tnsr)[n] * Rn, dim(tnsr)[n] * Rn)
    mat2 <- matrix(0, dim(tnsr)[n] * Rn, 1)
    
    # Iterate over all sample
    for (i in 1:tail(tnsr@modes, 1)) {
      U_red <- (tnsr_tnsr(tens_s(U, i), V_list, ms = mode_seq[-n]))
      U_red_unf <- n_unfold(U_red, n)
      W_unf <- n_unfold(tens_s(as.tensor(W), i)@data, n)
      Xt_unf <- n_unfold(tens_s(tnsr, i)@data, n)
      
      kr.first.1 <- Matrix::Matrix(fastmatrix::kronecker.prod(U_red_unf, diag(dim(tnsr)[n])))
      kr.sec.1 <- Matrix::Matrix(t(kr.first.1))
      mat1 <- mat1 + (kr.first.1 %*% (kr.sec.1 * c(W_unf)))
      mat2 <- mat2 + (kr.first.1 %*% (matrix(c(Xt_unf)) * c(W_unf)))
    }
    
    mat1 <- as.matrix(mat1)
    mat2 <- as.matrix(mat2)
    
    # Compute the updated Vn
    Vn.vec <- rfunctions::geninv(mat1) %*% mat2
    Vn <- matrix(c(Vn.vec), dim(Xt)[n], Rn)
    Vn <- OmicsPLS::orth(Vn)
    V_list.update[[n]] <- Vn
  }
  
  return(V_list.update)
}

U_samp <- function(Xt, V_list, W, ranks){
  # Get U without missing values
  N <- length(dim(Xt))
  kr.v <- V_list[[N]]
  
  for(i in (N-1):1){
    kr.v <- fastmatrix::kronecker.prod(kr.v, V_list[[i]])
  }
  kr.v.t <- t(kr.v)
  
  U.vec1 <- rfunctions::geninv(kr.v.t %*% (c(W) * kr.v))
  U.vec2  <- kr.v.t %*% (c(W) * matrix(c(Xt)))
  U.vec <- U.vec1 %*% U.vec2
  U.new <- array(c(U.vec), ranks)
  return(U.new)
}
U_samp_NA <- function(Xt, V_list, W, ranks){
  # Get U with missing values
  miss.idx <- which(is.na(Xt))
  Xt[miss.idx] <- 0
  
  N <- length(dim(Xt))
  kr.v <- V_list[[N]]
  
  Xt[miss.idx] <- 0
  
  for(i in (N-1):1){
    kr.v <- fastmatrix::kronecker.prod(kr.v, V_list[[i]])
  }
  kr.v.t <- t(kr.v)
  
  U.vec1 <- rfunctions::geninv(kr.v.t %*% (c(W) * kr.v))
  U.vec2  <- kr.v.t %*% (c(W) * matrix(c(Xt)))
  U.vec <- U.vec1 %*% U.vec2
  U.new <- array(c(U.vec), ranks)
  return(U.new)
}

safe_ginv <- function(X) {
  tryCatch({
    MASS::ginv(X)
  }, error = function(e) {
    message("ginv() failed, using eigen() fallback")
    eig <- eigen(X, symmetric = TRUE)
    tol <- .Machine$double.eps * max(dim(X)) * max(abs(eig$values))
    d_inv <- ifelse(abs(eig$values) > tol, 1 / eig$values, 0)
    eig$vectors %*% diag(d_inv) %*% t(eig$vectors)
  })
}

ROMPCA_OFS <- function(X, ranks, b = 1.5, scale.init, tpar = NULL, init, w.init, max_itr = 100, tol = 1e-06, silent = FALSE){
  # Cellwise and casewise robust MPCA.
  #
  # Arguments:
  # X: an P1x...xPL tensor.
  #    Current version takes up to L = 3.
  # ranks: the number of ranks for every mode.
  #        If NULL then the algorithm stops by showing the eigenvalue
  #        cumulative plot. The user needs to chose the rank from this.
  # b: the tuning constant for rho_1.
  # tol: tolerance of the IRLS algorithm (for stopping rule).
  # max_itr: maximum number of iterations.
  # tpar: tuning parameter vector including b, c, q1, and q2 to tune rho_2.
  #       Can be NULL and computed internally.
  # init: a list containing initial estimators for V, U and C.
  #       Typically NULL and computed internally.
  # scale.case: casewise residual scales.
  # scale.cell: cellwise residual scales.
  # silent: whether the progress bar is outputted.
  
  #### Auxiliary functions ####
  init.scale.comp <- function(X, b = 1.5, init, m.name = NULL){
    #### parameters ####
    tnsr <- as.tensor(X)
    num_modes <- tnsr@num_modes
    L <- (num_modes - 1)
    modes <- tnsr@modes
    X <- tnsr@data
    P <- dim(X)
    
    #### Initialisation ####
    Cent <- init$Center
    Xt <- tnsr_cent(as.tensor(X), mean_tens = (Cent))@data
    U <- init$U.tilde
    V_list <- init$V
    Xhat <- init$Xhat
    
    #### Scale from initialization ####
    scale.out <- get_scale_tanh(Xt, Xhat, b)
    scale.case <- scale.out$scale.case
    scale.cell <- scale.out$scale.cell
    
    #### Results ####
    if(!is.null(m.name)){
      scale.case <- as.matrix(scale.case)
      colnames(scale.case) <- m.name
    }
    
    return(scale.case)
  }
  calculateq1q2 <- function(b, c, maxit = 500, precScale = 1e-10) {
    # This function calculates the necessary parameters to make 
    # the wrapping psi function continuous.
    #
    # Input:
    # b: corner point of the wrapping psi function
    # c: rejection point of the wrapping psi function
    
    A <- 2 * pnorm(c) - 1 - 2 * c * dnorm(c)
    B <- 2 * pnorm(c) - 1
    k <- max(1,c)
    
    Anew <- A
    Bnew <- B
    knew <- k
    converged <- FALSE
    iter <- 0
    while (!converged & iter < maxit) {
      A <- Anew
      B <- Bnew
      k <- knew
      
      knew <- optimize(f = function(y) 
        abs(b - (A * (y - 1)) ^ (0.5) *
              tanh(0.5 * ((y - 1) * B ^ 2 / A) ^ 0.5*(c - b))),
        interval = c(1 + precScale, 1000),tol = precScale)$minimum
      Anew <- integrate(f = function(y) psiWrap(y, b, c, A, B, k) ^ 2 *
                          dnorm(y), lower = -c, upper = c)$value
      Bnew <- integrate(f = function(y) abs(psiWrap(y, b, c, A, B, k)) *
                          abs(y) * dnorm(y), lower = -c, upper = c)$value
      iter <- iter + 1
      converged <- max(abs(Anew - A), abs(Bnew - B), abs(knew - k)) < precScale
    }
    q1 <- sqrt(Anew * (knew - 1))
    q2 <- Bnew / 2 * sqrt((knew - 1) / Anew)
    return(list(q1 = q1, q2 = q2))
  }
  rho_tanh <- function(x, dime, b=1.5, bb = NULL, cc = NULL, q1 = NULL, q2 = NULL) { 
    # The rho function of wrapping.
    if(is.null(bb) | is.null(cc)){
      xx = 1.5*x/b
      bb = 1.5
      cc = 4 
      q1 = 1.540793
      q2 = 0.8622731
      q12 = q1/q2 
      dd = 3.7622126668 
      rhos = array(NA, dime)
      
      indsmall = which(abs(xx) <= bb)
      rhos[indsmall] = (xx[indsmall]^2)/2
      
      indmid = which(abs(xx) > bb & abs(xx) < cc)
      rhos[indmid] =(dd - q12*log(cosh(q2*(cc-abs(xx[indmid])))))
      
      indbig = which(abs(xx) >= cc)
      rhos[indbig] = dd
      rho <- rhos*(b/1.5)^2
    }else{
      if(bb > 100){
        rhos = array(NA, dime)
        rhos <- x^2
      }else{
        xx <- x
        if (is.null(q1)) {
          params <- calculateq1q2(bb, cc)
          q1 <- params$q1
          q2 <- params$q2
        }
        q12 <- q1 / q2
        dd <- (bb ^ 2 / 2) + (q1 / q2) * log(cosh(q2 * (cc - bb)))
        
        rhos = array(NA, dime)
        
        indsmall = which(abs(xx) <= bb)
        rhos[indsmall] = (xx[indsmall]^2)/2
        
        indmid = which(abs(xx) > bb & abs(xx) < cc)
        rhos[indmid] =(dd - q12*log(cosh(q2*(cc-abs(xx[indmid])))))
        
        indbig = which(abs(xx) >= cc)
        rhos[indbig] = dd
      }
    }
    
    return(rhos)
  }
  get_tuning_const_tanh <- function(dime, b_1 = 1.5, b_2 = 1){
    # Function that calculates the tuning constants under tanh rho
    
    D <- array(rnorm(prod(dime), mean = 0, sd = 1), dime)
    
    I <- dim(D)
    num_modes <- length(I)
    N <- (num_modes - 1)
    
    scale.cell <- apply(D, 1:N, scale_tanh)
    scale.cell <- array(rep(scale.cell, times = I[num_modes]), I)
    
    rho1 <- rho_tanh(D/scale.cell, dime = I, b = b_1)
    rho1_scaled <- scale.cell^2 * rho1
    rho1 <- sapply(1:tail(dim(D), 1), function(i) {
      sqrt(sum(tens_s(rho1_scaled, i))/prod(I[1:N]))
    })
    
    scale.row <- scale_tanh(rho1)
    
    rowres <- rho1/scale.row
    bb <- max(b_2 * quantile(rowres, 0.7), 0)
    cc <- max(b_2 * quantile(rowres, 0.99), 0.3)
    
    if(bb<100){
      params <- calculateq1q2(bb, cc)
      q1 <- params$q1 
      q2 <- params$q2
    }
    else{
      q1 <- q2 <- NA
    }
    par <- c(bb, cc, q1, q2)
    return(par)
  }
  get_c_scaletanh <- function(delta = 1.8811){
    set.seed(123)
    x<-rnorm(5000)
    c_vec<-seq(0.1, 10, 0.0001)
    m_vec<-numeric()
    for (ii in 1:length(c_vec)){
      
      m_vec[ii]<-mean(rho_tanh(x/c_vec[ii]))
      
    }
    dist<-abs(m_vec-delta)
    
    c<-c_vec[which.min(dist)]
    return(c)
  }
  scale_tanh <- function (u, delta = 1.8811, max.it = 100, tol = 1e-06, tolerancezero = .Machine$double.eps){
    # get scale using tanh rho
    rho_tanh_vec <- function(x, b = 1.5, bb = NULL, cc = NULL, q1 = NULL, q2 = NULL) { 
      # The rho function of wrapping.
      if(is.null(bb) | is.null(cc)){
        xx <- 1.5 * x / b
        bb <- 1.5
        cc <- 4
        q1 <- 1.540793
        q2 <- 0.8622731
        q12 <- q1 / q2
        dd <- 3.7622126668
        rhos <- rep(NA, length(xx))
        indsmall <- which(abs(xx) <= bb)
        rhos[indsmall] <- (xx[indsmall] ^ 2) / 2
        indmid <- which(abs(xx) > bb & abs(xx) < cc)
        rhos[indmid] <- (dd - q12 * log(cosh(q2 * (cc - abs(xx[indmid])))))
        indbig <- which(abs(xx) >= cc)
        rhos[indbig] = dd
      }
      else{
        if(bb > 100) {
          rhos <- rep(NA, length(x))
          rhos <- (x ^ 2)
        }
        else{
          xx <- x
          if (is.null(q1)) {
            params <- calculateq1q2(bb, cc)
            q1 <- params$q1
            q2 <- params$q2
          }
          
          q12 <- q1 / q2
          dd <- (bb ^ 2 / 2) + (q1 / q2) * log(cosh(q2 * (cc - bb)))
          
          rhos <- rep(NA, length(xx))
          indsmall <- which(abs(xx) <= bb)
          rhos[indsmall] <-  (xx[indsmall] ^ 2) / 2
          indmid <- which(abs(xx) > bb & abs(xx) < cc)
          rhos[indmid] <-
            (dd - q12 * log(cosh(q2 * (cc - abs(
              xx[indmid]
            )))))
          indbig <- which(abs(xx) >= cc)
          rhos[indbig] <- dd
        }
      }
      return(rhos)
    }
    
    #### main ####
    if(delta == 1.8811){
      c<-0.34308##
    }
    else{
      c <- get_c_scaletanh(delta)
    }
    # s0 <- median(abs(u))/0.6745
    s0 <- median(abs(u), na.rm = T)/0.6745
    if (s0 < tolerancezero) 
      return(0)
    err <- tol + 1
    it <- 0
    while ((err > tol) && (it < max.it)) {
      it <- it + 1
      s1 <- sqrt(s0^2 * mean(rho_tanh_vec(u/(c*s0)), na.rm = T)/delta)
      err <- abs(s1 - s0)/s0
      s0 <- s1
    }
    return(s0)
  }
  psiWrap <- function(x, b, c, A, B, k) {
    # Wrapping psi function
    indmid <- which(abs(x) >= b & abs(x) <= c)
    indup  <- which(abs(x) >= c)
    x[indmid] <- (A * (k - 1)) ^ (0.5) *
      tanh(0.5 * ((k - 1) * B ^ 2 / A) ^ 0.5 *
             (c - abs(x[indmid]))) * sign(x[indmid])
    x[indup] <- 0
    return(x)
  }
  
  get_scale_tanh <- function(Xt, Xhat, b_1 = 1.5){
    res <- list()
    
    P <- dim(Xt)
    num_modes <- length(P)
    L <- (num_modes - 1)
    D <- (Xt - Xhat)
    
    # Cellwise scale
    scale.cell <- apply(D, 1:L, scale_tanh) # new scale using tanh
    scale.cell <- array(rep(scale.cell, times = P[num_modes]), P)
    res$scale.cell <- scale.cell
    rho1 <- rho_tanh(D/scale.cell, dime = P, b = b_1)
    rho1 <- rho1 * scale.cell^2
    
    # Rowwise scale
    if(any(is.na(Xt))){
      res_N <- sapply(1:tail(dim(Xt), 1), function(i) {
        numNA <- length(which(!is.na(n_unfold(rho1, num_modes)[i,])))
        sqrt(sum(tens_s(rho1, i), na.rm = T)/numNA)
      })
    }else{
      res_N <- sapply(1:tail(dim(Xt), 1), function(i) {
        sqrt(sum(tens_s(rho1, i))/prod(P[1:L]))
      }) 
    }
    
    res$scale.case <- scale_tanh(res_N) # new scale using tanh
    
    return(res)
  }
  weight_tanh <- function(x, dime, b = 1.5, bb = NULL, cc = NULL, q1 = NULL, q2 = NULL){
    # The weight function of wrapping.
    psitanh <- function(xx, bb, cc, q1, q2){
      abs_xx <- abs(xx)
      psi <- xx
      
      # boolean indexing instead of which
      indb <- abs_xx <= bb
      indc <- abs_xx > bb & abs_xx <= cc
      indbig <- abs_xx > cc
      
      if(any(is.na(indc))){
        indc[is.na(indc)] <- FALSE
      }
      
      if(any(is.na(indbig))){
        indbig[is.na(indbig)] <- FALSE 
      }
      
      psi[indc] <- q1 * tanh(q2 * (cc - abs_xx[indc])) * sign(xx[indc])
      psi[indbig] <- 0
      
      psi
    }
    
    if(is.null(bb) | is.null(cc)){
      xx <- 1.5 * x / b
      bb <- 1.5
      cc <- 4
      q1 <- 1.540793
      q2 <- 0.8622731
      q12 <- q1 / q2
      dd <- 3.7622126668
      
      tanh_w <- ifelse(is.na(xx), NA, ifelse(xx == 0, 1, psitanh(xx, bb, cc, q1, q2) / xx))
      tanh_w <- array(tanh_w, dime)
      
    }else{
      if(bb > 100){
        xx <- x
        tanh_w <- array(sapply(xx, function(t){ ifelse(is.na(t), NA,  1 )}), dime)
      }else{
        xx <- x
        if(is.null(q1)){
          params <- calculateq1q2(bb, cc)
          q1 <- params$q1
          q2 <- params$q2
        }
        q12 <- q1 / q2
        dd <- (bb ^ 2 / 2) + (q1 / q2) * log(cosh(q2 * (cc - bb)))
        
        tanh_w <- ifelse(is.na(xx), NA, ifelse(xx == 0, 1, psitanh(xx, bb, cc, q1, q2) / xx))
        tanh_w <- array(tanh_w, dime)
      }
    }
    
    return(tanh_w)
  }
  weight_tanh_tanh <- function(Xt, Xhat, scale.cell, scale.case, b_1 = 1.5, bb, cc, q1, q2){
    # The weight function of wrapping 
    # combined for both casewise and cellwise.
    P <- dim(Xt)
    num_modes <- length(P)
    L <- (num_modes - 1)
    D <- (Xt - Xhat)
    
    w1 <- weight_tanh(D/scale.cell, dime = P, b = b_1)
    
    rho1 <- rho_tanh(D/scale.cell, dime = P, b = b_1)
    rho1_scaled <- scale.cell^2 * rho1
    
    if(any(is.na(Xt))) {
      rho1 <- sapply(1:tail(dim(Xt), 1), function(i) {
        numNA <- length(which(!is.na(n_unfold(
          rho1_scaled, num_modes
        )[i, ])))
        sqrt(sum(tens_s(rho1_scaled, i), na.rm = T) / numNA)
      })
    } else{
      rho1 <- sapply(1:tail(dim(Xt), 1), function(i) {
        sqrt(sum(tens_s(rho1_scaled, i)) / prod(P[1:L]))
      })
    }
    
    w2_vec <- weight_tanh(rho1/scale.case, length(rho1), bb = bb, cc = cc, q1 = q1, q2 = q2)
    w2 <- array(rep(w2_vec, each = prod(P[-num_modes])), dim = P)
    W <- w1 * w2
    
    res <- list(w1 = w1, w2 = w2, w2_vec = w2_vec, W = W)
    return(res)
  }
  get_loss_tanh <- function(Xt, Xhat, scale.cell, scale.case, b_1 = 1.5, bb, cc, q1, q2){
    # Loss function using tanh rhos
    P <- dim(Xt)
    num_modes <- length(P)
    L <- (num_modes - 1)
    D <- (Xt - Xhat)
    
    rho1 <- rho_tanh(D/scale.cell, dime = P, b = b_1)
    rho1_scaled <- scale.cell^2 * rho1
    
    if(any(is.na(Xt))){
      rho1 <- sapply(1:tail(dim(Xt), 1), function(i) {
        numNA <- length(which(!is.na(n_unfold(rho1_scaled, num_modes)[i,])))
        sqrt(sum(tens_s(rho1_scaled, i), na.rm = T)/numNA)
      })
      
      numNA <- sapply(1:tail(dim(Xt), 1), function(i) length(which(!is.na(n_unfold(rho1_scaled, num_modes)[i,]))))
      rho2 <- rho_tanh(rho1/scale.case, dime = length(rho1), bb = bb, cc = cc, q1 = q1, q2 = q2)*numNA
      
    }else{
      rho1 <- sapply(1:tail(dim(Xt), 1), function(i) {
        sqrt(sum(tens_s(rho1_scaled, i))/prod(P[1:L]))
      })
      
      rho2 <- rho_tanh(rho1/scale.case, dime = length(rho1), bb = bb, cc = cc, q1 = q1, q2 = q2)
    }
    
    return(sum(rho2))
  }
  
  #### Get tensor and dimensions ####
  tnsr <- as.tensor(X)
  num_modes <- tnsr@num_modes
  L <- (num_modes - 1)
  modes <- tnsr@modes
  X <- tnsr@data
  P <- dim(X)
  
  #### Extract initial estimates ####
  Cent <- init$Center
  Xt <- tnsr_cent(as.tensor(X), mean_tens = (Cent))@data
  V_list <- init$V
  
  U.list <- lapply(1:P[num_modes], function(i)
    U_samp(
      tens_s(as.tensor(Xt), i)@data,
      V_list,
      tens_s(as.tensor(w.init), i)@data,
      ranks
    ))
  U <- abind::abind(U.list, along = num_modes)
  Xhat <- ttl(as.tensor(U), V_list, ms = 1:L)
  
  # Scale from initialization
  scale.case <- scale.init$scale.case
  scale.cell <- scale.init$scale.cell
  
  # Get tuning constants
  if(is.null(tpar)){
    dime <- c(P[-num_modes], 10000)
    par <- get_tuning_const_tanh(dime, b_1 = b, b_2 = 100000)
  }else{
    par <- tpar
  }
  
  #### Initialize weights and loss ####
  Weight.est <- weight_tanh_tanh(Xt, Xhat@data, b_1 = b,
                                 scale.cell = scale.cell, 
                                 scale.case = scale.case, 
                                 bb = par[1], cc = par[2], 
                                 q1 = par[3], q2 = par[4])
  W <- Weight.est$W
  Wc <- Weight.est$w1
  
  if(any(is.na(X))) {
    miss.idx <- which(is.na(X))
    W[miss.idx] <- 0
    Wc[miss.idx] <- 0
  }
  
  E <- get_loss_tanh(Xt, Xhat@data, b_1 = b,
                     scale.cell = scale.cell, 
                     scale.case = scale.case,
                     bb = par[1], cc = par[2], 
                     q1 = par[3], q2 = par[4])
  EE <- matrix(c(0, E), nrow = 1)
  
  #### Main part ####
  converged <- FALSE
  itr <- 0
  if(silent == FALSE) {
    # cat("\n===============================================\n")
    # cat("            Out Of Sample prediction             \n")
    # cat("===============================================\n\n")
    cat("\nOut Of Sample:\n\n")
    
    pb <- txtProgressBar(min = 0, max = max_itr, style = 3)
  }
  
  while((itr < max_itr)){
    
    if(silent == FALSE) {
      setTxtProgressBar(pb, itr)
    }
    itr <- itr + 1
    
    ## Core tensor update
    if(any(is.na(X))) {
      U.list <- lapply(1:P[num_modes], function(i)
        U_samp_NA(
          tens_s(as.tensor(Xt), i)@data,
          V_list,
          tens_s(as.tensor(Wc), i)@data,
          ranks
        ))
    } else{
      U.list <- lapply(1:P[num_modes], function(i)
        U_samp(
          tens_s(as.tensor(Xt), i)@data,
          V_list,
          tens_s(as.tensor(Wc), i)@data,
          ranks
        ))
    }
    
    U <- abind::abind(U.list, along = num_modes)
    Xhat <- ttl(as.tensor(U), V_list, ms = 1:L)
    
    ## Weight update
    Weight.est <- weight_tanh_tanh(Xt, Xhat@data, b_1 = b,
                                   scale.cell = scale.cell, 
                                   scale.case = scale.case,
                                   bb = par[1], cc = par[2], 
                                   q1 = par[3], q2 = par[4])
    W <- Weight.est$W
    Wc <- Weight.est$w1
    Wr <- Weight.est$w2
    
    if(any(is.na(X))) {
      W[miss.idx] <- 0
      Wc[miss.idx] <- 0
    }
    
    ## Convergence
    ssDe <- get_loss_tanh(Xt, Xhat@data, b_1 = b,
                          scale.cell = scale.cell, 
                          scale.case = scale.case,
                          bb = par[1], cc = par[2], 
                          q1 = par[3], q2 = par[4])
    
    EE <- rbind(EE, c(itr, ssDe))
    if(abs(ssDe - E)/E < tol){
      converged <- TRUE
      if(silent == FALSE) {
        setTxtProgressBar(pb, max_itr)
      }
      break
    }
    
    if(itr == max_itr && silent == FALSE){
      setTxtProgressBar(pb, max_itr)
    }
    
    E <- ssDe
  }
  
  if(silent == FALSE) {
    close(pb)
  }
  
  #### Get imputation ####
  Xhat.decenter <- tnsr_cent(Xhat, mean_tens = (-Cent))@data
  Ximp <- aperm((Xhat.decenter + Wc*(X - Xhat.decenter)), c(3, 1, 2))
  
  #### Result ####
  res <- list()
  res$X <- X
  res$X.tilde <- Xt
  res$U.tilde <- U
  res$V <- V_list
  res$Xhat.decenter <- tnsr_cent(Xhat, mean_tens = (-Cent))
  res$Xhat <- Xhat@data
  res$Ximp <- Ximp
  res$Center <- Cent
  res$W <- W
  res$W.cell <- Wc
  res$W.case <- Wr
  res$loss <- EE
  res$itr <- itr
  res$converged <- converged
  res$scale.cell <- scale.cell
  res$scale.row <- scale.case
  
  return(res)
}

# Diagnostic tools --------------------------------------------------------
ResidualMap <- function(R, indcells = NULL, indrows = NULL, 
                        outrows = NULL, showcellvalues = NULL,
                        D = NULL, rowlabels = NULL, columnlabels = NULL, 
                        mTitle = "cell map", rowtitle = "cases", 
                        columntitle = "variables", 
                        showrows = NULL, showcolumns = NULL, 
                        nrowsinblock = NULL, 
                        ncolumnsinblock = NULL, 
                        manualrowblocksizes = NULL,
                        manualcolumnblocksizes = NULL,
                        rowblocklabels = NULL,
                        columnblocklabels = NULL,
                        sizemain = 1.5, sizetitles = 1.2, sizerowlabels = 1,
                        sizecolumnlabels = 1, sizecellvalues = 1, 
                        adjustrowlabels = 1, adjustcolumnlabels = 1,
                        columnangle = 90, 
                        colContrast = 1, outlyingGrad = TRUE, 
                        darkestColor = sqrt(qchisq(0.999, 1)), 
                        drawCircles = FALSE,
                        showVals = NULL, # only for backward compatibility
                        autolabel = TRUE # but will be ignored
) {
  
  colorBlocks <- function(Xin, rowblocksizes, columnblocksizes, 
                          colContrast) {
    # Auxiliary function, which mixes the colors of the cells
    # in each block.
    n <- length(rowblocksizes)
    d <- length(columnblocksizes)
    Xblock <- matrix(0, nrow = n, ncol = d)
    Xblockgrad <- matrix(0, nrow = n, ncol = d)
    rind <- cumsum(c(0,rowblocksizes))
    cind <- cumsum(c(0,columnblocksizes))
    for (i in seq_len(n)) {
      for (j in seq_len(d)) {
        # select the cells of Xin in the block (i,j):
        Xsel <- Xin[(rind[i]+1):rind[i+1],
                    (cind[j]+1):cind[j+1]]
        seltable <- tabulate(Xsel, nbins = 4)
        if (sum(seltable) > 0) {
          indmax <- which(seltable == max(seltable))[1]
          cntmax <- seltable[indmax]
          ncells <- rowblocksizes[i] * columnblocksizes[j] 
          gradmax <- (cntmax/ncells)^(1/colContrast)
        }
        else {
          indmax <- 0
          gradmax <- 1
        }
        Xblock[i, j] <- indmax
        Xblockgrad[i, j] <- gradmax
      }
    }
    return(list(X = Xblock, Xgrad = Xblockgrad))
  }
  
  isVectorInteger <- function(x, tol = .Machine$double.eps^0.5){
    y <- abs(x - round(x)) < tol 
    sum(1-y) == 0
  }
  
  # Here the main function starts
  variable <- rownr <- rescaleoffset <- x <- y <- NULL
  n <- nrow(R)
  d <- ncol(R)
  if (is.null(showcellvalues)) { showcellvalues <- showVals}
  if (!is.null(showcellvalues)) {
    if (!showcellvalues %in% c("D", "R")) {
      stop(paste("Invalid \"showcellvalues\" argument. Should be one of: NULL, \"D\", \"R\""))
    }
  }
  if (is.null(showcellvalues)) {
    D <- R
  } else if (showcellvalues == "D" & is.null(D)) {
    stop("When showcellvalues=\"D\" you must input the argument D")
  }
  if (is.null(D)) {
    D <- R
  } else { # D exists
    if (!all(dim(D) == dim(R))) 
      stop("The dimensions of D and R must match")
  }
  if (is.null(indcells)) {
    indcells <- which(abs(R) > sqrt(qchisq(0.998, 1)))
  }
  if(is.null(indrows) & is.null(outrows)){ drawCircles <- FALSE }
  
  if(!is.null(rowlabels)){ # rowlabels are given
    if (length(rowlabels) != n) {
      stop(paste0("Number of rowlabels does not match n = ",n))
    }
  } else { # no rowlabels are given
    if (is.null(rownames(R))) {
      rowlabels <- seq_len(n)
    } else { rowlabels <- rownames(R) }  
  } 
  if(!is.null(columnlabels)){ # columnlabels are given
    if (length(columnlabels) != d) {
      stop(paste0("Number of columnlabels does not match d = ",d))
    }
  } else { # no columnlabels are given
    if (is.null(colnames(R))) {
      columnlabels <- seq_len(d)
    } else { columnlabels <- colnames(R) }
  }
  # From here on we have n rowlabels and d columnnames. 
  # They are actually case names and variable names.
  
  
  if (!is.null(showcolumns) | !is.null(showrows)) {
    if (is.null(showrows)) {
      showrows <- seq_len(n)
    }
    else {
      if (!(all(showrows %in% seq_len(n))))
        stop(" showrows goes out of bounds")
    }
    if (is.null(showcolumns)) {
      showcolumns <- seq_len(d)
    }
    else {
      if (!(all(showcolumns %in% seq_len(d))))
        stop(" showcolumns goes out of bounds")
    }
    tempMat <- matrix(0, n, d)
    tempMat[indcells] <- 1
    tempMat <- tempMat[showrows, showcolumns]
    indcells <- which(tempMat == 1)
    tempVec <- rep(0, n)
    tempVec[indrows] <- 1
    tempVec <- tempVec[showrows]
    indrows <- which(tempVec == 1)
    rm(tempMat, tempVec)
    R <- R[showrows, showcolumns]
    D <- D[showrows, showcolumns]
    rowlabels <- rowlabels[showrows]
    columnlabels <- columnlabels[showcolumns]
    n <- nrow(R)
    d <- ncol(R)
    if (!is.null(outrows)) 
      outrows <- outrows[showrows]
  }
  
  blockRows <- blockColumns <- FALSE
  if(!is.null(manualrowblocksizes)) {
    if(!is.null(nrowsinblock)){
      cat(paste0("Input argument manualrowblocksizes ",
                 "has overruled argument nrowsinblock.\n"))
      blockRows <- TRUE # the rows will be blocked
    }
    msg <- paste0(
      "manualrowblocksizes should be a vector with strictly \n",
      "  positive integers, adding up to at most n = ",n)
    if(!is.vector(manualrowblocksizes)) stop(msg)
    if(!is.numeric(manualrowblocksizes)) stop(msg)
    if(!isVectorInteger(manualrowblocksizes)) stop(msg)
    if(sum(manualrowblocksizes < 1) > 0) stop(msg)
    if(sum(manualrowblocksizes) > n) stop(msg)
    if(sum(manualrowblocksizes != 1) == 0 ) {
      stop("All manualrowblocksizes are 1") }
    blockRows <- TRUE # the rows will be blocked
  } else { # manualrowblocksizes was not specified
    if(!is.null(nrowsinblock)){
      if(nrowsinblock > 1){
        if (nrowsinblock > n) stop(paste0(
          "Input argument nrowsinblock cannot be ",
          "more than n = ",n))
        blockRows <- TRUE # the rows will be blocked
      }
    }
  }
  
  if(!is.null(manualcolumnblocksizes)) {
    if(!is.null(ncolumnsinblock)){
      cat(paste0("Input argument manualcolumnblocksizes ",
                 "has overruled argument ncolumnsinblock.\n"))
    }
    msg <- paste0(
      "manualcolumnblocksizes should be a vector with strictly \n",
      "  positive integers, adding up to at most d = ",d)
    if(!is.vector(manualcolumnblocksizes)) stop(msg)
    if(!is.numeric(manualcolumnblocksizes)) stop(msg)
    if(!isVectorInteger(manualcolumnblocksizes)) stop(msg)
    if(sum(manualcolumnblocksizes < 1) > 0) stop(msg)
    if(sum(manualcolumnblocksizes) > d) stop(msg)
    if(sum(manualcolumnblocksizes != 1) == 0 ) {
      stop("All manualcolumnblocksizes are 1") }
    blockColumns <- TRUE # the columns will be blocked
  } else {
    if (!is.null(ncolumnsinblock)){
      if(ncolumnsinblock > 1){
        if(ncolumnsinblock > d) stop(paste0(
          "Input argument ncolumnsinblock cannot be ",
          "more than d = ",d)) 
        blockColumns <- TRUE # the columns will be blocked
      }
    } 
  }
  
  if((blockRows | blockColumns) & !is.null(showcellvalues)) {
    warning(paste0(
      "The option showcellvalues=\"D\" or showcellvalues=\"R\" cannot be\n", 
      "combined with blocking rows and/or columns,\n", 
      "so showcellvalues is set to NULL here."))
    showcellvalues <- NULL
  }
  
  X <- matrix(0, n, d)
  Xrow <- matrix(0, n, 1) # one entry per row, for circles
  Xrow[indrows, 1] <- 3   # on the right hand side
  if (blockRows | blockColumns) { 
    pcells <- indcells[indcells %in% which(R >= 0)]
    ncells <- indcells[indcells %in% which(R < 0)]
  } else {
    pcells <- which(R >= 0)
    ncells <- which(R < 0)
  }
  X[ncells] <- 1
  X[pcells] <- 2
  X[is.na(R)] <- 4
  
  if (blockRows | blockColumns) { # starts blocked situation
    rowblocksizes <- rep(1,n)
    if(blockRows){
      if(!is.null(manualrowblocksizes)){
        rowblocksizes <- manualrowblocksizes
        n <- length(rowblocksizes)
      } else {
        if(!is.null(nrowsinblock)){
          if(nrowsinblock > 1){
            n <- floor(n/nrowsinblock)
            rowblocksizes <- rep(nrowsinblock,n)
          }  
        }
      }
    }
    columnblocksizes <- rep(1,d)
    if (blockColumns) {
      if(!is.null(manualcolumnblocksizes)){
        columnblocksizes <- manualcolumnblocksizes
        d <- length(columnblocksizes)
      } else {
        if(!is.null(ncolumnsinblock)){
          if(ncolumnsinblock > 1){
            d <- floor(d/ncolumnsinblock)
            columnblocksizes <- rep(ncolumnsinblock,d)
          }
        }
      }
    }
    
    # For coloring the blocks inside the matrix:
    result <- colorBlocks(X, rowblocksizes, columnblocksizes,
                          colContrast)
    X <- result$X
    Xgrad <- result$Xgrad
    if(drawCircles){
      # For coloring (in grey) the circles on the right:
      result <- colorBlocks(Xrow, rowblocksizes, c(1), colContrast)
      Xrowgrad <- result$Xgrad
      Xrowgrad[result$X == 0] <- 0
    }
    
    # Now label the blocks as if they were cells:
    if (blockRows){
      if(is.null(rowblocklabels)){
        cat(paste0("No rowblocklabels were given, so they ", 
                   "are constructed automatically.\n"))
        laby <- rowlabels
        rowlabels <- rep(0, n) # this is the new (smaller) n
        rind <- cumsum(c(0,rowblocksizes))
        for (i in seq_len(n)) {
          if(rowblocksizes[i] == 1){
            rowlabels[i] <- laby[rind[i]+1]
          } else {
            rowlabels[i] <- paste0(
              laby[rind[i]+1],"-",laby[rind[i+1]])
          }
        }
      } else { # the user has given rowblocklabels
        if (length(rowblocklabels) != n) {
          stop(paste0("The number of rowblocklabels is ", 
                      length(rowblocklabels), 
                      " but there are ",n," row blocks."))
        }        
        rowlabels <- rowblocklabels
      }
    }
    if (blockColumns) {
      if(is.null(columnblocklabels)){
        cat(paste0("No columnblocklabels were given, so they ",
                   "are constructed automatically.\n"))
        labx <- columnlabels
        columnlabels <- rep(0, d)
        cind <- cumsum(c(0,columnblocksizes))
        for (j in seq_len(d)) {
          if(columnblocksizes[j] == 1){
            columnlabels[j] <- labx[cind[j]+1]
          } else {
            columnlabels[j] <- paste0(
              labx[cind[j]+1],"-",labx[cind[j+1]])
          }
        }
      } else { # the user has given columnblocklabels
        if (length(columnblocklabels) != d) {
          stop(paste0("The number of columnblocklabels is ", 
                      length(columnblocklabels), 
                      " but there are ",d," column blocks."))
        }
        columnlabels <- columnblocklabels
      }        
    } 
    # From here on the blocks are treated as cells,
    # with lower n and d, and with their own labels.
    
    Xdf <- data.frame(cbind(seq(1, n, 1), X))
    colnames(Xdf) <- c("rownr", seq(1, d, 1))
    rownames(Xdf) <- NULL
    Xdf$rownr <- with(Xdf, reorder(rownr, seq(n, 1, -1)))
    mX <- reshape2::melt(Xdf, id.var = "rownr", value.name = "CatNr")
    Xgraddf <- data.frame(cbind(seq(1, n, 1), Xgrad))
    colnames(Xgraddf) <- c("rownr", seq(1, d, 1))
    rownames(Xgraddf) <- NULL
    Xgraddf$rownr <- with(Xgraddf, reorder(rownr, seq(n, 1, -1)))
    mXgrad <- reshape2::melt(Xgraddf, id.var = "rownr", value.name = "grad")
    mX$grad <- mXgrad$grad
    mX$rescaleoffset <- mXgrad$grad + 10 * mX$CatNr
    if(drawCircles){
      mXrow <- data.frame(rownr = seq_len(n), 
                          rescaleoffset = Xrowgrad + 10 * 3)
    }
    scalerange <- c(0, 1)
    gradientends <- scalerange + rep(c(0, 10, 20, 30, 40), each = 2)
    colorends <- c("yellow", "yellow", "yellow", 
                   "blue", "yellow", "red", "white", 
                   "black", "yellow", "white")
    # ends blocked situation
  } else { # no blocking
    Ddf <- data.frame(cbind(seq(1, n, 1), D))
    colnames(Ddf) <- c("rownr", seq(1, d, 1))
    rownames(Ddf) <- NULL
    Ddf$rownr <- with(Ddf, reorder(rownr, seq(n, 1, -1)))
    mD <- reshape2::melt(Ddf, id.var = "rownr")
    Rdf <- data.frame(cbind(seq(1, n, 1), R))
    colnames(Rdf) <- c("rownr", seq(1, d, 1))
    rownames(Rdf) <- NULL
    Rdf$rownr <- with(Rdf, reorder(rownr, seq(n, 1, -1)))
    mR <- reshape2::melt(Rdf, id.var = "rownr")
    Xdf <- data.frame(cbind(seq(1, n, 1), X))
    colnames(Xdf) <- c("rownr", seq(1, d, 1))
    rownames(Xdf) <- NULL
    Xdf$rownr <- with(Xdf, reorder(rownr, seq(n, 1, -1)))
    mX <- reshape2::melt(Xdf, id.var = "rownr", value.name = "CatNr")
    if (!is.null(showcellvalues)) {
      if (showcellvalues == "D") 
        mX$data <- mD$value
      if (showcellvalues == "R") 
        mX$data <- mR$value
    }
    if (!outlyingGrad) {
      mX$rescaleoffset <- 10 * mX$CatNr
      scalerange <- c(0, 1)
      gradientends <- scalerange + rep(c(0, 10, 20, 30, 40), each = 2)
      gradientends
      colorends <- c("yellow", "yellow", "blue", 
                     "blue", "red", "red", "white", 
                     "black", "white", "white")
    } else { # if outlyingGrad
      Xgrad <- matrix(NA, n, d)
      Xgrad[indcells] <- abs(R[indcells])
      limL <- sqrt(qchisq(0.998, 1))
      limH <- darkestColor
      Xgrad[Xgrad > limH] <- limH
      Xgrad <- ((Xgrad - limL)/(limH - limL))^colContrast
      Xgrad[is.na(Xgrad)] <- 0
      Xgraddf <- data.frame(cbind(seq(1, n, 1), Xgrad))
      colnames(Xgraddf) <- c("rownr", seq(1, d, 1))
      rownames(Xgraddf) <- NULL
      Xgraddf$rownr <- with(Xgraddf, reorder(rownr, seq(n, 1, -1)))
      mXgrad <- reshape2::melt(Xgraddf, id.var = "rownr", value.name = "grad")
      mX$grad <- mXgrad$grad
      mX$rescaleoffset <- mXgrad$grad + 10 * mX$CatNr
      scalerange <- c(0, 1)
      gradientends <- scalerange + rep(c(0, 10, 20, 30, 40), each = 2)
      colorends <- c("yellow", "yellow", 
                     "yellow", "blue", "yellow", 
                     "red", "white", "black", 
                     "white", "white")
    } # ends outlyingGrad
    
    if(drawCircles){
      tempVec <- rep(0, n)
      tempVec[indrows] <- 1
      mXrow <- data.frame(rownr = seq_len(n), rescaleoffset = 40 - 
                            (10 * tempVec))
      rm(tempVec)
      if (is.null(outrows)) {
        mXrow$rescaleoffset[indrows] <- mXrow$rescaleoffset[indrows] + 1
      } else { # if there is an outrows
        limL <- 1
        limH <- 3
        outrows[outrows > limH] <- limH
        outrows <- ((outrows - limL)/(limH - limL))^colContrast
        mXrow$rescaleoffset[indrows] <- mXrow$rescaleoffset[indrows] + 
          outrows[indrows]
      } # ends outrows
    } # ends drawCircles
  } # ends unblocked situation
  
  if (drawCircles) { # Xrow is only used here
    circleFun <- function(centerx, centery, r, npoints) {
      tt <- seq(0, 2 * pi, length.out = npoints)
      xx <- centerx + r * cos(tt)
      yy <- centery + r * sin(tt)
      return(c(xx, yy))
    }
    columnlabels <- c(columnlabels, "", "") 
    # else it ends in the plot with NA NA when d+2
    # or still NA now it was changed to d+1
    centerx <- d + 1
    centery <- n:1
    radius <- 0.4
    npoints <- 100
    circlePoints <- mapply(circleFun, centerx, centery, radius, 
                           npoints)
    positions <- data.frame(rownr = rep(seq_len(n), each = npoints), 
                            x = c(circlePoints[seq_len(npoints), ]), y = c(circlePoints[(npoints + 
                                                                                           1):(2 * npoints), ]))
    datapoly <- merge(mXrow, positions, by = c("rownr"))
  } # ends if(drawCircles)
  
  rowlabels <- rev(rowlabels)
  base_size <- 10
  
  ##### Here ggplot starts
  
  ggp <- ggplot(data = mX, aes(variable, rownr)) + {
    geom_tile(aes(fill = scales::rescale(rescaleoffset, from = range(gradientends))), 
              color = "white")  } +
    { if (drawCircles){ 
      geom_polygon(data = datapoly, aes(x = x, y = y, fill = scales::rescale(rescaleoffset, from = range(gradientends)), group = rownr), colour = "black")} } + 
    scale_fill_gradientn(colours = colorends, values = scales::rescale(gradientends), 
                         rescaler = function(x, ...) x, oob = scales::squish) + coord_fixed() + theme_classic(base_size = base_size * 
                                                                                                                1) + labs(x = columntitle, y = rowtitle) + 
    { if(drawCircles){ scale_x_discrete(expand = c(0,0), limits = as.factor(seq(1, d+1 , 1)), labels = columnlabels) } else { scale_x_discrete(expand = c(0,0), limits = as.factor(seq(1, d , 1)), labels = columnlabels) } } + 
    scale_y_discrete(expand = c(0, 0), labels = rowlabels) + 
    ggtitle(mTitle) + 
    theme(legend.position = "none", axis.ticks = element_blank(), 
          plot.title = element_text(size = base_size * sizemain,
                                    hjust = 0.5, vjust = 1, face = "bold"),
          axis.text.x = element_text(size = base_size * sizecolumnlabels, 
                                     angle = columnangle, hjust = adjustcolumnlabels, 
                                     vjust = 0.5, colour = "black"), axis.text.y = element_text(size = base_size * sizerowlabels, angle = 0, hjust = adjustrowlabels, colour = "black"), 
          axis.title.x = element_text(colour = "black", 
                                      size = base_size * sizetitles, vjust = 1), axis.title.y = element_text(colour = "black",                                                                                                              size = base_size * sizetitles, vjust = 0), axis.line.x = element_blank(), 
          panel.border = element_blank()) + annotate(geom = "segment", 
                                                     x = 0.5, xend = d + 0.5, y = 0.5, yend = 0.5) + annotate(geom = "segment", 
                                                                                                              x = 0.5, xend = d + 0.5, y = n + 0.5, yend = n + 0.5) + 
    annotate(geom = "segment", x = d + 0.5, xend = d + 
               0.5, y = 0.5, yend = n + 0.5) 
  if (!is.null(showcellvalues)) {
    txtcol <- mX$CatNr
    txtcol[txtcol == 0] <- "black"
    txtcol[txtcol == 1] <- "white"
    txtcol[txtcol == 2] <- "white"
    txtcol[txtcol == 4] <- "black"
    ggp = ggp + geom_text(aes(label = ifelse(is.na(data), sprintf("%1.0f", data), round(data, 1))), 
                          size = base_size * sizecellvalues * 0.5, colour = txtcol, na.rm = TRUE)
  }
  return(ggp)
}

OutlierMap_TR <- function(tens.obj, X.model, 
                          ranks.mp, 
                          par.mpca, 
                          score_distance, 
                          n_clean = NULL, 
                          crit = 0.99, 
                          seed = 0, 
                          idx_to_label = NULL){
  #### function ####
  get_scale_tanh_NA <- function(At, Ahat, b_1 = 1.5){
    res <- list()
    
    I <- dim(At)
    num_modes <- length(I)
    N <- (num_modes - 1)
    D <- (At - Ahat)
    
    # Cellwise scale
    scale.cell <- apply(D, 1:N, scale_tanh)
    scale.cell <- array(rep(scale.cell, times = I[num_modes]), I)
    res$scale.cell <- scale.cell
    rho1 <- rho_tanh(D/scale.cell, dime = I, b = b_1)
    rho1 <- rho1 * scale.cell^2
    
    # Rowwise scale
    res_M <- sapply(1:tail(dim(At), 1), function(i) {
      numNA <- length(which(!is.na(n_unfold(rho1, num_modes)[i,])))
      sqrt(sum(tens_s(rho1, i), na.rm = T)/numNA)
    })
    res$scale.row <- scale_tanh(res_M)
    
    return(res)
  }
  
  #### Parameters ####
  Y <- tens.obj$Y
  Y.pred <- tens.obj$Y.pred
  X.cont <- tens.obj$X.cont
  dimX <- dim(X.cont)
  dimY <- dim(Y)
  N <- dimY[1] 
  Q <- dimY[-1]
  num_modes <- length(dimX)
  
  Y.reshape <- t(Y)
  Ypred.reshape <- t(Y.pred)
  
  if(is.null(n_clean)) n_clean <- min(N, 500)
  
  #### Compute t_y ####
  Y.reshape <- t(Y)
  Ypred.reshape <- t(Y.pred)
  scale.re <- get_scale_tanh_NA(Y.reshape, Ypred.reshape, 1.5)
  
  Res.rotot <- Y - Y.pred
  Res.std <- Res.rotot/t(scale.re$scale.cell)
  
  Res.rotot.reshape <- Y.reshape - Ypred.reshape
  ty_val <- rho_tanh(Res.rotot.reshape/scale.re$scale.cell, dime = dim(Res.rotot.reshape), b = 1.5)
  ty_val_scaled <- scale.re$scale.cell^2 * ty_val
  ty_val <- sapply(1:tail(dim(Res.rotot.reshape), 1), function(i) {
    sqrt(sum(tens_s(ty_val_scaled, i), na.rm = T)/prod(Q))
  })
  
  ty_val <- ty_val/scale.re$scale.row
  
  #### Get cutoffs for t_y ####
  set.seed(1998)
  Y_clean <- array(rnorm(prod(dim(Y))), dim(Y))
  # Y_clean <- Y_clean * scale.cell.re
  Y_clean <- Y_clean * t(scale.re$scale.cell)
  
  Ri <- Y_clean
  scale_1 <- apply(Ri, 2, scale_tanh)
  Ri2 <- Ri/matrix(scale_1, n_clean, Q, byrow = T)
  Ri2 <- rho_tanh(Ri2, dime = dim(Y_clean), b = 1.5)
  Ri3 <- matrix(Ri2, n_clean, Q)*matrix(scale_1^2, n_clean, Q, byrow = T)
  rowti <- sqrt(apply(Ri3, 1, sum)/Q)
  scale_2 <- scale_tanh(rowti) # is a single number
  rowres_std2 <- rowti/scale_2
  Ri_std <- Ri/matrix(scale_1, n_clean, Q, byrow = T)
  
  RD_clean <- apply(Ri_std, 1, function(x) sqrt(sum(x ^ 2, na.rm = T)))
  cutoff_rd <- quantile(RD_clean, crit)
  cutoffOD.Y <- quantile(rowres_std2, 0.99)
  cutoffOD.Y.low <- cutoffOD.Y
  cutoffOD.Y.high <- quantile(rowres_std2, 0.999)
  
  #### OutlierMap ####
  colContrast <- 1
  indrows <- which(ty_val >= cutoffOD.Y.low)
  limL <- cutoffOD.Y.low
  limH <- cutoffOD.Y.high
  
  grad <- ((pmin(pmax(ty_val, limL), limH) - limL) / (limH - limL))^colContrast #for Y
  CatNr <- rep(0, N)
  CatNr[indrows] <- 1
  rescaleoffset <- grad + 10 * CatNr
  gradientends <- c(0, 1, 10, 11)
  colorends <- c("white", "white", "gray", "black")
  
  cut.cell <- sqrt(qchisq(0.998, df = 1))
  R.std.unf <- Res.std
  R.std.ind <- abs(R.std.unf) > cut.cell
  
  R.std.ind.ave <- rowMeans(R.std.ind, na.rm = T)
  point.sizes <- scales::rescale(R.std.ind.ave, to = c(1, 3)) #change the point size
  
  # Compute vertical cutoff
  cutoff_sd <- sqrt(qchisq(0.99, prod(ranks.mp)))
  frob.rotot <- sapply(1:N, function(i) {
    sqrt(sum((Res.std[i,])^2, na.rm = T))
  })
  
  df <- data.frame(
    score_distance = sqrt(score_distance),
    frob.rotot = frob.rotot,
    ty_val = ty_val,
    point.size = point.sizes,
    color.value = rescaleoffset
  )

  df$label <- ifelse(seq_len(N) %in% idx_to_label,
                     paste0(seq_len(N)),
                     NA)
  
  # this is to manually adjust the label
  df_lab <- df[idx_to_label, ]
  df_lab$y_lab <- df_lab$frob.rotot + c(1,1,1)
  df_lab$x_lab <- df_lab$score_distance + c(1.5,1.5,1.5)
  
  # Plot
  gpp <- ggplot(df, aes(x = score_distance, y = frob.rotot)) +
    geom_point(shape = 21, color = "black", stroke = 0.4) +
    geom_point(aes(size = point.size, fill = color.value),
               shape = 21, color = "black", stroke = 0.4) +
    scale_fill_gradientn(
      colors = colorends,
      values = rescale(gradientends)
    ) +
    # scale_size_continuous() +
    geom_vline(xintercept = cutoff_sd, linetype = "dashed", color = "red", linewidth = 1.2) +
    geom_hline(yintercept = cutoff_rd, linetype = "dashed", color = "red", linewidth = 1.2) +
    ggtitle("ROTOT outlier map") +
    labs(
      x = bquote(paste( SD[n])),
      y = bquote(paste("||", tilde(R)[n], "||"))
    ) +
    guides(
      fill = "none",
      size = "none"
    ) +
    theme(plot.title = element_text(hjust = 0.5, size = 18, face = "bold"),
          panel.border = element_rect(color = "black",
                                      fill = NA,
                                      linewidth = 1),
          legend.title = element_blank(), 
          axis.title.y = element_text(size = 18),
          axis.title.x = element_text(size = 18),
          axis.text.x =  element_text(size = 13),
          axis.text.y =  element_text(size = 13),
          legend.position = "none"
    )
  
  gpp <- gpp +
    geom_text(
      data = df_lab,
      aes(x = x_lab, y = y_lab, label = label),
      size = 4,
      fontface = "bold",
      inherit.aes = FALSE
    )
  
  
  #### Save Results ####
  res <- list()
  res$score_distance <- sqrt(score_distance)
  res$RD_Y <- frob.rotot
  res$ty <- ty_val
  res$cut.ty.low <- cutoffOD.Y.low
  res$cut.ty.high <- cutoffOD.Y.high
  res$cutoff_sd <- cutoff_sd
  res$cutoff_rd <- cutoff_rd
  res$outmap <- gpp
  
  return(res)
  
}


The folder contains the R and C++ files for replicating the simulation results shown in the manuscript.

The files "functions.R" and "src.cpp" contain the functions to simulate data and implement the competing methods.

The proposed AMFEWMA method is implemented in version 1.5.0 of the R package funcharts.

The file "main.R" can be used to replicate the results obtained in the Simulation Study of the manuscript by appropriately setting the simulation parameters.
By default, it estimates the average run length for all the methods evaluated in the paper, in Scenario 1, corresponding to SL=0, for one of the 50 simulation runs.

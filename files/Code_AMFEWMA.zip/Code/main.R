###########################################################################
# libraries and functions -------------------------------------------------
###########################################################################
library(funcharts)
library(fda)
library(MASS)
library(abind)
library(Matrix)
library(Rcpp)
library(Rfast)
library(RSpectra)
source("functions.R")
sourceCpp("src.cpp")


###########################################################################
# select simulation parameters --------------------------------------------
###########################################################################

SL <- 0 # Set severity level from SL=0 (in-control process), to SL=1, SL=2, ..., SL=10
OC <- "OC_E" # set OC="OC_E" (expulsion shift, Scenario 1) or OC="OC_P" (phase shift, Scenario 2)

nobs_train <- 1000 # set training sample size
nobs_tun <- 1500 # set tuning sample size
p <- 10 # set number of functional variables
seed <- 1 # set seed for reproducibility, 50 simulation runs are performed in the paper with seed in 1:50


###########################################################################
# set other simulation parameters -----------------------------------------
###########################################################################

nbasis <- 10 # number of basis functions for functional data smoothing
ARL0 <- 200 # in-control ARL

nobs_transient <- 100 # number of IC observations before steady state (n_discard in paper)
nseq_I <- 200 # number of phase I sequences (n_boot in paper)
lseq_I <- ARL0 * 10 # length of training and tuning sequences

nseq_II <- 200 # number of phase II sequences in phase I
nII <- 50 # number of phase II sequences
lseq_II <- ARL0 * 10 # length of phase II sequences

epsilon <- 0.1 # epsilon (Section 2.4) used in algorithm for optimal selection of lambda and k

# select shift magnitude and type based on OC and SL
if (OC == "OC_E") {
  M_OC_vec <- seq(0, 0.015, l = 9)
  M_OC_vec <- seq(0, 0.012, l = 11)
}
if (OC == "OC_P") {
  M_OC_vec <- seq(0, 0.2, l = 9)
  M_OC_vec <- seq(0, 0.2, l = 11)
}
M_OC <- M_OC_vec[SL + 1]

###########################################################################
# generate Phase I data ---------------------------------------------------
###########################################################################
set.seed(seed)
data_1 <-
  sim_dat(
    nobs = nobs_train,
    nbasis = nbasis,
    p = p,
    OC = "no"
  )
data_1_2 <-
  sim_dat(
    nobs = nobs_tun,
    nbasis = nbasis,
    p = p,
    OC = "no"
  )

###########################################################################
# AMFEWMA Algorithm to select lambda and k --------------------------------
###########################################################################
lambda_vec <- c(0.1, 0.2, 0.3, 0.5, 1)
cost_k_vec <- c(1, 2, 3, 4)

mod_1_AMFEWMA <- AMFEWMA_PhaseI(mfdobj = data_1,
                                mfdobj_tuning = data_1_2,
                                ARL0 = ARL0,
                                bootstrap_pars = list(
                                  n_seq = nseq_I,
                                  l_seq = lseq_I
                                ),
                                optimization_pars = list(
                                  lambda_grid = lambda_vec, 
                                  k_grid = cost_k_vec, 
                                  epsilon = epsilon, 
                                  sd_small = 0.25, 
                                  sd_big = 2
                                ),
                                discrete_grid_length = 25,
                                score_function = "huber",
                                fev = 0.9,
                                n_skip = nobs_transient)

###########################################################################
# calculate ARL with competitor methods -----------------------------------
###########################################################################

## MFEWMA for each lambda (large k=100 to have MFEWMA)
lambda_vec <- c(0.1, 0.2, 0.3, 0.5, 1)
mod_1_MFEWMA <- list()
mod_1_Fasso <- list()
mod_1_Ren <- list()
for (ii in 1:length(lambda_vec)) {
  mod_1_MFEWMA[[ii]] <- AMFEWMA_PhaseI(mfdobj = data_1,
                                       mfdobj_tuning = data_1_2,
                                       lambda = lambda_vec[ii],
                                       k = 100,
                                       ARL0 = ARL0,
                                       bootstrap_pars = list(
                                         n_seq = nseq_I,
                                         l_seq = lseq_I
                                       ),
                                       discrete_grid_length = 25,
                                       fev = 0.9,
                                       n_skip = nobs_transient)
  mod_1_Fasso[[ii]] <- Fasso_PhaseI(
    mfdobj_x = data_1,
    mfdobj_x_tun = data_1_2,
    nseq = nseq_I,
    lseq = lseq_I,
    lseq_tun = lseq_I,
    lambda = lambda_vec[ii],
    cost_k = 100,
    ARL0_pre = ARL0,
    nobs_transient = nobs_transient
  )
  mod_1_Ren[[ii]] <- Ren_PhaseI(
    mfdobj_x = data_1,
    mfdobj_x_tun = data_1_2,
    nseq = nseq_I,
    lseq = lseq_I,
    lseq_tun = lseq_I,
    lambda = lambda_vec[ii],
    cost_k = 100,
    ARL0_pre = ARL0,
    nobs_transient = nobs_transient
  )
}

###########################################################################
# generate Phase II data --------------------------------------------------
###########################################################################
Results_vec <- numeric()
Results_vec[1] <- mod_1_AMFEWMA$lambda
Results_vec[2] <- mod_1_AMFEWMA$k
RL_AMFEWMA <- numeric(nII)
RL_MFEWMA <- list(length(lambda_vec))
RL_Fasso <- list(length(lambda_vec))
RL_Ren <- list(length(lambda_vec))
for (ii in 1:length(lambda_vec)) {
  RL_MFEWMA[[ii]] <- numeric(nII)
  RL_Fasso[[ii]] <- numeric(nII)
  RL_Ren[[ii]] <- numeric(nII)
}

mod_2_AMFEWMA_mat_list <- list()

for (iii in 1:nII) {
  data_2 <- sim_dat(
    nobs = lseq_II,
    nbasis = nbasis,
    p = p,
    OC = OC,
    M_OC = M_OC,
    nIC = 0
  )
  nobs_IC <- dim(data_1_2$coefs)[2]
  idx_IC <- sample(1:nobs_IC, nobs_transient, replace = TRUE)
  mod_2_AMFEWMA <- AMFEWMA_PhaseII(
    mfdobj_2 = rbind_mfd(data_1_2[idx_IC], data_2),
    mod_1 = mod_1_AMFEWMA,
    n_seq_2 = 1,
    l_seq_2 = lseq_II)
  RL_AMFEWMA[iii] <- mod_2_AMFEWMA$RL
  
  for (ii in 1:length(lambda_vec)) {
    mod_2_MFEWMA <- AMFEWMA_PhaseII(
      mfdobj_2 = rbind_mfd(data_1_2[idx_IC], data_2),
      mod_1 = mod_1_MFEWMA[[ii]],
      n_seq_2 = 1,
      l_seq_2 = lseq_II)
    RL_MFEWMA[[ii]][iii] <- mod_2_MFEWMA$RL
    
    mod_2_Fasso <- Fasso_PhaseII(
      data2 = data_2,
      data_IC = data_1_2,
      mod_1 =  mod_1_Fasso[[ii]],
      nobs_transient = nobs_transient,
      nseq = 1,
      lseq_II = lseq_II
    )
    RL_Fasso[[ii]][iii] <- mod_2_Fasso$RL
    
    mod_2_Ren <- Ren_PhaseII(
      data2 = data_2,
      data_IC = data_1_2,
      mod_1 =  mod_1_Ren[[ii]],
      nobs_transient = nobs_transient,
      nseq = 1,
      lseq_II = lseq_II
    )
    RL_Ren[[ii]][iii] <- mod_2_Ren$RL
    
  }
}

Results_vec[3] <- mean(RL_AMFEWMA, na.rm = TRUE)
for (ii in 1:length(lambda_vec)) {
  Results_vec[ii + 3] <- mean(RL_MFEWMA[[ii]], na.rm = TRUE)
}
for (ii in 1:length(lambda_vec)) {
  Results_vec[ii + 8] <- mean(RL_Fasso[[ii]], na.rm = TRUE)
}
for (ii in 1:length(lambda_vec)) {
  Results_vec[ii + 13] <- mean(RL_Ren[[ii]], na.rm = TRUE)
}

###########################################################################
# print the results -------------------------------------------------------
###########################################################################
names(Results_vec) <- c(
  "optimal_lambda",
  "optimal_k",
  "ARL_AMFEWMA",
  "ARL_MFEWMA_lambda_0.1",
  "ARL_MFEWMA_lambda_0.2",
  "ARL_MFEWMA_lambda_0.3",
  "ARL_MFEWMA_lambda_0.5",
  "ARL_MFEWMA_lambda_1",
  "ARL_B-MEWMA_Fasso_lambda_0.1",
  "ARL_B-MEWMA_Fasso_lambda_0.2",
  "ARL_B-MEWMA_Fasso_lambda_0.3",
  "ARL_B-MEWMA_Fasso_lambda_0.5",
  "ARL_B-MEWMA_Fasso_lambda_1",
  "ARL_MCPM_Ren_lambda_0.1",
  "ARL_MCPM_Ren_lambda_0.2",
  "ARL_MCPM_Ren_lambda_0.3",
  "ARL_MCPM_Ren_lambda_0.5",
  "ARL_MCPM_Ren_lambda_1"
)

print(Results_vec)

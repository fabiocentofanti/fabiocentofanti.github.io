# Simulation --------------------------------------------------------------
sim_dat <- function(nobs = 200,
                    nbasis = 5,
                    p = 10,
                    OC = "no",
                    M_OC = 0,
                    nIC = 0,
                    P = 100,
                    lambda = NULL) {
  if (nIC > nobs)
    stop("nIC cannot be greater than nobs")
  
  data <- simulation(
    nobs = nobs,
    p = p,
    OC = OC,
    M_OC = M_OC,
    P = P
  )
  data_list <- data$X_mat_list
  
  if (nIC > 0) {
    data_IC <- simulation(
      nobs = nIC,
      p = p,
      OC = "no",
      M_OC = 0,
      P = P
    )
    data_IC_list <- data_IC$X_mat_list
    for (ii in 1:p) {
      data_list[[ii]] <- rbind(data_IC_list[[ii]], data_list[[ii]])
    }
  }
  
  names(data_list) <- names(data$X_mat_list)
  data_mfd <-
    funcharts::get_mfd_list(data_list, n_basis = nbasis, lambda = lambda)
  data_mfd$raw <- NULL
  return(data_mfd)
}

generate_cov_str <- function(p = 3, P = 100) {
  n_comp_x <- 10
  x_seq <- seq(0, 1, l = P)
  get_mat <- function(cov) {
    P <- length(cov)
    covmat <- matrix(0, nrow = P, ncol = P)
    for (ii in 1:P) {
      covmat[ii, ii:P] <- cov[1:(P - ii + 1)]
      covmat[P - ii + 1, 1:(P - ii + 1)] <- rev(cov[1:(P - ii + 1)])
    }
    covmat
  }
  eig <- covmatList <- list()
  cov1 <- besselJ(x_seq * 8 , 0)
  covmat1 <- get_mat(cov1)
  eig1 <- RSpectra::eigs_sym(covmat1, n_comp_x)
  w <- 1 / P
  eig1$vectors <- eig1$vectors / sqrt(w)
  eig1$values <- eig1$values * w
  for (ii in 1:p) {
    covmatList[[ii]] <- covmat1
    eig[[ii]] <- eig1
  }
  eigList <- eig
  eigenvalues <-
    rowMeans(sapply(1:p, function(ii)
      eig[[ii]]$values))
  corr_mat <- vector("list", p)
  for (ii in 1:p) {
    corr_mat[[ii]] <- vector("list", p)
  }
  for (ii in 1:p) {
    for (jj in ii:p) {
      if (jj == ii) {
        corr_mat[[ii]][[jj]] <- covmatList[[ii]]
      } else {
        V <- eigList[[ii]]$vectors[, 1:n_comp_x]
        lambdas <- eigenvalues[1:n_comp_x]
        sum <- V %*% (t(V) * lambdas) / (1 + abs(ii - jj))
        corr_mat[[ii]][[jj]] <- sum
        corr_mat[[jj]][[ii]] <- t(sum)
      }
    }
    corr_mat[[ii]] <- do.call("cbind", corr_mat[[ii]])
  }
  corr_mat <- do.call("rbind", corr_mat)
  e <- RSpectra::eigs_sym(corr_mat, n_comp_x * p)
  list(e = e, P = P)
}

simulation <- function(nobs = 1000,
                       p = 3,
                       sd_e = 0.005,
                       sd = 0.002,
                       T_exp = 0.6,
                       OC = "no",
                       M_OC = 0,
                       P = 100) {
  
  cov_str <- generate_cov_str(p, P)
  e <- cov_str$e
  P <- cov_str$P
  x_seq <- seq(0, 1, l = P)
  w <- 1 / P
  n_comp_x <- max(which((cumsum(e$values) / sum(e$values)) < 0.999))
  meig <- list()
  for (ii in 1:p) {
    index <- 1:P + (ii - 1) * P
    meig[[ii]] <- e$vectors[index, 1:n_comp_x] / sqrt(w)
  }
  meigenvalues <- e$values[1:n_comp_x] * w
  meigenvalues[meigenvalues < 0] <- 0
  csi_X <- rnorm(
    n = length(meigenvalues) * nobs,
    mean = 0,
    sd = sqrt(rep(meigenvalues, each = nobs))
  )
  csi_X <- matrix(csi_X, nrow = nobs)
  
  fun_phase <- function(x_ini, M_g) {
    x <- numeric(P)
    T1 = 0.05
    T2 = 0.6
    a = (T2 - M_g - T1) / (T2 - T1)
    b = T1 - a * T1
    xx = x_ini * a + b
    a = (T2 - M_g - 1) / (T2 - 1)
    b = 1 - a
    xx2 = x_ini * a + b
    x[1:(T1 * P)] = x_ini[1:(T1 * P)]
    x[((T1 * P) + 1):(T2 * P)] = xx[((T1 * P) + 1):(T2 * P)]
    x[(T2 * P + 1):(P)] = xx2[(T2 * P + 1):(P)]
    x = (x - min(x)) / (max(x) - min(x)) * (0.15 - 0.0045) + 0.0045
    return(-(M_g / 20) * x_ini + 0.2074 + 0.3117 * exp((-(371.4)) * x) +
             0.5284 * (1 - exp((-(
               -0.8217
             )) * x)) - 423.3 * (1 + tanh(-26.15 * (x - (
               -0.1715
             )))))
  }
  
  fun_m <- function(x_ini, M_g) {
    x = x_ini
    x = (x - min(x)) / (max(x) - min(x)) * (0.15 - 0.0045) + 0.0045
    return(0.2074 + 0.3117 * exp((-(371.4)) * x) + 0.5284 * (1 - exp((-(
      -0.8217
    )) * x)) - 423.3 * (1 + tanh(-26.15 * (x - (
      -0.1715
    )))))
  }
  
  if (OC == "OC_P") {
    f1_m = fun_phase
  }
  else{
    f1_m = fun_m
  }
  
  if (OC == "no") {
    out_function <- function(n_g, p_g, M_g, T_exp)
      0
  }
  else if (OC == "OC_M") {
    out_function <- function(nobs, M_g, T_exp) {
      rep(M_g, P)
    }
  }
  else if (OC == "OC_E") {
    out_function <- function(nobs, M_g, T_exp) {
      out_values <- rep(0 , P)
      grid <- 1:P
      grid_new <- (grid - min(grid)) / (max(grid) - min(grid))
      a <- -M_g / (1 - T_exp)
      y <- a * (grid_new - T_exp)
      y[y > 0] = 0
      out_values = (y)
      return(out_values)
    }
  }
  else if (OC == "OC_P") {
    out_function <- function(n_g, p_g, M_g, T_exp)
      0
  }
  
  oc_case_mat <-
    matrix(t(out_function(1, M_OC, T_exp)), nobs, P * p, byrow = TRUE)
  oc_mat <- oc_case_mat
  oc_list <- list()
  for (ii in 1:p) {
    index <- 1:P + (ii - 1) * P
    oc_list[[ii]] <- oc_mat[, index]
  }
  
  X_mat_list <- list()
  for (ii in 1:p) {
    X1_scaled <- csi_X %*% t(meig[[ii]])
    X_mat_list[[ii]] <-
      t(f1_m(x_seq, M_OC) + t(X1_scaled) * sd) + rnorm(prod(dim(X1_scaled)), sd = sd_e) +
      oc_list[[ii]]
  }
  names(X_mat_list) = paste0("X", sprintf(1:p, fmt = "%02d"))
  out <- list(X_mat_list = X_mat_list)
  return(out)
}


# B-MEWMA Fasso --------------------------------------------------------------
Fasso_PhaseI <- function(mfdobj_x,
                         mfdobj_x_tun,
                         nseq,
                         lseq = 200,
                         l_xseq = 25,
                         lseq_tun = 200,
                         lambda,
                         cost_k,
                         huber = TRUE,
                         fev = 1,
                         ARL0_pre = 20,
                         nobs_transient = 100) {
  nbasis <- dim(mfdobj_x$coefs)[1]
  nobs <- dim(mfdobj_x$coefs)[2]
  nvar <- dim(mfdobj_x$coefs)[3]
  
  mean_mfdobj_x <- fda::mean.fd(mfdobj_x)
  basis <- mfdobj_x$basis
  
  # (TRAINING)
  mfdobj_x_cen <- funcharts::scale_mfd(mfdobj_x, center = mean_mfdobj_x, scale = FALSE)
  y <- mfdobj_x_cen * lambda
  
  coefy <- y$coefs
  coefx <- mfdobj_x_cen$coefs
  
  for (ii in 2:dim(mfdobj_x$coefs)[2]) {
    coefy[, ii,] <- lambda * coefx[, ii,] + (1 - lambda) * coefy[, ii - 1,]
  }
  y$coefs <- coefy
  
  ymat <- matrix(aperm(coefy, c(2, 1, 3)), nrow = dim(y$coefs)[2])
  sigmaY <- Rfast::cova(ymat)
  
  
  eigen <- eigen(sigmaY)
  var_spiegata <- cumsum(eigen$values) / sum(eigen$values)
  n_eigenvalues <- which(var_spiegata >= fev)[1]
  A <- eigen$values[1:n_eigenvalues]
  B <- eigen$vectors[, 1:n_eigenvalues]
  inv_sigmaY_reg <- B %*% diag(1 / A) %*% t(B)
  
  # (TUNING)
  mfdobj_x_cen <- funcharts::scale_mfd(mfdobj_x_tun, center = mean_mfdobj_x, scale = FALSE)
  coefx <- mfdobj_x_cen$coefs
  Xtun <- matrix(aperm(coefx, c(2, 1, 3)), nrow = dim(coefx)[2])
  
  par_fun_tun <- function(qq) {
    idx_tun <-
      sample(1:dim(mfdobj_x_tun$coefs)[2], lseq_tun, replace = TRUE)
    Y_array_tun <- statisticY_EWMA_cpp(
      Xtun,
      lambda = lambda,
      k = rep(100, ncol(Xtun)),
      huber = huber,
      idx = idx_tun
    )
    V2 <- colSums(t(Y_array_tun %*% B) ^ 2 / A)
    return(V2)
  }
  
  V2_mat <- do.call(rbind, lapply(1:nseq, function(x) par_fun_tun(x)))
  
  ARL <- -100
  iter <- 0
  hmin <- 0
  hmax <- max(V2_mat)
  while (abs(ARL - ARL0_pre) > 1e-2 &
         (hmax - hmin) > 1e-2 & iter < 50) {
    iter <- iter + 1
    h <- (hmin + hmax) / 2
    cond <- V2_mat[, -(1:nobs_transient)] > h
    if (max(V2_mat[, -(1:nobs_transient)]) < h) {
      ARL <- Inf
      hmax <- h
    } else {
      RL <- apply(cond, 1, function(x)
        which(x)[1])
      ARL <- mean(RL, na.rm = TRUE)
      if (ARL < ARL0_pre) {
        hmin <- h
      } else {
        hmax <- h
      }
    }
  }
  ARL0 <- ARL
  
  out <- list(
    inv_sigmaY_reg = inv_sigmaY_reg,
    mean_mfdobj_x = mean_mfdobj_x,
    h = h,
    ARL0 = ARL0,
    lambda = lambda,
    k = rep(100, nbasis * nvar),
    V2_mat = V2_mat,
    nobs_transient = nobs_transient,
    huber = huber,
    vectors = B,
    values = A
  )
  return(out)
}


Fasso_PhaseII <- function(data2,
                          data_IC,
                          mod_1,
                          nobs_transient = 100,
                          nseq = 1,
                          lseq_II) {
  nobs2 <- dim(data2$coefs)[2]
  nobs_IC <- dim(data_IC$coefs)[2]
  nvar <- dim(data2$coefs)[3]
  mean_mfdobj_x <- mod_1$mean_mfdobj_x
  vectors <- mod_1$vectors
  values <- mod_1$values
  lambda <- mod_1$lambda
  k <- mod_1$k
  h <- mod_1$h
  
  RL <- numeric(nseq)
  
  data_IC_cen <- funcharts::scale_mfd(data_IC, center = mean_mfdobj_x, scale = FALSE)
  data_IC_cen_mat <- matrix(aperm(data_IC_cen$coefs, c(2, 1, 3)), nrow = dim(data_IC_cen$coefs)[2])
  
  
  data2_cen <- funcharts::scale_mfd(data2, center = mean_mfdobj_x, scale = FALSE)
  X2 <- matrix(aperm(data2_cen$coefs, c(2, 1, 3)), nrow = dim(data2_cen$coefs)[2])
  
  V2 <- list()
  
  for (jj in 1:nseq) {
    idx_IC <- sample(1:nobs_IC, nobs_transient, replace = TRUE)
    if (nseq == 1) {
      idx2 <- 1:nobs2
    } else {
      idx2 <- sample(1:nobs2, lseq_II, replace = TRUE)
    }
    output <- get_RL_cpp(
      X2 = X2,
      X_IC = data_IC_cen_mat,
      idx2 = idx2,
      idx_IC = idx_IC,
      lambda = lambda,
      k = k,
      huber = mod_1$huber,
      h = h,
      Values = values,
      Vectors = vectors
    )
    V2[[jj]] <- output$T2
    RL[jj] <- output$RL
  }
  
  ARL_2 <- mean(RL, na.rm = TRUE)
  return(list(ARL_2 = ARL_2,
              RL = RL,
              V2 = V2))
}





# MCPM Ren -----------------------------------------------------------------
Ren_PhaseI <- function(mfdobj_x,
                       mfdobj_x_tun,
                       nseq,
                       lseq = 200,
                       l_xseq = 25,
                       lseq_tun = 200,
                       lambda,
                       cost_k,
                       huber = TRUE,
                       fev = 0.90,
                       ARL0_pre = 20,
                       nobs_transient = 100) {
  nbasis <- dim(mfdobj_x$coefs)[1]
  nobs <- dim(mfdobj_x$coefs)[2]
  nvar <- dim(mfdobj_x$coefs)[3]
  
  mean_mfdobj_x <- fda::mean.fd(mfdobj_x)
  
  xseq <- seq(0, 1, l = l_xseq)
  basis <- mfdobj_x$basis
  
  # (TRAINING)
  mfdobj_x_cen <- funcharts::scale_mfd(mfdobj_x, center = mean_mfdobj_x, scale = FALSE)
  Xeval_cen <- fda::eval.fd(xseq, mfdobj_x_cen)
  
  nobs <- dim(Xeval_cen)[2]
  nvar <- dim(Xeval_cen)[3]
  n <- dim(Xeval_cen)[1]
  
  
  Xeval_cen <- aperm(Xeval_cen, c(2, 1, 3))
  mua <- apply(Xeval_cen, 2:3, mean)
  
  cov_list <- lapply(1:nvar, function(jj) cov(Xeval_cen[, , jj]))
  cova <- Reduce("+", cov_list)
  
  eio <- eigen(cova)
  eval <- eio$values
  evec <- eio$vectors
  varprop <- cumsum(eval) / sum(eval)
  d <- which(varprop >= 0.95)[1]
  evec <- evec * n ^ 0.5
  eval <- eval / n
  
  scores <- lapply(1:d, function(ll) {
    sapply(1:nvar, function(jj) Xeval_cen[, , jj] %*% evec[, ll] / (n))
  })
  scores <- do.call(cbind, scores)
  
  Y <- scores * lambda
  for (ii in 2:nrow(Y)) {
    Y[ii,] <- lambda * scores[ii,] + (1 - lambda) * Y[ii - 1,]
  }
  sigmaY_list <- lapply(1:d, function(ll) {
    idx_ll <- (ll - 1) * nvar + 1:nvar
    Rfast::cova(Y[, idx_ll])
  })
  sigmaY <- as.matrix(bdiag(sigmaY_list))
  eigen <- eigen(sigmaY)
  var_spiegata <- cumsum(eigen$values) / sum(eigen$values)
  n_eigenvalues <- which(var_spiegata >= 1)[1]
  A <- eigen$values[1:n_eigenvalues]
  B <- eigen$vectors[, 1:n_eigenvalues]
  inv_sigmaY_reg <- B %*% diag(1 / A) %*% t(B)
  
  
  # (TUNING)
  mfdobj_x_tun_cen <- funcharts::scale_mfd(mfdobj_x_tun, center = mean_mfdobj_x, scale = FALSE)
  Xeval_tun_cen <- fda::eval.fd(xseq, mfdobj_x_tun_cen)
  nobs_tun <- dim(Xeval_tun_cen)[2]
  Xeval_tun_cen <- aperm(Xeval_tun_cen, c(2, 1, 3))
  Xeval_tun_cen_mat <-
    matrix(Xeval_tun_cen, nrow = dim(Xeval_tun_cen)[1])
  
  
  scores_tun <- lapply(1:d, function(ll) {
    sapply(1:nvar, function(jj) Xeval_tun_cen[, , jj] %*% evec[, ll] / (n))
  })
  scores_tun <- do.call(cbind, scores_tun)
  
  par_fun_tun <- function(qq) {
    idx_tun <- sample(1:dim(mfdobj_x_tun$coefs)[2], lseq_tun, replace = TRUE)
    Y_array_tun <- statisticY_EWMA_cpp(
      scores_tun,
      lambda = lambda,
      k = rep(100, ncol(scores_tun)),
      huber = huber,
      idx = idx_tun
    )
    V2 <- colSums(t(Y_array_tun %*% B) ^ 2 / A)
    return(V2)
  }
  
  V2_mat <- do.call(rbind, lapply(1:nseq, function(x) par_fun_tun(x)))
  
  ARL <- -100
  iter <- 0
  hmin <- 0
  hmax <- max(V2_mat)
  while (abs(ARL - ARL0_pre) > 1e-2 &
         (hmax - hmin) > 1e-2 & iter < 50) {
    iter <- iter + 1
    h <- (hmin + hmax) / 2
    cond <- V2_mat[, -(1:nobs_transient)] > h
    if (max(V2_mat[, -(1:nobs_transient)]) < h) {
      ARL <- Inf
      hmax <- h
    } else {
      RL <- apply(cond, 1, function(x)
        which(x)[1])
      ARL <- mean(RL, na.rm = TRUE)
      if (ARL < ARL0_pre) {
        hmin <- h
      } else {
        hmax <- h
      }
    }
  }
  ARL0 <- ARL
  
  out <- list(
    inv_sigmaY_reg = inv_sigmaY_reg,
    mean_mfdobj_x = mean_mfdobj_x,
    h = h,
    ARL0 = ARL0,
    lambda = lambda,
    k = rep(100, ncol(scores_tun)),
    xseq = xseq,
    V2_mat = V2_mat,
    nobs_transient = nobs_transient,
    huber = huber,
    vectors = B,
    values = A,
    evec = evec,
    eval = eval,
    d = d
  )
  return(out)
}


Ren_PhaseII <- function(data2,
                        data_IC,
                        mod_1,
                        nobs_transient = 100,
                        nseq = 1,
                        lseq_II) {
  nobs2 <- dim(data2$coefs)[2]
  nobs_IC <- dim(data_IC$coefs)[2]
  nvar <- dim(data2$coefs)[3]
  xseq <- mod_1$xseq
  mean_mfdobj_x <- mod_1$mean_mfdobj_x
  vectors <- mod_1$vectors
  values <- mod_1$values
  lambda <- mod_1$lambda
  k <- mod_1$k
  h <- mod_1$h
  d <- mod_1$d
  
  RL <- numeric(nseq)
  
  data_IC_cen <- funcharts::scale_mfd(data_IC, center = mean_mfdobj_x, scale = FALSE)
  data_IC_cen_eval <- fda::eval.fd(xseq, data_IC_cen)
  data_IC_cen_eval <- aperm(data_IC_cen_eval, c(2, 1, 3))
  n <- dim(data_IC_cen_eval)[2]
  
  scores_IC <- lapply(1:d, function(ll) {
    sapply(1:nvar, function(jj)
      data_IC_cen_eval[, , jj] %*% mod_1$evec[, ll] / (n))
  })
  scores_IC <- do.call(cbind, scores_IC)
  
  data2_cen <- funcharts::scale_mfd(data2, center = mean_mfdobj_x, scale = FALSE)
  data2_cen_eval <- fda::eval.fd(xseq, data2_cen)
  data2_cen_eval <- aperm(data2_cen_eval, c(2, 1, 3))
  
  scores2 <- lapply(1:d, function(ll) {
    sapply(1:nvar, function(jj)
      data2_cen_eval[, , jj] %*% mod_1$evec[, ll] / (n))
  })
  scores2 <- do.call(cbind, scores2)
  
  V2 <- list()
  
  for (jj in 1:nseq) {
    idx_IC <- sample(1:nobs_IC, nobs_transient, replace = TRUE)
    if (nseq == 1) {
      idx2 <- 1:nobs2
    } else {
      idx2 <- sample(1:nobs2, lseq_II, replace = TRUE)
    }
    output <- get_RL_cpp(
      X2 = scores2,
      X_IC = scores_IC,
      idx2 = idx2,
      idx_IC = idx_IC,
      lambda = lambda,
      k = k,
      huber = mod_1$huber,
      h = h,
      Values = values,
      Vectors = vectors
    )
    V2[[jj]] <- output$T2
    RL[jj] <- output$RL
  }
  
  ARL_2 <- mean(RL, na.rm = TRUE)
  return(list(ARL_2 = ARL_2,
              RL = RL,
              V2 = V2))
}
